package com.apple.ist.caffemac.test;

import org.apache.commons.lang.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class KioskAppSmokeTests extends KioskApp {
	
	@Test(dataProvider = "loadTestData")
	public void verifySettingsInKiosk(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyPrinterButton");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			launch()
				.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				.validatePrinterButton(station, menuItemsToSelect)
				.validateSecondaryPrinterConfigWithoutPrimary()
				.validatePrimaryPrinterConfig()
				.validateSecondaryPrinterConfig()
				.validateRegisterStationInLeftPane(menuItemsToSelect)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Printer configuration. Error:" + e);			
		}
	}

	@Test(dataProvider = "loadTestData")
	public void verifyOrderByCustomizingItem(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyOrderByCustomizingItem");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			//JSONArray itemsToOrder = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			
			// 
			//String selectStationForOrder = (String)testData.get("select_station_for_order");
			//String select_item_for_customization = (String)testData.get("customize_food_item");
			//String select_item_price_for_customization = (String)testData.get("customize_food_item_price");
			//String select_item_category_for_customization = (String)testData.get("customize_food_category");
			//String select_item_to_change = (String)testData.get("customize_food_item_to_change");
			//
			String strOrderPersonName = (String)testData.get("order_person_name");
			
			launch()
				.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(station, menuItemsToSelect)
				.checkLandingPage(station, menuItemsToSelect)
				.orderGivenItems(itemsToOrder)
				//.customizeItemAndAddToOrder(selectStationForOrder, select_item_for_customization, select_item_price_for_customization, select_item_category_for_customization, select_item_to_change)
				.checkOut(strOrderPersonName, itemsToOrder)
			.quitApp();
			
			//writeDataInRunStore("KIOSK_SPECIAL_CUSTOMIZED_ORDER", testData.toJSONString());
			
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the Order By Customizing Item. Error:" + e);						
		}
		
	}

	@Test(dataProvider = "loadTestData")
	public void verifyOrderByDirect(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyOrderByDirect");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			
			
			//JSONArray itemsToOrder = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}

			String strOrderPersonName = (String)testData.get("order_person_name");
			
			launch()
				.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(station, menuItemsToSelect)
				.checkLandingPage(station, menuItemsToSelect)
				//.addItemToOrder(selectStationForOrder, select_item_to_order, select_item_price)
				.orderGivenItems(itemsToOrder)
				.checkOut(strOrderPersonName, itemsToOrder)
			.quitApp();		
			
			/*
			String id = (String)testData.get("id");
			if(StringUtils.isBlank(id)) {
				id = "NOID";
			}
			writeDataInRunStore("KIOSK_STANDARD_NONCUSTOMIZED_ORDER_" + id, testData.toJSONString());
			*/
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the Order By Direct Item. Error:" + e);									
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyPlacingStandardOrder(JSONObject testData) throws Exception {
		
		log("Test:KioskAppFunctionalTests::verifyAddtoOrderButtonStandardItem");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			String foodType = (String)testData.get("menu_type");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			JSONArray itemName = (JSONArray)testData.get("food_item_added_again");
			String Quantity = (String)testData.get("quantity_displayed_my_order");
			String strExpectedTotalAfterRemove = (String)testData.get("expected_total_after_remove");
			String email = (String)testData.get("order_by_emailAddress");
			String Name = (String)testData.get("order_by_name");
			
			launch()
				.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(station, menuItemsToSelect)
				.checkLandingPage(station, menuItemsToSelect)
				.orderGivenItems(itemsToOrder)
				.quantityMyorderPage(itemName, foodType, Quantity, strExpectedTotalAfterRemove)
				.togo(itemsToOrder)
				.validateEmailfield(email,Name)
				
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the Add to Order button for standard items. Error:" + e);									
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyFoodItemsUnderGivenStation(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyFoodItemsUnderGivenStation");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			String selectStationToCheck = (String)testData.get("select_station_to_check");
			JSONArray foodItemsToCheck = (JSONArray)testData.get("check_food_items_under_selected_station");
			
			launch()
				.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(station, menuItemsToSelect)
				.checkLandingPage(station, menuItemsToSelect)
				.selectStationAndCheckFoodItems(selectStationToCheck, foodItemsToCheck)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Food Items Under Given Station. Error:" + e);												
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyOrderTotalAfterRemoveFoodItemsInOrderPage(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyOrderTotalAfterRemoveFoodItemsInOrderPage");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			
			//JSONArray itemsToOrder = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			log("Items to create is:" + itemsToOrder.toJSONString());
			
			JSONArray itemsToRemove = (JSONArray)testData.get("food_item_to_remove");
			String strOrderPersonName = (String)testData.get("order_person_name");
			String strExpectedTotalAfterRemove = (String)testData.get("expected_total_after_remove");
			
			launch()
				.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(station, menuItemsToSelect)
				.checkLandingPage(station, menuItemsToSelect)
				.orderGivenItems(itemsToOrder)
				.checkOutAfterRemovingItem(strOrderPersonName, itemsToOrder, itemsToRemove, strExpectedTotalAfterRemove)
			.quitApp();
			
			//writeDataInRunStore("KIOSK_STANDARD_CUSTOMIZED_ORDER", testData.toJSONString());
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Order Total After Removing Food Items In OrderPage. Error:" + e);															
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyRemoveStandardItem(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyRemoveStandardItem");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			log("Items to create is:" + itemsToOrder.toJSONString());
			
			JSONArray itemsToRemove = (JSONArray)testData.get("food_item_to_remove");
			String strOrderPersonName = (String)testData.get("order_person_name");
			String strExpectedTotalAfterRemove = (String)testData.get("expected_total_after_remove");
			
			launch()
				.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(station, menuItemsToSelect)
				.checkLandingPage(station, menuItemsToSelect)
				.orderGivenItems(itemsToOrder)
				.RemoveItemsMyorderPage(itemsToRemove, strExpectedTotalAfterRemove)
			.quitApp();

		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Order Total After Removing Food Items In OrderPage. Error:" + e);															
		}
	}
	


	@Test(dataProvider = "loadTestData")
	public void verifyPlacingCustomizedOrder(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyQuantityAfterAddingItemCustomize");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			String foodType = (String)testData.get("menu_type");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			log("Items to create is:" + itemsToOrder.toJSONString());
			
			JSONArray itemName = (JSONArray)testData.get("food_item_added_again");
			String Quantity = (String)testData.get("quantity_displayed_my_order");
			String strExpectedTotal = (String)testData.get("expected_total");
			JSONArray itemsToRemove = (JSONArray)testData.get("food_item_to_remove");
			String strOrderPersonName = (String)testData.get("order_person_name");
			String strExpectedTotalAfterRemove = (String)testData.get("expected_total_after_remove");
			
			launch()
				.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(station, menuItemsToSelect)
				.checkLandingPage(station, menuItemsToSelect)
				.orderGivenItems(itemsToOrder)
				.quantityMyorderPage(itemName, foodType, Quantity, strExpectedTotal)
				.RemoveItemsMyorderPage1(itemsToRemove, strExpectedTotalAfterRemove)
			.quitApp();

		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the quantity for Customized item. Error:" + e);															
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyClearOrderFunctionality(JSONObject testData) throws Exception {
	log("Test:KioskAppSmokeTests::verifyClearOrderDisable");
	try {
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
		JSONArray itemsToOrder = new JSONArray();
		for(Object o : foodItemKeys) {
			String keyName = (String)o;
			log("Getting data for key:" + keyName);
			JSONObject foodData = (JSONObject)getData(keyName);
			JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
			for(Object i : sourceFoodItems) {
				itemsToOrder.add(i);
			}
		}
		log("Items to create is:" + itemsToOrder.toJSONString());
		launch()
			.login(station, menuItemsToSelect)
			//.enableSecuritySettings()
			//.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateClearOrderDisable()
			.validateViewMyOrderDisable()
			.orderGivenItems(itemsToOrder)
			.validateClearOrderEnable()
			.validateViewMyOrderEnable()
			.clearOrderButtonAlert()
		.quitApp();
	} catch(Exception e) {
		Assert.assertTrue(false, "Exception while testing the clear order button disable when no items added to the cart. Error:" + e);			
	}
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void verifyLandingPageKiosk(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyLandingPageKioskIdle");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			
			//JSONArray itemsToOrder = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			log("Items to create is:" + itemsToOrder.toJSONString());
			
			
			launch()
			.login(station, menuItemsToSelect)
			.enableSecuritySettings(station)
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.saveConfigurationAndLandingPageValidation(station)
			
			//Block Commented by Chithra
				/*.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(station, menuItemsToSelect)
				.orderGivenItems(itemsToOrder)
				.validateKioskResetAlert()
				.validateLandingPage()
				.validateSpecialsFromLandingPage()*/
			.quitApp();
			
			//writeDataInRunStore("KIOSK_STANDARD_CUSTOMIZED_ORDER", testData.toJSONString());
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing landing page when kiosk idle. Error:" + e);															
		}
	}
	
	//Added by Chithra
	@Test(dataProvider = "loadTestData")
	public void verifyPaymentSettingWithoutCashKiosk(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyPaymentSettingWithoutCashKiosk");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			boolean isApplepaySelect = (Boolean) testData.get("is_applepay_select");
			boolean isCashSelect = (Boolean) testData.get("is_cash_select");
			boolean isMealVoucherSelect = (Boolean) testData.get("is_mealvoucher_select");
			
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			log("Items to create is:" + itemsToOrder.toJSONString());
			
			
			launch()
			.login(station, menuItemsToSelect)
			.enableSecuritySettings(station)
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.selectPayment(isApplepaySelect,isCashSelect,isMealVoucherSelect)
			.saveConfigurationAndLandingPageValidation(station)
			.quitApp();
			
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing payment methods configuration for Apple Pay and Meal Voucher. Error:" + e);															
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyPaymentSettingWithCashKiosk(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyPaymentSettingWithCashKiosk");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			boolean isApplepaySelect = (Boolean) testData.get("is_applepay_select");
			boolean isCashSelect = (Boolean) testData.get("is_cash_select");
			boolean isMealVoucherSelect = (Boolean) testData.get("is_mealvoucher_select");
			String userName=(String) testData.get("user_name");
			
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			log("Items to create is:" + itemsToOrder.toJSONString());
			
			
			launch()
			.login(station, menuItemsToSelect)
			.enableSecuritySettings(station)
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.selectPayment(isApplepaySelect,isCashSelect,isMealVoucherSelect)
			.saveConfigurationAndCashPaymentValidation(station,isCashSelect, userName)
			.quitApp();
			
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing payment methods configuration for Apple Pay, Cash, Meal Voucher Payment methods and its validation. Error:" + e);															
		}
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void verifyPaymentSettingForCashDrawerKiosk(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyPaymentSettingForCashDrawerKiosk");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			boolean isApplepaySelect = (Boolean) testData.get("is_applepay_select");
			boolean isCashSelect = (Boolean) testData.get("is_cash_select");
			boolean isMealVoucherSelect = (Boolean) testData.get("is_mealvoucher_select");
			String userName=(String) testData.get("user_name");
			
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			JSONArray cashDrawerDetail = (JSONArray)testData.get("cash_drawer_data");
			
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			log("Items to create is:" + itemsToOrder.toJSONString());
			
			launch()
			.login(station, menuItemsToSelect)
			.enableSecuritySettings(station)
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.selectPayment(isApplepaySelect,isCashSelect,isMealVoucherSelect)
			.cashDrawerValidationAndSelectCheck(cashDrawerDetail)
			.saveConfigurationAndCashPaymentValidation(station,isCashSelect, userName)
			.quitApp();
			
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing payment methods configuration for Apple Pay, Cash, Meal Voucher Payment methods and its validation. Error:" + e);															
		}
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void verifyKioskPaymentPage(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyMyOrderPage");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			
			//JSONArray itemsToOrder = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			log("Items to create is:" + itemsToOrder.toJSONString());
			
			
			launch()
				.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(station, menuItemsToSelect)
				.orderGivenItems(itemsToOrder)
				.validateMyOrderPage()
				.validateCheckoutPage()
				.validateNoCardDeviceAttachalert()
				.validateVoucherDisableNoName()
				.validatePayDisableNoName()
				.validateVoucherWithName()
				.validatePayWithName()
			.quitApp();
			
			//writeDataInRunStore("KIOSK_STANDARD_CUSTOMIZED_ORDER", testData.toJSONString());
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the my order page. Error:" + e);															
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyEmailIdPresent(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyEmailIdPresent");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			
			//JSONArray itemsToOrder = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			log("Items to create is:" + itemsToOrder.toJSONString());
			
			
			launch()
				.login(station, menuItemsToSelect)
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(station, menuItemsToSelect)
				.orderGivenItems(itemsToOrder)
				.validateMyOrderPage()
				.validateCheckoutPage()
				.validateNoCardDeviceAttachalert()
				.validateEmailIdPresent()
			.quitApp();
			
			//writeDataInRunStore("KIOSK_STANDARD_CUSTOMIZED_ORDER", testData.toJSONString());
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Order Total After Removing Food Items In OrderPage. Error:" + e);															
		}
	}
	
	//Added by Chithra
	@Test(dataProvider = "loadTestData")
	public void verifyAddToOrderForNonCustomizedOrder(JSONObject testData) throws Exception {
		
		log("Test:KioskAppFunctionalTests::verifyAddToOrderForNonCustomizedOrder");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			//String foodType = (String)testData.get("menu_type");
			boolean isApplepaySelect = (Boolean) testData.get("is_applepay_select");
			boolean isCashSelect = (Boolean) testData.get("is_cash_select");
			boolean isMealVoucherSelect = (Boolean) testData.get("is_mealvoucher_select");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			/*JSONArray itemName = (JSONArray)testData.get("food_item_added_again");
			String Quantity = (String)testData.get("quantity_displayed_my_order");
			String strExpectedTotalAfterRemove = (String)testData.get("expected_total_after_remove");
			String email = (String)testData.get("order_by_emailAddress");
			String Name = (String)testData.get("order_by_name");*/
			
			launch()
			.login(station, menuItemsToSelect)
			.enableSecuritySettings(station)
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.selectPayment(isApplepaySelect,isCashSelect,isMealVoucherSelect)
			.saveConfigurationAndLandingPageValidation(station)
			.orderGivenItems(itemsToOrder)
			.validateAddToOrder(itemsToOrder)
			
			
				//.quantityMyorderPage(itemName, foodType, Quantity, strExpectedTotalAfterRemove)
				//.togo(itemsToOrder)
				//.validateEmailfield(email,Name)
				
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the Add to Order button for standard items. Error:" + e);									
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyAddToOrderWithOrderQuantityValidation(JSONObject testData) throws Exception {
		
		log("Test:KioskAppFunctionalTests::verifyAddToOrderWithOrderQuantityValidation");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			//String foodType = (String)testData.get("menu_type");
			boolean isApplepaySelect = (Boolean) testData.get("is_applepay_select");
			boolean isCashSelect = (Boolean) testData.get("is_cash_select");
			boolean isMealVoucherSelect = (Boolean) testData.get("is_mealvoucher_select");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			/*JSONArray itemName = (JSONArray)testData.get("food_item_added_again");
			String Quantity = (String)testData.get("quantity_displayed_my_order");
			String strExpectedTotalAfterRemove = (String)testData.get("expected_total_after_remove");
			String email = (String)testData.get("order_by_emailAddress");
			String Name = (String)testData.get("order_by_name");*/
			
			launch()
			.login(station, menuItemsToSelect)
			.enableSecuritySettings(station)
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.selectPayment(isApplepaySelect,isCashSelect,isMealVoucherSelect)
			.saveConfigurationAndLandingPageValidation(station)
			.orderGivenItems(itemsToOrder)
			.validateAddToOrder(itemsToOrder)
			.totalOrderValidation()			
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the Add to Order with order qunatity validation. Error:" + e);									
		}
	}
	
	//New Method for Grab and Go check
	@Test(dataProvider = "loadTestData")
	public void verifyGrabAndGoCheckOut(JSONObject testData) throws Exception {
		
		log("Test:KioskAppFunctionalTests::verifyGrabAndGoCheckOut");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			//String foodType = (String)testData.get("menu_type");
			boolean isApplepaySelect = (Boolean) testData.get("is_applepay_select");
			boolean isCashSelect = (Boolean) testData.get("is_cash_select");
			boolean isMealVoucherSelect = (Boolean) testData.get("is_mealvoucher_select");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
				
			launch()
			.login(station, menuItemsToSelect)
			.enableSecuritySettings(station)
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.selectPayment(isApplepaySelect,isCashSelect,isMealVoucherSelect)
			.saveConfigurationAndLandingPageValidation(station)
			.orderGivenGrabAndGoItems(itemsToOrder)	
			.validateAddToOrder(itemsToOrder)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the Add to Order with order qunatity validation. Error:" + e);									
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyAddToCartWithCustomizedQuantityItem(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyAddToCartWithCustomizedQuantityItem");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			//JSONArray itemsToOrder = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			boolean isApplepaySelect = (Boolean) testData.get("is_applepay_select");
			boolean isCashSelect = (Boolean) testData.get("is_cash_select");
			boolean isMealVoucherSelect = (Boolean) testData.get("is_mealvoucher_select");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			
			// 
			//String selectStationForOrder = (String)testData.get("select_station_for_order");
			//String select_item_for_customization = (String)testData.get("customize_food_item");
			//String select_item_price_for_customization = (String)testData.get("customize_food_item_price");
			//String select_item_category_for_customization = (String)testData.get("customize_food_category");
			//String select_item_to_change = (String)testData.get("customize_food_item_to_change");
			//
			String strOrderPersonName = (String)testData.get("order_person_name");
			
			launch()
				.login(station, menuItemsToSelect)
				.enableSecuritySettings(station)
				.selectStationAndMenuItems(station, menuItemsToSelect)
				.selectPayment(isApplepaySelect,isCashSelect,isMealVoucherSelect)
				.saveConfigurationAndLandingPageValidation(station)
				.orderGivenItems(itemsToOrder)
				.validateAddToOrder(itemsToOrder)
				//.checkOut(strOrderPersonName, itemsToOrder)
				.quitApp();
			
			//writeDataInRunStore("KIOSK_SPECIAL_CUSTOMIZED_ORDER", testData.toJSONString());
			
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the Order By Customizing Item. Error:" + e);						
		}
		
	}

	@Test(dataProvider = "loadTestData")
	public void verifyAddToCartWithCustomizedListItem(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyAddToCartWithCustomizedListItem");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			//JSONArray itemsToOrder = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			boolean isApplepaySelect = (Boolean) testData.get("is_applepay_select");
			boolean isCashSelect = (Boolean) testData.get("is_cash_select");
			boolean isMealVoucherSelect = (Boolean) testData.get("is_mealvoucher_select");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			
			// 
			//String selectStationForOrder = (String)testData.get("select_station_for_order");
			//String select_item_for_customization = (String)testData.get("customize_food_item");
			//String select_item_price_for_customization = (String)testData.get("customize_food_item_price");
			//String select_item_category_for_customization = (String)testData.get("customize_food_category");
			//String select_item_to_change = (String)testData.get("customize_food_item_to_change");
			//
			String strOrderPersonName = (String)testData.get("order_person_name");
			
			launch()
				.login(station, menuItemsToSelect)
				.enableSecuritySettings(station)
				.selectStationAndMenuItems(station, menuItemsToSelect)
				.selectPayment(isApplepaySelect,isCashSelect,isMealVoucherSelect)
				.saveConfigurationAndLandingPageValidation(station)
				.orderGivenItems(itemsToOrder)
				.validateAddToOrder(itemsToOrder)
				//.checkOut(strOrderPersonName, itemsToOrder)
				.quitApp();
			
			//writeDataInRunStore("KIOSK_SPECIAL_CUSTOMIZED_ORDER", testData.toJSONString());
			
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the Order By Customizing Item. Error:" + e);						
		}
		
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyAddToCartWithCustomizedOptionItem(JSONObject testData) throws Exception {
		
		log("Test:KioskAppSmokeTests::verifyAddToCartWithCustomizedOptionItem");
		try {
			log("Data:" + testData.toJSONString());
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			//JSONArray itemsToOrder = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			boolean isApplepaySelect = (Boolean) testData.get("is_applepay_select");
			boolean isCashSelect = (Boolean) testData.get("is_cash_select");
			boolean isMealVoucherSelect = (Boolean) testData.get("is_mealvoucher_select");
			JSONArray itemsToOrder = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					itemsToOrder.add(i);
				}
			}
			
			// 
			//String selectStationForOrder = (String)testData.get("select_station_for_order");
			//String select_item_for_customization = (String)testData.get("customize_food_item");
			//String select_item_price_for_customization = (String)testData.get("customize_food_item_price");
			//String select_item_category_for_customization = (String)testData.get("customize_food_category");
			//String select_item_to_change = (String)testData.get("customize_food_item_to_change");
			//
			String strOrderPersonName = (String)testData.get("order_person_name");
			
			launch()
				.login(station, menuItemsToSelect)
				.enableSecuritySettings(station)
				.selectStationAndMenuItems(station, menuItemsToSelect)
				.selectPayment(isApplepaySelect,isCashSelect,isMealVoucherSelect)
				.saveConfigurationAndLandingPageValidation(station)
				.orderGivenItems(itemsToOrder)
				.validateAddToOrder(itemsToOrder)
				//.checkOut(strOrderPersonName, itemsToOrder)
				.quitApp();
			
			//writeDataInRunStore("KIOSK_SPECIAL_CUSTOMIZED_ORDER", testData.toJSONString());
			
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the Order By Customizing Item. Error:" + e);						
		}
		
	}
	
}


