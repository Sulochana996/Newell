package com.apple.ist.caffemac.test.util;


public interface ProcessOutputListener {

	public void outStream(String aLog);
	public void errorStream(String aErr);
}
