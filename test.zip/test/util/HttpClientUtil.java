package com.apple.ist.caffemac.test.util;


import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class HttpClientUtil {
	
	private static final String protocol= "https";
	private static final String BaseURL = "caffemacs-qa.corp.apple.com";
	private static final String BaseCertURL = "caffemacs-uat-cert.corp.apple.com";
	private static final String KDSUDID = "6D1ABCA6-D847-49EC-921D-E4FB777B5030";
	private static final String user = "yifeng_luo";
    private static final String token="ACMTKNeNpdVVmPo0YY/CuTeUW7bTBnNDsRhzlsjsZgMLxxg7lvzK+PdzdSMnlqqVVd/an0VdXHX1tdvS3JMBZt8+Md/X54f0uaqI2LJvvxfrPFb/T7X58ffwgGb3vw9NZVxTi9wRunKvzb+zcA2K6rEgAEW3iDqmLZby8KAE76+9t7Pk3dnwCs6/o9+In6HrX1T+AI4NB2yTA91RfZt9eD7/EUv39+/Cb/MsznR1xE0+dHmTw/k/ID/Dw/4mAKPlNP9CCPLOMBGri610gedkLmDsAfbcqpYOi3jMv5upVvPi3bdrQNGeyt9t6KKTeXT+0kgMqChIk9ex5jhDUmOauvx2Khkw1Xz2lHZgNTNnaq98buBISPLElD9rZG70HfaSOOGjg8Cc/cNohx8mblYehksJmM5Z/ExjtnkpEp/V1kOAsXQMGh2NFJhWuphYmbhiZnCOf0oSqHlbwwlkTqcVL3C3ZeQ0SMEoCXT6Fvm+AgG5GyeIdntwuynqzmOFG7o7gYLT905qxQ9LGbcAeOuGriYHIdL2pD/ky1ThhhUk1Zpdhl1kEtr6o8ybOIp0HJOSLNO7GVMJEmO2O6RXo1TDGAN/PHjw/wS97fijfRfyVH/NI4S8alYcAz3zK+oFREza2MoGpqvZyXaHOXI5Mamn5XziY9ZniJHCI60eKnudcD/rx2hnr3c/P+eGCpz44UubsjJhw1jrpgaKXG8gKHNah4JcE7uSgaEWPJGxv5thTcuUY0UZrQkJY2mYUVdowGAKdLjfXjocc9u+ZluFCwXom6SXNNoyEVxcOVQP327AAeRe5Dafd+dIYIIIdLtHr4deKjjMA3L6HoIb9qeDnwi7EALkA230jEwAxi6wbkyeEp9X7QH976yEGuxDR+AX1uXazTlMom6E7qIOrK1CB4SkNdQcg6rPrlVBwvS+YkOAfnK2M7KE4dsozCCP8wVZCHuJZYfTSqmphcH8iNeMzckAhVOpMtVqQMnhkTLSy84gEmUOy98oREkZ17zvNmc1eDRj/s5PUmKuScR31kZp0+s0oip2qlLDpKtyPzxB5yydsBGpkXBNQE616jGSuPz5hLRzqChODLccDAOe/nK6Gu2Uoo9twFVFmhvYe9ltolcldNborqlal9flxz5l5KYywO3eHSq64tdTAGwnJnbDaqnKNLxGMeFqz7INM1flDJuMFZI54Qbo9LxngtkmeXtcbhTdiEAm2koQAYZ2idmytBjEEE0TMgL3ohqQLLiitSSYfLiq09TvBXGtdKuiZlgXBeegQSF5Xu7KursqvaqTDi0DNJnFOO18upPuGeWZQp7hLynoXSCT2f8M68nZNp7x/jgcla8qjZqsmdEGis5JnJnMJl+lwG0zOyfLsPKEvM1sUPDzFGp7WCud5U9Ud4NBZbPIDBoVi36S0iRTfIbfjLW/GtQAxYsdLpeHs5LLy8jFix/tJhBYk6I7SAxElO4/nsAv2Qiu4CJuDb7p/UhzLD6+7TwBJS11DoveUQ/p7Rx6RwMabN4KaQeOnI1jU0E2kfWuCMUkP7WjYPKc3G9NRTsU9JPlZE29qFaKan7B2jVG/slFidk0ol7HS+eBaWggXVF7if7sH5hGJ3hcoc3ySDbLzwvRhe7SmUHnvYZfuu5DdtqETBrI6Ioa3ZeDbQQzfLLqMoUVmjREDO9/V/kbH9kxjjNLw65LNopmRoguoD/HPxC5XXwZdkeYhYUCpTrNTqfHieEwrTA2Nm14iWL1YTqE/sqUvGMJmK9+W3YvlSCahCDKR9PNo57G4B3QnRxvwv0qav47065t/JwO+uAb966PNvA9tYNw==";
    String sessionId; 
	
  public String appleConnect(){
	
	  String URI = protocol +"://" + BaseURL + "/auth";
	 
	try {

		HttpClient client = HttpClientBuilder.create().build();
		HttpPost httppost = new HttpPost(URI);
		httppost.addHeader("User-Agent", "KDS/1 CFNetwork/711.1.12 Darwin/14.0.0");
		httppost.addHeader("applicationIdentifier", "1");
		httppost.addHeader("X-Apple-DS-Username", user);
		httppost.addHeader("X-Apple-ios-SSO-Token", token);
		HttpResponse response = client.execute(httppost);
		
		if (response.getStatusLine().getStatusCode() != 200) {
			throw new RuntimeException("Failed : HTTP error code : "
			   + response.getStatusLine().getStatusCode());
		}
				
		
	   String json = EntityUtils.toString(response.getEntity(), "UTF-8");
        
            JSONParser parser = new JSONParser();
            Object resultObject = parser.parse(json);

            if (resultObject instanceof JSONObject) {
            	JSONObject obj=(JSONObject)resultObject;
                sessionId = (String)obj.get("sessionToken");
             
                

            }else  {
            	System.out.println("failed to retrieve data");
               
            }

        } catch (Exception e) {
		e.printStackTrace();
	}
	
	   return sessionId;
  }
   
  
  public void completeOrder(String sessionId, Integer orderID){
	  
	  String URI = protocol +"://" + BaseURL + "/api/v1/caffemac/orderitem/" + orderID + "/COMPLETED/0";
	  String cookie = "JSESSIONID=" + sessionId;
		 
		try {

			HttpClient client = HttpClientBuilder.create().build();
			HttpPut httpput = new HttpPut(URI);
			httpput.addHeader("User-Agent", "KDS/1 CFNetwork/711.1.12 Darwin/14.0.0");
			httpput.addHeader("Cookie", cookie);
			httpput.addHeader("X-Apple-CSRF-Token", "HELLO");
			httpput.addHeader("Content-Type", "application/json");
			System.out.println("value of URI " + URI);
			HttpResponse response = client.execute(httpput);
			
			if (response.getStatusLine().getStatusCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
				   + response.getStatusLine().getStatusCode());
			}
					

	      } catch (Exception e) {
			e.printStackTrace();
		}
	  
  }
   

}
