package com.apple.ist.caffemac.test.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PropertyReader {
	
	public static Properties readPropertiesFromFile(String fileName) {

	      Properties properties = new Properties();
	      File file = null;
	      try {
	          file = new File(fileName);
	          System.out.println("Reading from : " + file.getAbsolutePath());
	          FileReader fstream = new FileReader(fileName);
	          BufferedReader in = new BufferedReader(fstream);
	          properties.load(in);
	          in.close();
	          fstream.close();
	          return properties;
	      } catch (FileNotFoundException ex) {
	          Logger.getLogger(PropertyReader.class.getName()).log(Level.SEVERE, null, ex);
	          return null;
	      } catch (IOException ex) {
	          Logger.getLogger(PropertyReader.class.getName()).log(Level.SEVERE, null, ex);
	          return null;
	      } catch (Exception ex) {
	          ex.printStackTrace();
	          return null;
	      }
	  }

}
