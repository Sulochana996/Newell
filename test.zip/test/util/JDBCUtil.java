package com.apple.ist.caffemac.test.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;




public class JDBCUtil {
	
	//JDBC driver name and database URL
	static String JDBC_DRIVER = null;
	static String DBusername = null;
	static String DBpassword = null;
	static String DBURL = null;
	
	Connection conn = null;
	Statement  stmt = null;
	ResultSet rs = null;
	
	public void CreateConn(){
		
		try {
			getPropValues();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		try {
			Class.forName(JDBC_DRIVER);
			conn = DriverManager.getConnection(DBURL, DBusername,DBpassword);
		    stmt = conn.createStatement();
		    }
			 catch (SQLException e) 
		       {
				 Logger.getLogger(JDBCUtil.class.getName()).log(Level.SEVERE, null, e);
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				 Logger.getLogger(JDBCUtil.class.getName()).log(Level.SEVERE, null, e);
		   }
	      
	 }
	
	public void activateMealProgram(int id, int remainingbalance ){
		
		String SQLstmt1 = "UPDATE MEAL_PROGRAM_USER SET REDEEM_DATE=NULL WHERE ID =  " + id;
		System.out.println(SQLstmt1);
		rs = ExecQuery(SQLstmt1);
		
		String SQLstmt2 = "UPDATE MEAL_PROGRAM_USER SET REMAINING_VALUE=" +remainingbalance + "WHERE ID =  " + id;
		System.out.println(SQLstmt2);
		rs = ExecQuery(SQLstmt2);
		
		
	}
	
	public void markVoucherReady(Integer id){
		
		String SQLstmt = "update MEAL_TICKET set STATUS='READY' where ID=" + id;
		System.out.println(SQLstmt);
		rs = ExecQuery(SQLstmt);
		
	}
	
	public void changeCaffeName(String configureStationName, String orignalStationName, String caffeName){
		
		String SQLstmt = "update FOOD_STATION set STATION_NAME = '"+configureStationName+"' where ID = (select id from food_station where station_name = '"+orignalStationName+"' and caffe_id = (select id from caffe where caffe_name = '"+caffeName+"'))";
		System.out.println(SQLstmt);
		rs = ExecQuery(SQLstmt);
		System.out.println("Updated sucessfully");
		
	}
	
	public void deleteIngredientInDb(String category, String ingredientName, String caffeRegion){
		
		double a =  Math.floor(Math.random()*10000 +1);
		
		String SQLstmt = "update global_ingrednt set ingredient_name='"+ingredientName+ a+"'  where (global_ingredient_category_id = (select id from global_ingredient_category where category_name = '"+category+"') and ingredient_name = '"+ingredientName+"' and region_id = (select id from caffe_region where region_name= '"+caffeRegion+"'))";
		System.out.println(SQLstmt);
		rs = ExecQuery(SQLstmt);
		/*
		int categoryID = 0;
		int caffeRegionID = 0;
		String SQLstmt1 = "select id from global_ingredient_category where category_name = '" + category+"'"; 
		System.out.println(SQLstmt1);
		try {
			categoryID = ExecQuery(SQLstmt1).getInt(1);
			System.out.println("categoryID " + categoryID);
		}catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		String SQLstmt2 = "select id from caffe_region where region_name= '" + caffeRegion+ "'"; 
		try{
		caffeRegionID = ExecQuery(SQLstmt2).getInt(1);
		System.out.println("caffeRegionID " + caffeRegionID);
        }catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		String SQLstmt3 = "delete from global_ingrednt where (global_ingredient_category_id = '" + categoryID + "' and ingredient_name = '" + ingredientName + "' and region_id = '" + caffeRegionID + "')";
		System.out.println(SQLstmt3);
		rs = ExecQuery(SQLstmt3);*/
		
		System.out.println("Updated Ingredient sucessfully");
		
	}
	
	public void markVoucherApproved(){
		
		String SQLstmt = "update MEAL_TICKET_REQUEST set STATUS='APPROVED' where id = (select Max(id) from MEAL_TICKET_REQUEST)";
		System.out.println(SQLstmt);
		rs = ExecQuery(SQLstmt);
		
	}
	
	public String changeStatus (String voucherType, String updateStatus){
		String SQLstmt = "update "+voucherType+"_REQUEST set STATUS='"+updateStatus+"' where id = (select Max(id) from "+voucherType+"_REQUEST)";
		System.out.println(SQLstmt);
		rs = ExecQuery(SQLstmt);	
		return updateStatus;
	}
	
	
	public List<String> getAllCaffe(){
		
		List<String> CaffeName = new ArrayList<String>();
		String SQLstmt = "select CAFFE_NAME from CAFFE";
		System.out.println(SQLstmt);
		rs = ExecQuery(SQLstmt);

		// add Caffe name result set to List
		
		 try {
			 
			while(rs.next()){
				 CaffeName.add(rs.getString(1));
			     } 
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		 
		 Iterator<String> itr = CaffeName.iterator();
	        while(itr.hasNext()){
	            System.out.println(itr.next());
	        }
	        
		 return CaffeName;
		
	}
	
	public List<String> getCaffeNamebyUserID (String id){
		
		List<Integer> CaffeID = getCaffeIDbyUserID(id);
		List<String> CaffeName = new ArrayList<String>();
		
		
		// retrieving data from string list array in for loop
		for (int i=0;i < CaffeID.size();i++)
		{
		CaffeName.add(getCaffeNamebyCaffeID(CaffeID.get(i)));
		  
		}
		
		Iterator<String> itr = CaffeName.iterator();
        while(itr.hasNext()){
            System.out.println(itr.next());
        }
        
        return CaffeName;

		
	}
	
	public String getCaffeNamebyCaffeID (Integer id){
		
		String SQLstmt = "select CAFFE_NAME from CAFFE where ID=" + id;
		System.out.println(SQLstmt);
		rs = ExecQuery(SQLstmt);
		
		 String CaffeName =null;
    	 try {
    	 if(rs.next()){
    		 CaffeName = rs.getString(1);
    	
         } else {
        	 System.out.println("GetCaffeNamebyCaffeiD didn't return any name");
          }
    	 } catch (SQLException e) {
 			Logger.getLogger(JDBCUtil.class.getName()).log(Level.SEVERE, null, e);
 		}
    	 
    	 return CaffeName;
		
		
		
	}
	
	public List<Integer> getCaffeIDbyUserID (String id){
		
		String SQLstmt = "select CAFFE_ID  from TEAM where TEAM_MEMBER_DSID=" + id;
		System.out.println(SQLstmt);
		rs = ExecQuery(SQLstmt);
		List<Integer> CaffeID= new ArrayList<Integer>();
		try {
			while(rs.next())
			    CaffeID.add(rs.getInt(1));
		} catch (SQLException e) {
			e.printStackTrace();
		}

         return CaffeID;
		
	}
     public ResultSet ExecQuery(String sqlStmt) {
    	 try {
			rs = stmt.executeQuery(sqlStmt);
		} catch (SQLException e) {
			Logger.getLogger(JDBCUtil.class.getName()).log(Level.SEVERE, null, e);
		}
    	 
    	 return rs;
		
      }
     
   
     
	
     public Integer GetOrderID(){
    	 
    	 int orderID = 0;
    	 try {
    	 if(rs.next()){
    		 orderID = rs.getInt(1);
    	
         } else {
        	 System.out.println("GetOrderID didn't return any ID");
          }
    	 } catch (SQLException e) {
 			Logger.getLogger(JDBCUtil.class.getName()).log(Level.SEVERE, null, e);
 		}
    	 
    	 return orderID;
		
	}
	
	public void CloseConn(){
		try {
			rs.close();
			conn.close();
		} catch (SQLException e) {
			Logger.getLogger(JDBCUtil.class.getName()).log(Level.SEVERE, null, e);
		}
	}
	
	
	public void getPropValues() throws IOException {
		InputStream inputStream = null;
		 
		try {
			
	        Properties prop = new Properties();
			String propFileName = "database.properties";
 
			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
 
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}
 
		    // get the property value and print it out
			DBusername = prop.getProperty("DBusername");
			DBpassword = prop.getProperty("DBpassword");
			JDBC_DRIVER = prop.getProperty("JDBC_DRIVER");
			DBURL = prop.getProperty("DB_URL");
            System.out.println("value from property file " + DBusername +DBpassword+JDBC_DRIVER+DBURL);
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
			inputStream.close();
		}
		
	}
}
