package com.apple.ist.caffemac.test.util;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;

import com.apple.framework.core.utils.ProcessRunner;

public class AppUtilities {

	public static File getFile(String aFileName) {
		File f = null;
		System.out.println("Checking the file:" + aFileName);
		f = new File(aFileName);
		if(f.exists()) {
			return f;
		}
		
		aFileName = System.getProperty("user.dir") + File.separator + aFileName;
		System.out.println("Checking the file:" + aFileName);
		f = new File(aFileName);
		if(f.exists()) {
			return f;
		}
		return null;
	}
	
	public static String getFileContent(File f) {
		try {
			return FileUtils.readFileToString(f);
		} catch(Exception e) {
			System.err.println(e.getMessage());
		}
		return null;
	}
	
	public static void delay(long ms) {
		try {
			Thread.sleep(ms);
		} catch(Exception e) {}
	}
	
	public static String getCurrentTimestamp() {
		SimpleDateFormat frmt = new SimpleDateFormat("HHmmss_SSS_ddMMyyyy");
		return frmt.format(Calendar.getInstance().getTime());
	}
	
	public static String getCurrentTimestamp(String frmtPattern) {
		SimpleDateFormat frmt = new SimpleDateFormat(frmtPattern);
		return frmt.format(Calendar.getInstance().getTime());
	}
	
	public static boolean loginUATAppleConnect(String fwkBaseFolder, String username, String password, boolean logOffPreviousUser) {
		boolean status = false;

		
		List<String> cmds = new ArrayList<String>();
		cmds.add("python");
		cmds.add(fwkBaseFolder + File.separator + "utils" + File.separator + "appleconnect" + File.separator + "authenticate_appleconnect.py");
		cmds.add(username);
		cmds.add(password);
		if (logOffPreviousUser) {
			cmds.add("1");
		}

		ProcessRunner runner = new ProcessRunner(cmds);
		int exitCode = runner.runProcessAndWaitToComplete();

		if (exitCode == 0) { // Success in appleconnect login
			System.out.println(StringUtils.join(runner.getOutput().toArray()));
			System.out.println("Successfully logged in to apple connect as user:" + username);
			status = true;
		} else {
			System.out.println("Failed to login to apple connect as user:" + username);
			System.out.println(StringUtils.join(runner.getError().toArray()));
		}

		return status;
	}	
	
	public static boolean minimiseOtherProcess(String fwkBaseFolder) {
		boolean status = false;
		
		String scriptToRun = "osascript "+fwkBaseFolder  + "utils" + File.separator + "minimiseprocess" + File.separator + "HideAllApps.scpt"+ " ~/ram.txt";
		System.out.println(scriptToRun);
		try {
			Runtime.getRuntime().exec(scriptToRun);
			status = true;
		} catch (IOException e) {
			e.printStackTrace();
		}

		return status;
	}
}
