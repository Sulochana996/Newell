package com.apple.ist.caffemac.test;

import java.io.File;
import java.io.FileReader;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.apple.ist.caffemac.test.common.ApplicationTestBase;
import com.apple.ist.caffemac.test.util.AppUtilities;

public class CaffeMacsAppTestFlows extends ApplicationTestBase {

	public CaffeMacsAppTestFlows() {
		// TODO Auto-generated constructor stub
		strAppName = "caffemac_interaction_scenarios";	//this will be used for getting 
	}
	
	@Test(dataProvider = "loadTestData")
	public void validatePlacingOrderByCreatingNewMenu (JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			String caffe_version =  (String)testData.get("caffe_version");
			String station_type =  (String)testData.get("station_type");
			
			
			MenuMakerApp menuMakerApp = new MenuMakerApp(appObject, getRunParams());
			menuMakerApp.launch()
				.login()
				.createGivenFoodItems(foodItems)
				.quitApp();		
			log("Successfully created menu item in Caffeportal");
			
			log("The test data for the Guest app is:" + testData.toJSONString());
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()

			.login()
			.selectCaffeLocation(caffe_location,caffe_version,station_type)
			//.selectCaffeLocation(caffe_location)
			.orderGivenItems(foodItems, caffe_location) 
			//.ChangeOrderQuantity(numberOfItems)
			//.validatePriceStandard() 
			//.toGoValidation()
		.quitApp();
			
			log("Successfully verified the To Go confirmation in Guestapp");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the To Go confirmation in Guestapp. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyKDSSoldOutItemInGuestApp(JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray ingredientsToBeSoldOut = (JSONArray)testData.get("food_items_to_be_sold");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			
			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
			kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(station, menuItemsToSelect)
				.makeIngredientsAsSoldOut(ingredientsToBeSoldOut)
			.quitApp();	
			
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(foodItems) 
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
			JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYGUESTAPPORDERINKDS_GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			//JSONObject prevData = getTempData("GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			Assert.assertNotNull(prevData , "Failed to get the previously placed order details in guest app");
			log("prev data:" + prevData.toJSONString());
			
			JSONObject prevRunData = convertPrevRunData("NOT_USED", prevData);
			log("customized run data:" + prevRunData.toJSONString());
			if(prevRunData != null) {
				log("Customized KDS data is:" + prevRunData.toJSONString());
				ordersToCheck = (JSONArray)prevRunData.get("order_list");
			}
			
			log("Successfully verified the order placed in Guest app in KDS");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the order from GuestApp to KDS. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyGuestAppOrderInKDS(JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(foodItems) 
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
			log("Order list is: "+ordersToCheck);
			JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYGUESTAPPORDERINKDS_GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			log("The previous data is: "+prevData);
			//JSONObject prevData = getTempData("GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			Assert.assertNotNull(prevData , "Failed to get the previously placed order details in guest app");
			log("prev data:" + prevData.toJSONString());
			
			JSONObject prevRunData = convertPrevRunData("NOT_USED", prevData);
			log("customized run data:" + prevRunData.toJSONString());
			if(prevRunData != null) {
				log("Customized KDS data is:" + prevRunData.toJSONString());
				ordersToCheck = (JSONArray)prevRunData.get("order_list");
			}
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
			kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(station, menuItemsToSelect)
				.verifyLandingPageWithPendingOrders(ordersToCheck)
			.quitApp();	
			
			log("Successfully verified the order placed in Guest app in KDS");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the order from GuestApp to KDS. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateOrderDetailsInKDS(JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(foodItems) 
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
			log("Order list is:"+ordersToCheck);
			JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VALIDATEORDERDETAILSINKDS_GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			log("Previous data is: "+prevData);
			//JSONObject prevData = getTempData("GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			Assert.assertNotNull(prevData , "Failed to get the previously placed order details in guest app");
			log("prev data:" + prevData.toJSONString());
			
			JSONObject prevRunData = convertPrevRunData("NOT_USED", prevData);
			log("customized run data:" + prevRunData.toJSONString());
			if(prevRunData != null) {
				log("Customized KDS data is:" + prevRunData.toJSONString());
				ordersToCheck = (JSONArray)prevRunData.get("order_list");
			}
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
			kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(station, menuItemsToSelect)
				.verifyLandingPageWithPendingOrders(ordersToCheck)
				.openTile(ordersToCheck)
				.printerButton()
				.guestAppNotifyButton()
				.cancelButton()
				//.completePendingOrders(ordersToCheck)
				//.validateCheckButton(ordersToCheck)
				
				.givenOrderCompletedInOrderHistory(ordersToCheck)
			.quitApp();	
			
			log("Successfully verified the order placed in Guest app in KDS");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the order from GuestApp to KDS. Error:" + e);
		}
	}

	@Test(dataProvider = "loadTestData")
	public void verifyCancellingorderfromorderhistoryPage(JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(foodItems) 
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
			JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYCANCELLINGORDERFROMORDERHISTORYPAGE_GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			//JSONObject prevData = getTempData("GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			Assert.assertNotNull(prevData , "Failed to get the previously placed order details in guest app");
			log("prev data:" + prevData.toJSONString());
			
			JSONObject prevRunData = convertPrevRunData("NOT_USED", prevData);
			log("customized run data:" + prevRunData.toJSONString());
			if(prevRunData != null) {
				log("Customized KDS data is:" + prevRunData.toJSONString());
				ordersToCheck = (JSONArray)prevRunData.get("order_list");
			}
			log("I am here");
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
			kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(station, menuItemsToSelect)
				.completePendingOrders(ordersToCheck)
				.givenOrderCompletedInOrderHistory(ordersToCheck)
				.cancelOrder()
			.quitApp();	
			
			log("Successfully verified the Notify button for Guestapp orders in KDS");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the order from GuestApp to KDS. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCancelOrderAndOrderHistoryPage(JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(foodItems) 
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
			JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYCANCELORDERANDORDERHISTORYPAGE_GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			//JSONObject prevData = getTempData("GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			Assert.assertNotNull(prevData , "Failed to get the previously placed order details in guest app");
			log("prev data:" + prevData.toJSONString());
			
			JSONObject prevRunData = convertPrevRunData("NOT_USED", prevData);
			log("customized run data:" + prevRunData.toJSONString());
			if(prevRunData != null) {
				log("Customized KDS data is:" + prevRunData.toJSONString());
				ordersToCheck = (JSONArray)prevRunData.get("order_list");
			}
			log("I am here");
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
			kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(station, menuItemsToSelect)
				.verifyLandingPageWithPendingOrders(ordersToCheck)
				.cancelGivenOrders(ordersToCheck)
			.quitApp();	
			
			log("Successfully verified the Notify button for Guestapp orders in KDS");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the order from GuestApp to KDS. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCompleteOrdersinPendingOrdersPageCustomize(JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(foodItems) 
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
			JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYCOMPLETEORDERSINPENDINGORDERSPAGECUSTOMIZE_GUESTAPP_SPECIAL_CUSTOMIZED_1");
			//JSONObject prevData = getTempData("GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			Assert.assertNotNull(prevData , "Failed to get the previously placed order details in guest app");
			log("prev data:" + prevData.toJSONString());
			
			JSONObject prevRunData = convertPrevRunData("NOT_USED", prevData);
			log("customized run data:" + prevRunData.toJSONString());
			if(prevRunData != null) {
				log("Customized KDS data is:" + prevRunData.toJSONString());
				ordersToCheck = (JSONArray)prevRunData.get("order_list");
			}
			log("I am here");
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
			kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(station, menuItemsToSelect)
				.verifyLandingPageWithPendingOrders(ordersToCheck)
				.validateCheckButton(ordersToCheck)
				.givenOrderCompletedInOrderHistory(ordersToCheck)
			.quitApp();	
			
			log("Successfully verified the Notify button for Guestapp orders in KDS");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the order from GuestApp to KDS. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCompleteOrdersinPendingOrdersPageStandard(JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(foodItems) 
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
			JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYCOMPLETEORDERSINPENDINGORDERSPAGESTANDARD_GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			//JSONObject prevData = getTempData("GUESTAPP_STANDARD_NONCUSTOMIZED_1");
			Assert.assertNotNull(prevData , "Failed to get the previously placed order details in guest app");
			log("prev data:" + prevData.toJSONString());
			
			JSONObject prevRunData = convertPrevRunData("NOT_USED", prevData);
			log("customized run data:" + prevRunData.toJSONString());
			if(prevRunData != null) {
				log("Customized KDS data is:" + prevRunData.toJSONString());
				ordersToCheck = (JSONArray)prevRunData.get("order_list");
			}
			log("I am here");
			String station =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
			kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(station, menuItemsToSelect)
				.verifyLandingPageWithPendingOrders(ordersToCheck)
				.validateCheckButton(ordersToCheck)
				.givenOrderCompletedInOrderHistory(ordersToCheck)
			.quitApp();	
			
			log("Successfully verified the Notify button for Guestapp orders in KDS");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the order from GuestApp to KDS. Error:" + e);
		}
	}
	

	@Test(dataProvider = "loadTestData")
	public void validateToGoInGuestAppConfirmation(JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			MenuMakerApp menuMakerApp = new MenuMakerApp(appObject, getRunParams());
			menuMakerApp.launch()
				.login()
				.createGivenFoodItems(foodItems)
				.quitApp();		
			log("Successfully created menu item in Caffeportal");
			
			//testData = getCustomizedTestDataForGuestApp(testData);
			log("The test data for the Guest app is:" + testData.toJSONString());
			
			//String caffe_location =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut() 
				.toGoValidation()
			.quitApp();	
			
			log("Successfully verified the To Go confirmation in Guestapp");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the To Go confirmation in Guestapp. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateForHereInGuestAppConfirmation(JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			MenuMakerApp menuMakerApp = new MenuMakerApp(appObject, getRunParams());
			menuMakerApp.launch()
				.login()
				.createGivenFoodItems(foodItems)
				.quitApp();		
			log("Successfully created menu item in Caffeportal");
			
			log("The test data for the Guest app is:" + testData.toJSONString());
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut() 
				.forHereValidation()
			.quitApp();	
			
			log("Successfully verified the To Go confirmation in Guestapp");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the To Go confirmation in Guestapp. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateToGoInGuestConfirmationForHereToGo(JSONObject testData) throws Exception {
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			MenuMakerApp menuMakerApp = new MenuMakerApp(appObject, getRunParams());
			menuMakerApp.launch()
				.login()
				.createGivenFoodItems(foodItems)
				.quitApp();		
			log("Successfully created menu item in Caffeportal");
			
			log("The test data for the Guest app is:" + testData.toJSONString());
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut() 
				.toGoValidation()
			.quitApp();	
			
			log("Successfully verified the To Go confirmation in Guestapp");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the To Go confirmation in Guestapp. Error:" + e);
		}
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void verifyCreatedCustomizedStandardFoodItemViaMenuMakerInGuestApp(JSONObject testData) throws Exception {
		
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);

			MenuMakerApp menuMakerApp = new MenuMakerApp(appObject, getRunParams());
			menuMakerApp.launch()
				.login()
				.createGivenFoodItems(foodItems)
				.quitApp();		
			
			//Customize the data required for guest app from data source
			log("The test data for the Guest app is:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(foodItems) 
				.quitApp();
			log("Successfully placed the menu item:");
			
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while newly created standard customized food item from MenuMaker in GuestApp. Error:" + e);
		}
	}	
	
	private JSONArray getTestDataFoodItemsForGuestApp(JSONObject testData, String key) {
		
		JSONArray foodItems = new JSONArray();
		JSONObject foodData = (JSONObject)getData(key);
		JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
		for(Object i : sourceFoodItems) {
			JSONObject obj = (JSONObject)i;
			obj.put("order_person_name", testData.get("order_person_name"));
			foodItems.add(i);
		}

		JSONArray foodItemsToRemove = (JSONArray)testData.get("food_items_to_remove");
		JSONArray foodItemsListAfterRemoval = (JSONArray)foodItems.clone();
		
		if(foodItemsToRemove != null && foodItemsToRemove.size() > 0) {
			
			String totalExpectedOrderValueAfterItemRemove = (String)testData.get("food_expected_total_order_value_after_remove");
			
			for(Object o : foodItemsToRemove) {
				String itemToRemove = (String)o;
				
				for(Object i : foodItems) {
					JSONObject item = (JSONObject)i;
					String itemName = (String)item.get("food_item_name");
					
					if(StringUtils.equalsIgnoreCase(itemToRemove, itemName)) {
						if(foodItemsListAfterRemoval.remove(item)) {
							log("Successfully removed the item:" + itemName);
							break;
						} else {
							log("Failed to remove the item:" + itemName);
						}
					}
				}
			}
		}
		log("The final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
		
		//Update the food item total cost if required
		DecimalFormat frmt  = new DecimalFormat("0.00");
		for(Object o : foodItemsListAfterRemoval) {
			JSONObject item = (JSONObject)o;
			boolean iscustomItem = (Boolean)item.get("is_custom_item");
			log("Is custom item:" + iscustomItem);
			if(iscustomItem) {
				String itemPrice = (String)item.get("food_item_price");
				log("Item price:" + itemPrice);
				JSONArray customItems = (JSONArray)item.get("customize_food_item");
				double changeToIncrease = 0;
				for(Object k : customItems) {
					JSONObject customItem = (JSONObject)k;
					log("Item :" + customItem.toJSONString());
					String customItemPrice = (String)customItem.get("customize_food_item_increase_price");
					log("Item price to increase:" + customItemPrice);
					if(StringUtils.isNotBlank(customItemPrice)) {
						changeToIncrease += Double.parseDouble(customItemPrice);
					}
				}
				String totalItemPrice = frmt.format(Double.parseDouble(itemPrice) + changeToIncrease);
				log("Total price is:" + totalItemPrice);
				item.put("select_food_item_price_final", totalItemPrice);
			}
			
		}
		log("The Updated final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
		
		return foodItemsListAfterRemoval;
	}
	
	
	private JSONObject getSpecialNonCustomizedTestDataForGuestApp(JSONObject testData) {
			
		JSONArray data = (JSONArray)testData.get("food_items_to_create");
		JSONObject sourceItem = (JSONObject)data.get(0);
		log("The source item is:" + sourceItem.toJSONString());
		JSONObject item  = new JSONObject();
		item.put("configure_caffe_station", (String)sourceItem.get("select_caffe_location"));
		JSONArray stations = new JSONArray();
		stations.add(sourceItem.get("select_station"));
		item.put("enable_menu_items", stations);
		
		JSONArray foodItems = new JSONArray();
		JSONObject itemToOrder = new JSONObject();
		itemToOrder.put("select_station_for_order", sourceItem.get("select_station"));
		itemToOrder.put("select_item_to_order", sourceItem.get("food_item_name"));
		itemToOrder.put("select_food_item_price", sourceItem.get("food_item_price"));
		itemToOrder.put("is_custom_item", sourceItem.get("is_custom_item"));
		
		foodItems.add(itemToOrder);
		item.put("food_items_to_order", foodItems);
		
		JSONArray foodITemsToRemove = new JSONArray();
		item.put("food_items_to_remove", foodITemsToRemove);
		item.put("food_expected_total_order_value_after_remove", "");
		
		return item;
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCreatedCustomizedStandardAndSpecialFoodItemViaMenuMakerInGuestApp(JSONObject testData) throws Exception {
		
		try {
			
			testData = (JSONObject)getData("StandardCustomizedMenuData");
			log("Test data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			
			MenuMakerApp menuMakerApp = new MenuMakerApp(appObject, getRunParams());
			menuMakerApp.launch()
				.login()
				.createGivenFoodItems(foodItemsList)
				.quitApp();		
			
			//Customize the data required for guest app from data source
			testData = getCustomizedTestDataForGuestApp(testData);
			log("The test data for the Guest app is:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(foodItems) 
				.quitApp();
			log("Successfully placed the menu item:");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while newly created standard food item from MenuMaker in GuestApp. Error:" + e);
		}
	}	
	
	@Test(dataProvider = "loadTestData")
	public void validateAddCustomizedMenuInGuestApp(JSONObject testData) throws Exception {
		
		log ("Test case name: validateAddMenuGuestApp");
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
			menuMaker.launch()
				.login()
				.createGivenFoodItems(foodItems)
				.quitApp();	
			log("Successfully created the menu item in Menumaker app");
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			log("Successfully verified the Menu item in guestApp");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the menu in GuestApp from Menumaker. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateAddStandardMenuInGuestApp(JSONObject testData) throws Exception {
		
		log ("Test case name: validateAddMenuGuestApp");
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
			menuMaker.launch()
				.login()
				.createGivenFoodItems(foodItems)
				.quitApp();	
			log("Successfully created the menu item in Menumaker app");
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.validateMenuDetails(foodItems, caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			log("Successfully verified the Menu item in guestApp");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the menu in GuestApp from Menumaker. Error:" + e);
		}
	}

	@Test(dataProvider = "loadTestData")
	public void validateAddCustomizedMenuInKiosk(JSONObject testData) throws Exception {
		
		log ("Test case name: validateAddCustomizedMenuInKiosk");
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
			menuMaker.launch()
				.login()
				.createGivenFoodItems(foodItems)
				.quitApp();	
			log("Successfully created the menu item in Menumaker app");

			
			KioskApp kiosk = new KioskApp(appObject, getRunParams());
			kiosk.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
				.validateMenuDetails(foodItems, caffe_location)
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			log("Successfully verified the Menu item in guestApp");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the menu in Kiosk from Menumaker. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateAddStandardMenuInKiosk(JSONObject testData) throws Exception {
		
		log ("Test case name: validateAddStandardMenuInKiosk");
		try {
			if(testData == null) {
				log("the data is not configured for this testcase");
			} else {
				log("The test data given is:" + testData.toJSONString());
			}
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String strDataKey = (String)testData.get("testdata_key");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
			
			MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
			menuMaker.launch()
				.login()
				.createGivenFoodItems(foodItems)
				.quitApp();	
			log("Successfully created the menu item in Menumaker app");
			
			
			KioskApp kiosk = new KioskApp(appObject, getRunParams());
			kiosk.launch()
				.login()
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
				.validateMenuDetails(foodItems, caffe_location)
				.quitApp();
			log("Successfully placed the menu item in guest app");
			
			log("Successfully verified the Menu item in guestApp");
		} catch(Exception e) {
			e.printStackTrace();
			Assert.assertTrue(false, "Exception while verifying the menu in Kiosk from Menumaker. Error:" + e);
		}
	}
	

	@Test(dataProvider = "loadTestData")
	public void validateActivatedStationInGuestApp(JSONObject testData) throws Exception {
		
		log ("Test case name: validateAddMenuGuestApp");
		
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}
		String caffe_location =  (String)testData.get("configure_caffe_station");
		String strDataKey = (String)testData.get("testdata_key");
		JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
		
		MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
		menuMaker.launch()
			.login()
			//.navigateToStationPage(foodItems)
			.activateStations(foodItems)
		.quitApp();	
		
		log("Successfully created the menu item in Menumaker app");
		
		GuestApp guestApp = new GuestApp(appObject, getRunParams());
		guestApp.launch()
			//.login()
			.selectCaffeLocation(caffe_location)
			//.orderGivenItems(foodItems, caffe_location)
			.validateStationName(foodItems)
			.quitApp();
		
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateDeactivatedStationInGuestApp(JSONObject testData) throws Exception {
		
		log ("Test case name: validateAddMenuGuestApp");
		
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}
		String caffe_location =  (String)testData.get("configure_caffe_station");
		String strDataKey = (String)testData.get("testdata_key");
		JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
		MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
		
		menuMaker.launch()
			.login()
			.deActivateStations(foodItems)
		.quitApp();	
		
		log("Successfully created the menu item in Menumaker app");
		JSONObject stationDetails= (JSONObject) foodItems.get(0);
		String station = (String) stationDetails.get("select_station");
		GuestApp guestApp = new GuestApp(appObject, getRunParams());
		guestApp.launch()
			//.login()
			.selectCaffeLocation(caffe_location)
			.validateStationIsPresent(station, caffe_location)
			.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateActivatedStationInKiosk(JSONObject testData) throws Exception {
		
		log ("Test case name: validateAddMenuGuestApp");
		
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}
		String caffe_location =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		String strDataKey = (String)testData.get("testdata_key");
		JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
		MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
	
		menuMaker.launch()
			.login()
			//.navigateToStationPage(foodItems)
			.activateStations(foodItems)
			.createGivenFoodItems(foodItems)
		.quitApp();	
		
		log("Successfully created the menu item in Menumaker app");
		
		KioskApp kiosk = new KioskApp(appObject, getRunParams());
		kiosk.launch()
			.login()
			//.enableSecuritySettings()
			//.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
			.orderGivenItems(foodItems)
			.quitApp();
		
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateDeactivatedStationInKiosk(JSONObject testData) throws Exception {
		
		log ("Test case name: validateAddMenuGuestApp");
		
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}
		String caffe_location =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		String strDataKey = (String)testData.get("testdata_key");
		JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
		MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
		
		menuMaker.launch()
			.login()
			.deActivateStations(foodItems)
		.quitApp();	
		
		log("Successfully created the menu item in Menumaker app");
		
		KioskApp kiosk = new KioskApp(appObject, getRunParams());
		kiosk.launch()
			.login()
			//.enableSecuritySettings()
			//.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
			.deActivateStations(caffe_location, foodItems)
			.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateActivatedStationInKDS2Up(JSONObject testData) throws Exception {
		log ("Test case name: validateAddMenuGuestApp");
		
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}
		String caffe_location =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		String strDataKey = (String)testData.get("testdata_key");
		JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
		
		MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
		menuMaker.launch()
			.login()
			.activateStations(foodItems)
		.quitApp();	
		
		log("Successfully created the menu item in Menumaker app");
		String station =  (String)testData.get("configure_caffe_station");
		KDSApp kdsApp = new KDSApp(appObject, getRunParams());
		kdsApp.launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.selectStationIn2Up(menuItemsToSelect)
			.quitApp();	
			
		log("Successfully verified the Cancel button in KDS");
		
	}
	
	@Test(dataProvider = "loadTestData")
	public void validatedeActivatedStationInKDS2Up(JSONObject testData) throws Exception {
		log ("Test case name: validateAddMenuGuestApp");
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}	
		String caffe_location =  (String)testData.get("configure_caffe_station");
	 	JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
	 	String strDataKey = (String)testData.get("testdata_key");
	 	JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
	 	MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
	 	menuMaker.launch()
	 		.login()
	 		.deActivateStations(foodItems)
	 		.quitApp();	
	 	
	 	log("Successfully created the menu item in Menumaker app");
	 	String station =  (String)testData.get("configure_caffe_station");
	 	KDSApp kdsApp = new KDSApp(appObject, getRunParams());
	 	kdsApp.launch()
	 		.login()
	 		.enableSecuritySettings()
	 		.selectStationAndMenuItems(station, menuItemsToSelect)
	 	 	.validate2UpFordeActivatedStations(foodItems)
	 	 	.quitApp();	
	 	log("Successfully verified the deactivated station in KDS 2up screen");
	 	}
	
	
	@Test(dataProvider = "loadTestData")
	public void validateActivatedStationInKDSAvailability(JSONObject testData) throws Exception {
		log ("Test case name: validateActivatedStationInKDSAvailability");
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}	
		String caffe_location =  (String)testData.get("configure_caffe_station");
	 	JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
	 	String strDataKey = (String)testData.get("testdata_key");
	 	JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
	 	
	 	MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
	 	menuMaker.launch()
	 		.login()
	 		.activateStations(foodItems)
	 	.quitApp();	
	 	
	 	log("Successfully created the menu item in Menumaker app");
	 	String station =  (String)testData.get("configure_caffe_station");
	 	KDSApp kdsApp = new KDSApp(appObject, getRunParams());
	 	kdsApp.launch()
	 		.login()
	 		.enableSecuritySettings()
	 		.selectStationAndMenuItems(station, menuItemsToSelect)
	 	 	.validateAvailabilityForActivatedStations(foodItems)
	 	 	.quitApp();	
	 	log("Successfully verified the deactivated station in KDS 2up screen");
	 	}
	
	
	@Test(dataProvider = "loadTestData")
	public void validatedeActivatedStationInKDSAvailability(JSONObject testData) throws Exception {
		log ("Test case name: validatedeActivatedStationInKDSAvailability");
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}	
		String caffe_location =  (String)testData.get("configure_caffe_station");
	 	JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
	 	String strDataKey = (String)testData.get("testdata_key");
	 	JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
	 	
	 	MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
	 	menuMaker.launch()
	 		.login()
	 		.deActivateStations(foodItems)
	 	.quitApp();	
	 	
	 	log("Successfully created the menu item in Menumaker app");
	 	String station =  (String)testData.get("configure_caffe_station");
	 	KDSApp kdsApp = new KDSApp(appObject, getRunParams());
	 	kdsApp.launch()
	 		.login()
	 		.enableSecuritySettings()
	 		.selectStationAndMenuItems(station, menuItemsToSelect)
	 	 	.validateAvailabilityFordeActivatedStations(foodItems)
	 	 	.quitApp();	
	 	log("Successfully verified the deactivated station in KDS Availability screen");
	 	}
	
	@Test(dataProvider = "loadTestData")
	public void validateSoldOutInKioskAndGuestapp(JSONObject testData) throws Exception {
		log ("Test case name: validateSoldOutInKiosk");
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}	
		String caffe_location =  (String)testData.get("configure_caffe_station");
	 	JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
	 	String strDataKey = (String)testData.get("testdata_key");
	 	JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
	 	
	 	MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
	 	menuMaker.launch()
	 		.login()
	 		.createGivenFoodItems(foodItems)
	 	.quitApp();	
	 	
	 	log("Successfully created the menu item in Menumaker app");
	 	//String station =  (String)testData.get("configure_caffe_station");
	 	GuestApp guestApp = new GuestApp(appObject, getRunParams());
		guestApp.launch()
		//	.login()
			.selectCaffeLocation(caffe_location)
			.orderGivenItems(foodItems, caffe_location)
			.ChangeOrderQuantity("25")
			.checkoutThroughPayrollDeduction()
			.soldOutValidation(foodItems)
			.quitApp();
	 	
	 	KioskApp kiosk = new KioskApp(appObject, getRunParams());
		kiosk.launch()
			.login()
			//.enableSecuritySettings()
			//.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
			.soldOutValidation(foodItems)
			.quitApp();
	 	log("Successfully verified the sold out menu in KDS");
			
	 	log("Successfully verified the deactivated station in KDS Availability screen");
	 	}
	
	
	
	
	@Test(dataProvider = "loadTestData")
	public void validatePlaceOrderWhenCapLimitedInGuestApp(JSONObject testData) throws Exception {
		log ("Test case name: validatePlaceOrderWhenCapLimitedInGuestApp");
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}	
		String caffe_location =  (String)testData.get("configure_caffe_station");
	 	//JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
	 	String strDataKey = (String)testData.get("testdata_key");
	 	JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
	 	
	 	MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
	 	menuMaker.launch()
	 		.login()
	 		.createGivenFoodItems(foodItems)
	 	.quitApp();	
	 	
	 	log("Successfully created the menu item in Menumaker app");
	 	//String station =  (String)testData.get("configure_caffe_station");
	 	
	 	GuestApp guestApp = new GuestApp(appObject, getRunParams());
		guestApp.launch()
			.login()
			.selectCaffeLocation(caffe_location)
			.orderGivenItems(foodItems, caffe_location)
			.ChangeOrderQuantityWhenLimited("27");
		
	 	log("Successfully verified the deactivated station in KDS Availability screen");
	 	}
	
	@Test(dataProvider = "loadTestData")
	public void validateItemInGuestAppAndKioskWhenMarketSoldOutKDS(JSONObject testData) throws Exception {
		log ("Test case name: validatePlaceOrderWhenCapLimitedInGuestApp");
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}	
		//String caffe_location =  (String)testData.get("configure_caffe_station");
		String station =  (String)testData.get("configure_caffe_station");
	 	JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
	 	String strDataKey = (String)testData.get("testdata_key");
	 	JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
	 	KDSApp kdsApp = new KDSApp(appObject, getRunParams());
	 	kdsApp.launch()
	 		.login()
	 		.enableSecuritySettings()
	 		.selectStationAndMenuItems(station, menuItemsToSelect)
	 	 	.validateAvailabilityButton1(foodItems, false)
	 	 	.quitApp();	
	 	
	 	log("Successfully marked the item as sold out in KDS");
	 	
	 	GuestApp guestApp = new GuestApp(appObject, getRunParams());
		guestApp.launch()
			//.login()
			.selectCaffeLocation(station)
			.soldOutValidation(foodItems)
		.quitApp();
	 	log("Successfully verified the sold out menu in Guestapp");
	 	
	 	KioskApp kiosk = new KioskApp(appObject, getRunParams());
		kiosk.launch()
			.login()
			//.enableSecuritySettings()
			//.selectStationAndMenuItems(station, menuItemsToSelect)
			.soldOutValidation(foodItems)
			.quitApp();
	 	log("Successfully verified the sold out menu in Kiosk");
	 	
	 	kdsApp.launch()
 		.login()
 		.enableSecuritySettings()
 		.selectStationAndMenuItems(station, menuItemsToSelect)
 	 	.validateAvailabilityButton1(foodItems, true)
 	 	.quitApp();	
	 	
	 	log("Successfully unmarked the item as sold out in KDS");
	 	
	 	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCaffeIsClosedInGuestApp(JSONObject testData) throws Exception {
		log ("Test case name: verifyCaffeIsClosedInGuestApp");
	
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}
		String caffe_location =  (String)testData.get("configure_caffe_station");
		String strDataKey = (String)testData.get("testdata_key");
		//JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
	
		testData = (JSONObject)getData(strDataKey);
		log("Data:" + testData.toJSONString());
		JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
		MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
		menuMaker.launch()
			.login()
			.navigateToCaffePage(caffeDetails)
			.verifyAddSchedule()
		.quitApp();	
		
		GuestApp guestApp = new GuestApp(appObject, getRunParams());
		guestApp.launch()
			//.login()
			.selectCaffeLocation(caffe_location)
			.verifyCaffeClosed()
			.quitApp();

	}
	
	

@Test(dataProvider = "loadTestData")
public void validateRemoveMenuInKDSAvailability(JSONObject testData) throws Exception {
log ("Test case name: verifyCaffeIsClosedInGuestApp");

try {
	log("Data:" + testData.toJSONString());
	JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_delete");
	JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
	String strDataKey = (String)testData.get("testdata_key");
	JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
	
	MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
	menuMaker.launch()
		.login()
		.createGivenFoodItems(foodItems)
		.removeFoodItems(foodItemsList)
		.quitApp();	
	log("Successfully created the menu item in Menumaker app");

	String station =  (String)testData.get("configure_caffe_station");
	log("The station is: "+station);
	KDSApp kdsApp = new KDSApp(appObject, getRunParams());
	kdsApp.launch()
		.login()
		.enableSecuritySettings()
		.selectStationAndMenuItems(station, menuItemsToSelect)
		.validateRemoveMenuItemInAvailability(foodItemsList)
		.quitApp();	
	
	menuMaker.launch()
		.login()
		.createGivenFoodItems(foodItems)
		.quitApp();	
	log("Successfully created the menu item again in Menumaker app");

	} catch(Exception e) {
	Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
}
}

@Test(dataProvider = "loadTestData")
public void validateGrabnGoStationInGuestApp(JSONObject testData) throws Exception {

log ("Test case name: validateGrabnGoStationInGuestApp");
try {
	log("Data:" + testData.toJSONString());
	String caffe_location =  (String)testData.get("configure_caffe_station");
	//String strDataKey = (String)testData.get("testdata_key");

	//testData = (JSONObject)getData(strDataKey);
	JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
	log("The caffe details");
	MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
	menuMaker.launch()
		.login()
		.navigateToStationPage(caffeDetails)
		.verifyStationType(caffeDetails)
	.quitApp();
	
	GuestApp guestApp = new GuestApp(appObject, getRunParams());
	guestApp.launch()
		//.login()
		.selectCaffeLocation(caffe_location)
		.verifyCaffeClosed()
		.quitApp();

}catch(Exception e) {
	Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
}
}


	@Test(dataProvider = "loadTestData")
	public void verifyCaffeIsClosedInKiosk(JSONObject testData) throws Exception {
		
		log ("Test case name: verifyCaffeIsClosedInKiosk");
		
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}
		String caffe_location =  (String)testData.get("configure_caffe_station");
		
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
		
		log("About to launch MenuMaker");
		MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
		menuMaker.launch()
			.login()
			.navigateToCaffePage(caffeDetails)
			.verifyAddSchedule()
		.quitApp();	
		
		KioskApp kioskApp = new KioskApp(appObject, getRunParams());

		kioskApp.launch()
		.login()
		//.enableSecuritySettings()
		//.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
		.verifyCaffeClosed(menuItemsToSelect)
		.quitApp();

	}

	@Test(dataProvider = "loadTestData")
	public void verifyCaffeIsClosedForNonMealTimeInKiosk(JSONObject testData) throws Exception {
		
		log ("Test case name: verifyCaffeIsClosedForNonMealTimeInKiosk");
		
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}
		String caffe_location =  (String)testData.get("configure_caffe_station");
		
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		JSONArray caffeDetails = (JSONArray)testData.get("AlvesCaffeValidation_Existing_UAT");
		
		log("About to launch MenuMaker");
		MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
		menuMaker.launch()
			.login()
			.navigateToCaffePage(caffeDetails)
			.verifyAddSchedule()
		.quitApp();	
		
		KioskApp kioskApp = new KioskApp(appObject, getRunParams());

		kioskApp.launch()
		.login()
		.enableSecuritySettings()
		.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
		.verifyCaffeClosed(menuItemsToSelect)
		.quitApp();

	}
	

	@Test(dataProvider = "loadTestData")
	public void verifyCaffeIsOpenInGuestApp(JSONObject testData) throws Exception {
		
		log ("Test case name: verifyCaffeIsOpenInGuestApp");
		
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}
		String caffe_location =  (String)testData.get("configure_caffe_station");
		String strDataKey = (String)testData.get("testdata_key");
		//JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
	
		testData = (JSONObject)getData(strDataKey);
		log("Data:" + testData.toJSONString());
		JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
		MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
		menuMaker.launch()
			.login()
			.navigateToCaffePage(caffeDetails)
			.verifyAddSchedule()
		.quitApp();	
		
		GuestApp guestApp = new GuestApp(appObject, getRunParams());
		guestApp.launch()
			.login()
			.selectCaffeLocation(caffe_location)
			.verifyCaffeClosed()
			.quitApp();

	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCaffeIsOpenInKiosk(JSONObject testData) throws Exception {
		
		log ("Test case name: verifyCaffeIsOpenInKiosk");
		
		if(testData == null) {
			log("the data is not configured for this testcase");
		} else {
			log("The test data given is:" + testData.toJSONString());
		}
		String caffe_location =  (String)testData.get("configure_caffe_station");
		
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		JSONArray caffeDetails = (JSONArray)testData.get("AlvesCaffeValidation_Existing_UAT");
		
		log("About to launch MenuMaker");
		MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
		menuMaker.launch()
			.login()
			.navigateToCaffePage(caffeDetails)
			.verifyAddSchedule()
		.quitApp();	
		
		KioskApp kioskApp = new KioskApp(appObject, getRunParams());

		kioskApp.launch()
		.login()
		.enableSecuritySettings()
		.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
		.verifyCaffeClosed(menuItemsToSelect)
		.quitApp();

	}


	@Test(dataProvider = "loadTestData")
	public void validateRemoveMenuInGuestApp(JSONObject testData) throws Exception {
		
		log ("Test case name: validateRemoveMenuInGuestApp");
		
		try {
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_delete");
			MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
			menuMaker.launch()
				.login()
				.removeFoodItems(foodItemsList)
			.quitApp();	
			
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			String caffe_location = (String) foodItem.get("select_caffe_location");
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateRemoveMenuInKioskApp(JSONObject testData) throws Exception {
		
		log ("Test case name: verifyCaffeIsClosedInGuestApp");
		
		try {
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_delete");
			MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
			menuMaker.launch()
				.login()
				.removeFoodItems(foodItemsList)
			.quitApp();	
			
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			String station = (String) foodItem.get("select_caffe_location");
			JSONArray enableStations = (JSONArray)foodItem.get("select_stations");
			KioskApp kioskApp = new KioskApp(appObject, getRunParams());
			kioskApp.launch()
				.login()
				//.enableSecuritySettings()
				.validateMenuItemIsRemoved(station,  enableStations)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
		}
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void validateChangedMenuNameInGuestApp(JSONObject testData) throws Exception {
		
		log ("Test case name: validateRemoveMenuInGuestApp");
		
		try {
			JSONArray foodItemDetail = (JSONArray) testData.get("food_item_to_change");
			log(foodItemDetail.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			
			MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
			menuMaker.launch()
				.login()
				.createGivenFoodItems(foodItemsList)
				.changeFoodItemName((JSONObject)foodItemDetail.get(0))
			.quitApp();	
			
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			String caffe_location = (String) foodItem.get("select_caffe_location");
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItemDetail, caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateChangedStationNameInGuestApp(JSONObject testData) throws Exception {
		
		log ("Test case name: validateChangedStationNameInGuestApp");
		
		try {
			log("Data:" + testData.toJSONString());
			String changeStationName = (String) testData.get("station_name_change");
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
		
			MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
			menuMaker.launch()
				.login()
				.modifyStationName(caffeDetails , changeStationName)
				.quitApp();	
			
			JSONObject foodItem = (JSONObject) caffeDetails.get(0);
			String caffe_location = (String) foodItem.get("select_caffe_location");
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.validateStation(changeStationName,caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateChangedStationNameInKDS(JSONObject testData) throws Exception {
		
		log ("Test case name: validateChangedStationNameInKDS");
		
		try {
			log("Data:" + testData.toJSONString());
			String changeStationName = (String) testData.get("station_name_change");
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
		
			MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
			menuMaker.launch()
				.login()
				.modifyStationName(caffeDetails , changeStationName)
				.quitApp();	
			
			log(caffeDetails.toJSONString());

			JSONObject caffeDetail = (JSONObject)caffeDetails.get(0);

			String caffe = (String)caffeDetail.get("select_caffe_location");
			JSONArray changedStation = (JSONArray) caffeDetail.get("select_station");
			log(changedStation.toJSONString());
			log(caffe);
			
			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
			kdsApp.launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(caffe, changedStation)
		.quitApp();	
			log("Successfully validated in KDS");
			
			GuestApp guestApp = new GuestApp(appObject, getRunParams());
			guestApp.launch()
				//.login()
				.selectCaffeLocation(caffe)
				.validateStation(changeStationName,caffe)
			.quitApp();
			log("Successfully validated in guestApp");
			/*
			KioskApp kioskApp = new KioskApp(appObject, getRunParams());
			kioskApp.launch()
				.login()
				//.enableSecuritySettings()
				.selectStationAndMenuItems(caffe, changedStation)
			.quitApp();
			*/
			log("Sucessfully validated in Kiosk");
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateChangedStationNameInKiosk(JSONObject testData) throws Exception {
		
		log ("Test case name: validateChangedStationNameInKiosk");
		
		try {
			log("Data:" + testData.toJSONString());
			String changeStationName = (String) testData.get("station_name_change");
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
		
			MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
			menuMaker.launch()
				.login()
				.modifyStationName(caffeDetails , changeStationName)
				.quitApp();	
			
			log(caffeDetails.toJSONString());
			JSONObject foodItem = (JSONObject) caffeDetails.get(0);
			log(foodItem.toJSONString());
			JSONArray changedStation = (JSONArray) foodItem.get("select_station");
			String caffe_location = (String) foodItem.get("select_caffe_location");
			
			KioskApp kioskApp = new KioskApp(appObject, getRunParams());
			kioskApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(caffe_location, changedStation)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
		}
	}
	
		@Test(dataProvider = "loadTestData")
		public void validateMainStationInGuestApp(JSONObject testData) throws Exception {
			log ("Test case name: validateMainStationInGuestApp");
			try {
				log("Data:" + testData.toJSONString());
				String caffe_location =  (String)testData.get("configure_caffe_station");
				//String strDataKey = (String)testData.get("testdata_key");
		
			//testData = (JSONObject)getData(strDataKey);
				JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
				log("The caffe details");
				
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.navigateToStationPage(caffeDetails)
					.verifyStationTypeForHere(caffeDetails)
				.quitApp();	
				
				GuestApp guestApp = new GuestApp(appObject, getRunParams());
				guestApp.launch()
					.login()
					.selectCaffeLocation(caffe_location)
					.orderGivenItems(caffeDetails, caffe_location)
					.verifyStationInForHere()
					.quitApp();
		
			}catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
			}
		}
		
		@Test(dataProvider = "loadTestData")
		public void validateGrabnGoToGoInGuestApp(JSONObject testData) throws Exception {
			
			log ("Test case name: validateMainStationInGuestApp");
			try {
				log("Data:" + testData.toJSONString());
				String caffe_location =  (String)testData.get("configure_caffe_station");
				//String strDataKey = (String)testData.get("testdata_key");
		
				//testData = (JSONObject)getData(strDataKey);
				JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
				log("The caffe details");
				
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.navigateToStationPage(caffeDetails)
					.verifyStationTypeToGo(caffeDetails)
				.quitApp();	
				
	 			GuestApp guestApp = new GuestApp(appObject, getRunParams());
	 			guestApp.launch()
	 				.login()
	 				.selectCaffeLocation(caffe_location)
					.verifyCaffeClosed()
					.orderGivenItems(caffeDetails, caffe_location)
					.verifyStationInToGo()
					.checkoutThroughPayrollDeduction()
				.toGoValidation()
	 				.quitApp();
		
		
	 		}catch(Exception e) {
	 			Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
	 		}
		}
		
		@Test(dataProvider = "loadTestData")
		public void verifyMenuDisplayOrderGuestApp(JSONObject testData) throws Exception {
			
			log ("Test case name: verifyMenuDisplayOrderGuestApp");
			try {
				log("Data:" + testData.toJSONString());
				//String caffe_location =  (String)testData.get("configure_caffe_station");
				JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
				JSONObject caffeDetail = (JSONObject)caffeDetails.get(0);
				log("The caffe details" +caffeDetail.toJSONString());
				String caffe =  (String)caffeDetail.get("select_caffe_location");
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.getDisplayOrderMenu(caffeDetail)
				.quitApp();	
				log(menuMaker.foodItemCollection.toString());
				log(menuMaker.foodItemNameDisplayOrderCollection.toString());
				
				//HashMap <Integer,String> menumakerDispOrder = new HashMap<Integer,String>();
				
				//menumakerDispOrder= menuMaker.foodItemNameDisplayOrderCollection;
				//log(menumakerDispOrder.toString());
	 			GuestApp guestApp = new GuestApp(appObject, getRunParams());
	 			guestApp.launch()
	 				//.login()
	 				.selectCaffeLocation(caffe)
	 				.validateMenuDisplayOrder(caffe,caffeDetail,menuMaker.foodItemNameDisplayOrderCollection)
	 				.quitApp();
		
		
	 		}catch(Exception e) {
	 			Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
	 		}
		}
		
		@Test(dataProvider = "loadTestData")
		public void verifyMenuDisplayOrderKiosk(JSONObject testData) throws Exception {
			
			log ("Test case name: verifyMenuDisplayOrderKiosk");
			try {
				log("Data:" + testData.toJSONString());
				//String caffe_location =  (String)testData.get("configure_caffe_station");
				JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
				JSONObject caffeDetail = (JSONObject)caffeDetails.get(0);
				log("The caffe details" +caffeDetail.toJSONString());
				String caffe =  (String)caffeDetail.get("select_caffe_location");
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.getDisplayOrderMenu(caffeDetail)
				.quitApp();	
				log(menuMaker.foodItemCollection.toString());
				log(menuMaker.foodItemNameDisplayOrderCollection.toString());
				
				HashMap <Integer,String> menumakerDispOrder = new HashMap<Integer,String>();
				
				menumakerDispOrder= menuMaker.foodItemNameDisplayOrderCollection;
				log(menumakerDispOrder.toString());
				
				JSONArray menuItemsToSelect= (JSONArray) caffeDetail.get("select_stations");
				log(menuItemsToSelect.toJSONString());
	 			KioskApp kioskApp = new KioskApp(appObject, getRunParams());
	 			kioskApp.launch()
	 				.login()
	 			//	.enableSecuritySettings()
	 				//.selectStationAndMenuItems(caffe, menuItemsToSelect)
	 				.validateMenuDisplayOrder(caffeDetail,menumakerDispOrder)
	 			.quitApp();

	 		}catch(Exception e) {
	 			Assert.assertTrue(false, "Exception while testing menu display order. Error:" + e);
	 			
	 		}
		}
		
		@Test(dataProvider = "loadTestData")
		public void verifyStationDisplayOrderGuestApp(JSONObject testData) throws Exception {
			
			log ("Test case name: verifyStationDisplayOrderGuestApp");
			try {
				log("Data:" + testData.toJSONString());
				//String caffe_location =  (String)testData.get("configure_caffe_station");
				JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
				JSONObject caffeDetail = (JSONObject)caffeDetails.get(0);
				log("The caffe details" +caffeDetail.toJSONString());
				String caffe =  (String)caffeDetail.get("select_caffe_location");
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.getDisplayOrderStation(caffeDetails)
					//.checkItemsAvailablityForStations(caffeDetails)
				.quitApp();	
				
				log(menuMaker.stationOrder.toString());
				//log(menuMaker.foodItemNameDisplayOrderCollection.toString());
				
				//HashMap <Integer,String> menumakerDispOrder = new HashMap<Integer,String>();
				
				//menumakerDispOrder= menuMaker.foodItemNameDisplayOrderCollection;
				//log(menumakerDispOrder.toString());
	 			GuestApp guestApp = new GuestApp(appObject, getRunParams());
	 			guestApp.launch()
	 				//.login()
	 				.selectCaffeLocation(caffe)
	 				.validateStationDisplayOrder(caffeDetail,menuMaker.stationOrder)
	 				.quitApp();
		
		
	 		}catch(Exception e) {
	 			Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
	 		}
		}
		
		@Test(dataProvider = "loadTestData")
		public void verifyStationDisplayOrderKiosk(JSONObject testData) throws Exception {
			
			log ("Test case name: verifyStationDisplayOrderKiosk");
			try {
				log("Data:" + testData.toJSONString());
				//String caffe_location =  (String)testData.get("configure_caffe_station");
				JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
				JSONObject caffeDetail = (JSONObject)caffeDetails.get(0);
				log("The caffe details" +caffeDetail.toJSONString());
				String caffe =  (String)caffeDetail.get("select_caffe_location");
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.getDisplayOrderStation(caffeDetails)
					//.checkItemsAvailablityForStations(caffeDetails)
				.quitApp();	
				
				log(menuMaker.stationOrder.toString());
				//log(menuMaker.foodItemNameDisplayOrderCollection.toString());
				
				//HashMap <Integer,String> menumakerDispOrder = new HashMap<Integer,String>();
				
				//menumakerDispOrder= menuMaker.foodItemNameDisplayOrderCollection;
				//log(menumakerDispOrder.toString());
	 			KioskApp kioskApp = new KioskApp(appObject, getRunParams());
	 			kioskApp.launch()
	 				.login()
	 				.enableSecuritySettings()
	 				.validateStationDisplayOrder(caffeDetail,menuMaker.stationOrder)
	 				.quitApp();
		
		
	 		}catch(Exception e) {
	 			Assert.assertTrue(false, "Exception while testing display order kiosk. Error:" + e);
	 		}
		}
		@Test(dataProvider = "loadTestData")
		public void validateGrabnGoStationInKiosk(JSONObject testData) throws Exception {
			
			log ("Test case name: validateGrabnGoStationInKiosk");
			try {
				log("Data:" + testData.toJSONString());
				String caffe_location =  (String)testData.get("configure_caffe_station");
				JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
				JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
				log("The caffe details");
				
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.navigateToStationPage(caffeDetails)
					.verifyStationTypeToGo(caffeDetails)
				.quitApp();	
				
				KioskApp kioskApp = new KioskApp(appObject, getRunParams());
				kioskApp.launch()
					.login()
					.enableSecuritySettings()
					.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
					.orderGivenItems(caffeDetails)
					//.verifyStationInToGo()
					.quitApp();
		
			}catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
			}
		}

		@Test(dataProvider = "loadTestData")
		public void validateGuestAppWaitTimeToKDS(JSONObject testData) throws Exception {
			
			log ("Test case name: validateGuestAppWaitTimeToKDS");
			try {
				
				String testDataKey = (String)testData.get("testdata_key");
				log("The test data to be taken is from:" + testDataKey);
				JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
				
				testData = (JSONObject)getData(testDataKey);
				log("Data:" + testData.toJSONString());
				JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
				JSONObject foodItem = (JSONObject) foodItemsList.get(0);		
				
				log("Data:" + testData.toJSONString());
				String caffe_location =  (String)foodItem.get("select_caffe_location");
				//JSONArray caffeDetails = (JSONArray)foodItem.get("caffe_details");
						
				
				log("The caffe details");
				
	 			GuestApp guestApp = new GuestApp(appObject, getRunParams());
	 			guestApp.launch()
	 				//.login()
	 				.selectCaffeLocation(caffe_location)
	 				.validateStationWaitTime(foodItemsList, caffe_location)
	 			.quitApp();
	 			String waitTime = guestApp.temp;
				
	 			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
				kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(caffe_location,menuItemsToSelect)
				.validateGuestAppWaitTimeValidation(waitTime, menuItemsToSelect)
			.quitApp();	
		
			}catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
			}
		}
		
		@Test(dataProvider = "loadTestData")
		public void validateKioskWaitTimeToKDS(JSONObject testData) throws Exception {
//Failed Test case - Kiosk is not working as expected
			log ("Test case name: validateKioskWaitTimeToKDS");
			try {
				String timeToIncrease= (String)testData.get("increase_time");
				String testDataKey = (String)testData.get("testdata_key");
				log("The test data to be taken is from:" + testDataKey);
				JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
				
				testData = (JSONObject)getData(testDataKey);
				log("Data:" + testData.toJSONString());
				JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
				JSONObject foodItem = (JSONObject) foodItemsList.get(0);		
				
				log("Data:" + testData.toJSONString());
				String caffe_location =  (String)foodItem.get("select_caffe_location");
				//JSONArray caffeDetails = (JSONArray)foodItem.get("caffe_details");
						
				
				log("The caffe details");
				
				KioskApp kioskApp = new KioskApp(appObject, getRunParams());
				kioskApp.launch()
					.login()
					//.enableSecuritySettings()
					//.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
					.validateStationWaitTime(foodItemsList, caffe_location)
				.quitApp();
	 			String waitTime = kioskApp.temp;
				
	 			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
	 			kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(caffe_location,menuItemsToSelect)
				.validateGuestAppWaitTimeValidation(waitTime, menuItemsToSelect)
				.increaseWaitTime(timeToIncrease, menuItemsToSelect)
			.quitApp();	
				
			String waitTime1 = kdsApp.temp;
			
			kioskApp.launch()
				.login()
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
				.validateIncreaseInStationWaitTime(waitTime1, foodItemsList, caffe_location)
			.quitApp();
			
			kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(caffe_location,menuItemsToSelect)
				.resetWaitTime(menuItemsToSelect)
				.quitApp();	
			String waitTime2 = kdsApp.temp;
			
			kioskApp.launch()
				.login()
				//.enableSecuritySettings()
				//.selectStationAndMenuItems(caffe_location, menuItemsToSelect)
				.validateStationWaitTime(foodItemsList, caffe_location)
				.assertWaitTime(waitTime2)
			.quitApp();
		
			}catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
			}
		}
		
		@Test(dataProvider = "loadTestData")
		public void validateGuestAppIncreaseWaitTimeInKDS(JSONObject testData) throws Exception {
			
			log ("Test case name: validateGuestAppIncreaseWaitTimeInKDS");
			try {
				
				String timeToIncrease= (String)testData.get("increase_time");
				
				String testDataKey = (String)testData.get("testdata_key");
				log("The test data to be taken is from:" + testDataKey);
				JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
				
				testData = (JSONObject)getData(testDataKey);
				log("Data:" + testData.toJSONString());
				JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
				JSONObject foodItem = (JSONObject) foodItemsList.get(0);		
				
				log("Data:" + testData.toJSONString());
				String caffe_location =  (String)foodItem.get("select_caffe_location");
				//JSONArray caffeDetails = (JSONArray)foodItem.get("caffe_details");
						
				
				log("The caffe details");
				
				KDSApp kdsApp = new KDSApp(appObject, getRunParams());
				kdsApp.launch()
					.login()
					.enableSecuritySettings()
					.selectStationAndMenuItems(caffe_location,menuItemsToSelect)
					.increaseWaitTime(timeToIncrease, menuItemsToSelect)
				.quitApp();	
				String waitTime = kdsApp.temp;
				
	 			GuestApp guestApp = new GuestApp(appObject, getRunParams());
	 			guestApp.launch()
	 				//.login()
	 				.selectCaffeLocation(caffe_location)
	 				.validateIncreaseInStationWaitTime(waitTime, foodItemsList, caffe_location)
	 			.quitApp();
			}catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
			}
		}
		
		
		@Test(dataProvider = "loadTestData"/*, dependsOnMethods = { "validateGuestAppIncreaseWaitTimeInKDS" }*/)
		public void validateGuestAppDecreaseWaitTimeInKDS(JSONObject testData) throws Exception {
			
			log ("Test case name: validateGuestAppDecreaseWaitTimeInKDS");
			try {
				
				String testDataKey = (String)testData.get("testdata_key");
				log("The test data to be taken is from:" + testDataKey);
				JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
				
				testData = (JSONObject)getData(testDataKey);
				log("Data:" + testData.toJSONString());
				JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
				JSONObject foodItem = (JSONObject) foodItemsList.get(0);		
				
				log("Data:" + testData.toJSONString());
				String caffe_location =  (String)foodItem.get("select_caffe_location");
				//String station =  (String)foodItem.get("select_station");
				//JSONArray caffeDetails = (JSONArray)foodItem.get("caffe_details");
						
				
				log("The caffe details");
	 			KDSApp kdsApp = new KDSApp(appObject, getRunParams());
				kdsApp.launch()
				.login()
				.enableSecuritySettings()
				.selectStationAndMenuItems(caffe_location,menuItemsToSelect)
				.resetWaitTime(menuItemsToSelect)
				.quitApp();	
				String waitTime = kdsApp.temp;
	 			GuestApp guestApp = new GuestApp(appObject, getRunParams());
	 			guestApp.launch()
	 				//.login()
	 				.selectCaffeLocation(caffe_location)
	 				.validateStationWaitTime(foodItemsList, caffe_location)
	 				.assertWaitTime(waitTime)
	 			.quitApp();		
	 			}catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
			}
		}
		
		
		@Test(dataProvider = "loadTestData")
		public void validateSpecialsInGuestApp(JSONObject testData) throws Exception {
			
			log ("Test case name: validateSpecialsInGuestApp");
			try {
				if(testData == null) {
					log("the data is not configured for this testcase");
				} else {
					log("The test data given is:" + testData.toJSONString());
				}
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String strDataKey = (String)testData.get("testdata_key");
				JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
				
				
				log("Data:" + testData.toJSONString());
				
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.createGivenFoodItems(foodItems)
					.quitApp();	
				log("Successfully created the menu item in Menumaker app");
				
				GuestApp guestApp = new GuestApp(appObject, getRunParams());
				guestApp.launch()
					.login()
					.selectCaffeLocation(caffe_location)
					.validateFoodItemType(caffe_location,foodItems)
					.quitApp();
				
				log("Successfully verified the Menu item in guestApp");
			} catch(Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false, "Exception while verifying the menu in GuestApp from Menumaker. Error:" + e);
			}
		}
		
		@Test(dataProvider = "loadTestData")
		public void validateStandardsInGuestApp(JSONObject testData) throws Exception {
			
			log ("Test case name: validateStandardsInGuestApp");
			try {
				if(testData == null) {
					log("the data is not configured for this testcase");
				} else {
					log("The test data given is:" + testData.toJSONString());
				}
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String strDataKey = (String)testData.get("testdata_key");
				JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
				
				
				log("Data:" + testData.toJSONString());
				
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.createGivenFoodItems(foodItems)
					.quitApp();	
				log("Successfully created the menu item in Menumaker app");
				
				GuestApp guestApp = new GuestApp(appObject, getRunParams());
				guestApp.launch()
					.login()
					.selectCaffeLocation(caffe_location)
					.validateFoodItemType(caffe_location,foodItems)
					.quitApp();
				
				log("Successfully verified the Menu item in guestApp");
			} catch(Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false, "Exception while verifying the menu in GuestApp from Menumaker. Error:" + e);
			}
		}
		@Test(dataProvider = "loadTestData")
		public void validateVariableMenuNotDisplayedInGuestApp(JSONObject testData) throws Exception {
			
			log ("Test case name: validateVariableMenuNotDisplayedInGuestApp");
			try {
				if(testData == null) {
					log("the data is not configured for this testcase");
				} else {
					log("The test data given is:" + testData.toJSONString());
				}
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String strDataKey = (String)testData.get("testdata_key");
				JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
				
				
				log("Data:" + testData.toJSONString());
				
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.activateStations(foodItems)
					.createGivenFoodItems(foodItems)
					.quitApp();	
				log("Successfully created the menu item in Menumaker app");
				
				GuestApp guestApp = new GuestApp(appObject, getRunParams());
				guestApp.launch()
					//.login()
					.selectCaffeLocation(caffe_location)
					.verifyCaffeClosed()
					.quitApp();
				log("Successfully placed the menu item in guest app");
				
				log("Successfully verified the Menu item in guestApp");
			} catch(Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false, "Exception while verifying the menu in GuestApp from Menumaker. Error:" + e);
			}
		}
		
		@Test(dataProvider = "loadTestData")
		public void placeOrderVariableMenuInGuestApp(JSONObject testData) throws Exception {
			
			log ("Test case name: placeOrderVariableMenuInGuestApp");
			try {
				if(testData == null) {
					log("the data is not configured for this testcase");
				} else {
					log("The test data given is:" + testData.toJSONString());
				}
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String strDataKey = (String)testData.get("testdata_key");
				JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
				
				
				log("Data:" + testData.toJSONString());
				
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.activateStations(foodItems)
					.createGivenFoodItems(foodItems)
					.quitApp();	
				log("Successfully created the menu item in Menumaker app");
				
				GuestApp guestApp = new GuestApp(appObject, getRunParams());
				guestApp.launch()
					//.login()
					.selectCaffeLocation(caffe_location)
					.validateMenuDetails(foodItems, caffe_location)
					.orderGivenItems(foodItems, caffe_location)
					.checkOut(foodItems) 
					.quitApp();
				log("Successfully placed the menu item in guest app");
				
				log("Successfully verified the Menu item in guestApp");
			} catch(Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false, "Exception while verifying the menu in GuestApp from Menumaker. Error:" + e);
			}
		}
		
		@Test(dataProvider = "loadTestData")
		public void validateVariableMenuInKiosk(JSONObject testData) throws Exception {
			
			log ("Test case name: validateVariableMenuInKiosk");
			try {
				if(testData == null) {
					log("the data is not configured for this testcase");
				} else {
					log("The test data given is:" + testData.toJSONString());
				}
				String username = (String) testData.get("employee_username");
				String password = (String) testData.get("employee_password");
				JSONArray selectStations = (JSONArray) testData.get("enable_menu_items");
				
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String strDataKey = (String)testData.get("testdata_key");
				JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);

				
				log("Data:" + testData.toJSONString());
				
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch(username,password)
					.login(username,password)
					.activateStations(foodItems)
					.createGivenFoodItems(foodItems)
					.quitApp();	
				log("Successfully created the menu item in Menumaker app");
				
				KioskApp kioskApp = new KioskApp(appObject, getRunParams());
				kioskApp.launch()
					.login()
					.enableSecuritySettings()
					.selectStationAndMenuItems(caffe_location, selectStations)
					.validateMenuDetails(foodItems, caffe_location)
				.quitApp();

				log("Successfully verified the Menu item in guestApp");
			} catch(Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false, "Exception while verifying the menu in GuestApp from Menumaker. Error:" + e);
			}
		}
		
		@Test(dataProvider = "loadTestData")
		public void validateVariableMenuNotDisplayedInKiosk(JSONObject testData) throws Exception {
			
			log ("Test case name: validateVariableMenuNotDisplayedInKiosk");
			try {
				if(testData == null) {
					log("the data is not configured for this testcase");
				} else {
					log("The test data given is:" + testData.toJSONString());
				}
				JSONArray selectStations = (JSONArray) testData.get("enable_menu_items");
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String strDataKey = (String)testData.get("testdata_key");
				JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
				
				
				log("Data:" + testData.toJSONString());
				
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.activateStations(foodItems)
					.createGivenFoodItems(foodItems)
					.quitApp();	
				log("Successfully created the menu item in Menumaker app");
				
				KioskApp kioskApp = new KioskApp(appObject, getRunParams());
				kioskApp.launch()
					.login()
					.enableSecuritySettings()
					.selectStationAndMenuItems(caffe_location, selectStations)
					.verifyCaffeClosed(foodItems)
				.quitApp();
				
				
				log("Successfully verified the Menu item in guestApp");
			} catch(Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false, "Exception while verifying the menu in GuestApp from Menumaker. Error:" + e);
			}
		}
		
		@Test(dataProvider = "loadTestData")
		public void placeOrderVariableMenuInKiosk(JSONObject testData) throws Exception {
			
			log ("Test case name: placeOrderVariableMenuInKiosk");
			try {
				if(testData == null) {
					log("the data is not configured for this testcase");
				} else {
					log("The test data given is:" + testData.toJSONString());
				}
				JSONArray selectStations = (JSONArray) testData.get("enable_menu_items");
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String strDataKey = (String)testData.get("testdata_key");
				JSONArray foodItems = getTestDataFoodItemsForGuestApp(testData, strDataKey);
				
				
				log("Data:" + testData.toJSONString());
				
				MenuMakerApp menuMaker = new MenuMakerApp(appObject, getRunParams());
				menuMaker.launch()
					.login()
					.activateStations(foodItems)
					.createGivenFoodItems(foodItems)
					.quitApp();	
				log("Successfully created the menu item in Menumaker app");
				
				KioskApp kioskApp = new KioskApp(appObject, getRunParams());
				kioskApp.launch()
					.login()
					.enableSecuritySettings()
					.selectStationAndMenuItems(caffe_location, selectStations)
					.validateMenuDetails(foodItems, caffe_location)
				.quitApp();
				log("Successfully placed the menu item in guest app");
				
				log("Successfully verified the Menu item in guestApp");
			} catch(Exception e) {
				e.printStackTrace();
				Assert.assertTrue(false, "Exception while verifying the menu in GuestApp from Menumaker. Error:" + e);
			}
		}

	
	private JSONObject getCustomizedTestDataForGuestApp(JSONObject testData) {
		
		JSONArray data = (JSONArray)testData.get("food_items_to_create");
		JSONObject sourceItem = (JSONObject)data.get(0);
		log("The source item is:" + sourceItem.toJSONString());
		JSONObject item  = new JSONObject();
		item.put("configure_caffe_station", (String)sourceItem.get("select_caffe_location"));
		JSONArray stations = new JSONArray();
		stations.add(sourceItem.get("select_station"));
		item.put("enable_menu_items", stations);
		
		JSONArray foodItems = new JSONArray();
		JSONObject itemToOrder = new JSONObject();
		itemToOrder.put("select_station_for_order", sourceItem.get("select_station"));
		itemToOrder.put("select_item_to_order", sourceItem.get("food_item_name"));
		itemToOrder.put("select_food_item_price", sourceItem.get("food_item_price"));
		itemToOrder.put("is_custom_item", sourceItem.get("is_custom_item"));
		
		foodItems.add(itemToOrder);
		item.put("food_items_to_order", foodItems);
		
		JSONArray foodITemsToRemove = new JSONArray();
		item.put("food_items_to_remove", foodITemsToRemove);
		item.put("food_expected_total_order_value_after_remove", "");
		
		JSONArray customItems = (JSONArray)sourceItem.get("customize_food_item");
		JSONArray customItemsToAdd = new JSONArray();
		
		for(Object o : customItems) {
			JSONObject customItem = (JSONObject)o;
			
			JSONArray arr = (JSONArray)customItem.get("customize_food_items");
			JSONObject customValue = (JSONObject)arr.get(0);
			
			JSONObject t = new JSONObject();
			t.put("customize_food_item_category", customItem.get("customize_food_item_category"));
			t.put("customize_food_item", customValue.get("customize_food_item_name"));
		
			customItemsToAdd.add(t);
		}
		item.put("customize_items", customItemsToAdd);
		
		return item;
	}
	
	private JSONObject convertPrevRunData(String category, JSONObject source) {
		if(source == null) {
			return null;
		}
	
		JSONObject result = new JSONObject();
		
		JSONArray foodItems = new JSONArray();
		String orderid = (String)source.get("orderid");
		if(StringUtils.isNotBlank(orderid)) {
			orderid = orderid.replaceAll("Order #", "");
			orderid = orderid.replaceAll("#", "");
		}
		source.put("order_id", orderid);
		source.put("order_by", (String)source.get("order_person_name"));
		source.put("food_item_count", 1);
		source.put("is_order_from_kiosk", false);
		source.remove("orderid");
		
		foodItems.add(source);
		
		result.put("order_list", foodItems);
		
		return result;
	}

	private JSONObject getTempData(String aKey) {
		
		JSONObject j = null;
		
		try {
			JSONParser p = new JSONParser();
			Properties prop = new Properties();
			FileReader reader = new FileReader(AppUtilities.getFile(strBaseDir + File.separator + "run_data.txt"));
			prop.load(reader);
			j = (JSONObject)p.parse(prop.getProperty(aKey));
		} catch(Exception e) {
			e.printStackTrace();
		}
		return j;
	}
	
	
}

