package com.apple.ist.caffemac.test.common;

import java.awt.Robot;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.lang.reflect.Method;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.sikuli.api.DesktopScreenRegion;
import org.sikuli.api.ImageTarget;
import org.sikuli.api.ScreenRegion;
import org.sikuli.api.Target;
import org.sikuli.api.robot.Keyboard;
import org.sikuli.api.robot.desktop.DesktopKeyboard;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;

import com.apple.ist.caffemac.test.util.AppUtilities;

public  class ApplicationTestBase {
	
	public static final int DEFAULT_ELEMENT_TIMEOUT_IN_SECONDS = 20;
	public static final String OUTPUT_FAILURE_SCREENSHOTS_FOLDER = "/../screenshots";
	public static final String RUNTIME_DATA_FOLDER = "/../runtime_datastore";
	
		
	public JSONObject appObject = null;
	public String strAppName;

	public String strRuntimeStoreFolder;
	public String strOutputScreenshotsFolder;
	public String strCurrentTestcaseName;
	public String strOutputDir;
	public String strBaseDir;
	public Robot r;
	public Keyboard keyboard;
	public ScreenRegion screen;
	
	public enum StringVerification {
		CONTAINS,
		STARTS_WITH,
		ENDS_WITH,
		EXACTMATCH
	}
	
	public enum StringCase {
		CASE_SENSITIVE,
		CASE_INSENSITIVE
	}
	
	public ApplicationTestBase() {
		strAppName = "DUMMY";
		init();
	}
	
	public ApplicationTestBase(String aAppName) {
		strAppName = aAppName;
		init();
	}
	
	public void log(String aLog) {
		logToFile(AppUtilities.getCurrentTimestamp("HH:mm:ss\t") + aLog);
	}
	
	public JSONObject getRunParams() {
		JSONObject params = new JSONObject();
		params.put("strRuntimeStoreFolder", strRuntimeStoreFolder);
		params.put("strOutputScreenshotsFolder", strOutputScreenshotsFolder);
		params.put("strCurrentTestcaseName", strCurrentTestcaseName);
		params.put("strOutputDir", strOutputDir);
		params.put("strBaseDir", strBaseDir);
		//params.put("strAppName", strAppName);
		
		return params;
	}
	
	public void initWithParams(JSONObject data) {
		strRuntimeStoreFolder = (String)data.get("strRuntimeStoreFolder");
		strOutputScreenshotsFolder = (String)data.get("strOutputScreenshotsFolder");
		strCurrentTestcaseName = (String)data.get("strCurrentTestcaseName");
		strOutputDir = (String)data.get("strOutputDir");
		strBaseDir = (String)data.get("strBaseDir");
		//strAppName = (String)data.get("strAppName");
	}
	
	private void init() {
		try {
			keyboard = new DesktopKeyboard();
			screen = new DesktopScreenRegion();
			r = new Robot();
			log("Initialization complete for the app:" + strAppName);
		} catch(Exception e) {
			log("Exception while initializing the robot. Error:" + e);
		}
	}
	
	public Long getLong(String key) {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			return (Long)app.get(key);
		}
		return null;
	}
	
	public Object getData(String param) {
		return appObject.get(param);
	}

	public String getParameter(String key) {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			return (String)app.get(key);
		}
		return null;
	}
	
	public String getBrowserName() {
		if(appObject == null) {
			log("Looks like the app object found to be null and looking for app name as:" + strAppName);
		}
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			return (String)app.get("browser");
		}
		return null;
	}

	public String getAppLoginUsername() {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			return (String)app.get("username");
		}
		return null;
		
	}
	public String getAppLoginPassword() {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			return (String)app.get("password");
		}
		return null;
	}
	
	public long getElementLoadTimeout() {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			Long timeOut = (Long)app.get("element_timeout_in_seconds");
			return Long.valueOf(timeOut);
		}
		return DEFAULT_ELEMENT_TIMEOUT_IN_SECONDS;
	}
	
	public String getUILocator(String locator) {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			JSONObject appUILocators = (JSONObject)app.get("ui_locators");
			
			if(appUILocators != null) {
				return (String)appUILocators.get(locator);
			}
		}
		return null;
	}
	
	public JSONArray getTestData(String aTestcaseName) {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			JSONObject appData = (JSONObject)app.get("data");
			//log("The app data set:" + appData.toJSONString());
			JSONArray testdataSet = (JSONArray)appData.get(aTestcaseName);
			//log("The data for the testcase:" + testdataSet.toJSONString());
			return testdataSet;
		}
		return null;
	}
	
	@BeforeSuite
	public void initializeSuite(ITestContext aContext) {
		log("The output dir in the beforesuite:" + aContext.getOutputDirectory());
		strOutputDir = aContext.getOutputDirectory();
		strBaseDir = strOutputDir + "/../../../";
		strBaseDir = FilenameUtils.normalize(strBaseDir);
		
		createRuntimeLogFolders();
		writeDataInRunStore("INITIALIZED", "true");
	}
	
	@BeforeClass
	@Parameters({ "configuration" })
	public void initApp(ITestContext aContext, String appConfigFile) throws Exception {
		log("The input app config file:" + appConfigFile);

		log("The Before Class output dir in the beforesuite:" + aContext.getOutputDirectory());
		strOutputDir = aContext.getOutputDirectory();
		strBaseDir = strOutputDir + "/../../../";
		strBaseDir = FilenameUtils.normalize(strBaseDir);
		log("The base dir before class:" + strBaseDir);
		
		File f = AppUtilities.getFile(appConfigFile);
		Assert.assertNotNull(f, "Given application configuration file:" + appConfigFile + " doesn't exists..");
		log("The application config file:" + f.getAbsolutePath());
		
		//log("Getting App data");
		String appData = AppUtilities.getFileContent(f);
		//log("App Data:" + appData);
		Assert.assertNotNull(appData, "Failed to get the Application Configuration..");
		
		JSONParser parser = new JSONParser();
		appObject = (JSONObject)(parser.parse(appData));
		Assert.assertNotNull(appObject, "Failed while parsing the application configuration");
		
	}
	
	@DataProvider(name = "loadTestData")
	public Object[][] loadTestData(Method m) {
		//log("Loading hte test data for:" + m.getName());
		JSONArray a = getTestData(m.getName());
		if(a == null || a.size() <= 0) {
			return new Object[1][1];
		}
		//log("The data is:" + a.toJSONString());
		Object[][] data = new Object[a.size()][1];		
		for(int i = 0; i < a.size(); i++) {
			data[i][0] = a.get(i);
		}
		return data;
	}
	
	@BeforeClass
	public void setUpBeforeTestMethod(ITestContext aContext) {
		strOutputDir = aContext.getOutputDirectory();
		log("BeforeClass Outputdir:" + strOutputDir);
		createRuntimeLogFolders();
	}
	
	private void createRuntimeLogFolders() {
		if(StringUtils.isEmpty(strOutputDir)) {
			log("Output Directory is not set. Failure in creating the log folders");
			return;
		}
		
		strOutputScreenshotsFolder = strOutputDir + File.separator + OUTPUT_FAILURE_SCREENSHOTS_FOLDER;
		strOutputScreenshotsFolder = FilenameUtils.normalize(strOutputScreenshotsFolder);
		File f = new File(strOutputScreenshotsFolder);
		try {
			if(! f.isDirectory()) {
				log("The screenshot folder:" + strOutputScreenshotsFolder + " doesnt exist..");
				FileUtils.forceMkdir(f);
			}
		} catch(Exception e) {
			System.err.println("Failed in creating the output screenshots folder");
		}
		strRuntimeStoreFolder = strOutputDir + File.separator + RUNTIME_DATA_FOLDER;
		strRuntimeStoreFolder = FilenameUtils.normalize(strRuntimeStoreFolder);
		f = new File(strRuntimeStoreFolder);
		try {
			if(! f.isDirectory()) {
				log("The runtime data folder:" + strRuntimeStoreFolder + " doesnt exist..");
				FileUtils.forceMkdir(f);
			}
		} catch(Exception e) {
			System.err.println("Failed in creating the runtime datastore screenshots folder");
		}
	}

	@BeforeMethod
	public void setUpBeforeTestMethod(ITestContext aContext, Method m) {
		log("Base class Setup before test method...");
		strCurrentTestcaseName = m.getName();
	}
	

	public String readDataFromRunStore(String key) {
		if(StringUtils.isEmpty(key)) {
			log("The given key to read from runtime store is null / empty");
			return null;
		}
		String runtimeFile = strRuntimeStoreFolder + File.separator + "datastore.properties";
		File f = new File(runtimeFile);
		if(f.isFile()) {
			Properties p = new Properties();
			try {
				FileInputStream in = new FileInputStream(runtimeFile);
				p.load(in);;
				in.close();
				
			} catch(Exception e) {
				log("Exception while loading the existing runtime store file data. Error:" + e);
				return null;
			}
			return p.getProperty(key);
		} 
		return null;
	}
	
	public boolean writeDataInRunStore(String key, String value) {
		boolean status = false;
		
		String runtimeFile = strRuntimeStoreFolder + File.separator + "datastore.properties";
		Properties p = new Properties();
		File f = new File(runtimeFile);
		if(f.isFile()) {
			try {
				FileInputStream in = new FileInputStream(runtimeFile);
				p.load(in);;
				in.close();
				
			} catch(Exception e) {
				log("Exception while loading the existing runtime store file data. Error:" + e);
			}
		}
		p.setProperty(key, value);
		try {
			FileOutputStream out = new FileOutputStream(runtimeFile);
			p.store(out, "Updated at:" + AppUtilities.getCurrentTimestamp());
			out.close();
			status = true;
		} catch(Exception e) {
			log("Exception while storing the runtime store file data. Error:" + e);
		}
		
		
		return status;
	}
	
	
	public Object getPreviousExecutionResultsFromStore(String aKey) {
		
		try {
			String data = readDataFromRunStore(aKey);
			if(StringUtils.isNotBlank(data)) {
				JSONParser p = new JSONParser();
				return p.parse(data);
			}
		} catch(Exception e) {
			log("Exception occurred while getting the execution results from previous test:" + aKey);
		}
		return null;
	}
	
	public JSONArray getTestDataFromApp(String appName, String aTestcaseName) {
		JSONObject app = (JSONObject)appObject.get(appName);
		if(app != null) {
			JSONObject appData = (JSONObject)app.get("data");
			JSONArray testdataSet = (JSONArray)appData.get(aTestcaseName);
			log("The data for the testcase:" + testdataSet.toJSONString());
			return testdataSet;
		}
		return null;
	}
	
	public boolean isImageFoundInScreen(String aFile) {
		boolean status = false;
		log("Finding the image:" + aFile + " in the desktop screen");
		if(screen == null) {
			log("Screen is found to be null");
			return status;
		}
		try {
			Target imgTarget = new ImageTarget(new File(aFile));
			//imgTarget.setMinScore(0.7);
			ScreenRegion found = screen.find(imgTarget);
			if(found != null) {
				log("The image found at the level of:" + found.getScore());
				log("The image found at:" + found.getBounds().toString());
				status = true;
			} else {
				log("The image is not found");
			}
		} catch(Exception e) {
			e.printStackTrace();
			log("Exception occurred while finding the image. Error:" + e);
		}
		return status;
	}
	
	private void logToFile(String aLog) {
		
		String outputFile = strOutputDir + File.separator;
		if(StringUtils.isBlank(strCurrentTestcaseName)) {
			outputFile += "_overview";
		} else {
			outputFile += strCurrentTestcaseName;
		}
		outputFile += ".log";
		try {
			System.out.println(aLog);
			aLog += "\n";
			FileUtils.writeStringToFile(new File(outputFile), aLog, true);
		} catch(Exception e) {}
	}
	
	protected void storeOrderIdDetailsToRunStore(int index, JSONObject item) {
		if(item == null) {
			log("Failed to store the ortder id details as the item given found to be null");
			return;
		}
		if(! writeDataInRunStore(getOrderIDKeyToStore(index, item), item.toJSONString())) {
			log("Failed while storing the order id details to runtime store");
		} else {
			log("Successfully stored the order id details to runtime store");
		}
	}
	
	private String getOrderIDKeyToStore(int index, JSONObject item) {
		String key = strCurrentTestcaseName.toUpperCase() + "_" +  strAppName.toUpperCase();
		
		String strFoodType = (String)item.get("food_type");
		if(StringUtils.equalsIgnoreCase(strFoodType, "standard") || StringUtils.equalsIgnoreCase(strFoodType, "special")) {
			key += "_" + strFoodType.toUpperCase();
		} else  {
			key += "_DEFAULT";
		}
		boolean isCustomized = (Boolean)item.get("is_custom_item");
		if(isCustomized) {
			key += "_CUSTOMIZED";
		} else {
			key += "_NONCUSTOMIZED";
		}
		key += "_" + index;
		log("The key in which the order details to be stored is:" + key);
		return key;
	}
	
	/*
	abstract void failCurrentTest();
	abstract void takeScreenshotNow();
	abstract boolean launchApp();
	abstract void closeApp();
	abstract boolean tapElement(String uiLocatorKey);
	abstract boolean clickElement(String uiLocatorKey);
	abstract boolean typeText(String uiLocatorKey, String value);
	abstract WebElement waitForElement(String uiLocatorKey);
	abstract WebElement waitForElement(String uiLocatorKey, long timeOutInSeconds);
	*/
}
