package com.apple.ist.caffemac.test.common;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.lang.reflect.Method;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.exec.CommandLine;
import org.apache.commons.exec.DefaultExecuteResultHandler;
import org.apache.commons.exec.DefaultExecutor;
import org.apache.commons.exec.ExecuteException;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.apple.ist.caffemac.test.util.AppUtilities;

public class WebApplicationTestBase extends ApplicationTestBase {

	public CustomAssert Assert;

	protected WebDriver driver;
	private static final int retryOnStaleElementException = 3;
	public WebApplicationTestBase(String appName) {
		super(appName);
		Assert = new CustomAssert(this, null);
	}
	
	@BeforeMethod
	public void setUpBeforeTestMethod(ITestContext aContext, Method m) {
		log("Web Test setup before test method");
		strCurrentTestcaseName = m.getName();
	}
	
	public boolean launchApp() {
		
		try {
			String strBrowserName = getBrowserName();
			Assert.assertNotNull(strBrowserName, "Failed to launch the application as the browser in which the app to be launched is not defined");
			Assert.assertTrue(StringUtils.isNotEmpty(strBrowserName), "Failed to launch the application as the browser in which the app to be launched is not defined");
			String env = System.getProperty("environment");
			env = env.toLowerCase();
			String webURL= "url_"+env;
			String url = getParameter(webURL);
			log("Launching URL:"+ url);
			Assert.assertNotNull(url, "Failed to launch the application as the application URL is not defined");
			Assert.assertTrue(StringUtils.isNotEmpty(url), "Failed to launch the application as application url is not defined");
			Assert.assertTrue(initBrowser(strBrowserName), "Failed in initializing the browser");
			
			
			Long pageTimeOut = getLong("page_timeout_in_seconds");
			driver.manage().timeouts().pageLoadTimeout(pageTimeOut.longValue(), TimeUnit.SECONDS);
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			driver.get(url);
			driver.manage().window().maximize();
			log("Successfully loaded the url:" + url);
			return true;
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception occurred while launching the application. Error:" + e.getMessage());
		}
		return false;
	}
	
	public Boolean highlightSafari(){
		/*Function to highlight Safari
		 *To use Robot function in Framework we need to configure the following 
		 *Change Hide Safari option to Command + L instead of Command +H in the Keyboard shortcuts
		 *This function minimise 10 Processes in the machine
		 */
		Robot r;
		try {
			r = new Robot();
			//r.mouseMove(70,10);
			//r.mousePress(InputEvent.);
			for (int i =0 ; i<1; i++){
			r.keyPress(KeyEvent.VK_META);
			r.keyPress(KeyEvent.VK_H);
			r.keyRelease(KeyEvent.VK_H );
			r.keyRelease(KeyEvent.VK_META );
		
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			log("Minimised other processes");
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return true;

	}
	
	private boolean initBrowser(String browserName) {
		boolean status = false;
		
		browserName = browserName.toLowerCase();
		if(StringUtils.containsIgnoreCase(browserName, "firefox")) {
			driver = new FirefoxDriver();
		
			driver.manage().timeouts().pageLoadTimeout(getLong("page_timeout_in_seconds"), TimeUnit.SECONDS);
			status = true;
		} else if(StringUtils.containsIgnoreCase(browserName, "safari")) {
			//if(!driver)
			driver = new SafariDriver();
			status = true;
		} else {
			log("Looks like unknown browser name is given:" + browserName);
		}
		
		
		return status;
	}
	
	
	public void closeApp() {
		log("Closing the browser...app");
		if(driver != null) {
			driver.quit();
		} else {
			log("Looks like the driver found to be null...for the browser app...");
		}
	}
	
	public void takeScreenshotNow() {
		if(driver == null) {
			System.err.println("Failed in taking the screenshot as the driver instance is null");
			return;
		}
		String screenshotFile = strOutputScreenshotsFolder + File.separator + strCurrentTestcaseName + "_" + AppUtilities.getCurrentTimestamp() + ".png";
		log("On failure, saving the screenshot to:" + screenshotFile);
		try {
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	        FileUtils.copyFile(scrFile, new File(screenshotFile));
	        log("Failure screenshot has been taken");
		} catch(Exception e) {
			System.err.println("Failed in taking the screenshot. Error:" + e);
		}
	}
	
	
	public boolean tapElement(String uiLocatorKey) {
		return clickElement(uiLocatorKey);
	}

	public boolean clickElement(String uiLocatorKey) {
		boolean status = false;
		int attempt = 0;
		while(attempt < retryOnStaleElementException && (! status)) {
			try {
				WebElement element = waitForElement(uiLocatorKey, getElementLoadTimeout());		
				if(element == null) {
					log("Failed to find/click on element:" + uiLocatorKey);
					return false;
				}
				scrollToElement(element);
				element.click();
				status = true;
				log("Successfully clicked on element:" + uiLocatorKey);
			} catch(StaleElementReferenceException s) {
				log("Stale element exception on finding/clicking on the element:" + uiLocatorKey + " at attempt:" + attempt);
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception occurred while clicking on element:" + uiLocatorKey + ", Error:" + e);
			}
			attempt ++;
		}
		return status;
	}
	
	public boolean typeText(String uiLocatorKey, String value) {
		boolean status = false;	
		int attempt = 0;
		while(attempt < retryOnStaleElementException && (! status)) {
			try {
				WebElement element = waitForElement(uiLocatorKey, getElementLoadTimeout());
				
				if(element == null) {
					log("Failed to find/type on element:" + uiLocatorKey);
					return false;
				}
				
				scrollToElement(element);
				//Thread.sleep(2000);
				element.click();
				element.clear();
				element.sendKeys(value);
				status = true;
				log("Successfully typed data:" + value + " on element:" + uiLocatorKey);
			} catch(StaleElementReferenceException s) {
				log("Stale element exception on finding the element:" + uiLocatorKey + " at attempt:" + attempt);
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception occurred while typing the data:" + value + " on element:" + uiLocatorKey + ", Error:" + e);
			}
			attempt ++;
		}
		return status;
	}
	
	public boolean scrollToElement(WebElement element) {
		try {
			JavascriptExecutor executor = (JavascriptExecutor)driver;

			//Option #0
			//Actions actions = new Actions(driver);
			//actions.moveToElement(element);
			// actions.click();
			//actions.perform();
			
			//Option #1
			/*
			if(element != null) {
				element.sendKeys("");
			}
			*/
			
			//Option #2
			/*
			int x = 0;
			while((Double)executor.executeScript("return arguments[0].getBoundingClientRect().top", element) < 0 ) {
				x = x + 2;
				executor.executeScript("window.scrollByLines(2)");
				log("Client top is = " + (Double)executor.executeScript("return arguments[0].getBoundingClientRect().top", element));			
			}
			log("Element is visible after  " + x + " scrolls");
			*/
			
			//Option #3
			//executor.executeScript("arguments[0].scrollIntoView(true);", element);
			
			//Option #4
			
			Point p = element.getLocation();
			log("Element original position:" + p.getX() + "," + p.getY());
			executor.executeScript("window.scroll(" + p.getX() + "," + (p.getY()-150) + ");");
			log("Scrolled to new position:" + p.getX() + "," + (p.getY()-150));

			Thread.sleep(500); 
						
			return true;
		} catch(Exception e) {
			log("Exception occurred while scrolling to the element. Ignore it");
		}
		return false;
	}
	
	public boolean waitForElementWithText(String uiLocatorKey, String expectedText) {
		return waitForElementWithText(uiLocatorKey, expectedText, getElementLoadTimeout());
	}

	
	public boolean waitForElementWithText(String uiLocatorKey, String expectedText, long timeOutInSeconds) {
		
		WebElement element = waitForElement(uiLocatorKey);
		if(element == null) {
			log("Failed while waiting for the text in element:" + uiLocatorKey);
			return false;
		}
		WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
		return wait.until(ExpectedConditions.textToBePresentInElement(element, expectedText));
	}	

	public WebElement waitForElement(String uiLocatorKey) {
		return waitForElement(uiLocatorKey, getElementLoadTimeout());
	}

	public WebElement waitForElement(String uiLocatorKey, long timeOutInSeconds) {
		WebElement element = null;
		String uiLocator = getUILocator(uiLocatorKey);
		if(uiLocator == null) {
			System.err.println("Failed to find the element key:" + uiLocatorKey + ", Using it as it is");
			uiLocator = uiLocatorKey;
		}
		
		class CustomConditionVerifier implements ExpectedCondition<WebElement> {
			By by = null;
			public CustomConditionVerifier(By aBy) {
				this.by  = aBy;
			}
			@Override
			public WebElement apply(WebDriver arg0) {
				// TODO Auto-generated method stub
				WebElement element = null;
				try {
					element = arg0.findElement(by);
				} catch(StaleElementReferenceException stale) {
					log("Stale element exception is found. Ignoring it now..");
					element = null;
				}
				return element != null ? element : null;
			}
		}
		try {
			WebDriverWait wait = (WebDriverWait)new WebDriverWait(driver, timeOutInSeconds).ignoring(StaleElementReferenceException.class);
			if(uiLocator.startsWith("xpath=")) {
				uiLocator = uiLocator.substring(6);
				log("Identifying the element using xPath:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");
				element = wait.until(new CustomConditionVerifier(By.xpath(uiLocator)));
			} else if(uiLocator.startsWith("id=")) {
				uiLocator = uiLocator.substring(3);
				log("Identifying the element using id:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");	
				element = wait.until(new CustomConditionVerifier(By.id(uiLocator)));
			} else if(uiLocator.startsWith("css=")) {
				uiLocator = uiLocator.substring(4);
				log("Identifying the element using css:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");	
				element = wait.until(new CustomConditionVerifier(By.cssSelector(uiLocator)));
			} else if(uiLocator.startsWith("link=")) {
				uiLocator = uiLocator.substring(5);
				log("Identifying the element using link:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");	
				element = wait.until(new CustomConditionVerifier(By.linkText(uiLocator)));
			}

		} catch(Exception e) {
			System.err.println("Failed to find the element:" + uiLocator + " with in:" + timeOutInSeconds + " seconds... Error:" + e.getMessage());
			return null;
		}
		
		return element;
	}	
	
	public List<WebElement> waitForElements(String uiLocatorKey) {
		return waitForElements(uiLocatorKey, getElementLoadTimeout());
	}
	
	public List<WebElement> waitForElements(String uiLocatorKey, long timeOutInSeconds) {
		List<WebElement> elements = null;
		String uiLocator = getUILocator(uiLocatorKey);
		if(uiLocator == null) {
			System.err.println("Failed to find the element key:" + uiLocatorKey + ", Using it as it is");
			uiLocator = uiLocatorKey;
		}
		class CustomConditionVerifierForElements implements ExpectedCondition<List<WebElement>> {
			By elementBy = null;
			public CustomConditionVerifierForElements(By elementBy) {
				this.elementBy = elementBy;
			}
			@Override
			public List<WebElement> apply(WebDriver arg0) {
				// TODO Auto-generated method stub
				List<WebElement> list = arg0.findElements(elementBy);
				return list != null && list.size() > 0 ? list : null;
			}
		}
		
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
			
			if(uiLocator.startsWith("xpath=")) {
				uiLocator = uiLocator.substring(6);
				log("Identifying the element using xPath:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");
				elements = wait.until(new CustomConditionVerifierForElements(By.xpath(uiLocator)));
			} else if(uiLocator.startsWith("id=")) {
				uiLocator = uiLocator.substring(3);
				log("Identifying the element using id:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");	
				elements = wait.until(new CustomConditionVerifierForElements(By.id(uiLocator)));
			} else if(uiLocator.startsWith("css=")) {
				uiLocator = uiLocator.substring(4);
				log("Identifying the element using css:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");	
				elements = wait.until(new CustomConditionVerifierForElements(By.cssSelector(uiLocator)));
			} else if(uiLocator.startsWith("link=")) {
				uiLocator = uiLocator.substring(5);
				log("Identifying the element using link:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");	
				elements = wait.until(new CustomConditionVerifierForElements(By.linkText(uiLocator)));
			}
		} catch(Exception e) {
			System.err.println("Failed to find the element:" + uiLocator + " with in:" + timeOutInSeconds + " seconds... Error:" + e.getMessage());
			return null;
		}
		
		return elements;
	}
	
	public void failCurrentTest() {
		
		//Take the screenshot on failure
		takeScreenshotNow();		
		//quit the app
		closeApp();
	}
	
}
