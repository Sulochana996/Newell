package com.apple.ist.caffemac.test.common;

import java.io.File;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ITestContext;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.apple.ist.caffemac.test.util.AppUtilities;
import com.apple.ist.caffemac.test.util.ProcessRunner;

import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class MobileApplicationTestBase extends ApplicationTestBase {
	
	public CustomAssert Assert;
	protected IOSDriver driver;
	//Sulo paramater
	public static String uiLocatorKeyCus;
	public static String jSonParamter;
	public MobileApplicationTestBase(String appName) {
		super(appName);
		Assert = new CustomAssert(null, this);
	}
	
	@BeforeMethod
	public void setUpBeforeTestMethod(ITestContext aContext, Method m) {
		strCurrentTestcaseName = m.getName();
		log("Mobile class Setup before test method..." + strCurrentTestcaseName);
		
		//setCleanAppiumEnvironment();
	}
	
	@AfterMethod
	public void cleanEnvironmentAfterTest() {
		log("Clean up after the test:" + strCurrentTestcaseName);
		if(driver != null) {
			log("Mobile driver found to be valid. Closing it now..");
			driver.quit();
			log("Mobile driver is closed...");
		} else {
			log("Mobile driver instance is found to be null.. Ignore now..!!!");
		}
	}
	
	@AfterClass
	public void killSimulators() {
		
		try {
			String strKillAppiumServerScriptFile = strBaseDir + "kill_simulators.sh";
			List<String> cmd = new ArrayList<String>();
			cmd.add("/bin/bash");
			cmd.add(strKillAppiumServerScriptFile);
			
			ProcessRunner runner = new ProcessRunner(cmd);
			int exitCode = runner.runProcessAndWaitToComplete();
	
			if (exitCode == 0) { // Success in appleconnect login
				log("Successfully killed the appium simulators.." + StringUtils.join(runner.getOutput().toArray()));
			
			} else {
				log("Failed to kill the appium simulators..." + StringUtils.join(runner.getError().toArray()));
			}
		} catch(Exception e) {
			log("Exception while setting up the clean environment for Appium. Error:" + e);
		}
	}
	private void setCleanAppiumEnvironment() {
		
		try {
			String strKillAppiumServerScriptFile = strBaseDir + "kill_appium_server.sh";
			String strStartAppiumServerScriptFile = strBaseDir + "start_appium_server.sh";
			List<String> cmd = new ArrayList<String>();
			cmd.add("/bin/bash");
			cmd.add(strKillAppiumServerScriptFile);
			
			ProcessRunner runner = new ProcessRunner(cmd);
			int exitCode = runner.runProcessAndWaitToComplete();
	
			if (exitCode == 0) { // Success in appleconnect login
				log("Successfully killed the appium servers.." + StringUtils.join(runner.getOutput().toArray()));
			
				//start the appium server now
				
				cmd.clear();
				cmd.add("/bin/bash");
				cmd.add(strStartAppiumServerScriptFile);
				runner = new ProcessRunner(cmd);
				exitCode = runner.runProcessAndWaitToComplete();
				if (exitCode == 0) { // Success in appleconnect login
					log("Successfully started the appium server.." + StringUtils.join(runner.getOutput().toArray()));
				} else {
					log("Failed while starting the appium server.." + StringUtils.join(runner.getError().toArray()));
				}
			} else {
				log("Failed to kill the appium servers..." + StringUtils.join(runner.getError().toArray()));
			}
		} catch(Exception e) {
			log("Exception while setting up the clean environment for Appium. Error:" + e);
		}
	}
	
	public String getAppiumVersion() {
		return (String)appObject.get("appium_version");
	}
	public String getAppiumServerURL() {
		return (String)appObject.get("appium_server_url");
	}

	public String getAppName() {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			return (String)app.get("app_name");
		}
		return null;
	}
	public String getAppSDK() {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			return (String)app.get("sdk");
		}
		return null;
	}
	public String getAppDevice() {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			return (String)app.get("device");
		}
		return null;
	}
	public String getAppPath() {
		
		String envVarName = strAppName.toUpperCase() +"_"+System.getProperty("environment")+ "_APP_PATH";
		log("Looking for the Application path in the environment variable as:" + envVarName);
		String envAppPathName = System.getenv(envVarName);
		if(StringUtils.isEmpty(envAppPathName)) {
			log("The application path in the environment variable:" + envVarName + " is not found. Looking into Application config");
			JSONObject app = (JSONObject)appObject.get(strAppName);
			if(app != null) {
				log("The application path for app:" + strAppName + " is found as:" + (String)app.get("path"));
				return (String)app.get("path");
			}
			return null;
		} 
		log("The application path for app:" + strAppName + " is found as:" + envAppPathName);
	//	getiOSAppEnvVersion(envAppPathName);
		return envAppPathName;
	}
	
	/*public void getiOSAppEnvVersion(String envAppPathName) {
		try {
			String strAppVersionScriptFile = strBaseDir + "appVersion.sh";
			List<String> cmd = new ArrayList<String>();
			cmd.add("/bin/bash");
			cmd.add(strAppVersionScriptFile);
			cmd.add(envAppPathName);
			
			ProcessRunner runner = new ProcessRunner(cmd);
			runner.runProcessAndWaitToComplete();
			log("Application Environment and Version"+runner.getOutput().toString());
		}catch(Exception e){
			
		}
	}*/

	public String getDeviceType() {
		JSONObject app = (JSONObject)appObject.get(strAppName);
		if(app != null) {
			return (String)app.get("device_type");
		}
		return null;
	}
	
	private void dumpAppiumEnvironmentConfigured() {
		StringBuilder buf = new StringBuilder();
		buf.append("Appium Version:").append(getAppiumVersion()).append("\n");
		buf.append("Appium Server URL:").append(getAppiumServerURL()).append("\n");
		
		log("Appium Environment:\n" + buf.toString());
	}
	
	private void dumpAppSpecificParametersGiven() {
		StringBuilder buf = new StringBuilder();
		buf.append("App Name:").append(getAppName()).append("\n");
		buf.append("App Path:").append(getAppPath()).append("\n");
		buf.append("App SDK:").append(getAppSDK()).append("\n");
		buf.append("App Device:").append(getAppDevice()).append("\n");
		
		log("Application Parameters Configured:\n" + buf.toString());
	}
	
	public void launchAppleConnect_iPad()  {
		try {
			log("The appleconnect file path is: "+System.getenv("APPLECONNECT_IPAD"));
			log("Launching the AppleConnect mobile application with the following environment");
			dumpAppiumEnvironmentConfigured();
			dumpAppSpecificParametersGiven();
			
		    DesiredCapabilities capabilities = new DesiredCapabilities();
		    
		    capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, getAppSDK());
		    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, getAppDevice());
		    capabilities.setCapability(MobileCapabilityType.APP, System.getenv("APPLECONNECT_IPAD"));
		    capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
		   // capabilities.setCapability("no-reset", true);
		    //capabilities.setCapability("fullReset", false);
		    //capabilities.setCapability("nativeWebTap", true);
		    capabilities.setCapability("noReset", false);
		    capabilities.setCapability("fullReset", true);
		    capabilities.setCapability("nativeWebTap", true);
		    capabilities.setCapability("useNewWDA", false);
		    capabilities.setCapability("waitForQuiescence", false);
		   
		    capabilities.setCapability("waitForAppScript", "$.delay(10000);$.acceptAlert();");
		   // appleConnectSign();
		    //capabilities.setCapability("appiumVersion", getAppiumVersion());
		    URL localAppiumServerURL = new URL(getAppiumServerURL());
		    driver = new IOSDriver(localAppiumServerURL,capabilities);
		    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		    log("Launched Apple Connect Sucessfully");
		    AppUtilities.delay(20000);
		    //driver.quit();
		    driver.switchTo().alert().accept();
			//return driver != null ? true : false;
		} catch(Exception e) {
			Assert.assertTrue(false, "Failed while launching the application. Error:" + e);
		}
		//return false;
	}
	
	public void launchAppleConnect_iPhone()  {
		try {
			log("The appleconnect file path is: "+System.getenv("APPLECONNECT_IPHONE"));
			log("Launching the AppleConnect mobile application with the following environment");
			dumpAppiumEnvironmentConfigured();
			dumpAppSpecificParametersGiven();
			
		    DesiredCapabilities capabilities = new DesiredCapabilities();
		    
		    capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, getAppSDK());
		    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, getAppDevice());
		    capabilities.setCapability(MobileCapabilityType.APP, System.getenv("APPLECONNECT_IPHONE"));
		    capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
		    capabilities.setCapability("noReset", false);
		    capabilities.setCapability("fullReset", true);
		    capabilities.setCapability("nativeWebTap", true);
		    capabilities.setCapability("useNewWDA", true);
		    capabilities.setCapability("waitForQuiescence", false);
		   // capabilities.setCapability("no-reset", true);
		    //capabilities.setCapability("full-reset", false);
		    //capabilities.setCapability("nativeWebTap", true);
		    capabilities.setCapability("waitForAppScript", "$.delay(10000);$.acceptAlert();");
		   

		   // appleConnectSign();
		   // capabilities.setCapability("appiumVersion", getAppiumVersion());
		    URL localAppiumServerURL = new URL(getAppiumServerURL());
		    driver = new IOSDriver(localAppiumServerURL,capabilities);
		    driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		    
		    log("Launched Apple Connect Sucessfully");
		    //driver.quit();
		   AppUtilities.delay(20000);
		    /*WebDriverWait wait  = new WebDriverWait(driver,20);
		    wait.until(ExpectedCondition.alertIsPresent);*/
		    driver.switchTo().alert().accept();
			//return driver != null ? true : false;
		} catch(Exception e) {
			Assert.assertTrue(false, "Failed while launching the application. Error:" + e);
		}
		//return false;
	}

	public void appleConnectSign() {
		log("Perform Apple connect sign in");
	/*	Assert.assertTrue(clickElement("button_appleconnect_accounts"), "Failed to find the accounts button");
		Assert.assertTrue(clickElement("button_appleconnect_signin"), "Failed to find the sign in button");
		Assert.assertNotNull(waitForElement("textfield_appleconnect_username"), "Failed to find the apple connect username field");
	    Assert.assertTrue(typeText("textfield_appleconnect_username", "santhanalakshmi_k"), "Failed to type the login username");
	    Assert.assertTrue(typeText("textfield_appleconnect_username", "******"), "Failed to type the login password");   
		*/
	}
	
	public boolean swipeToDirection_iOS_XCTest(MobileElement el, String direction) {
        try {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            HashMap<String, String> swipeObject = new HashMap<String, String>();
            if (direction.equals("d")) {
                swipeObject.put("direction", "down");
            } else if (direction.equals("u")) {
                swipeObject.put("direction", "up");
            } else if (direction.equals("l")) {
                swipeObject.put("direction", "left");
            } else if (direction.equals("r")) {
                swipeObject.put("direction", "right");
            }
            swipeObject.put("element", el.getId());
            js.executeScript("mobile:swipe", swipeObject);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

	
	public void ScrollWithElement()
	{
		RemoteWebElement elements =  (RemoteWebElement) driver.findElement(By.xpath("//XCUIElementTypeStaticText[@name='Text View']"));
		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		scrollObject.put("element", ((RemoteWebElement) elements).getId());
		scrollObject.put("toVisible", "true");
		js.executeScript("mobile: scroll", scrollObject);
	}
	
	
	public boolean launchApp()  {
		try {
			
			log("Launching the mobile application with the following environment");
			dumpAppiumEnvironmentConfigured();
			dumpAppSpecificParametersGiven();
			
		    DesiredCapabilities capabilities = new DesiredCapabilities();
		    
		    capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, getAppSDK());
		    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, getAppDevice());
		    capabilities.setCapability(MobileCapabilityType.APP, getAppPath());
		    capabilities.setCapability("noReset", true);
		    capabilities.setCapability("fullReset", false);
		    capabilities.setCapability("nativeWebTap", true);
		    capabilities.setCapability("useNewWDA", true);
		    capabilities.setCapability("waitForQuiescence", false);
		    
		    capabilities.setCapability("waitForAppScript", "$.delay(10000);$.acceptAlert();");
		    
		    //Boolean realDevice = true;
		    if (getDeviceType().equals("real")){
		    capabilities.setCapability("udid", "2d37ca6975850b358f4cc2397dab8bb916c46560");
		    capabilities.setCapability("bundleId", "com.apple.ist.OrderingApp-UAT");
		    }      
		    capabilities.setCapability("appiumVersion", getAppiumVersion());
		    URL localAppiumServerURL = new URL(getAppiumServerURL());
		    driver = new IOSDriver(localAppiumServerURL,capabilities);
		    driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		    
			return driver != null ? true : false;
		} catch(Exception e) {
			Assert.assertTrue(false, "Failed while launching the application. Error:" + e);
		}
		return false;
	}
	
	public boolean launchApp_iPad()  {
		try {
			
			log("Launching the mobile application in iPad with the following environment");
			dumpAppiumEnvironmentConfigured();
			dumpAppSpecificParametersGiven();
			
		    DesiredCapabilities capabilities = new DesiredCapabilities();
		    
		    capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, getAppSDK());
		    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, getAppDevice());
		    capabilities.setCapability(MobileCapabilityType.APP, getAppPath());
		    //capabilities.setCapability(MobileCapabilityType.FULL_RESET, false);
            //capabilities.setCapability(MobileCapabilityType.NO_RESET, true);
		    capabilities.setCapability("noReset", true);
		    capabilities.setCapability("fullReset", false);
		    capabilities.setCapability("nativeWebTap", true);
		    capabilities.setCapability("useNewWDA", true);
		    capabilities.setCapability("waitForQuiescence", false);
		    capabilities.setCapability("orientation","LANDSCAPE");
		    capabilities.setCapability("waitForAppScript", "$.delay(10000);$.acceptAlert();");
		    URL localAppiumServerURL = new URL(getAppiumServerURL());
		    driver = new IOSDriver(localAppiumServerURL,capabilities);
		    driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		    
			return driver != null ? true : false;
		} catch(Exception e) {
			Assert.assertTrue(false, "Failed while launching the application. Error:" + e);
		}
		return false;
	}

	public boolean launchAppleConnectApp()  {
		try {
			
			log("Launching the mobile application with the following environment");
			dumpAppiumEnvironmentConfigured();
			dumpAppSpecificParametersGiven();
			
		    DesiredCapabilities capabilities = new DesiredCapabilities();
		    
		    capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, getAppSDK());
		    capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, getAppDevice());
		    capabilities.setCapability(MobileCapabilityType.APP, getAppPath());
		    capabilities.setCapability("nativeWebTap", true);
		    capabilities.setCapability("useNewWDA", true);
		    capabilities.setCapability("waitForQuiescence", false);
		    
		    capabilities.setCapability("waitForAppScript", "$.delay(10000);$.acceptAlert();");
		    //capabilities.setCapability("udid", "2d37ca6975850b358f4cc2397dab8bb916c46560");
	       	      
		    capabilities.setCapability("appiumVersion", getAppiumVersion());
		    URL localAppiumServerURL = new URL(getAppiumServerURL());
		    driver = new IOSDriver(localAppiumServerURL,capabilities);
		    driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		    
			return driver != null ? true : false;
		} catch(Exception e) {
			Assert.assertTrue(false, "Failed while launching the application. Error:" + e);
		}
		return false;
	}

	public void closeApp()  {	
		log("Closing the mobile...app");
		if(driver != null) {
			driver.quit();
			log("Closed the mobile app....");
		} else {
			log("Looks like the mobile app driver instance is null");
		}
	}
	
	public void takeScreenshotNow() {
		if(driver == null) {
			System.err.println("Failed in taking the screenshot as the driver instance is null");
			return;
		}
		String screenshotFile = strOutputScreenshotsFolder + File.separator + strCurrentTestcaseName + "_" + AppUtilities.getCurrentTimestamp() + ".png";
		try {
			File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	        FileUtils.copyFile(scrFile, new File(screenshotFile));
		} catch(Exception e) {
			System.err.println("Failed in taking the screenshot. Error:" + e);
		}
	}
	
	public boolean tapElement(String uiLocatorKey) {
		boolean status = false;
			try {
			MobileElement element = waitForElement(uiLocatorKey, getElementLoadTimeout());
			
			if(element == null) {
				log("Failed to find/tap on element:" + uiLocatorKey);
				return false;
			}
			
			element.tap(1, 1);
			status = true;
			log("Successfully tapped on element:" + uiLocatorKey);
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception occurred while tapping on element:" + uiLocatorKey + ", Error:" + e);
		}
		return status;
	}
	
	public boolean doubleTapElement(String uiLocatorKey) {
		boolean status = false;
		try {
			MobileElement element = waitForElement(uiLocatorKey, getElementLoadTimeout());
			
			if(element == null) {
				log("Failed to find/tap on element:" + uiLocatorKey);
				return false;
			}
			element.tap(2, 1);
			status = true;
			log("Successfully double tapped on element:" + uiLocatorKey);
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception occurred while double tapping on element:" + uiLocatorKey + ", Error:" + e);
		}
		return status;
	}

	public boolean clickElement(String uiLocatorKey) {
		boolean status = false;
		
		try {
			MobileElement element = waitForElement(uiLocatorKey, getElementLoadTimeout());
			
			if(element == null) {
				log("Failed to find/click on element:" + uiLocatorKey);
				return false;
			}
			element.click();
			status = true;
			log("Successfully clicked on element:" + uiLocatorKey);
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception occurred while clicking on element:" + uiLocatorKey + ", Error:" + e);
		}
		return status;
	}
	
	/*public MobileElement MobileElementClick(String uiLocatorKey) {
		MobileElement element = null;
		String uiLocator = getUILocator(uiLocatorKey);
		
		try {
			//MobileElement element = waitForElement(uiLocatorKey, getElementLoadTimeout());
			
			element = (MobileElement)d.findElementByIosUIAutomation(uiLocator);
			if(element == null) {
				log("Failed to find/click on element:" + uiLocatorKey);
				return false;
			}
			element.click();
			status = true;
			log("Successfully clicked on element:" + uiLocatorKey);
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception occurred while clicking on element:" + uiLocatorKey + ", Error:" + e);
		}
		return status;
	}*/
	
	public boolean typeText(String uiLocatorKey, String value) {
		boolean status = false;
		
		try {
			MobileElement element = waitForElement(uiLocatorKey, getElementLoadTimeout());
			
			if(element == null) {
				log("Failed to find/type on element:" + uiLocatorKey);
				return false;
			}
			element.click();
			element.clear();
			element.sendKeys(value);
			status = true;
		log("Successfully typed data:" + value + " on element:" + uiLocatorKey);		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception occurred while typing value:" + value + " on element:" + uiLocatorKey + ", Error:" + e);
		}
		return status;
	}
	
	public MobileElement isElementPresent(String uiLocatorKey) {
		MobileElement element = null;
		int timeOutInSeconds = 5;
		String uiLocator = getUILocator(uiLocatorKey);
		if(uiLocator == null) {
			log("Failed to find the element key:" + uiLocatorKey + ", Using it as it is");
			uiLocator = uiLocatorKey;
		}
		try {
			if(uiLocator.startsWith("ios=")) {
				uiLocator = uiLocator.substring(4);
				log("Identifying the element using IOS way:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");
				
				WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
				class IOSCustomCondition implements ExpectedCondition<MobileElement> {
					String uiLocator = null;
					public IOSCustomCondition(String uiLocator) {
						this.uiLocator = uiLocator;
					}
					@Override
					public MobileElement apply(WebDriver arg0) {
						// TODO Auto-generated method stub
						IOSDriver d = (IOSDriver)arg0;
						MobileElement element = (MobileElement)d.findElementByIosUIAutomation(uiLocator);
						return element != null ? element : null;
					}
				}
				element = wait.until(new IOSCustomCondition(uiLocator));
				
				//Found element; Return that
				//element = (MobileElement)driver.findElementByIosUIAutomation(uiLocator);	
				
			} else if(uiLocator.startsWith("xpath=")) {
				uiLocator = uiLocator.substring(6);
				log("Identifying the element using xPath:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");
	
				WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
				//wait.until(ExpectedConditions.visibilityOf((MobileElement)driver.findElementByXPath(uiLocator)));

				//Found element; Return that
				//element = (MobileElement)driver.findElementByIosUIAutomation(uiLocator);
				class XPathCustomCondition implements ExpectedCondition<MobileElement> {
					String uiLocator = null;
					public XPathCustomCondition(String uiLocator) {
						this.uiLocator = uiLocator;
					}
					@Override
					public MobileElement apply(WebDriver arg0) {
						// TODO Auto-generated method stub
						IOSDriver d = (IOSDriver)arg0;
						MobileElement element = (MobileElement)d.findElementByXPath(uiLocator);
						return element != null ? element : null;
					}
				}
				element = wait.until(new XPathCustomCondition(uiLocator));
			}
		} catch(TimeoutException timeOut) {
			log("Timeout exception. Given element:" + uiLocator + " is not found");
			return null;
		}	catch(Exception e) {
			log("Failed to find the element:" + uiLocator + " with in:" + timeOutInSeconds + " seconds... Error:" + e.getMessage());
			return null;
		}
		
		return element;		
	}

	public MobileElement waitForElement(String uiLocatorKey) {
		return waitForElement(uiLocatorKey, getElementLoadTimeout());
	}
	
	
	/*public boolean scrollTo(String aText, boolean exact) {
		boolean status = false;
		if(driver != null) {
			if(exact) {
				
				driver.scrollToExact(aText);
				status = true;
			} else {
				driver.scrollTo(aText);
				status = true;
			}
		}
		return status;
	}
	*/
	
	//Sulo = Reusable methods
	public String findElementXpathAndReplaceText(String uiLocatorKeyCus,String jSonParamter) {
		String strItem1 = "";
		try {
			strItem1= getUILocator(jSonParamter).replaceAll("<REPLACE_TEXT>",uiLocatorKeyCus);
			System.out.println("JSon paramater is : "+jSonParamter);
			System.out.println("uilocatorkeyCus is : "+uiLocatorKeyCus);
			AppUtilities.delay(5000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return strItem1;
	}
	
	public boolean swipeViaJS(int startX, int startY, int endX, int endY, long delay) {
		boolean status = false;
		if(driver != null) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			HashMap swipeObject = new HashMap();
			swipeObject.put("startX", startX);
			swipeObject.put("startY", startY);
			swipeObject.put("endX", endX);
			swipeObject.put("endY", endY);
			swipeObject.put("duration", delay);
			js.executeScript("mobile: swipe", swipeObject);
			
			status = true;
		}
		return status;
	}
	
	
	public boolean clickHiddenElement(MobileElement e) {
		boolean status = false;
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap<String, Double> tapObject = new HashMap<String, Double>();
		tapObject.put("x", (double) e.getLocation().getX());
		tapObject.put("y", (double) e.getLocation().getY());
		tapObject.put("duration", 0.1);
		js.executeScript("mobile: tap", tapObject);	
		
		status = true;
		return status;
	}
	
	public boolean downScrollTo() {
		boolean status = false;
		if(driver != null) {
			
			
			HashMap scrollObject = new HashMap();
			scrollObject.put("direction", "up");
			//scrollObject.put("element", ((RemoteWebElement) e).getId());
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("mobile: scroll", scrollObject);
			
			
			/*
			String name = e.getAttribute("name");
			log("Scrolling to element whose name is:" + name);
			if(StringUtils.isNotBlank(name)) {
				driver.scrollToExact(name);
			}
			*/
			
			/*
			Dimension dimensions = driver.manage().window().getSize();
			Double screenHeightStart = dimensions.getHeight() * 0.5;
			int scrollStart = screenHeightStart.intValue();
			System.out.println("s="+scrollStart);
			Double screenHeightEnd = dimensions.getHeight() * 0.2;
			int scrollEnd = screenHeightEnd.intValue();
			for (int i = 0; i < dimensions.getHeight(); i++) {
				driver.swipe(0,scrollStart,0,scrollEnd,2000);
				if (driver.findElements(By.name(e.getText())).size() > 0) {
					status = true;
					break;
				}
			}
			*/
		}
		return status;
	}
	
	public boolean upScrollTo() {
		boolean status = false;
		if(driver != null) {
			
	/*		
			HashMap scrollObject = new HashMap();
			scrollObject.put("direction", "down");
			//scrollObject.put("element", ((RemoteWebElement) e).getId());
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("mobile: scroll", scrollObject);*/
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			HashMap<String, String> scrollObject = new HashMap<String, String>();
			scrollObject.put("direction", "down");
	//		scrollObject.put("element", ((RemoteWebElement) e).getId());
			js.executeScript("mobile: scroll", scrollObject);
		}
		return status;
	}
	
	
	
	
	public MobileElement waitForElement(String uiLocatorKey, long timeOutInSeconds) {
		MobileElement element = null;
		String uiLocator = getUILocator(uiLocatorKey);
		if(uiLocator == null) {
			log("Failed to find the element key:" + uiLocatorKey + ", Using it as it is");
			uiLocator = uiLocatorKey;
		}
		try {
			if(uiLocator.startsWith("ios=")) {
				uiLocator = uiLocator.substring(4);
				log("Identifying the element using IOS way:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");
				
				WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
				class IOSCustomCondition implements ExpectedCondition<MobileElement> {
					String uiLocator = null;
					public IOSCustomCondition(String uiLocator) {
						this.uiLocator = uiLocator;
					}
					@Override
					public MobileElement apply(WebDriver arg0) {
						// TODO Auto-generated method stub
						IOSDriver d = (IOSDriver)arg0;
						MobileElement element = (MobileElement)d.findElementByIosUIAutomation(uiLocator);
						return element != null ? element : null;
					}
				}
				element = wait.until(new IOSCustomCondition(uiLocator));
				
				//Found element; Return that
				//element = (MobileElement)driver.findElementByIosUIAutomation(uiLocator);	
				
			} else if(uiLocator.startsWith("xpath=")) {
				uiLocator = uiLocator.substring(6);
				log("Identifying the element using xPath:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");
	
				WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
				//wait.until(ExpectedConditions.visibilityOf((MobileElement)driver.findElementByXPath(uiLocator)));

				//Found element; Return that
				//element = (MobileElement)driver.findElementByIosUIAutomation(uiLocator);
				class XPathCustomCondition implements ExpectedCondition<MobileElement> {
					String uiLocator = null;
					public XPathCustomCondition(String uiLocator) {
						this.uiLocator = uiLocator;
					}
					@Override
					public MobileElement apply(WebDriver arg0) {
						// TODO Auto-generated method stub
						IOSDriver d = (IOSDriver)arg0;
						MobileElement element = (MobileElement)d.findElementByXPath(uiLocator);
						return element != null ? element : null;
					}
				}
				element = wait.until(new XPathCustomCondition(uiLocator));
			} else if(uiLocator.startsWith("name=")) {
				uiLocator = uiLocator.substring(5);
				log("Identifying the element using Name:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");
				
				WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
				class Name implements ExpectedCondition<MobileElement> {
					String uiLocator = null;
					public Name(String uiLocator) {
						this.uiLocator = uiLocator;
					}
					@Override
					public MobileElement apply(WebDriver arg0) {
						// TODO Auto-generated method stub
						IOSDriver d = (IOSDriver)arg0;
						MobileElement element = (MobileElement)d.findElementByName(uiLocator);
						return element != null ? element : null;
					}
				}
				element = wait.until(new Name(uiLocator));
			} else if(uiLocator.startsWith("accessibilityid=")) {
				uiLocator = uiLocator.substring(16);
				log("Identifying the element using AccessibilityId:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");
				
				WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
				class AccessibilityId implements ExpectedCondition<MobileElement> {
					String uiLocator = null;
					public AccessibilityId(String uiLocator) {
						this.uiLocator = uiLocator;
					}
					@Override
					public MobileElement apply(WebDriver arg0) {
						// TODO Auto-generated method stub
						IOSDriver d = (IOSDriver)arg0;
						MobileElement element = (MobileElement)d.findElementByAccessibilityId(uiLocator);
						return element != null ? element : null;
					}
				}
				element = wait.until(new AccessibilityId(uiLocator));
			}
			
		} catch(Exception e) {
			log("Failed to find the element:" + uiLocator + " with in:" + timeOutInSeconds + " seconds... Error:" + e.getMessage());
			return null;
		}
		
		/*
		if(element != null) {
			String name = element.getAttribute("name");
			if(StringUtils.isNotBlank(name)) {
				log("Scrolling to element whose name is:" + name);
				driver.scrollTo(name);
			}
		}
		*/
		
		return element;
	}

	
	public List<WebElement> waitForElements(String uiLocatorKey) {
		return waitForElements(uiLocatorKey, getElementLoadTimeout());
	}
	
	public List<WebElement> waitForElements(String uiLocatorKey, long timeOutInSeconds) {
		List<WebElement> elements = null;
		String uiLocator = getUILocator(uiLocatorKey);
		if(uiLocator == null) {
			log("Failed to find the element key:" + uiLocatorKey + ", Using it as it is");
			uiLocator = uiLocatorKey;
		}
		try {
			if(uiLocator.startsWith("ios=")) {
				uiLocator = uiLocator.substring(4);
				log("Identifying the element using IOS way:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");
				
				WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
				class IOSCustomCondition implements ExpectedCondition<List<WebElement>> {
					String uiLocator = null;
					public IOSCustomCondition(String uiLocator) {
						this.uiLocator = uiLocator;
					}
					@Override
					public List<WebElement> apply(WebDriver arg0) {
						// TODO Auto-generated method stub
						IOSDriver d = (IOSDriver)arg0;
						List<WebElement> list = (List<WebElement>)d.findElementsByIosUIAutomation(uiLocator);
						return list != null && list.size() > 0 ? list : null;
					}
				}
				elements = wait.until(new IOSCustomCondition(uiLocator));
				
				//Found element; Return that
				//element = (MobileElement)driver.findElementByIosUIAutomation(uiLocator);	
				
			} else if(uiLocator.startsWith("xpath=")) {
				uiLocator = uiLocator.substring(6);
				log("Identifying the element using xPath:" + uiLocator + " with max timeout of:" + timeOutInSeconds + " seconds..");
	
				WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
				//wait.until(ExpectedConditions.visibilityOf((MobileElement)driver.findElementByXPath(uiLocator)));

				//Found element; Return that
				//element = (MobileElement)driver.findElementByIosUIAutomation(uiLocator);
				class XPathCustomCondition implements ExpectedCondition<List<WebElement>> {
					String uiLocator = null;
					public XPathCustomCondition(String uiLocator) {
						this.uiLocator = uiLocator;
					}
					@Override
					public List<WebElement> apply(WebDriver arg0) {
						// TODO Auto-generated method stub
						IOSDriver d = (IOSDriver)arg0;
						List<WebElement> list = (List<WebElement>)d.findElementsByXPath(uiLocator);
						return list != null && list.size() > 0 ? list : null;
					}
				}
				elements = wait.until(new XPathCustomCondition(uiLocator));
			}
		} catch(Exception e) {
			log("Failed to find the element:" + uiLocator + " with in:" + timeOutInSeconds + " seconds... Error:" + e.getMessage());
			return null;
		}
		
		return elements;
	}
	
	public boolean waitForElementWithText(String uiLocatorKey, String expectedText) {
		return waitForElementWithText(uiLocatorKey, expectedText, getElementLoadTimeout());
	}

	
	public boolean waitForElementWithText(String uiLocatorKey, String expectedText, long timeOutInSeconds) {
		
		WebElement element = waitForElement(uiLocatorKey);
		if(element == null) {
			log("Failed while waiting for the text in element:" + uiLocatorKey);
			return false;
		}
		WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
		return wait.until(ExpectedConditions.textToBePresentInElement(element, expectedText));
	}	
	
	public String waitForElementAndGetText(String uiLocatorKey) {
		return waitForElementAndGetText(uiLocatorKey, getElementLoadTimeout());
	}

	
	public String waitForElementAndGetText(String uiLocatorKey, long timeOutInSeconds) {
		
		try {
			WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
			//return wait.until(ExpectedConditions.textToBePresentInElement(element, expectedText));
			class CustomConditionVerifier implements ExpectedCondition<String> {
				String uiLocatorKey;
				public CustomConditionVerifier(String uiLocatorKey) {
					this.uiLocatorKey = uiLocatorKey;
				}
				@Override
				public String apply(WebDriver arg0) {
					// TODO Auto-generated method stub
					WebElement element = waitForElement(uiLocatorKey);
					if(element == null) {
						log("Failed while waiting for the text in element:" + uiLocatorKey);
						return null;
					}
					IOSDriver d = (IOSDriver)arg0;
					String value = element.getText();
					//String value = element.getAttribute("value");
					if(value != null) {
						value = value.trim();
						if(StringUtils.isNotEmpty(value)) {
							return value;
						}
					}
					return null;
				}
			}
			return wait.until(new CustomConditionVerifier(uiLocatorKey));
		} catch(Exception e) {
			log("Exception occurred while waiting for the data in the element:" + uiLocatorKey + ", Error:" + e.getMessage());
		}
		return null;
	}	
	
	public MobileElement waitForElementWithCustomAttribute(String uiLocatorKey, String attributeName, String attributeValue, StringVerification verifyOption, StringCase sensitive) {
		return waitForElementWithCustomAttribute(uiLocatorKey, attributeName, attributeValue, verifyOption, sensitive, getElementLoadTimeout());
	}	
	
	public MobileElement waitForElementWithCustomAttribute(String uiLocatorKey, String attributeName, String attributeValue, StringVerification verifyOption, StringCase sensitive, long timeOutInSeconds) {
		
		WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);
		class CustomAttributeVerifier implements ExpectedCondition<MobileElement> {
			String uiLocatorKey;
			String attributeName;
			String expectedValue;
			StringVerification v;
			StringCase c;
			public CustomAttributeVerifier(String uiLocatorKey, String attributeName, String expectedValue, StringVerification v, StringCase c) {
				this.uiLocatorKey = uiLocatorKey;
				this.attributeName = attributeName;
				this.expectedValue = expectedValue;
				this.v = v;
				this.c = c;
			}
			@Override
			public MobileElement apply(WebDriver arg0) {
				
				// TODO Auto-generated method stub
				boolean result = false;
				MobileElement element = waitForElement(uiLocatorKey);
				if(element != null) {
					String value = element.getAttribute(attributeName);
					if(v == StringVerification.STARTS_WITH) {
						
						if(c == StringCase.CASE_INSENSITIVE) {
							result = StringUtils.startsWithIgnoreCase(value, expectedValue);
						} else if(c == StringCase.CASE_SENSITIVE) {
							result = StringUtils.startsWith(value, expectedValue);
						}
					} else if(v == StringVerification.ENDS_WITH) {
						if(c == StringCase.CASE_INSENSITIVE) {
							result = StringUtils.endsWithIgnoreCase(value, expectedValue);
						} else if(c == StringCase.CASE_SENSITIVE) {
							result = StringUtils.endsWith(value, expectedValue);
						}
					} else if (v == StringVerification.CONTAINS) {
						if(c == StringCase.CASE_INSENSITIVE) {
							result = StringUtils.containsIgnoreCase(value, expectedValue);
						} else if(c == StringCase.CASE_SENSITIVE) {
							result = StringUtils.contains(value, expectedValue);
						}
					} else if(v == StringVerification.EXACTMATCH) {
						if(c == StringCase.CASE_INSENSITIVE) {
							result = StringUtils.equalsIgnoreCase(value, expectedValue);
						} else if(c == StringCase.CASE_SENSITIVE) {
							result = StringUtils.equals(value, expectedValue);
						}
					}
				}
				if(result == true) {
					return element;
				}
				return null;
			}
		}
		return wait.until(new CustomAttributeVerifier(uiLocatorKey, attributeName, attributeValue, verifyOption, sensitive));
	}	

	public void failCurrentTest() {
		
		//Take the screenshot on failure
		takeScreenshotNow();		
		//quit the app
		closeApp();
	}
	
}
