package com.apple.ist.caffemac.test.common;
import java.util.List;

import org.testng.asserts.Assertion;
import org.testng.asserts.IAssert;
import org.testng.collections.Lists;

public class CustomAssert extends Assertion {

	private List<String> m_messages = Lists.newArrayList();
	private ApplicationTestBase test;
	private WebApplicationTestBase webTest;
	private MobileApplicationTestBase mobileTest;

	public CustomAssert(WebApplicationTestBase wTest, MobileApplicationTestBase mTest) {
		webTest = wTest;
		mobileTest = mTest;
	}

	@Override
	public void onBeforeAssert(IAssert a) {
		//log("Before assert on:" + a.getMessage());
		m_messages.add("Test:" + a.getMessage());
	}

	@Override
	public void onAssertFailure(IAssert assertCommand, AssertionError ex) {
		super.onAssertFailure(assertCommand, ex);
		System.err.println(assertCommand.getMessage());
		if(webTest != null) {
			webTest.failCurrentTest();
		}
		if(mobileTest != null) {
			mobileTest.failCurrentTest();
		}
	}

	public List<String> getMessages() {
		return m_messages;
	}
}
