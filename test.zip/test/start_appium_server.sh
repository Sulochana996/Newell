#! /bin/bash
echo 'Starting the server...'
appium
echo 'Started the appium server in background. Waiting for 10 seconds...'
sleep 10
ps -ef | grep Appium
pid=`sh pid-for-server.sh "Appium"`
echo "The pid of the Appium server is:$pid"
