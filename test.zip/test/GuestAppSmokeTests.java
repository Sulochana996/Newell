package com.apple.ist.caffemac.test;

import java.text.DecimalFormat;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class GuestAppSmokeTests extends GuestApp {

	
	@Test(dataProvider = "loadTestData")
	public void verifyOrderPlacementUsingPayroll(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			JSONArray foodItemsToRemove = (JSONArray)testData.get("food_items_to_remove");
			String totalExpectedOrderValueAfterItemRemove = (String)testData.get("food_expected_total_order_value_after_remove");
			
			JSONArray foodItemsListAfterRemoval = (JSONArray)foodItems.clone();
			
			for(Object o : foodItemsToRemove) {
				String itemToRemove = (String)o;
				
				for(Object i : foodItems) {
					JSONObject item = (JSONObject)i;
					String itemName = (String)item.get("food_item_name");
					
					if(StringUtils.equalsIgnoreCase(itemToRemove, itemName)) {
						if(foodItemsListAfterRemoval.remove(item)) {
							log("Successfully removed the item:" + itemName);
							break;
						} else {
							log("Failed to remove the item:" + itemName);
						}
					}
				}
			}
			log("The final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
			
			//Update the food item total cost if required
			DecimalFormat frmt  = new DecimalFormat("0.00");
			for(Object o : foodItemsListAfterRemoval) {
				JSONObject item = (JSONObject)o;
				boolean iscustomItem = (Boolean)item.get("is_custom_item");
				log("Is custom item:" + iscustomItem);
				if(iscustomItem) {
					String itemPrice = (String)item.get("food_item_price");
					log("Item price:" + itemPrice);
					JSONArray customItems = (JSONArray)item.get("customize_food_item");
					double changeToIncrease = 0;
					for(Object k : customItems) {
						JSONObject customItem = (JSONObject)k;
						log("Item :" + customItem.toJSONString());
						String customItemPrice = (String)customItem.get("customize_food_item_increase_price");
						log("Item price to increase:" + customItemPrice);
						if(StringUtils.isNotBlank(customItemPrice)) {
							changeToIncrease += Double.parseDouble(customItemPrice);
						}
					}
					String totalItemPrice = frmt.format(Double.parseDouble(itemPrice) + changeToIncrease);
					log("Total price is:" + totalItemPrice);
					item.put("select_food_item_price_final", totalItemPrice);
				}
				
			}
			log("The Updated final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
			
			
			launch();
				//.login()
				//.selectCaffeLocation(caffe_location)
				//.orderGivenItems(foodItems, caffe_location)
				//.removeFoodItemsIfEnabled(foodItemsToRemove, totalExpectedOrderValueAfterItemRemove)
				//.checkOut()
			//.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyDeleteStandarditeminOrder(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			JSONArray foodItemsToRemove = (JSONArray)testData.get("food_items_to_remove");
			String totalExpectedOrderValueAfterItemRemove = (String)testData.get("food_expected_total_order_value_after_remove");
			
			JSONArray foodItemsListAfterRemoval = (JSONArray)foodItems.clone();
			
			for(Object o : foodItemsToRemove) {
				String itemToRemove = (String)o;
				
				for(Object i : foodItems) {
					JSONObject item = (JSONObject)i;
					String itemName = (String)item.get("food_item_name");
					
					if(StringUtils.equalsIgnoreCase(itemToRemove, itemName)) {
						if(foodItemsListAfterRemoval.remove(item)) {
							log("Successfully removed the item:" + itemName);
							break;
						} else {
							log("Failed to remove the item:" + itemName);
						}
					}
				}
			}
			log("The final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
			
			//Update the food item total cost if required
			DecimalFormat frmt  = new DecimalFormat("0.00");
			for(Object o : foodItemsListAfterRemoval) {
				JSONObject item = (JSONObject)o;
				boolean iscustomItem = (Boolean)item.get("is_custom_item");
				log("Is custom item:" + iscustomItem);
				if(iscustomItem) {
					String itemPrice = (String)item.get("food_item_price");
					log("Item price:" + itemPrice);
					JSONArray customItems = (JSONArray)item.get("customize_food_item");
					double changeToIncrease = 0;
					for(Object k : customItems) {
						JSONObject customItem = (JSONObject)k;
						log("Item :" + customItem.toJSONString());
						String customItemPrice = (String)customItem.get("customize_food_item_increase_price");
						log("Item price to increase:" + customItemPrice);
						if(StringUtils.isNotBlank(customItemPrice)) {
							changeToIncrease += Double.parseDouble(customItemPrice);
						}
					}
					String totalItemPrice = frmt.format(Double.parseDouble(itemPrice) + changeToIncrease);
					log("Total price is:" + totalItemPrice);
					item.put("select_food_item_price_final", totalItemPrice);
				}
				
			}
			log("The Updated final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
			
			launch()
				//.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.removeFoodItemsIfEnabled(foodItemsToRemove, totalExpectedOrderValueAfterItemRemove)
				.checkOut() 
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}


	@Test(dataProvider = "loadTestData")
	public void verifyNonUSEmployeeOrderPlacement(JSONObject testData) throws Exception {
		
		try {
			log("Data:" + testData.toJSONString());
			String caffe_location =  (String)testData.get("configure_caffe_station");
			JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
			
			String username = (String)testData.get("non_apple_employee_username");
			String password = (String)testData.get("non_apple_employee_password");
			
			launch()
				.login(username, password)
				.selectCaffeLocation(caffe_location)
				.isMyOrderEnabled()
			.quitApp();
			
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Non US Employee Order Placement. Error:" + e);			
		}
	}	
	
	/*@Test(dataProvider = "loadTestData")
	public void validateStandardOrders(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String numberOfItems = (String)testData.get("IncreaseNoOfItems");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			//launch();
			launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location) 
				.ChangeOrderQuantity(numberOfItems)
				.validatePriceStandard() 
				.toGoValidation()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add to Order button. Error:" + e);			
		}
	}*/
	
	@Test(dataProvider = "loadTestData")
	public void validateStandardOrders(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String caffe_version =  (String)testData.get("caffe_version");
			String station_type =  (String)testData.get("station_type");
			
			String numberOfItems = (String)testData.get("IncreaseNoOfItems");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			log(caffe_version+station_type);
			launch()
				.login()
				.selectCaffeLocation(caffe_location,caffe_version,station_type)
				.orderGivenItems(foodItems, caffe_location) 
				
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add to Order button. Error:" + e);			
		}
	}


	//***********************Sulo - Add to order Customized list ************************************
		@Test(dataProvider = "loadTestData")
		public void placeACustomizedItemOrderForListPayrollDeduction(JSONObject testData) throws Exception  {
			
			try {
				log("Data:" + testData.toJSONString());
				
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String caffe_version =  (String)testData.get("caffe_version");
				String station_type =  (String)testData.get("station_type");
				String amount= (String)testData.get("voucher_amount");
				
				String numberOfItems = (String)testData.get("IncreaseNoOfItems");
				JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
				//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
				JSONArray foodItems = new JSONArray();
				for(Object o : foodItemKeys) {
					String keyName = (String)o;
					log("Getting data for key:" + keyName);
					JSONObject foodData = (JSONObject)getData(keyName);
					JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
					
					for(Object i : sourceFoodItems) {
						foodItems.add(i);
					}
				}
				log(caffe_version+station_type);
				launch()
					.login()
					.selectCaffeLocation(caffe_location,caffe_version,station_type)
					.orderGivenItems(foodItems, caffe_location,station_type) 
					.checkoutThroughPayrollDeduction();
				    quitApp();
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Add to Order button and pay the order. Error:" + e);			
			}
		}
		
	
	//***********************Sulo - Add to order Customized list ************************************
	@Test(dataProvider = "loadTestData")
	public void placeACustomizedItemOrderForListPaywithVoucher(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String caffe_version =  (String)testData.get("caffe_version");
			String station_type =  (String)testData.get("station_type");
			String amount= (String)testData.get("voucher_amount");
			
			String numberOfItems = (String)testData.get("IncreaseNoOfItems");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			log(caffe_version+station_type);
			launch()
				.login()
				.selectCaffeLocation(caffe_location,caffe_version,station_type)
				.orderGivenItems(foodItems, caffe_location,station_type) 
				.clickPayVoucher(amount)
			    .quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add to Order button and pay the order. Error:" + e);			
		}
	}
	
	//***********************Sulo - Add to order Customized Option ************************************
		@Test(dataProvider = "loadTestData")
		public void placeACustomizedItemOrderForOptionPaywithVoucher(JSONObject testData) throws Exception  {
			
			try {
				log("Data:" + testData.toJSONString());
				
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String caffe_version =  (String)testData.get("caffe_version");
				String station_type =  (String)testData.get("station_type");
				String amount= (String)testData.get("voucher_amount");
				
				String numberOfItems = (String)testData.get("IncreaseNoOfItems");
				
				log("caffe location"+caffe_location);
				log("caffe caffe_version"+caffe_version);
				log("caffe station_type"+station_type);
				log("caffe amount"+amount);
				
				
				JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
				//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
				JSONArray foodItems = new JSONArray();
				for(Object o : foodItemKeys) {
					String keyName = (String)o;
					log("Getting data for key:" + keyName);
					JSONObject foodData = (JSONObject)getData(keyName);
					JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
					
					for(Object i : sourceFoodItems) {
						foodItems.add(i);
					}
				}
				log(caffe_version+station_type);
				launch()
					.login()
					.selectCaffeLocation(caffe_location,caffe_version,station_type)
					.orderGivenItems(foodItems,caffe_location,station_type) 
					.clickPayVoucher(amount)
				    .quitApp();
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Add to Order button and pay the order. Error:" + e);			
			}
		}
	
		//***********************Sulo - Add to order Customized Quantiy ************************************
		@Test(dataProvider = "loadTestData")
		public void placeACustomizedItemOrderForQuantityPaywithVoucher(JSONObject testData) throws Exception  {
			
			try {
				log("Data:" + testData.toJSONString());
				
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String caffe_version =  (String)testData.get("caffe_version");
				String station_type =  (String)testData.get("station_type");
				String amount= (String)testData.get("voucher_amount");
				
				String numberOfItems = (String)testData.get("IncreaseNoOfItems");
				JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
				//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
				JSONArray foodItems = new JSONArray();
				for(Object o : foodItemKeys) {
					String keyName = (String)o;
					log("Getting data for key:" + keyName);
					JSONObject foodData = (JSONObject)getData(keyName);
					JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
					
					for(Object i : sourceFoodItems) {
						foodItems.add(i);
					}
				}
				log(caffe_version+station_type);
				launch()
					.login()
					.selectCaffeLocation(caffe_location,caffe_version,station_type)
					.orderGivenItems(foodItems,caffe_location,station_type) 
					.clickPayVoucher(amount)
				    .quitApp();
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Add to Order button and pay the order. Error:" + e);			
			}
		}
		
	//***********************Sulo - Add to order Customized list and update ************************************
	@Test(dataProvider = "loadTestData")
	public void placeACustomizedItemWithUpdateAndOrderPaywithVoucher(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String caffe_version =  (String)testData.get("caffe_version");
			String station_type =  (String)testData.get("station_type");
			String updateItem = (String)testData.get("update_food_item_name");
			//String updateFoodItem = (String)testData.get("customize_food_item_to_update_category");
			//String updateFoodItemType = (String)testData.get("customize_food_item_to_update_category_type");
			String amount= (String)testData.get("voucher_amount");
		
			
			//Calling object
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
	
			//Calling update array data as object from app_config
			JSONArray foodUpdateItems = (JSONArray)testData.get("food_items_to_create");
			for(Object j : foodUpdateItems) {
				foodItems.add(j);
				System.out.println("items : "+foodItems.add(j));
				}
			
			//Calling update items form data as object from app_config
				 log("Current food item is a customized one..");
                 JSONArray customUpdateItems = (JSONArray)testData.get("customize_food_item_to_update");
                 System.out.println("cutomized_food_item "+ customUpdateItems);
		
                 log(caffe_version+station_type);
                 
                 //TestMethods
                 launch()
                 .login()
				.selectCaffeLocation(caffe_location,caffe_version,station_type)
				.orderGivenItems(foodItems, caffe_location,station_type) 
				.customizeOrderedItemAndUpdate(updateItem)    
				.clickPayVoucher(amount)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add to Order button. Error:" + e);			
		}
	}
	
	//***********************Sulo - Add to order Customized list and update as favorite************************************
		@Test(dataProvider = "loadTestData")
		public void validateCustomizedOrderAsFavourite(JSONObject testData) throws Exception  {
			
			try {
				log("Data:" + testData.toJSONString());
				//update_food_item_name
				
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String caffe_version =  (String)testData.get("caffe_version");
				String station_type =  (String)testData.get("station_type");
				String favouritemItem = (String)testData.get("food_item_name");
				String selectStation = (String)testData.get("select_station");
				
	
				log(caffe_version+station_type);
				log("caffe location"+caffe_location);
				log("caffe caffe_version"+caffe_version);
				log("caffe station_type"+station_type);
				log("caffe of favourite item is : "+favouritemItem);
		
				launch()
					.login()
					.selectCaffeLocation(caffe_location,caffe_version,station_type)
					.addfavouriteItem(station_type,selectStation)
					.customizeOrderAsFavourite(favouritemItem) 
				.quitApp();
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Add to Order button. Error:" + e);			
			}
		}
		
		//***********************Sulo - Add to order Customized list and update as favorite and uncheck favorite it ************************************
		@Test(dataProvider = "loadTestData")
		public void validateCustomizedOrderAsFavouriteAndUnCheckFavourite(JSONObject testData) throws Exception  {
			
			try {
				log("Data:" + testData.toJSONString());
				//update_food_item_name
				
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String caffe_version =  (String)testData.get("caffe_version");
				String station_type =  (String)testData.get("station_type");
				String favouritemItem = (String)testData.get("food_item_name");
				String selectStation = (String)testData.get("select_station");
				
	
				log(caffe_version+station_type);
				log("caffe location"+caffe_location);
				log("caffe caffe_version"+caffe_version);
				log("caffe station_type"+station_type);
				log("caffe of favourite item is : "+favouritemItem);
		
				launch()
					.login()
					.selectCaffeLocation(caffe_location,caffe_version,station_type)
					.addfavouriteItem(station_type,selectStation)
					.customizeOrderAsFavourite(favouritemItem) 
					.customizeOrderAsUnCheckFavourite(favouritemItem) 
				.quitApp();
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Add to Order button. Error:" + e);			
			}
		}
		
		
		//***********************Sulo -Validate the order Status************************************
				@Test(dataProvider = "loadTestData")
		public void validateCustomizedOrderStatus(JSONObject testData) throws Exception  {
					
					try {
						log("Data:" + testData.toJSONString());
						
						String caffe_location =  (String)testData.get("configure_caffe_station");
						String caffe_version =  (String)testData.get("caffe_version");
						String username =  (String)testData.get("username");
						String password =  (String)testData.get("password");
						
						
						String station_type =  (String)testData.get("station_type");
						String amount= (String)testData.get("voucher_amount");
						String station_type_s= (String)testData.get("select_station_s");
						String food_type= (String)testData.get("food_item_name_s");
						String setcaffename = (String)testData.get("IncreaseNoOfItems");
						
						log("caffe location"+caffe_location);
						log("caffe caffe_version"+caffe_version);
						log("caffe station_type"+station_type);
						log("caffe amount"+amount);
						
						
						JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
						//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
						JSONArray foodItems = new JSONArray();
						for(Object o : foodItemKeys) {
							String keyName = (String)o;
							log("Getting data for key:" + keyName);
							JSONObject foodData = (JSONObject)getData(keyName);
							JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
							
							for(Object i : sourceFoodItems) {
								foodItems.add(i);
							}
						}
						log(caffe_version+station_type);
						launch()
							.login()
							.selectCaffeLocation(caffe_location,caffe_version,station_type)
							.orderGivenItems(foodItems,caffe_location,station_type) 
							//.clickPayVoucher(amount)
							.clickPayrollDeduction()
							.validateThankyouPageAndOrderStatusContent(caffe_location,station_type_s,food_type)
						 .quitApp();
					} catch(Exception e) {
						Assert.assertTrue(false, "Exception while testing for Add to Order button and pay the order. Error:" + e);			
					}
				}
				
				
				
		//***********************Sulo -Validate the order History ************************************
				@Test(dataProvider = "loadTestData")
		public void validateCustomizedOrderHistory(JSONObject testData) throws Exception  {
					
					try {
						log("Data:" + testData.toJSONString());
						
						String caffe_location =  (String)testData.get("configure_caffe_station");
						String caffe_version =  (String)testData.get("caffe_version");
						String station_type =  (String)testData.get("station_type");
						String amount= (String)testData.get("voucher_amount");
						String station_type_s= (String)testData.get("select_station_s");
						String food_type= (String)testData.get("food_item_name_s");
						String foodType=(String)testData.get("food_type");
						
				
						
					
						
						log("caffe location"+caffe_location);
						log("caffe caffe_version"+caffe_version);
						log("caffe station_type"+station_type);
						log("caffe amount"+amount);
						
						
						JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
						//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
						JSONArray foodItems = new JSONArray();
						for(Object o : foodItemKeys) {
							String keyName = (String)o;
							log("Getting data for key:" + keyName);
							JSONObject foodData = (JSONObject)getData(keyName);
							JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
							
							for(Object i : sourceFoodItems) {
								foodItems.add(i);
							}
						}
						log(caffe_version+station_type);
						launch()
							.login()
							.selectCaffeLocation(caffe_location,caffe_version,station_type)
							.orderGivenItems(foodItems,caffe_location,station_type) 
							.clickPayrollDeduction()
							.validateThankyouPageAndOrderStatusContent(caffe_location,station_type_s,food_type)
							.verifyOrderHistory(caffe_location,station_type_s,food_type)
						 .quitApp();
					} catch(Exception e) {
						Assert.assertTrue(false, "Exception while testing for Add to Order button and pay the order. Error:" + e);			
					}
				}
					
			
		
	@Test(dataProvider = "loadTestData")
	public void validateLabelItem(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String caffe_version =  (String)testData.get("caffe_version");
			String station_type =  (String)testData.get("station_type");
			
			String numberOfItems = (String)testData.get("IncreaseNoOfItems");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			log(caffe_version+station_type);
			log("Add to order Customized list and update ");
		
	
			launch()
				.login()
				.selectCaffeLocation(caffe_location,caffe_version,station_type)
				.orderGivenItems(foodItems, caffe_location) 
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add to Order button. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void DebugScript(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String caffe_version =  (String)testData.get("caffe_version");
			String station_type =  (String)testData.get("station_type");
			
			String numberOfItems = (String)testData.get("IncreaseNoOfItems");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			log(caffe_version+station_type);
			//launch();
			launch()
				.login()
				//.Debugwait(caffe_location,caffe_version,station_type)
				.selectCaffeLocation(caffe_location,caffe_version,station_type)
				.orderGivenItems(foodItems, caffe_location,station_type) 
				//.ChangeOrderQuantity(numberOfItems)
				//.validatePriceStandard() 
				//.toGoValidation()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add to Order button. Error:" + e);			
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyPlaceOrderApplePay(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			
			launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkoutThroughApplePay()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add to Order button. Error:" + e);			
		}
	}
	

	@Test(dataProvider = "loadTestData")
	public void verifyQuantityStepupStandard(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			
			launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.validateQuantityIncreaseStandard(foodItems) 
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Quantity. Error:" + e);			
		}
	}


	/*Unable to automate because of + & - Buttons
	 * @Test(dataProvider = "loadTestData")
	public void verifyModificationItemFromCartCustomize(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			
			launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.updateCustomizeMenu(foodItems) 
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Quantity. Error:" + e);			
		}
	}*/
/*
	@Test(dataProvider = "loadTestData")
	public void verifyHidePayrollButtonWhenOff(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			
			launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.validateHidePayrollOff()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Quantity. Error:" + e);			
		}
	}
	*/
	@Test(dataProvider = "loadTestData")
	public void verifyPayrollButtonAuthScreen(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			
			launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.verifyPayrollButtonAuthScreen()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Quantity. Error:" + e);			
		}
	}
	

	@Test(dataProvider = "loadTestData")
	public void verifyOrderFromSpecialsScreen(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			
			launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.verifySpecialMenu(foodItems)
				//.verifyItemFromSpecialsScreen(foodItems)
				.orderFromSpecialsScreen(foodItems)
				.checkoutThroughPayrollDeduction()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while placing orders from Specials screen. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyPayrollForType1User(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			
			launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkoutThroughPayrollDeduction()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Payroll Deduction button. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyPlaceOrderPayrollDeduction(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			
			launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.validatePayrollDeductWhenHide()
				.validatePayrollDeductWhenNotHide()
				.validatePayrollAuthScreen()
				.orderGivenItems(foodItems, caffe_location)
				.checkoutThroughPayrollDeduction()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Payroll Deduction button. Error:" + e);			
		}
	}

	
	@Test(dataProvider = "loadTestData")
	public void verifyPlaceOrderAfterChangingCaffe(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			
			launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkoutThroughPayrollDeduction()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Payroll Deduction button. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyApplePayForType4User(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}

			String username = (String)testData.get("non_apple_employee_username");
			String password = (String)testData.get("non_apple_employee_password");
			log(username);
			log(password);
			
			launch()
				.login(username, password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.verifyApplePayForType4()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while verifying apple pay for Type 4 user. Error:" + e);			
		}
	}
	
	
	//Sulochana 
	@Test(dataProvider = "loadTestData")
	public void verifyCaffeDetails(JSONObject testData) throws Exception  {
		
		try {
			
			log("Data:" + testData.toJSONString());
			String aCaffeLocation =  (String)testData.get("configure_caffe_station");
			String caffe_version =  (String)testData.get("caffe_version");
			String caffename =  (String)testData.get("m_caffe_name");
			String caffeaddress =  (String)testData.get("m_caffe_address");
		//	String moreinformation =  (String)testData.get("station_more_info");
			log("****************Data******************:" +caffename+caffeaddress);
			
              /* //Print the data
			 log("Current food item is a customized one.."+testData.toJSONString());*/
            
			launch()
				.login()
				.selectCaffeLocationHomePage(aCaffeLocation,caffe_version)
				.selectMoreInfo()
				.validateCaffeNameAndCaffeAddress(caffename,caffeaddress)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while verifying caffe address in Caffe screen. Error:" + e);			
		}
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void validateDefaultCaffeLocation(JSONObject testData) throws Exception  {

		try {
			
			log("Data:" + testData.toJSONString());
			
			//String setStationNameSelect =  (String)testData.get("station_name");
			String setStationName =  (String)testData.get("station_name");
			//String getStationName =  (String)testData.get("verify_lbl_default_caffe_home_page");
			launch()
				.login()
				.verifyDefaultCaffeLocation(setStationName)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while verifying caffe address in Caffe screen. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyVoucherPaymentMode(JSONObject testData) throws Exception  {

		try {
			
			log("Data:" + testData.toJSONString());
			
			//String setStationNameSelect =  (String)testData.get("station_name");
			String setStationName =  (String)testData.get("station_name");
			launch()
				.login()
				.verifyDefaultCaffeLocation(setStationName)
				.verifyVoucherPaymentModesAsMealPrgOrMealVoucher(setStationName)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while verifying caffe address in Caffe screen. Error:" + e);			
		}
	}
	

	
	@Test(dataProvider = "loadTestData")
	public void verifyOrderThroughMealProgramLessThanOrEqualToAmount(JSONObject testData) throws Exception  {
		
			try {
				log("Data:" + testData.toJSONString());
			//	String totalExpectedOrderValue = null;
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String caffe_version =  (String)testData.get("caffe_version");
				String station_type =  (String)testData.get("station_type");
				JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
				String totalExpectedOrderValued = (String)testData.get("voucher_amount");
				String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			
				JSONArray foodItems = new JSONArray();
				for(Object o : foodItemKeys) {
					String keyName = (String)o;
					log("Getting data for key:" + keyName);
					JSONObject foodData = (JSONObject)getData(keyName);
					JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
					for(Object i : sourceFoodItems) {
						foodItems.add(i);
						//String foodItemDetail = i.toString();
						JSONObject foodItemDetails = (JSONObject) i;
					//	totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
					}
				}
			//	JSONArray vouchersList = (JSONArray)testData.get("vouchers");
				
				
			
				launch()
					.login()
					.selectCaffeLocation(caffe_location,caffe_version,station_type)
					.orderGivenItems(foodItems, caffe_location,station_type) 
					//	.voucherAvailablity()
						/*.voucherDetails()
					.selectVoucher(vouchersList)*/
					
					.payVoucherBtnLessAmount(totalExpectedOrderValued)
				.quitApp();
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
			}
		}
		
	
	@Test(dataProvider = "loadTestData")
	public void verifyOrderThroughMealVoucherLessThanOrEqualToAmount(JSONObject testData) throws Exception  {
		
			try {
				log("Data:" + testData.toJSONString());
			//	String totalExpectedOrderValue = null;
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String caffe_version =  (String)testData.get("caffe_version");
				String station_type =  (String)testData.get("station_type");
				JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
				String totalExpectedOrderValued = (String)testData.get("voucher_amount");
				String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			
				JSONArray foodItems = new JSONArray();
				for(Object o : foodItemKeys) {
					String keyName = (String)o;
					log("Getting data for key:" + keyName);
					JSONObject foodData = (JSONObject)getData(keyName);
					JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
					for(Object i : sourceFoodItems) {
						foodItems.add(i);
						//String foodItemDetail = i.toString();
						JSONObject foodItemDetails = (JSONObject) i;
					//	totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
					}
				}
			//	JSONArray vouchersList = (JSONArray)testData.get("vouchers");
				
				
			
				launch()
					.login()
					.selectCaffeLocation(caffe_location,caffe_version,station_type)
					.orderGivenItems(foodItems, caffe_location,station_type) 
						//.voucherAvailablity()
						/*.voucherDetails()
					.selectVoucher(vouchersList)*/
					
					.payMealVoucherBtnLessAmount(totalExpectedOrderValued)
				.quitApp();
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
			}
		}
		


	@Test(dataProvider = "loadTestData")
	public void verifyOrderThroughMealProgramAndMealVoucherLessThanOrEqualToAmount(JSONObject testData) throws Exception  {
		
			try {
				log("Data:" + testData.toJSONString());
			//	String totalExpectedOrderValue = null;
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String caffe_version =  (String)testData.get("caffe_version");
				String station_type =  (String)testData.get("station_type");
				JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
				String totalExpectedOrderValuedMP = (String)testData.get("voucher_meal_program_amount");
				String totalExpectedOrderValuedMV = (String)testData.get("voucher_meal_voucher_amount");
				String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			
				JSONArray foodItems = new JSONArray();
				for(Object o : foodItemKeys) {
					String keyName = (String)o;
					log("Getting data for key:" + keyName);
					JSONObject foodData = (JSONObject)getData(keyName);
					JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
					for(Object i : sourceFoodItems) {
						foodItems.add(i);
						//String foodItemDetail = i.toString();
						JSONObject foodItemDetails = (JSONObject) i;
					//	totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
					}
				}
			//	JSONArray vouchersList = (JSONArray)testData.get("vouchers");
				
				
			
				launch()
					.login()
					.selectCaffeLocation(caffe_location,caffe_version,station_type)
					.orderGivenItems(foodItems, caffe_location,station_type) 
				//	.voucherAvailablity()
				//	.voucherDetails()
					//.selectVoucher(vouchersList)
					
					.payMealProgramAndMealVoucherBtnLessAmount(totalExpectedOrderValuedMP,totalExpectedOrderValuedMV)
				.quitApp();
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
			}
		}
		

	

	@Test(dataProvider = "loadTestData")
	public void verifyDeselectedSameMealProgramVoucherUsedForNextOrder(JSONObject testData) throws Exception  {
		
			try {
				log("Data:" + testData.toJSONString());
			//	String totalExpectedOrderValue = null;
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String caffe_version =  (String)testData.get("caffe_version");
				String station_type =  (String)testData.get("station_type");
				JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
				String totalExpectedOrderValuedMP = (String)testData.get("voucher_meal_program_amount");
				String amount= (String)testData.get("voucher_amount");
				String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			
				JSONArray foodItems = new JSONArray();
				for(Object o : foodItemKeys) {
					String keyName = (String)o;
					log("Getting data for key:" + keyName);
					JSONObject foodData = (JSONObject)getData(keyName);
					JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
					for(Object i : sourceFoodItems) {
						foodItems.add(i);
						//String foodItemDetail = i.toString();
						JSONObject foodItemDetails = (JSONObject) i;
					//	totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
					}
				}
			//	JSONArray vouchersList = (JSONArray)testData.get("vouchers");
				
				
			
				launch()
					.login()
					.selectCaffeLocation(caffe_location,caffe_version,station_type)
					.orderGivenItems(foodItems, caffe_location,station_type) 
					.clickToSelectPayVoucher()
					.clickToDeSelectVoucher()
					.landHomePageDeSelect()
					
					.orderGivenItems(foodItems, caffe_location,station_type) 
					.clickToPayVoucherAgain()
				.quitApp();
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
			}
		}
		

	
	
	
	@Test(dataProvider = "loadTestData")
	public void verifyDeleteCustomizediteminOrder(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			JSONArray foodItemsToRemove = (JSONArray)testData.get("food_items_to_remove");
			String totalExpectedOrderValueAfterItemRemove = (String)testData.get("food_expected_total_order_value_after_remove");
			
			JSONArray foodItemsListAfterRemoval = (JSONArray)foodItems.clone();
			
			for(Object o : foodItemsToRemove) {
				String itemToRemove = (String)o;
				
				for(Object i : foodItems) {
					JSONObject item = (JSONObject)i;
					String itemName = (String)item.get("food_item_name");
					
					if(StringUtils.equalsIgnoreCase(itemToRemove, itemName)) {
						if(foodItemsListAfterRemoval.remove(item)) {
							log("Successfully removed the item:" + itemName);
							break;
						} else {
							log("Failed to remove the item:" + itemName);
						}
					}
				}
			}
			log("The final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
			
			//Update the food item total cost if required
			DecimalFormat frmt  = new DecimalFormat("0.00");
			for(Object o : foodItemsListAfterRemoval) {
				JSONObject item = (JSONObject)o;
				boolean iscustomItem = (Boolean)item.get("is_custom_item");
				log("Is custom item:" + iscustomItem);
				if(iscustomItem) {
					String itemPrice = (String)item.get("food_item_price");
					log("Item price:" + itemPrice);
					JSONArray customItems = (JSONArray)item.get("customize_food_item");
					double changeToIncrease = 0;
					for(Object k : customItems) {
						JSONObject customItem = (JSONObject)k;
						log("Item :" + customItem.toJSONString());
						String customItemPrice = (String)customItem.get("customize_food_item_increase_price");
						log("Item price to increase:" + customItemPrice);
						if(StringUtils.isNotBlank(customItemPrice)) {
							changeToIncrease += Double.parseDouble(customItemPrice);
						}
					}
					String totalItemPrice = frmt.format(Double.parseDouble(itemPrice) + changeToIncrease);
					log("Total price is:" + totalItemPrice);
					item.put("select_food_item_price_final", totalItemPrice);
				}
				
			}
			log("The Updated final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
			
			launch()
				//.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.removeFoodItemsIfEnabled(foodItemsToRemove, totalExpectedOrderValueAfterItemRemove)
				.checkOut() 
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}

	@Test(dataProvider = "loadTestData")
	public void verifySeperateOrderIdCustomizeditems(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			launch()
				//.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(totalExpectedOrderValue)
				.reteriveorderdetails()
				.ValidateOrder(totalExpectedOrderValue)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void VerifyModifyOrder(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			String ChangeItemQuantity = (String)testData.get("ChangeQuantity");
			
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.modifyCustomize(ChangeItemQuantity)
				.checkoutThroughPayrollDeduction()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifySeperateOrderIdsStandardnCustomize(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			launch()
				//.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(totalExpectedOrderValue)
				.reteriveorderdetails()
				.ValidateOrder(totalExpectedOrderValue)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifySeperateOrderIdStandarditems(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			launch()
				//.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(totalExpectedOrderValue)
				.reteriveorderdetails()
				.ValidateOrder(totalExpectedOrderValue)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyOrdernumberAndStatusofitems(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			launch()
				//.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.checkOut(totalExpectedOrderValue)
				.reteriveorderdetails()
				.ValidateOrder(totalExpectedOrderValue)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}


	@Test(dataProvider = "loadTestData")
	public void verifyAvailableVouchersForUserWithoutVoucher(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			//String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}

	

	@Test(dataProvider = "loadTestData")
	public void verifyPayVoucherBtnDispOrderItemIsLessThanVoucherPriceUncheck(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}

			JSONArray vouchersList = (JSONArray)testData.get("vouchers");
			String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			launch()
				//.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.payVoucherBtnValidation(vouchersList,totalExpectedOrderValue)
				.validateTotalaftUncheck(uncheckVoucher)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyPayrollDeductionBtnDispOrderItemIsGreaterThanVoucherPrice(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("vouchers");
			String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.payVoucherBtnValidation(vouchersList,totalExpectedOrderValue)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Payroll deduction and iPay button is displayed when the order Item detail is Greater than voucher amount. Error:" + e);			
		}
	}
	

	@Test(dataProvider = "loadTestData")
	public void verifyMealProgramDetails(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray mealProgramList = (JSONArray)testData.get("meal_program");
			
			launch()
				.login(username,password)
				.validatevoucher()
				.validateMealProgram(mealProgramList)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Payroll deduction and iPay button is displayed when the order Item detail is Greater than voucher amount. Error:" + e);			
		}
	}


	@Test(dataProvider = "loadTestData")
	public void verifyTransferVoucherPage(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			String transferemail = (String)testData.get("transfer_email_address");
			String employeeType = (String)testData.get("transfer_email_Type");
			JSONArray voucherList = (JSONArray) testData.get("vouchers");

			launch()
				//.login(username,password)
				.validatevoucher()
				.vouchersInAscendingOrder()
				.validateVouchers(voucherList)
				.voucherAmountTransferPage()
				.transferVoucher(transferemail,employeeType)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Transfer voucher page displayed by clicking transfer button. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyEmailIdTransferVoucherPageForDiffTypeEmployees(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			String transferemail1 = (String)testData.get("transfer_email_address_type1");
			String transferemail2 = (String)testData.get("transfer_email_address_type4");
			String transferemail3 = (String)testData.get("transfer_email_address_type_others");
			String employeeType1 = (String)testData.get("transfer_email_Type1");
			String employeeType2 = (String)testData.get("transfer_email_Type2");
			String employeeType3 = (String)testData.get("transfer_email_Type3");
			JSONArray voucherList = (JSONArray) testData.get("vouchers");
			launch()
				//.login(username,password)
				.validatevoucher()
				.validateVouchers(voucherList)
				.transferVoucher()
				.transferVoucher(transferemail1,employeeType1)
				.validateVouchers(voucherList)
				.transferVoucher()
				.transferVoucher(transferemail2,employeeType2)
				.validateVouchers(voucherList)
				.transferVoucher()
				.transferVoucher(transferemail3,employeeType3)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Transfer voucher page displayed by clicking transfer button. Error:" + e);			
		}
	}
	

	@Test(dataProvider = "loadTestData")
	public void verifyChangeinQuantity(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			String numberOfItems = (String)testData.get("ChangenumberofItem");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.ChangeOrderQuantity(numberOfItems)
				.checkOutforstandardItems(totalExpectedOrderValue)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Change in Quantity. Error:" + e);			
		}
	}

	
	@Test(dataProvider = "loadTestData")
	public void verifyCustomizedOrders(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			String numberOfItems = (String)testData.get("IncreaseNoOfItems");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			JSONArray foodItemsToRemove = (JSONArray)testData.get("food_items_to_remove");
			String totalExpectedOrderValueAfterItemRemove = (String)testData.get("food_expected_total_order_value_after_remove");
			
			JSONArray foodItemsListAfterRemoval = (JSONArray)foodItems.clone();
			
			for(Object o : foodItemsToRemove) {
				String itemToRemove = (String)o;
				
				for(Object i : foodItems) {
					JSONObject item = (JSONObject)i;
					String itemName = (String)item.get("food_item_name");
					
					if(StringUtils.equalsIgnoreCase(itemToRemove, itemName)) {
						if(foodItemsListAfterRemoval.remove(item)) {
							log("Successfully removed the item:" + itemName);
							break;
						} else {
							log("Failed to remove the item:" + itemName);
						}
					}
				}
			}
			log("The final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
			launch()
				//.login(username,password)
			//	.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				//.DeleteOrder(foodItemsToRemove)
				//.orderGivenItems(foodItems, caffe_location)
				//.ChangeOrderQuantity(numberOfItems)
				//.validatePriceStandard()
				.checkOut()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add to order button. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void VerifyMaxServingCustomize(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add to order button. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void VerifyMinServingCustomize(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add to order button. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validatePayWithVoucherBtnAvailable(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					//String foodItemDetail = i.toString();
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("vouchers");
			//String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			launch()
				//.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.payVoucherBtnLessAmount(totalExpectedOrderValue)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validatePayrollWhenMVMPAvailable(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					//String foodItemDetail = i.toString();
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("vouchers");
			//String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.checkOut()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void validateOrderThroMV(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					//String foodItemDetail = i.toString();
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("vouchers");
			//String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			String voucherValue = "10.00";
			String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			launch()
				//.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.selectVoucher(voucherValue)
				.checkOutThroMealVoucher()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateOrderThroMVAndPayroll(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					//String foodItemDetail = i.toString();
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("vouchers");
			//String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			String voucherValue = "10.00";
			String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.selectVoucher(voucherValue)
				.checkOutThroMealVoucherAndPayroll()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyVoucherRemovedWhenDeletedMenu(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
		JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
		JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					//String foodItemDetail = i.toString();
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray foodItemsToRemove = (JSONArray)testData.get("food_items_to_remove");
			String totalExpectedOrderValueAfterItemRemove = (String)testData.get("food_expected_total_order_value_after_remove");
			
			JSONArray foodItemsListAfterRemoval = (JSONArray)foodItems.clone();
			
			for(Object o : foodItemsToRemove) {
				String itemToRemove = (String)o;
				
				for(Object i : foodItems) {
					JSONObject item = (JSONObject)i;
					String itemName = (String)item.get("food_item_name");
					
					if(StringUtils.equalsIgnoreCase(itemToRemove, itemName)) {
						if(foodItemsListAfterRemoval.remove(item)) {
							log("Successfully removed the item:" + itemName);
							break;
						} else {
							log("Failed to remove the item:" + itemName);
						}
					}
				}
			}
			log("The final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
			
			JSONArray vouchersList = (JSONArray)testData.get("vouchers");
			//String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			String voucherValue = "10.00";
			String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			launch()
				.login()
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.selectVoucher(voucherValue)
				.toCloseSelectVoucher()
				.removeFoodItemsIfEnabled(foodItemsToRemove, totalExpectedOrderValueAfterItemRemove)
				.validateMealVoucherUnSelected()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
	}


	@Test(dataProvider = "loadTestData")
	public void verifySameMealVoucherUsedAftUncheck(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("vouchers");
			String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
			
			String uncheckVoucher = (String)testData.get("voucher_to_uncheck");
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.voucherDetails()
				.toCloseSelectVoucher()
				.payVoucherBtnValidation(vouchersList,totalExpectedOrderValue)
				.validateTotalaftUncheck(uncheckVoucher)
				.voucherDetails()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData", dependsOnMethods = {"verifyEmailIdTransferVoucherPageForDiffTypeEmployees"})
	public void verifyPayTransferedVoucher(JSONObject testData) throws Exception  {
		
			try {
				log("Data:" + testData.toJSONString());
				String totalExpectedOrderValue = null;
				String caffe_location =  (String)testData.get("configure_caffe_station");
				String username = (String)testData.get("US_apple_employee_username");
				String password = (String)testData.get("US_apple_employee_password");
				JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
				//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
				JSONArray foodItems = new JSONArray();
				for(Object o : foodItemKeys) {
					String keyName = (String)o;
					log("Getting data for key:" + keyName);
					JSONObject foodData = (JSONObject)getData(keyName);
					JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
					for(Object i : sourceFoodItems) {
						foodItems.add(i);
						//String foodItemDetail = i.toString();
						JSONObject foodItemDetails = (JSONObject) i;
						totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
					}
				}
				JSONArray vouchersList = (JSONArray)testData.get("vouchers");
				//String totalExpectedOrderValue = (String)testData.get("food_expected_total_order_value");
				//String voucherValue = "10.00";
				launch()
					.login(username,password)
					.selectCaffeLocation(caffe_location)
					.orderGivenItems(foodItems, caffe_location)
					.voucherAvailablity()
					.selectVoucher(vouchersList)
					.checkOutThroMealVoucher()
				.quitApp();
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
			}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyMealProgramIsDisplayed1(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray mealProgramList = (JSONArray)testData.get("meal_program");
			launch()
				.login(username,password)
				.getTime(mealProgramList ,foodItems, caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}

	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyMealProgramIsDisplayed2(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray mealProgramList = (JSONArray)testData.get("meal_program");
			launch()
				.login(username,password)
				.getTime(mealProgramList ,foodItems, caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}

	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyMealProgramIsDisplayed3(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray mealProgramList = (JSONArray)testData.get("meal_program");
			launch()
				.login(username,password)
				.getTime(mealProgramList ,foodItems, caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}

	}
	
	@Test(dataProvider = "loadTestData")
	public void VerifympDisplayed(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("meal_program");
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.selectMealProgram(vouchersList)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
		}
	
	@Test(dataProvider = "loadTestData")
	public void verifyPayWithMealProgram(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("meal_program");
			resetMealProgram();
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.selectMealProgram(vouchersList)
				.checkOutThroMealVoucher()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
		}
	
	@Test(dataProvider = "loadTestData")
	public void verifyPayWithMealProgramMealVoucher(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("meal_program");
			JSONArray vouchersList1 = (JSONArray)testData.get("vouchers");
			resetMealProgram();
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.selectMealProgram(vouchersList)
				.selectVoucherAfterMP(vouchersList1)
				.checkOutThroMealVoucher()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
		}
	@Test(dataProvider = "loadTestData")
	public void verifyPayWithMealProgramPayroll(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("meal_program");
			resetMealProgram();
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.selectMealProgram(vouchersList)
				.checkOutThroMealVoucherAndPayroll()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
		}
	@Test(dataProvider = "loadTestData")
	public void verifyPayWithMealProgramVoucherPayroll(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("meal_program");
			JSONArray vouchersList1 = (JSONArray)testData.get("vouchers");
			resetMealProgram();
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.selectMealProgram(vouchersList)
				.selectVoucherAfterMP(vouchersList1)
				.checkOutThroMealVoucherAndPayroll()
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
		}
	@Test(dataProvider = "loadTestData")
	public void verifyMealProgramIsPresentSameSession(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("meal_program");
			JSONArray vouchersList1 = (JSONArray)testData.get("vouchers");
			resetMealProgram();
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.selectMealProgram(vouchersList)
				.checkOutThroMealVoucher()
				.orderAgainSameSession()
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.validateMPIsNotPresent(vouchersList)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
		}
	
	@Test(dataProvider = "loadTestData")
	public void verifyMealProgramIsPresentDiffSession(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			String totalExpectedOrderValue = null;
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
					JSONObject foodItemDetails = (JSONObject) i;
					totalExpectedOrderValue = (String)foodItemDetails.get("food_item_price");
				}
			}
			JSONArray vouchersList = (JSONArray)testData.get("meal_program");
			JSONArray vouchersList1 = (JSONArray)testData.get("vouchers");
			resetMealProgram();
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.selectMealProgram(vouchersList)
				.checkOutThroMealVoucher()
			.quitApp();
			
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.voucherAvailablity()
				.validateMPIsNotPresent(vouchersList)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Pay voucher button is displayed when the order Item detail is less than voucher amount. Error:" + e);			
		}
		}
	@Test(dataProvider = "loadTestData")
	public void verifyMealProgramRemovedAfterDelete(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			JSONArray foodItemsToRemove = (JSONArray)testData.get("food_items_to_remove");
			String totalExpectedOrderValueAfterItemRemove = (String)testData.get("food_expected_total_order_value_after_remove");
			
			JSONArray foodItemsListAfterRemoval = (JSONArray)foodItems.clone();
			resetMealProgram();
			for(Object o : foodItemsToRemove) {
				String itemToRemove = (String)o;
				
				for(Object i : foodItems) {
					JSONObject item = (JSONObject)i;
					String itemName = (String)item.get("food_item_name");
					
					if(StringUtils.equalsIgnoreCase(itemToRemove, itemName)) {
						if(foodItemsListAfterRemoval.remove(item)) {
							log("Successfully removed the item:" + itemName);
							break;
						} else {
							log("Failed to remove the item:" + itemName);
						}
					}
				}
			}
			log("The final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
			
			//Update the food item total cost if required
			DecimalFormat frmt  = new DecimalFormat("0.00");
			for(Object o : foodItemsListAfterRemoval) {
				JSONObject item = (JSONObject)o;
				boolean iscustomItem = (Boolean)item.get("is_custom_item");
				log("Is custom item:" + iscustomItem);
				if(iscustomItem) {
					String itemPrice = (String)item.get("food_item_price");
					log("Item price:" + itemPrice);
					JSONArray customItems = (JSONArray)item.get("customize_food_item");
					double changeToIncrease = 0;
					for(Object k : customItems) {
						JSONObject customItem = (JSONObject)k;
						log("Item :" + customItem.toJSONString());
						String customItemPrice = (String)customItem.get("customize_food_item_increase_price");
						log("Item price to increase:" + customItemPrice);
						if(StringUtils.isNotBlank(customItemPrice)) {
							changeToIncrease += Double.parseDouble(customItemPrice);
						}
					}
					String totalItemPrice = frmt.format(Double.parseDouble(itemPrice) + changeToIncrease);
					log("Total price is:" + totalItemPrice);
					item.put("select_food_item_price_final", totalItemPrice);
				}
				
			}
			log("The Updated final order to be verified in checkout is:" + foodItemsListAfterRemoval.toJSONString());
			JSONArray vouchersList = (JSONArray)testData.get("meal_program");
			
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
				.navigateToMyOrderPage()
				.selectMealProgram(vouchersList)
				.removeFoodItemsIfEnabled(foodItemsToRemove, totalExpectedOrderValueAfterItemRemove)
				.checkOut() 
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void VerifyNotRequiredFoodGroup(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			String ChangeItemQuantity = (String)testData.get("ChangeQuantity");
			
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}
	@Test(dataProvider = "loadTestData")
	public void VerifyRequiredFoodGroup(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			String ChangeItemQuantity = (String)testData.get("ChangeQuantity");
			
			launch()
				.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}
	@Test(dataProvider = "loadTestData")
	public void sampleScript(JSONObject testData) throws Exception  {
		
		try {
			log("Data:" + testData.toJSONString());
			
			String caffe_location =  (String)testData.get("configure_caffe_station");
			String username = (String)testData.get("US_apple_employee_username");
			String password = (String)testData.get("US_apple_employee_password");
			JSONArray foodItemKeys = (JSONArray)testData.get("food_items_to_order");
			//JSONArray foodItems = (JSONArray)testData.get("food_items_to_order");
			JSONArray foodItems = new JSONArray();
			for(Object o : foodItemKeys) {
				String keyName = (String)o;
				log("Getting data for key:" + keyName);
				JSONObject foodData = (JSONObject)getData(keyName);
				JSONArray sourceFoodItems = (JSONArray)foodData.get("food_items_to_create");
				for(Object i : sourceFoodItems) {
					foodItems.add(i);
				}
			}
			String ChangeItemQuantity = (String)testData.get("ChangeQuantity");
			
			launch()
				//.login(username,password)
				.selectCaffeLocation(caffe_location)
				.orderGivenItems(foodItems, caffe_location)
			.quitApp();
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Order Placement Using Payroll. Error:" + e);			
		}
	}
}
