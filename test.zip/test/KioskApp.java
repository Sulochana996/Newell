package com.apple.ist.caffemac.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebElement;

import com.apple.ist.caffemac.test.common.MobileApplicationTestBase;
import com.apple.ist.caffemac.test.util.AppUtilities;

import io.appium.java_client.MobileElement;

public class KioskApp extends MobileApplicationTestBase {

	public static final String APPNAME= "kiosk";
	public String temp;
	public String applicationUserName; 
	public String applicationUserPassword; 
	public KioskApp() {
		super(APPNAME);
	}
	
	public KioskApp(JSONObject dataObject) {
		super(APPNAME);
		appObject = dataObject;
	}

	 public KioskApp(JSONObject dataObject, JSONObject runParams) {
	        super(APPNAME);
	        appObject = dataObject;
	        initWithParams(runParams);
	    }
	
	public KioskApp launch() throws Exception {
		
		//Commented by Chithra
		launchAppleConnect_iPad();
		appleConnectLogin();
		//quitApp();
		applicationUserName = getAppLoginUsername();
		applicationUserPassword = getAppLoginPassword();
		Assert.assertTrue(launchApp_iPad(), "Failed in launching the App:" + APPNAME);
		
		//Assert.assertTrue(launchApp(), "Failed in launching the App:" + APPNAME);
		return this;
	}
	
	public KioskApp registerStations() {
		//List<String> value = new ArrayList<String>();
		//List<String> name = new ArrayList<String>();
		List<WebElement> stations = driver.findElements(By.className("UIATableCell"));
		for(int i=0; i<stations.size(); i++) {
			//value.add((stations.get(i)).getAttribute("value"));
			String value = (stations.get(i)).getAttribute("value");
			if(value.equals("1")) {
				String name = (stations.get(i)).getAttribute("name");
				if (!name.contains("Stations")) {
					String stationName = getUILocator("cell_station_to_select").replaceAll("<REPLACE_ITEM_TO_SELECT>", name);
					Assert.assertTrue(clickElement(stationName), "Failed to click the Station name");
				}
			}
			//log("Reading the item of:" +name);
			}
		return this;
	}
	
	public KioskApp appleConnectLogin() {
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("button_appleconnect_settings"), "Failed to find the settings button");
		Assert.assertTrue(clickElement("button_appleconnect_advanced_settings"), "Failed to find the advanced settins screen");
		Assert.assertTrue(clickElement("button_appleconnect_reset"), "Failed to click the appleconnect reset button");
		String alertResetAppleConnectLocator = getUILocator("alert_reset_appleconnect_button");
		MobileElement alertResetAppleConnect = isElementPresent(alertResetAppleConnectLocator);
		if (alertResetAppleConnect!=null) {
			Assert.assertTrue(clickElement(alertResetAppleConnectLocator), "Failed to click reset appleconnect alert message");
		}
		MobileElement environmentSwitch = waitForElement("switchbutton_appleconnect_prompt_environment");
		String environmentSwitchValue = environmentSwitch.getAttribute("value");
		log("The value of the switch is: "+environmentSwitchValue);
		if (environmentSwitchValue.equals("0")) {
			Assert.assertTrue(clickElement("switchbutton_appleconnect_prompt_environment"), "Failed to click the prompt for environment button");
		}
		Assert.assertTrue(clickElement("button_appleconnect_accounts"), "Failed to find the accounts button");
    	//Assert.assertTrue(clickElement("button_appleconnect_signin_when_signedin"), "Failed to find the sign in button");
		Assert.assertTrue(clickElement("button_appleconnect_signin"), "Failed to find the sign in button");
		Assert.assertTrue(clickElement("button_appleconnect_useracceptance"), "Failed to find the user acceptance popup");
		AppUtilities.delay(5000);
		driver.getKeyboard();
		Assert.assertTrue(clickElement("textfield_appleconnect_username"), "Failed to find the apple connect username field");
		//Assert.assertTrue(clickElement("button_appleconnect_username_clear"), "Failed to click clear button");
		Assert.assertTrue(typeText("textfield_appleconnect_username", getAppLoginUsername()), "Failed to type the login username");
		Assert.assertTrue(typeText("textfield_appleconnect_password", getAppLoginPassword()), "Failed to type the login password");
		MobileElement passwordField = waitForElement("textfield_appleconnect_password");
		passwordField.sendKeys(Keys.RETURN);
		AppUtilities.delay(4000);
	    return this;
	    }
	
	public void quitApp() {
		closeApp();
	}
	
	public KioskApp login(String station, JSONArray menuItemsToSelect) {		
		AppUtilities.delay(10000);
		
		//Copied below Code from KDS login - Chithra
		
		//To go to settings screen if landing page is loaded
		String cafeValidateLocator = getUILocator("caffe_validation_after_config").replaceAll("<REPLACE_CAFE_LOCATION>", station);
		if(isElementPresent(cafeValidateLocator)!=null) {
			
			Assert.assertNotNull("waitForElement(cafeValidateLocator)","Failed to find Station name in Landing Page");
			
			//Double Tap to move to Settings screen
			Assert.assertTrue(doubleTapElement_XCTest(waitForElement(cafeValidateLocator)),"Failed to double tap on Station name in landing page");
			Assert.assertTrue(doubleTapElement_XCTest(waitForElement(cafeValidateLocator)),"Failed to double tap on Station name in landing page");
			
			/*TouchActions action = new TouchActions(driver);
			action.doubleTap(waitForElement(cafeValidateLocator));
			action.perform();*/
			
			AppUtilities.delay(15000);
					
		}
		
		Assert.assertNotNull(waitForElement("welcome_text"));
		
		AppUtilities.delay(15000);
		AppUtilities.delay(5000);
		
		driver.getKeyboard().sendKeys(getAppLoginUsername());//"ramjagan_ru"); //getAppLoginUsername()
		AppUtilities.delay(1000);
		driver.getKeyboard().sendKeys(Keys.RETURN);
		AppUtilities.delay(1000);
		
		String alert = driver.switchTo().alert().getText();
		if (alert != null) {
		driver.switchTo().alert().dismiss();
		MobileElement welcome1 = waitForElement("welcome_text");
		driver.getKeyboard().sendKeys(getAppLoginPassword()); //getAppLoginPassword()
		AppUtilities.delay(1000);
		driver.getKeyboard().sendKeys(Keys.RETURN);
		AppUtilities.delay(3000);
		}else {
			driver.getKeyboard().sendKeys(getAppLoginPassword());
			AppUtilities.delay(1000);
			driver.getKeyboard().sendKeys(Keys.RETURN);
			AppUtilities.delay(3000);
		}
		AppUtilities.delay(10000);
		/*MobileElement alertCameraAccess = isElementPresent("alert_camera_access");
		if(alertCameraAccess != null) {
			String text = alertCameraAccess.getText();
			if(StringUtils.containsIgnoreCase(text, getUILocator("access_camera_alert"))) {
				log("No Camera alert has been shown. Dismissing it now..");
				driver.switchTo().alert().accept();
				//clickElement("btn_ok_alert_camera_access");
				log("OK button of No Camera Alert has been clicked");
			}
		else {
			log("The no Camera alert has not been shown");
			}
		}*/
		//to handle Camera alert - Chithra
		AppUtilities.delay(20000);
		try {
				String alert1 = driver.switchTo().alert().getText();
				if (alert1 != null) {
					driver.switchTo().alert().dismiss();
				}
				
		} catch(Exception e) {
			log("Exception while handling initial login alert"+e.getMessage());
		}
		try {
			String alert2 = driver.switchTo().alert().getText();
			if (alert2 != null) {
				driver.switchTo().alert().dismiss();
			
			}}
				catch(Exception e) {
				log("Exception while handling initial login alert"+e.getMessage());
			}
		Assert.assertNotNull(waitForElement("cell_app_settings_cafe_stations"), "Failed to find the Cafe stations after login");
		
		AppUtilities.delay(5000);
		return this;		
		
		
		
		//String welcomeScreen = getUILocator("landing_page_kiosk");
		/*MobileElement welcomeScreen1=waitForElement("landing_page_kiosk");
		if (!welcomeScreen1.isDisplayed()) {
			//driver.rotate(ScreenOrientation.LANDSCAPE);
			driver.getKeyboard();
		//Assert.assertNotNull(waitForElement("static_apple_connect_username"), "Failed to find the apple connect username field");
			Assert.assertTrue(typeText("textfield_appleconnect_username", getAppLoginUsername()), "Failed to type the login username");
			Assert.assertTrue(typeText("textfield_appleconnect_password", getAppLoginPassword()), "Failed to type the login password");
			MobileElement passwordField = waitForElement("textfield_appleconnect_password");
			passwordField.sendKeys(Keys.RETURN);*/
		//Assert.assertTrue(clickElement("btn_apple_connect_login"), "Failed to click the login button");
			//AppUtilities.delay(10000);
		/*handleAlertOnLaunch();
		
		MobileElement alertCameraAccess = isElementPresent("alert_camera_access");
		if(alertCameraAccess != null) {
			String text = alertCameraAccess.getText();
			if(StringUtils.containsIgnoreCase(text, getUILocator("access_camera_alert"))) {
				log("No Camera alert has been shown. Dismissing it now..");
				driver.switchTo().alert().accept();
				//clickElement("btn_ok_alert_camera_access");
				log("OK button of No Camera Alert has been clicked");
			}
		else {
			log("The no Camera alert has not been shown");
			}
		}
		
		//clickElement("btn_ok_connection_failure_alert");
			Assert.assertNotNull(waitForElement("cell_app_settings_cafe_stations"), "Failed to find the Cafe stations after login");
			registerStations();
			/*enableSecuritySettings();
			selectStationAndMenuItems(station, menuItemsToSelect);
			}
		else {
			Assert.assertTrue(clickElement("landing_page_kiosk"), "Failed to click the landing page");
		}
		//Assert.assertTrue(clickElement("btn_cafe_settings_done"), "Failed to select the Done button after selecting the menu items in the station");
		AppUtilities.delay(5000);
		return this;*/
	}
	
	public KioskApp login() {		
		AppUtilities.delay(10000);
		//String welcomeScreen = getUILocator("landing_page_kiosk");
		MobileElement welcomeScreen1=isElementPresent("landing_page_kiosk");
		log("The status of welcomeScreen is: "+welcomeScreen1);
		if (welcomeScreen1 == null) {
			//driver.rotate(ScreenOrientation.LANDSCAPE);
			driver.getKeyboard();
		//Assert.assertNotNull(waitForElement("static_apple_connect_username"), "Failed to find the apple connect username field");
			Assert.assertTrue(typeText("textfield_appleconnect_username", getAppLoginUsername()), "Failed to type the login username");
			Assert.assertTrue(typeText("textfield_appleconnect_password", getAppLoginPassword()), "Failed to type the login password");
			MobileElement passwordField = waitForElement("textfield_appleconnect_password");
			passwordField.sendKeys(Keys.RETURN);
		//Assert.assertTrue(clickElement("btn_apple_connect_login"), "Failed to click the login button");
			AppUtilities.delay(10000);
		/*handleAlertOnLaunch();
		
		MobileElement alertCameraAccess = isElementPresent("alert_camera_access");
		if(alertCameraAccess != null) {
			String text = alertCameraAccess.getText();
			if(StringUtils.containsIgnoreCase(text, getUILocator("access_camera_alert"))) {
				log("No Camera alert has been shown. Dismissing it now..");
				driver.switchTo().alert().accept();
				//clickElement("btn_ok_alert_camera_access");
				log("OK button of No Camera Alert has been clicked");
			}
		else {
			log("The no Camera alert has not been shown");
			}
		}
		*/
		//clickElement("btn_ok_connection_failure_alert");
			Assert.assertNotNull(waitForElement("cell_app_settings_cafe_stations"), "Failed to find the Cafe stations after login");
			registerStations();
			}
		else {
			Assert.assertTrue(clickElement("landing_page_kiosk"), "Failed to click the landing page");
		}
		//Assert.assertTrue(clickElement("btn_cafe_settings_done"), "Failed to select the Done button after selecting the menu items in the station");
		AppUtilities.delay(5000);
		return this;
	}
	
	private void handleAlertOnLaunch() {
		long startTime = System.currentTimeMillis();
		long endTime = startTime + (getElementLoadTimeout() * 60);
		boolean alertHandlingDone = false;
		while(startTime < endTime) {
			
			MobileElement alertText = isElementPresent("static_heading_no_certificate_alert");
			MobileElement appleConnectUsername = isElementPresent("static_apple_connect_username");
			
			if(alertText != null) {
				String text = alertText.getText();
				if(StringUtils.containsIgnoreCase(text, getUILocator("no_certificate_alert_text"))) {
					log("No certificate alert has been shown. Dismissing it now..");
					clickElement("btn_ok_no_certificate_alert");
					log("OK button of No Certificate Alert has been clicked");
					alertHandlingDone = true;
				}
				else if(StringUtils.containsIgnoreCase(text, getUILocator("Communication_failure_text"))){
					log("Communication failure alert has been shown");
					clickElement("btn_ok_no_certificate_alert");
					log("OK button of Communication failure Alert has been clicked");
					alertHandlingDone = true;
				}
				else 
				{
					log("Capture text properly");
				}
					
			}
			if(appleConnectUsername != null) {
				log("Looks like Appleconnect login is shown. Certificate Alert might be handled by Appium start-up itself.");
				alertHandlingDone = true;
			}
			
			if(alertHandlingDone) {
				break;
			}
			AppUtilities.delay(1000);
			startTime = System.currentTimeMillis();
		}
		
		if(! alertHandlingDone) {
			log("Something went wrong as no certificate alert is not shown / apple connect login is not shown");
		}
	}
	
	public KioskApp enableSecuritySettings() {
	
		MobileElement alertText = isElementPresent("alert_before_certificate");
		if(alertText != null) {
			String text = alertText.getText();
			if(StringUtils.containsIgnoreCase(text, getUILocator("no_certificate_alert_before_download"))) {
				log("No certificate alert has been shown. Dismissing it now..");
				clickElement("btn_ok_no_certificate_alert");
				log("OK button of No Certificate Alert has been clicked");
			}
		else {
			log("The no certificate alert has not been shown");
			}
		}
		
		//driver.switchTo().alert().accept();
		Assert.assertTrue(clickElement("cell_app_settings_ssl_certificate"), "Failed to click the SSL Certificate Cell option");
		Assert.assertTrue(clickElement("btn_app_settings_download_install_certificate"), "Failed to click the Download / Install Certificate button");
		Assert.assertNotNull(waitForElement("static_success_download_certificate"), "Failed to find the success message after clicking the download/install certificate button");
		
		Assert.assertTrue(clickElement("cell_app_settings_cafe_stations"), "Failed to click the Cafe / Stations Cell option");
		Assert.assertNotNull(waitForElement("cell_app_settings_select_cafe"), "Failed to find the Select Cafe cell option");
		
		log("Sucessfully downloaded the certificate");
		
		return this;
	}
	
	public KioskApp enableSecuritySettings(String aStationName) {
				
		//To go to settings screen if landing page is loaded
		/*String cafeValidateLocator = getUILocator("caffe_validation_after_config").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
		if(isElementPresent(cafeValidateLocator)!=null) {
			//Double Tap to move to Settings screen
			//Assert.assertTrue(doubleTapElement_XCTest(waitForElement(cafeValidateLocator)),"Failed to double tap on Station name in landing page");
					
			AppUtilities.delay(15000);
			//Code to enter password
		
		}
		else {
			log("Default Caffe location selection is not done. Already on Settings page");
		}*/
		
		//To validate if ssl certificate is already installed
		if(isElementPresent("cell_app_settings_ssl_certificate")!=null) {
			Assert.assertTrue(clickElement("cell_app_settings_ssl_certificate"), "Failed to click the SSL Certificate Cell option");
			if(isElementPresent("static_success_download_certificate")==null) {
				Assert.assertTrue(clickElement("btn_app_settings_download_install_certificate"), "Failed to click the Download / Install Certificate button");
				Assert.assertNotNull(waitForElement("static_success_download_certificate"), "Failed to find the success message after clicking the download/install certificate button");
			
				log("Sucessfully downloaded the certificate");
			}	
			Assert.assertTrue(clickElement("cell_app_settings_cafe_stations"), "Failed to click the Cafe / Stations Cell option");
			Assert.assertNotNull(waitForElement("cell_app_settings_select_cafe"), "Failed to find the Select Cafe cell option");
		
		}
		
		
		
		return this;
	}
	
	public KioskApp selectPayment(boolean applePayFlag, boolean cashFlag, boolean mealVoucherFlag) {
			
		//Click on Payment Methods tab
		Assert.assertNotNull(waitForElement("payment_methods_settings"), "Failed to find Payment methods locator");
		Assert.assertTrue(clickElement("payment_methods_settings"), "Failed to click Payment methods locator");
		
		if(applePayFlag) {
			log("Apple Pay payment selection:");
			Assert.assertNotNull(waitForElement("apple_pay_text_validate"), "Failed to find Apple Pay Payment method");
			Assert.assertTrue(clickElement("apple_pay_select_button"), "Failed to click Apple Pay payment switch button");
		}
		if(cashFlag) {
			log("Cash payment selection:");
			Assert.assertNotNull(waitForElement("cash_text_validate"), "Failed to find Cash Payment method");
			Assert.assertTrue(clickElement("cash_select_button"), "Failed to click Cash payment switch button");
			
			//Validation of Manage Cash Drawer link
			Assert.assertTrue(waitForElement("manage_cash_drawer_link").isEnabled(),"Failed as Manage Cash Drawer link is disabled");
		}
		if(mealVoucherFlag) {
			log("Meal Voucher Pay payment selection:");
			Assert.assertNotNull(waitForElement("meal_voucher_text_validate"), "Failed to find Meal Voucher Payment method");
			Assert.assertTrue(clickElement("meal_voucher_select_button"), "Failed to click Meal Voucher payment switch button");
		}
		
		return this;
	}

	public boolean doubleTapElement_XCTest(MobileElement el)
	{
		try {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			HashMap<String, String> tapObject = new HashMap<String, String>();
			tapObject.put("element", el.getId());
			js.executeScript("mobile:doubleTap", tapObject);
			return true;
		} catch (Exception e) {
			log("Exception occured while double tap on locator: "+e.getMessage());
			return false;
		}
	}

	
	public KioskApp validateRegisterStationInLeftPane(JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("btn_cafe_settings_done"), "Failed to select the Done button after selecting the menu items in the station");
		
		String strItemLocator = getUILocator("cell_item_to_select_in_left_menu");
		for(int i = 0; i < itemsToChoose.size(); i++) {
			String menuItem = (String)itemsToChoose.get(i);
			log("The menu item is: "+menuItem);
			String itemLocator = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertNotNull(waitForElement(itemLocator), "Failed to find the configured Menu Item:" + menuItem + " on the left side");
		}
		log("Successfully found the registered stations");
		return this;
	}
	
	public KioskApp selectStationAndMenuItems(String aStationName, JSONArray itemsToChoose) {
		
		if(waitForElement("cell_app_settings_select_cafe").getText().equalsIgnoreCase("Please Select a Caffè")) {
			Assert.assertTrue(clickElement("cell_app_settings_select_cafe"), "Failed to select the Cafe Location");
			AppUtilities.delay(2000);
			Assert.assertNotNull(waitForElement("btn_back_to_cafe_stations_in_select_cafe_location"), "Failed to find the Back button in selecting the cafe locations");
		
			String cafeLocator = getUILocator("cell_select_cafe_location").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
			
			MobileElement e = waitForElement(cafeLocator);
			if(!e.isDisplayed()) {
				swipeToDirection_iOS_XCTest(e, "u");
			}
						
			Assert.assertTrue(clickElement(cafeLocator), "Failed to select the Cafe Location:" + aStationName);
		
			//To select all Registered Stations
			Assert.assertTrue(clickElement("select_all_stations"), "Failed to select the Done button after selecting the menu items in the station");	
			AppUtilities.delay(2000);
			Assert.assertTrue(clickElement("unselect_all_stations"), "Failed to select the Done button after selecting the menu items in the station");	
			AppUtilities.delay(2000);
			Assert.assertTrue(clickElement("select_all_stations"), "Failed to select the Done button after selecting the menu items in the station");	
			AppUtilities.delay(2000);
		}
		else {
			log("Default Caffe Station is already selected :"+aStationName);
		}
		//To select a particular caffe station option from Registered statios list
		/*String strItemLocator = getUILocator("cell_station_to_select");
		String strItemLocatorEnabled = getUILocator("cell_station_enabled");
		for(int i = 0; i < itemsToChoose.size(); i++) {
			String menuItem = (String)itemsToChoose.get(i);
			String itemLocator = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertTrue(tapElement(itemLocator), "Failed to select the Menu Item:" + menuItem);
			//wait for it to to enabled
			AppUtilities.delay(2000);
			String itemLocatorEnabled = strItemLocatorEnabled.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertNotNull(waitForElement(itemLocatorEnabled), "Failed to select the Item:" + menuItem);
			AppUtilities.delay(2000);
		}*/
		
		return this;
	}
	
	//Added by Chithra
	public KioskApp saveConfigurationAndLandingPageValidation(String aStationName) {
		
		Assert.assertTrue(clickElement("btn_cafe_settings_done"), "Failed to select the Done button after selecting the menu items in the station");
		log("The caffe and stations are enabled");
		//wait for Landing Page to Load
		AppUtilities.delay(16000);
		//Validation of Caffe Station selected name in Landing Page
		String cafeValidateLocator = getUILocator("caffe_validation_after_config").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
		Assert.assertNotNull(waitForElement(cafeValidateLocator), "Failed to find the Cafe Location after configuration completion:" + aStationName);
		
		return this;
	}
	
	public KioskApp saveConfigurationAndCashPaymentValidation(String aStationName, boolean isCashSelect, String userName) {
		if(isCashSelect) {
			Assert.assertTrue(clickElement("btn_cafe_settings_done"), "Failed to select the Done button after selecting the menu items in the station");
			log("The caffe and stations are enabled");
			//wait for Landing Page to Load
			AppUtilities.delay(20000);
			//Code to enter password
			driver.getKeyboard().sendKeys(getAppLoginPassword());
			driver.getKeyboard().sendKeys(Keys.RETURN);
			
			AppUtilities.delay(20000);
			
			//Validation of Caffe Station selected name in Landing Page
			String cafeValidateLocator = getUILocator("caffe_validation_after_config").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
			Assert.assertNotNull(waitForElement(cafeValidateLocator), "Failed to find the Cafe Location after configuration completion:" + aStationName);
						
			log("User Name Validation for Cash payment");
			
			String userNameLocator = getUILocator("loggedin_user_landing_page").replaceAll("<REPLACE_NAME>", userName);
			log("userNameLocator: "+userNameLocator);
			Assert.assertNotNull(waitForElement(userNameLocator), "Failed to find the Logged in user name after configuration completion:" + userName);
			Assert.assertNotNull(waitForElement("logout_link_landing_page"), "Failed to find the Logout link after configuration completion:" + userName);
			log("Cash Payment configuration completed successfully");
		}
		return this;
	}
	
	//Added by Chithra
	public KioskApp cashDrawerValidationAndSelectCheck(JSONArray cashDrawerDetails) {
		
		log("Cash Drawer validation");
		String ipAddressValidator= null; 
		String tillValidator = null;
		
		Assert.assertNotNull(cashDrawerDetails, "Failed as the cashDrawer data found to be null");
		Assert.assertTrue(cashDrawerDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		
		for (Object cashDrawer: cashDrawerDetails){
			Assert.assertTrue(waitForElement("manage_cash_drawer_link").isEnabled(),"Failed as Manage Cash Drawer link is disabled");
			Assert.assertTrue(clickElement("manage_cash_drawer_link"),"Failed to click Manage Cash Drawer link");
			
			JSONObject cashDrawerDetail = (JSONObject) cashDrawer;
			
			JSONArray cashDrawerIPDetails=(JSONArray) cashDrawerDetail.get("ip_address_data");
			JSONArray cashDrawerTillDetails=(JSONArray) cashDrawerDetail.get("till_data");
			String amount=(String) cashDrawerDetail.get("amount");
			
			//Cash Drawer Select
			for(Object cashDrawerIP: cashDrawerIPDetails) {
				JSONObject cashDrawerIPDetail = (JSONObject) cashDrawerIP;				
				String selectIPAddress = (String) cashDrawerIPDetail.get("select_ip_address");
				JSONArray ipAddressList = (JSONArray) cashDrawerIPDetail.get("validate_ip_list");
				
				if(ipAddressList.size() > 0) {
					Assert.assertNotNull(waitForElement("cash_drawer_link"), "Failed to find the Cash drawer link");
					Assert.assertTrue(clickElement("cash_drawer_link"),"Failed to click Cash Drawer link");
					Assert.assertNotNull(waitForElement("manage_registers_button"), "Failed to find the Manage Registers button link");
					
					for(int i=0;i<ipAddressList.size();i++) {							
						ipAddressValidator = getUILocator("ip_address_data").replaceAll("<REPLACE_DATA>", ipAddressList.get(i).toString());
						Assert.assertNotNull(waitForElement(ipAddressValidator), "Failed to find the IP Address Data");
					}
					ipAddressValidator = getUILocator("ip_address_data").replaceAll("<REPLACE_DATA>", selectIPAddress);
					Assert.assertTrue(clickElement(ipAddressValidator), "Failed to click the IP Address Data");
				}				
			}			
			
			//Cash Drawer Till Select
			for(Object cashDrawerTill: cashDrawerTillDetails) {
				JSONObject cashDrawerTillDetail = (JSONObject) cashDrawerTill;				
				String selectTillData = (String) cashDrawerTillDetail.get("select_till_data");
				JSONArray tillList = (JSONArray) cashDrawerTillDetail.get("validate_till_list");
				
				if(tillList.size() > 0) {
					Assert.assertNotNull(waitForElement("till_link"), "Failed to find the Till link");
					Assert.assertTrue(clickElement("till_link"),"Failed to click Till link");
					Assert.assertNotNull(waitForElement("manage_registers_button"), "Failed to find the Manage Registers button link");
					
					for(int i=0;i<tillList.size();i++) {							
						tillValidator = getUILocator("till_name_data").replaceAll("<REPLACE_DATA>", tillList.get(i).toString());
						Assert.assertNotNull(waitForElement(tillValidator), "Failed to find the Till Data");
					}
					tillValidator = getUILocator("till_name_data").replaceAll("<REPLACE_DATA>", selectTillData);
					Assert.assertTrue(clickElement(tillValidator), "Failed to click the Till Data");
				}				
			}		
			
			//Cash Drawer Amount
			AppUtilities.delay(5000);
			Assert.assertNotNull(waitForElement("amount_link"), "Failed to find the amount link");
			Assert.assertTrue(clickElement("amount_link"),"Failed to click Amount link");
				
			int i=0;
			String amountDigit = null;
			String amount_select_button = null;
			for(int j=0;j<amount.length();j++) {
				i=j+1;
				amountDigit= amount.substring(j, i);
				log("Amount digit to click: "+ amountDigit);
				
				if(!amountDigit.equals(".")) {
					amount_select_button = getUILocator("amountfield_select_button").replaceAll("<REPLACE_DATA>",amountDigit);
					Assert.assertTrue(clickElement(amount_select_button),"Failed to click Amount button");
				}				
			}	
			
			Assert.assertTrue(clickElement("amount_done_button"), "Failed to click the amount field link");
						
			//Register Drawer validation
			Assert.assertTrue(waitForElement("register_drawer_link").isEnabled(), "Failed to find the Register Drawer link");
			
			//Click on Back button
			Assert.assertTrue(clickElement("back_button_manage_registers"),"Failed to click Back link");
			
		}	
		
		//to load Manage Cash drawer screen
		AppUtilities.delay(5000);	
		
		return this;
	}
	
	
	public KioskApp validateMenuItemIsRemoved(String aStationName, JSONArray itemsToChoose) {
		
		Assert.assertTrue(clickElement("cell_app_settings_select_cafe"), "Failed to select the Cafe Location");
		Assert.assertNotNull(waitForElement("btn_back_to_cafe_stations_in_select_cafe_location"), "Failed to find the Back button in selecting the cafe locations");
		
		String cafeLocator = getUILocator("cell_select_cafe_location").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
		Assert.assertNotNull(waitForElement(cafeLocator), "Failed to find the Cafe Location of:" + aStationName);
		Assert.assertTrue(clickElement(cafeLocator), "Failed to select the Cafe Location:" + aStationName);
		
		//make sure it it selected
		cafeLocator = getUILocator("cell_default_cafe_selected").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
		Assert.assertNotNull(waitForElement(cafeLocator), "Failed to find the Selected Cafe Location of:" + aStationName);
		
		String strItemLocator = getUILocator("cell_station_to_select");
		String strItemLocatorEnabled = getUILocator("cell_station_enabled");
		for(int i = 0; i < itemsToChoose.size(); i++) {
			String menuItem = (String)itemsToChoose.get(i);
			String itemLocator = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertTrue(tapElement(itemLocator), "Failed to select the Menu Item:" + menuItem);
			
			//wait for it to to enabled
			AppUtilities.delay(2000);
			String itemLocatorEnabled = strItemLocatorEnabled.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertNull(waitForElement(itemLocatorEnabled), "Failed to remove the Item:" + menuItem);
			AppUtilities.delay(2000);
		}
		Assert.assertTrue(clickElement("btn_cafe_settings_done"), "Failed to select the Done button after selecting the menu items in the station");
		
		return this;
	}
	
	public KioskApp deActivateStations(String aStationName, JSONArray itemsToChoose) {
		
		if (waitForElement("kiosk_caffe_closed") != null){
		 Assert.assertNotNull(waitForElement("static_app_heading"), "Failed to find the App Heading in the Landing page");
		
		String strItemLocator = getUILocator("cell_item_to_select_in_left_menu");
		String strItemLocatorToCheck = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", "All Specials");
		waitForElement(strItemLocatorToCheck);
		
		String menuItem = null;
		
		
		for(Object o : itemsToChoose) {
            JSONObject item = (JSONObject)o;
            menuItem = (String)item.get("select_station");
            String caffe = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
            Assert.assertNull(waitForElement(caffe), "The deactivated station is present in Kiosk");
		} 
		}
		
		/*
		
		for(int i = 0; i < itemsToChoose.size(); i++) {
			menuItem = (String)itemsToChoose.get(i);
			caffe = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			log("The caffe is: "+caffe);
			Assert.assertNull((caffe), "The deactivated station is still present");
			//Assert.assertTrue(clickElement(itemLocator), "Failed to find the configured Menu Item:" + menuItem + " on the left side");
		}*/
		return this;
	}
	
	
	
    public KioskApp verifyCaffeClosed(JSONArray menuItemsToSelect) {
        
        Assert.assertNotNull(waitForElement("kiosk_caffe_closed"), "Failed to find the Cafe stations status");
        log("Caffe is not open at the moment");
        return this;
    }
	
	public KioskApp validatePrinterButton(String aStationName, JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("cell_app_settings_select_cafe"), "Failed to select the Cafe Location");
		Assert.assertNotNull(waitForElement("btn_back_to_cafe_stations_in_select_cafe_location"), "Failed to find the Back button in selecting the cafe locations");
		
		String cafeLocator = getUILocator("cell_select_cafe_location").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
		Assert.assertNotNull(waitForElement(cafeLocator), "Failed to find the Cafe Location of:" + aStationName);
		Assert.assertTrue(clickElement(cafeLocator), "Failed to select the Cafe Location:" + aStationName);
		
		//make sure it it selected
		cafeLocator = getUILocator("cell_default_cafe_selected").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
		Assert.assertNotNull(waitForElement(cafeLocator), "Failed to find the Selected Cafe Location of:" + aStationName);
		
		String strItemLocator = getUILocator("cell_station_to_select");
		String strItemLocatorEnabled = getUILocator("cell_station_enabled");
		for(int i = 0; i < itemsToChoose.size(); i++) {
			String menuItem = (String)itemsToChoose.get(i);
			String itemLocator = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertTrue(tapElement(itemLocator), "Failed to select the Menu Item:" + menuItem);
			
			//wait for it to to enabled
			AppUtilities.delay(2000);
			String itemLocatorEnabled = strItemLocatorEnabled.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertNotNull(waitForElement(itemLocatorEnabled), "Failed to select the Item:" + menuItem);
			AppUtilities.delay(2000);
		}
		Assert.assertTrue(clickElement("cell_app_settings_printer_left_side"), "Failed to find Printer menu on left side");
		Assert.assertTrue(clickElement("cell_app_settings_printer_button"), "Failed to choose the printer button");
		MobileElement alertText = isElementPresent("alert_primary_printer_config");
		if(alertText != null) {
			String text = alertText.getText();
			if(StringUtils.containsIgnoreCase(text, getUILocator("no_alert_primary_printer_config"))) {
				log("No Primary printer configuration alert has been shown. Dismissing it now..");
				clickElement("btn_ok_no_certificate_alert");
				log("OK button of No Primary Printer Configuration Alert has been clicked");
			}
		else {
			log("The no Primary Printer configuration alert has not been shown");
			}
		}
		Assert.assertTrue(clickElement("cell_app_settings_ssl_certificate"), "Failed to click the SSL Certificate Cell option");
		Assert.assertTrue(clickElement("cell_app_settings_printer_left_side"), "Failed to find Printer menu on left side");
		MobileElement strItem = waitForElement("cell_app_settings_printer_button");
		boolean strItemValue = strItem.isSelected();
		if (strItemValue == true) {
			log("The printer button is selected");
			Assert.assertTrue(strItemValue);
		}
		log("The printer button is enabled");
		return this;
	}
	
	public KioskApp validatePrimaryPrinterConfig() {
		log("In primary printer config");
		Assert.assertTrue(clickElement("cell_app_settings_primary_printer_button"), "Failed to find Printer menu on left side");
		Assert.assertTrue(clickElement("cell_app_settings_ssl_certificate"), "Failed to click the SSL Certificate Cell option");
		Assert.assertTrue(clickElement("cell_app_settings_printer_left_side"), "Failed to find Printer menu on left side");
		MobileElement strItem = waitForElement("cell_app_settings_primary_printer_button");
		boolean strItemValue = strItem.isSelected();
		if (strItemValue == true) {
			log("The primary printer button is selected");
			Assert.assertTrue(strItemValue);
		}
		log("The primary printer button is enabled");
		return this;
	}
	
	public KioskApp validateSecondaryPrinterConfig() {
		Assert.assertTrue(clickElement("cell_app_settings_secondary_printer_button"), "Failed to find Printer menu on left side");
		Assert.assertTrue(clickElement("cell_app_settings_ssl_certificate"), "Failed to click the SSL Certificate Cell option");
		Assert.assertTrue(clickElement("cell_app_settings_printer_left_side"), "Failed to find Printer menu on left side");
		MobileElement strItem = waitForElement("cell_app_settings_secondary_printer_button");
		boolean strItemValue = strItem.isSelected();
		if (strItemValue == true) {
			log("The Secondary printer button is selected");
			Assert.assertTrue(strItemValue);
		}
		log("The Secondary printer button is enabled");
		return this;
	}
	
	public KioskApp validateSecondaryPrinterConfigWithoutPrimary() {
		MobileElement alertText = isElementPresent("alert_primary_printer_config");
		if(alertText != null) {
			String text = alertText.getText();
			if(StringUtils.containsIgnoreCase(text, getUILocator("no_alert_primary_printer_config"))) {
				log("No Primary printer configuration alert has been shown. Dismissing it now..");
				clickElement("btn_ok_no_certificate_alert");
				log("OK button of No Primary Printer Configuration Alert has been clicked");
			}
		else {
			log("The no Primary Printer configuration alert has not been shown");
			}
		}
		Assert.assertTrue(clickElement("cell_app_settings_secondary_printer_button"), "Failed to find Printer menu on left side");
		Assert.assertNotNull(waitForElement("alert_secondary_printer_config"), "Failed to display the alert message when configuring secondary printer without configuring primary");
		clickElement("btn_ok_no_certificate_alert");
		return this;
	}
	
	public KioskApp checkLandingPage(String aStationName, JSONArray itemsToChoose) {
		
		Assert.assertNotNull(waitForElement("static_app_heading"), "Failed to find the App Heading in the Landing page");
		
		String strItemLocator = getUILocator("cell_item_to_select_in_left_menu");
		String strItemLocatorToCheck = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", "All Specials");
		Assert.assertNotNull(waitForElement(strItemLocatorToCheck), "Failed to find the All Specials item in the left side");
		
		for(int i = 0; i < itemsToChoose.size(); i++) {
			String menuItem = (String)itemsToChoose.get(i);
			String itemLocator = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertTrue(clickElement(itemLocator), "Failed to find the configured Menu Item:" + menuItem + " on the left side");
		}
		return this;
	}

	
	public KioskApp selectStationAndCheckFoodItems(String aStationName, JSONArray itemsToVerify) {
		
		Assert.assertNotNull(waitForElement("static_app_heading"), "Failed to find the App Heading in the Landing page");
		
		String strItemLocator = getUILocator("cell_item_to_select_in_left_menu");
		String strItemLocatorToCheck = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", aStationName);
		Assert.assertTrue(clickElement(strItemLocatorToCheck), "Failed to find the station to be selected in the left side");
		
		String strFoodItem = getUILocator("food_item_on_right_side");
		for(int i = 0; i < itemsToVerify.size(); i++) {
			String menuItem = (String)itemsToVerify.get(i);
			String itemLocator = strFoodItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertNotNull(waitForElement(itemLocator), "Failed to find the configured food Item:" + menuItem + " for station:" + aStationName);
		}
		log("Test Case completed");
		return this;
	}

	public KioskApp orderGivenItems(JSONArray items) {
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		
		for(Object item : items) {
			JSONObject itemDetails = (JSONObject)item;
			Assert.assertNotNull(orderGivenItem(itemDetails), "Failed while ordering the item:" + itemDetails.toJSONString());
		}
		return this;
	}
	
	public KioskApp orderGivenGrabAndGoItems(JSONArray items) {
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		
		for(Object item : items) {
			JSONObject itemDetails = (JSONObject)item;
			Assert.assertNotNull(orderGivenGrabAndGoItem(itemDetails), "Failed while ordering the item:" + itemDetails.toJSONString());
		}
		return this;
	}
	
	public KioskApp orderGivenGrabAndGoItem(JSONObject item) {
		
		String strStationToSelect = (String)item.get("select_station");	
		String strItemToOrder = (String)item.get("food_item_name");
		//Select Station
		String strItem = getUILocator("main_station_landing_page");		
		String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect);
		Assert.assertTrue(clickElement(selectStationItem), "Failed to select the left side of the station:" + strStationToSelect);
		log("The items to be ordered is: "+strItemToOrder);
		
		String foodItemToSelectLocator = getUILocator("item_to_order_grab_and_go");
				
		String foodItemToSelect = foodItemToSelectLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", strItemToOrder);
		Assert.assertNotNull(waitForElement(foodItemToSelect), "Failed to find the food item");
		AppUtilities.delay(5000);
		//wait for Add button for the item
		String btnAddToOrder = getUILocator("add_button_landing_page");
		btnAddToOrder = btnAddToOrder.replaceAll("<REPLACE_ITEM_TO_SELECT>", strItemToOrder);
		Assert.assertTrue(clickElement(btnAddToOrder), "Failed to click on the Add button in the screen for the item:" + strItemToOrder);
		log("Successfully found and clicked on Add Button");
				
		Assert.assertNotNull(waitForElement("check_out_button"), "Failed to check the Checkout button in the Landing page after adding the item");
						
		log("Successfully added the item as per the given test data");
		return this;
		
	}	
	
	//Added by Chithra
	public KioskApp validateAddToOrder(JSONArray items) {
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		
		Assert.assertTrue(clickElement("check_out_button"), "Failed to click the Checkout button in the Landing page");
		Assert.assertNotNull(waitForElement("myorder_header"), "Failed to find the My order popup heading after clicking view order from Landing page");
		Assert.assertNotNull(waitForElement("cancel_button_myorder_page"), "Failed to find the Checkout Cancel button in Checkout Screen");
		Assert.assertNotNull(waitForElement("continue_button_myorder_page"), "Failed to find the Checkout Continue button in Checkout Screen");
		
		for(Object item : items) {
			JSONObject itemDetails = (JSONObject)item;
			String strStationToSelect = (String)itemDetails.get("select_station");
			String strItemToOrder = (String)itemDetails.get("food_item_name");
			String strItemPrice = (String)itemDetails.get("food_item_price");
			
			String strItem = getUILocator("item_name_myorder_page");
			strItem=strItem.replaceAll("<REPLACE_ITEM_NAME>",strItemToOrder);			
			Assert.assertNotNull(waitForElement(getUILocator("main_station_landing_page").replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect)), "Failed to find the main station:" + strStationToSelect + "in My Order screen");	
			Assert.assertNotNull(waitForElement(strItem), "Failed to find the item :" + strItemToOrder + "in My Order screen");
		}
		
		Assert.assertTrue(clickElement("continue_button_myorder_page"), "Failed to click Continue button in My order page");
		AppUtilities.delay(2000);
		//My Info page validation
		Assert.assertNotNull(waitForElement("my_info_header"), "Failed to find My Info in Checkout page");
		log("Validated checkout page");
		//Click on back button
		Assert.assertTrue(clickElement("back_button_landing_page"), "Failed to click Back button in My Info page");
		AppUtilities.delay(2000);
		//Click on Cancel button
		Assert.assertTrue(clickElement("cancel_button_myorder_page"), "Failed to click Cancel button in My Order page");
		AppUtilities.delay(2000);
		
		return this;
	}
	
	
	public KioskApp orderGivenItem(JSONObject item) {
		
		String strStationToSelect = (String)item.get("select_station");
		Boolean isCustomizedItem = (Boolean)item.get("is_custom_item");
	
		String strItemToOrder = (String)item.get("food_item_name");
		String strItemPrice = (String)item.get("food_item_price");
		
		String strItemCustomizeCategory = null;
		String strItemCustomiseCategoryType = null;
		JSONObject customFirstChangeItem = null;
		JSONArray cusItemList = (JSONArray)item.get("customize_food_item");
		
		if(cusItemList != null && cusItemList.size() > 0) {
			JSONObject customFirstItem = (JSONObject)cusItemList.get(0);

			strItemCustomizeCategory = (String)customFirstItem.get("customize_food_item_category");
			strItemCustomiseCategoryType = (String)customFirstItem.get("customize_food_item_category_type");
			
			JSONArray customizdFoodItemsList = (JSONArray)customFirstItem.get("customize_food_items");
			customFirstChangeItem = (JSONObject)customizdFoodItemsList.get(0);
			
		}
		//String strItemCustomizeCategory = (String)item.get("customize_food_category");
		//String strSelectCustomItem = (String)item.get("customize_food_item_to_change");

		
		if(! isCustomizedItem) {
			return addItemToOrder(strStationToSelect, strItemToOrder, strItemPrice);
		}
		return customizeItemAndAddToOrder(strStationToSelect, strItemToOrder, strItemPrice, strItemCustomizeCategory, customFirstChangeItem, strItemCustomiseCategoryType);
	}
	
	public KioskApp addItemToOrder(String station, String itemToOrder, String itemPrice) {
		
		//Commented lines - Chithra
		//Assert.assertNotNull(waitForElement("static_app_heading"), "Failed to find the App Heading in the Landing page");
		//String strItem = getUILocator("cell_item_to_select_in_left_menu");
		
		//Updated Locators
		String strItem = getUILocator("main_station_landing_page");		
		String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
		Assert.assertTrue(clickElement(selectStationItem), "Failed to select the left side of the station:" + station);
		log("The items to be ordered is: "+itemToOrder);
		
		//Click customize on the item
		//String foodItemToSelectLocator = getUILocator("food_item_on_right_side");--Commented for locator change - Chithra
		String foodItemToSelectLocator = getUILocator("item_to_order_landing_page");
		
		String foodItemToSelect = foodItemToSelectLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToOrder);
		Assert.assertTrue(clickElement(foodItemToSelect), "Failed to select the food item");
		//strItem = getUILocator("btn_price_on_item_to_select_detail_page");
		//strItem = getUILocator("btn_price_on_item_to_select");
		//String strItemPriceButton = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToOrder);
		//String strItemPriceButton = strItem.replaceAll("<REPLACE_ITEM_PRICE>", itemPrice);
		//Assert.assertTrue(clickElement(strItemPriceButton), "Failed to select the Item price for the item:" + itemToOrder);
		AppUtilities.delay(5000);
		//wait for add to order / customize
		String btnAddToOrder = getUILocator("add_to_order_button_landing_page");
		//strItem = getUILocator("btn_addtoorder_on_item_to_select_direct");
		//String btnAddToOrder = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToOrder);
		Assert.assertTrue(clickElement(btnAddToOrder), "Failed to click on the Add to Order / Customize button in the Direct / custom screen for the item:" + itemToOrder);
		log("Successfully found Add to order Button");
		//dont customize the order and click now
		/*
		strItem = getUILocator("btn_addtoorder_on_item_to_select");
		if(waitForElement(strItem, 2) != null) {
			//click the element now
			Assert.assertTrue(clickElement(strItem), "Failed to click on the Add to Order custom screen for the item:" + itemToOrder);
		}
		*/
		//Commented below line for locator change 
		//Assert.assertNotNull(waitForElement("btn_checkout_from_main_menu"), "Failed to check the Checkout button in the Landing page after adding the item");
		//Assert.assertTrue(clickElement("btn_back_from_menu_detail_page"), "Failed to find back button in menu detail page");
		
		
		Assert.assertNotNull(waitForElement("check_out_button"), "Failed to check the Checkout button in the Landing page after adding the item");
		Assert.assertTrue(clickElement("back_button_landing_page"), "Failed to find back button in menu detail page");
		
		
		log("Successfully added the item as per the given test data");
		return this;
		
	}
	
	public KioskApp validateMenuDetails(JSONArray items, String aCaffeLocation) {
    	log("Items to be ordered is:" + items.toJSONString());
    	JSONObject itemDetails = null;
    	for(Object item : items) {
            itemDetails = (JSONObject)item;
    	}
        String strStationToSelect = (String)itemDetails.get("select_station");
        String strItemToOrder = (String)itemDetails.get("food_item_name");
        String strItemPrice = (String)itemDetails.get("food_item_price");
        String strFoodItemType = (String)itemDetails.get("food_type");
        String strFoodItemDesc = (String)itemDetails.get("food_item_desc");
        JSONArray components = (JSONArray)itemDetails.get("components");
        JSONObject componentDetails = null;
    	for(Object componentDetail : components) {
    		componentDetails = (JSONObject)componentDetail;
    	}
    	String strComponentName = (String)componentDetails.get("component_name");
    	JSONArray strCompIngredients = (JSONArray) componentDetails.get("ingredients");
    	JSONObject strCompNutrition = (JSONObject) componentDetails.get("component_item_nutrition");
        JSONObject nutrition = (JSONObject)itemDetails.get("food_item_nutrition");
        //Menu item Nutrition info
        String strCalorie = (String)nutrition.get("calorie");
        String strFat = (String)nutrition.get("fat");
        String strCarbs = (String)nutrition.get("carbs");
        String strSugar = (String)nutrition.get("sugar");
        String strProtein = (String)nutrition.get("protein");
        String strFiber = (String)nutrition.get("fiber");
        //Component Nutrition info
        String strCompCalorie = (String)strCompNutrition.get("calorie");
 	    String strCompFat = (String)strCompNutrition.get("fat");
 	    String strCompCarbs = (String)strCompNutrition.get("carbs");
 	    String strCompSugar = (String)strCompNutrition.get("sugar");
 	    String strCompProtein = (String)strCompNutrition.get("protein");
 	    String strCompFiber = (String)strCompNutrition.get("fiber");
        
        log(strStationToSelect);
        log(strItemToOrder);
        log(strItemPrice);
        log(strFoodItemType);
        log(strFoodItemDesc);
        log(strComponentName);
        log(strCalorie);
        log(strFat); 
        log(strCarbs);
        log(strSugar);
        log(strProtein);
        log(strFiber);
        
        Assert.assertNotNull(waitForElement("static_app_heading"), "Failed to find the App Heading in the Landing page");
		String strItem = getUILocator("cell_item_to_select_in_left_menu");
		
		String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect);
		Assert.assertTrue(clickElement(selectStationItem), "Failed to select the left side of the station:" + strStationToSelect);
        
        AppUtilities.delay(5000);
        String strItemNameLocator = getUILocator("food_item_on_right_side").replaceAll("<REPLACE_ITEM_TO_SELECT>", strItemToOrder);
        Assert.assertNotNull(waitForElement(strItemNameLocator), "Failed to find the item name");
        String strItemPriceLocator = getUILocator("btn_price_on_item_to_select").replaceAll("<REPLACE_ITEM_TO_SELECT>", strItemToOrder);
        String strItemPriceButton = strItemPriceLocator.replaceAll("<REPLACE_ITEM_PRICE>", strItemPrice);
        Assert.assertNotNull(waitForElement(strItemPriceButton), "Failed to find the item's price");
        Assert.assertTrue(clickElement(strItemNameLocator), "Failed to click the item name");
        String strComponentLocator = getUILocator("cell_component_name_detail_page").replaceAll("<REPLACE_COMPONENT_NAME>", strComponentName);
        String strComponentNameLocator = strComponentLocator.replaceAll("<REPLACE_COMPONENT_NAME>", strComponentName);
        Assert.assertNotNull(waitForElement(strComponentNameLocator), "Failed to find the component Name");
        String strItemDescLocator = getUILocator("cell_description_menu_detail_page").replaceAll("<REPLACE_DESCRIPTION>", strFoodItemDesc);
        Assert.assertNotNull(waitForElement(strItemDescLocator), "Failed to find the item name");
        String ingredient = null;
    	for(Object ing : strCompIngredients) {
			ingredient = (String)ing;
			log("The ingredient is:"+ingredient);
			String strComponentIngredientsLocator = getUILocator("cell_component_ingredients_menu_detail_page").replaceAll("<REPLACE_COMPONENT_INGREDIENTS>", ingredient);
			Assert.assertNotNull(waitForElement(strComponentIngredientsLocator), "Failed to find the components ingredeints");
		}
    	
 	    String strComponentCalorie = getUILocator("cell_component_nutrition_cal_detail_page").replaceAll("<REPLACE_COMPONENT_NUTRITION>", strCompCalorie);
 	    Assert.assertNotNull(waitForElement(strComponentCalorie), "Failed to find the components ingredeints");
 	    String strComponentFat = getUILocator("cell_component_nutrition_cal_detail_page").replaceAll("<REPLACE_COMPONENT_NUTRITION>", strCompFat+"g");
	    Assert.assertNotNull(waitForElement(strComponentFat), "Failed to find the components ingredeints");
	    String strComponentCarbs = getUILocator("cell_component_nutrition_cal_detail_page").replaceAll("<REPLACE_COMPONENT_NUTRITION>", strCompCarbs+"g");
 	    Assert.assertNotNull(waitForElement(strComponentCarbs), "Failed to find the components ingredeints");
 	    String strComponentSugar = getUILocator("cell_component_nutrition_cal_detail_page").replaceAll("<REPLACE_COMPONENT_NUTRITION>", strCompSugar+"g");
	    Assert.assertNotNull(waitForElement(strComponentSugar), "Failed to find the components ingredeints");
	    String strComponentProtein = getUILocator("cell_component_nutrition_cal_detail_page").replaceAll("<REPLACE_COMPONENT_NUTRITION>", strCompProtein+"g");
 	    Assert.assertNotNull(waitForElement(strComponentProtein), "Failed to find the components ingredeints");
 	    String strComponentFiber = getUILocator("cell_component_nutrition_cal_detail_page").replaceAll("<REPLACE_COMPONENT_NUTRITION>", strCompFiber+"g");
	    Assert.assertNotNull(waitForElement(strComponentFiber), "Failed to find the components ingredeints");
        
        return this;
    	
    }
	
public KioskApp customizeItemAndAddToOrder(String station, String itemToCustomize, String itemPrice, String itemCategoryToChange, JSONObject customChangeItem , String itemCategoryType) {
		
		String itemToBeChanged = (String)customChangeItem.get("customize_food_item_name");
		Assert.assertNotNull(itemCategoryToChange, "Failed to customize as Item category to be changed is found to be null");
		Assert.assertNotNull(itemToBeChanged, "Failed to customize as Item to be selected is found to be null");
		
		//Assert.assertNotNull(waitForElement("static_app_heading"), "Failed to find the App Heading in the Landing page");
		String strItem = getUILocator("main_station_landing_page");
		
		String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
		Assert.assertTrue(clickElement(selectStationItem), "Failed to select the left side of the station:" + station);
		
		//Click customize on the item 
		strItem = getUILocator("item_to_order_landing_page");
		String strItemPriceButton = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToCustomize);
		//strItemPriceButton = strItemPriceButton.replaceAll("<REPLACE_ITEM_PRICE>", itemPrice);
		Assert.assertTrue(clickElement(strItemPriceButton), "Failed to select the Item price for customization for the item:" + itemToCustomize);

		strItem = getUILocator("item_name_for_customize");
		String strItemName = strItem.replaceAll("<REPLACE_TEXT>", itemToCustomize);
		Assert.assertNotNull(waitForElement(strItemName), "Failed to select the Item price for customization for the item:" + itemToCustomize);
			
		//wait for Customize button
		String strItemCustomizeButton = getUILocator("customize_button");
		Assert.assertNotNull(waitForElement(strItemCustomizeButton), "Failed to find the CUSTOMIZE button after clicking the price button for the item:" + itemToCustomize);
		
		Assert.assertTrue(clickElement(strItemCustomizeButton), "Failed to click the customization button for the item:" + itemToCustomize);
		
		//select different option as the given data
		if(itemCategoryType.equalsIgnoreCase("Quantity")) {
			log("Customize Item Add to cart with Quanity");
			
			String strItemCategory = getUILocator("item_category_name_customize");
			strItemCategory = strItemCategory.replaceAll("<REPLACE_TEXT>", itemCategoryToChange.toUpperCase());
			Assert.assertNotNull(waitForElement(strItemCategory), "Failed to find the Category for the item:" + itemToCustomize);
			
			strItem = getUILocator("item_name_customize");
			String strCustomizeItemOption = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToBeChanged);
			Assert.assertTrue(clickElement(strCustomizeItemOption), "Failed to click on the option to be customized in the custom screen for the item:" + itemToBeChanged);
			
			//To check increment and decrement buttons availability
			String strDecrementButton = getUILocator("item_quantity_decrement_button").replaceAll("<REPLACE_ITEM_TO_SELECT>",itemToBeChanged);
			Assert.assertNotNull(waitForElement(strDecrementButton), "Failed to find Decrement button");
			String strIncrementButton = getUILocator("item_quantity_increment_button").replaceAll("<REPLACE_ITEM_TO_SELECT>",itemToBeChanged);
			Assert.assertNotNull(waitForElement(strIncrementButton), "Failed to find Decrement button");
			
			
		}
		else if(itemCategoryType.equalsIgnoreCase("Option")) {
			log("Customize Item Add to cart with option data");
			
			String strItemCategory = getUILocator("item_category_name_customize");
			strItemCategory = strItemCategory.replaceAll("<REPLACE_TEXT>", itemCategoryToChange.toUpperCase());
			Assert.assertNotNull(waitForElement(strItemCategory), "Failed to find the Category for the item:" + itemToCustomize);
			
			strItem = getUILocator("item_name_customize");
			String strCustomizeItemOption = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToBeChanged);
			Assert.assertTrue(clickElement(strCustomizeItemOption), "Failed to click on the option to be customized in the custom screen for the item:" + itemToBeChanged);
			
			String strItemOptionData=getUILocator("item_option_info");
			strItemOptionData = strItemOptionData.replaceAll("<REPLACE_TEXT>", customChangeItem.get("customize_food_item_nutrition").toString());
			Assert.assertNotNull(waitForElement(strItemOptionData), "Failed to find the Option data for the item:" + itemToBeChanged);
			
			//Check mark validation
			String strCheckMark = getUILocator("item_option_check_mark");
			strCheckMark = strCheckMark.replaceAll("<REPLACE_TEXT>", itemToBeChanged);
			Assert.assertNotNull(waitForElement("list_tick_mark"),"Failed to find tick mark for the list item");
		}
		else if(itemCategoryType.equalsIgnoreCase("List")) {
			log("Customize Item Add to cart with List data");
			
			String strItemCategory = getUILocator("item_category_name_customize");
			strItemCategory = strItemCategory.replaceAll("<REPLACE_TEXT>", itemCategoryToChange.toUpperCase());
			Assert.assertNotNull(waitForElement(strItemCategory), "Failed to find the Category for the item:" + itemToCustomize);
			
			strItem = getUILocator("item_name_customize");
			String strCustomizeItemOption = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToBeChanged);
			Assert.assertNotNull(waitForElement(strCustomizeItemOption), "Failed to find customized item list in the custom screen for the item:" + itemToBeChanged);
			
			String strItemListMoreInfo = getUILocator("list_item_more_info_arrow");
			strItemListMoreInfo = strItemListMoreInfo.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToBeChanged);
			Assert.assertTrue(clickElement(strItemListMoreInfo), "Failed to click on the More Info >  for the list item:" + itemToBeChanged);
			
			//List Data screen validation
			String strItemListHeader = getUILocator("list_data_header_screen");
			strItemListHeader = strItemListHeader.replaceAll("<REPLACE_TEXT>", customChangeItem.get("customize_list_food_group_name").toString());
			Assert.assertNotNull(waitForElement(strItemListHeader), "Failed to find list data group name in header");
			
			//Check mark validation
			Assert.assertNotNull(waitForElement("list_tick_mark"),"Failed to find tick mark for the list item");
			
			//<Customize button click
			String strCustomizeNavigateBack = getUILocator("navigate_back_to_customize_list");
			strCustomizeNavigateBack = strCustomizeNavigateBack.replaceAll("<REPLACE_TEXT>", customChangeItem.get("customize_list_food_group_name").toString());
			Assert.assertTrue(clickElement(strCustomizeNavigateBack), "Failed to click on <Customize button");
		}
		
		//add to order
		String btnAddToOrder = getUILocator("add_to_order_button_customize_page");
		Assert.assertTrue(clickElement(btnAddToOrder), "Failed to click on the Add to Order button in the custom screen for the item:" + itemToCustomize);

		
		log("Successfully added customized item as per the given test data to Cart");
		return this;
	}
	
	public KioskApp checkOut(String strOrderPersonName, JSONArray itemsToOrder) {
		
		Assert.assertTrue(clickElement("btn_checkout_from_main_menu"), "Failed to click the Checkout button in the Landing page");
		Assert.assertNotNull(waitForElement("static_heading_checkout_popup"), "Failed to find the Checkout popup heading after clicking Checkout from Landing page");
		Assert.assertNotNull(waitForElement("btn_cancel_checkout_popup"), "Failed to find the Checkout Cancel button in Checkout Screen");
		Assert.assertNotNull(waitForElement("btn_continue_checkout_popup"), "Failed to find the Checkout Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("text_name_checkout_popup"), "Failed to find the Checkout Name textbox in Checkout Screen");
		
		Assert.assertTrue(typeText("text_name_checkout_popup", strOrderPersonName), "Failed to type name in the Checkout Screen");
		Assert.assertTrue(clickElement("btn_continue_checkout_popup"), "Failed to click the Continue button in Checkout Screen");
		
		Assert.assertNotNull(waitForElement("btn_back_checkout_popup"), "Failed to find the Back button after clicking Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("btn_placeorder_checkout_popup"), "Failed to find the Place Order button after clicking Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("static_total_checkout_popup"), "Failed to find the Total order value static after clicking Continue button in Checkout Screen");
				
		Assert.assertTrue(clickElement("btn_placeorder_checkout_popup"), "Failed to click the Place Order button after clicking Continue button in Checkout Screen");
		
		
		//thank you page
		Assert.assertNotNull(waitForElement("btn_done_thank_page"), "Failed to find the Done heading after clicking Place Order");
		
		String strItem = getUILocator("static_thank_you_with_name");
		String strNameInThankYou = strItem.replaceAll("<REPLACE_ORDER_NAME>", strOrderPersonName);
		Assert.assertNotNull(waitForElement(strNameInThankYou), "Failed to find the Thank you text with the name in Final page");
	
		strItem = getUILocator("individual_item_in_thank_you_page");
		List<WebElement> list = waitForElements(strItem);
		log("No. of element:" + list.size());
		boolean found = false;
		JSONArray itemListFromPage = new JSONArray();
		int orderIndex = -1;
		String station = "";
		for(WebElement e : list) {
			orderIndex++;
			//MobileElement cell = (MobileElement)e;
			JSONObject itemDetails = new JSONObject();
			List<WebElement> staticList = e.findElements(By.className("UIAStaticText"));
			int index = 0;
			for(WebElement staticItem : staticList) {
				String value = staticItem.getAttribute("value");
				log("Reading the item of:" + value + " at index:" + index);
				if(orderIndex == 0) {
					switch(index) {
					case 0:
						station = value;
						itemDetails.put("station", value);
						break;
					case 1:
						itemDetails.put("orderid", value);
						break;
					case 2:
						itemDetails.put("name", value);
						break;
					case 3:
						itemDetails.put("desc", value);
						break;
					case 4:
						itemDetails.put("ForHere/Togo", value);
						break;
					case 5:
						itemDetails.put("price", value);
						break;
					}
				} else if(orderIndex == 1) {
					switch(index) {
					case 0:
						itemDetails.put("orderid", value);
						break;
					case 1:
						itemDetails.put("name", value);
						break;
					case 2:
						itemDetails.put("desc", value);
						break;
					case 3:
						itemDetails.put("ForHere/Togo", value);
						break;
					case 4:
						itemDetails.put("price", value);
						break;
					}					
				} else if(orderIndex == 2) {
					switch(index) {
					case 0:
						itemDetails.put("orderid", value);
						break;
					case 1:
						itemDetails.put("desc", value);
						break;
					case 2:
						itemDetails.put("ForHere/Togo", value);
						break;
					case 3:
						itemDetails.put("price", value);
						break;
					case 4:
						itemDetails.put("name", value);
						break;
					}					
				}
				index++;
			}
			itemListFromPage.add(itemDetails);
			
			//MobileElement orderedItem = (MobileElement)cell.findElementByXPath("//UIAStaticText[contains(@value, '" + item_selected_for_order + "')]");
			//Assert.assertNotNull(orderedItem, "Failed to find the item ordered:" + item_selected_for_order + " in thank you page");
		}
		log("Items read from Order Thank you page:" + itemListFromPage.toJSONString());
		//storing the created order in store so that it can be re-used
		//writeDataInRunStore("DATA_FROM_" + strCurrentTestcaseName, itemListFromPage.toJSONString());
		
		int foodItemIndex = -1;
		for(Object i : itemsToOrder) {
			JSONObject item = (JSONObject)i;
			String item_selected_for_order = (String)item.get("food_item_name");
			log("Checking the item:" + item_selected_for_order);
			found = false;
			JSONObject itemUIToRemove = null;
			for(Object itemFromUI : itemListFromPage) {
				JSONObject itemUI = (JSONObject)itemFromUI;
				itemUIToRemove = itemUI;
				if(((String)itemUI.get("name")).equalsIgnoreCase(item_selected_for_order)) {
					foodItemIndex++;
					item.put("orderid",  (String)itemUI.get("orderid"));
					item.put("order_person_name", strOrderPersonName);
					storeOrderIdDetailsToRunStore((foodItemIndex + 1), item);
					found = true;
					break;
				}
				
			}
			if(found && itemUIToRemove != null) {
				itemListFromPage.remove(itemUIToRemove);
			}
			Assert.assertTrue(found, "Failed to find the item ordered:" + item_selected_for_order + " in thank you page");
			log("Successfully found the item:" + item_selected_for_order + " in order thank you page ");
		}
		log("The items in the order thank you page has been verified successfully");
		Assert.assertTrue(clickElement("btn_done_thank_page"), "Failed to click the Done heading after clicking Place Order");
		
		return this;
	}
		
	public KioskApp checkOutAfterRemovingItem(String strOrderPersonName, JSONArray itemsToOrder, JSONArray itemsToRemove, String strExpectedTotalAfterRemove) {
		
		Assert.assertTrue(clickElement("btn_checkout_from_main_menu"), "Failed to click the Checkout button in the Landing page");
		Assert.assertNotNull(waitForElement("static_heading_checkout_popup"), "Failed to find the Checkout popup heading after clicking Checkout from Landing page");
		Assert.assertNotNull(waitForElement("btn_cancel_checkout_popup"), "Failed to find the Checkout Cancel button in Checkout Screen");
		Assert.assertNotNull(waitForElement("btn_continue_checkout_popup"), "Failed to find the Checkout Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("text_name_checkout_popup"), "Failed to find the Checkout Name textbox in Checkout Screen");
		
		Assert.assertTrue(typeText("text_name_checkout_popup", strOrderPersonName), "Failed to type name in the Checkout Screen");
		Assert.assertTrue(clickElement("btn_continue_checkout_popup"), "Failed to click the Continue button in Checkout Screen");
		
		Assert.assertNotNull(waitForElement("btn_back_checkout_popup"), "Failed to find the Back button after clicking Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("btn_placeorder_checkout_popup"), "Failed to find the Place Order button after clicking Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("static_total_checkout_popup"), "Failed to find the Total order value static after clicking Continue button in Checkout Screen");
				
		
		String strItemToRemove = getUILocator("btn_remove_food_item_checkout_popup");
		for(Object item : itemsToRemove) {
			String itemToRemove = (String)item;
			log("Removing the item:" + itemToRemove);
			String strItemToRemoveLocator = strItemToRemove.replaceAll("<REPLACE_ITEM_TO_REMOVE>", itemToRemove);
			Assert.assertTrue(clickElement(strItemToRemoveLocator), "Failed to click the Remove button of the food item:" + itemToRemove);
		}
		log("All the food items to be removed has been successfully removed");
		
		//get the total and check
		String strOrderTotalValue = getUILocator("static_total_value_checkout_popup");
		strOrderTotalValue = strOrderTotalValue.replaceAll("<REPLACE_ORDER_TOTAL>", strExpectedTotalAfterRemove);
		Assert.assertNotNull(waitForElement(strOrderTotalValue), "Failed to find order total:" + strExpectedTotalAfterRemove + " after removing the food item in the order page");
		log("Total order value has been checked after removing the configured food item");
		
		Assert.assertTrue(clickElement("btn_placeorder_checkout_popup"), "Failed to click the Place Order button after clicking Continue button in Checkout Screen");
		
		//thank you page
		Assert.assertNotNull(waitForElement("btn_done_thank_page"), "Failed to find the Done heading after clicking Place Order");
		
		String strItem = getUILocator("static_thank_you_with_name");
		String strNameInThankYou = strItem.replaceAll("<REPLACE_ORDER_NAME>", strOrderPersonName);
		Assert.assertNotNull(waitForElement(strNameInThankYou), "Failed to find the Thank you text with the name in Final page");
	
		strItem = getUILocator("individual_item_in_thank_you_page");
		List<WebElement> list = waitForElements(strItem);
		log("No. of element:" + list.size());
		boolean found = false;
		JSONArray itemListFromPage = new JSONArray();
		for(WebElement e : list) {
			//MobileElement cell = (MobileElement)e;
			JSONObject itemDetails = new JSONObject();
			List<WebElement> staticList = e.findElements(By.className("UIAStaticText"));
			int index = 0;
			for(WebElement staticItem : staticList) {
				String value = staticItem.getAttribute("value");
				log("Reading the item of:" + value);
				switch(index) {
				case 0:
					itemDetails.put("station", value);
					break;
				case 1:
					itemDetails.put("orderid", value);
					break;
				case 2:
					itemDetails.put("name", value);
					break;
				case 3:
					itemDetails.put("food_item_to_change", value);
					break;
				case 4:
					itemDetails.put("price", value);
					break;
				case 5:
					itemDetails.put("ForHere/Togo", value);
					break;
				}
				index++;
			}
			itemListFromPage.add(itemDetails);
			
			//MobileElement orderedItem = (MobileElement)cell.findElementByXPath("//UIAStaticText[contains(@value, '" + item_selected_for_order + "')]");
			//Assert.assertNotNull(orderedItem, "Failed to find the item ordered:" + item_selected_for_order + " in thank you page");
		}
		log("Items read from Order Thank you page:" + itemListFromPage.toJSONString());
		

		JSONArray backUpItems = (JSONArray)itemsToOrder.clone();
		log("Cloned Items:" + backUpItems.toJSONString());
		//remove the item which are removed
		for(Object i : backUpItems) {
			JSONObject item = (JSONObject)i;
			for(Object itemNameToRemove : itemsToRemove) {
				String itemToRemove = (String)itemNameToRemove;
				if( ((String)item.get("food_item_name")).equalsIgnoreCase(itemToRemove)) {
					itemsToOrder.remove(item);
					break;
				}
			}
		}		
		log("Items to check after removing the item:" + itemsToOrder.toJSONString());
		//store the data in runtime store
		//writeDataInRunStore("DATA_FROM_" + strCurrentTestcaseName, itemsToOrder.toJSONString());
		
		int foodItemIndex = -1;
		for(Object i : itemsToOrder) {
			JSONObject item = (JSONObject)i;
			String item_selected_for_order = (String)item.get("food_item_name");
			log("Checking the item:" + item_selected_for_order);
			found = false;
			for(Object itemFromUI : itemListFromPage) {
				JSONObject itemUI = (JSONObject)itemFromUI;
				if(((String)itemUI.get("name")).equalsIgnoreCase(item_selected_for_order)) {
					foodItemIndex++;
					item.put("orderid",  (String)itemUI.get("orderid"));
					item.put("order_person_name", strOrderPersonName);
					storeOrderIdDetailsToRunStore((foodItemIndex + 1), item);
					found = true;
					break;
				}
			}
			Assert.assertTrue(found, "Failed to find the item ordered:" + item_selected_for_order + " in thank you page");
			log("Successfully found the item:" + item_selected_for_order + " in order thank you page ");
		}
		log("The items in the order thank you page has been verified successfully");
		Assert.assertTrue(clickElement("btn_done_thank_page"), "Failed to click the Done heading after clicking Place Order");
		
		return this;
	}
	
	public KioskApp RemoveItems(JSONArray itemsToOrder, JSONArray itemsToRemove, String strExpectedTotalAfterRemove) {
		
		Assert.assertTrue(clickElement("btn_checkout_from_main_menu"), "Failed to click the Checkout button in the Landing page");
		Assert.assertNotNull(waitForElement("static_heading_checkout_popup"), "Failed to find the Checkout popup heading after clicking Checkout from Landing page");
		Assert.assertNotNull(waitForElement("btn_cancel_checkout_popup"), "Failed to find the Checkout Cancel button in Checkout Screen");
		Assert.assertNotNull(waitForElement("btn_continue_checkout_popup"), "Failed to find the Checkout Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("text_name_checkout_popup"), "Failed to find the Checkout Name textbox in Checkout Screen");
		
		Assert.assertTrue(clickElement("btn_continue_checkout_popup"), "Failed to click the Continue button in Checkout Screen");
		
		Assert.assertNotNull(waitForElement("btn_back_checkout_popup"), "Failed to find the Back button after clicking Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("btn_placeorder_checkout_popup"), "Failed to find the Place Order button after clicking Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("static_total_checkout_popup"), "Failed to find the Total order value static after clicking Continue button in Checkout Screen");
				
		
		String strItemToRemove = getUILocator("btn_remove_food_item_checkout_popup");
		for(Object item : itemsToRemove) {
			String itemToRemove = (String)item;
			log("Removing the item:" + itemToRemove);
			String strItemToRemoveLocator = strItemToRemove.replaceAll("<REPLACE_ITEM_TO_REMOVE>", itemToRemove);
			Assert.assertTrue(clickElement(strItemToRemoveLocator), "Failed to click the Remove button of the food item:" + itemToRemove);
		}
		log("All the food items to be removed has been successfully removed");
		return this;
		
	}
	public KioskApp RemoveItemsMyorderPage(JSONArray itemsToRemove, String strExpectedTotalAfterRemove) {
		
		Assert.assertTrue(clickElement("btn_checkout_from_main_menu"), "Failed to click the Checkout button in the Landing page");
		Assert.assertNotNull(waitForElement("my_order_page1"), "Failed to find the My order popup heading after clicking view order from Landing page");
		String strItemToRemove = getUILocator("btn_remove_food_item_checkout_popup");
		for(Object item : itemsToRemove) {
			String itemToRemove = (String)item;
			log("Removing the item:" + itemToRemove);
			String strItemToRemoveLocator = strItemToRemove.replaceAll("<REPLACE_ITEM_TO_REMOVE>", itemToRemove);
			Assert.assertTrue(clickElement(strItemToRemoveLocator), "Failed to click the Remove button of the food item:" + itemToRemove);
		}
		log("All the food items to be removed has been successfully removed");
		return this;
		
	}
	
public KioskApp RemoveItemsMyorderPage1(JSONArray itemsToRemove, String strExpectedTotalAfterRemove) {
		Assert.assertNotNull(waitForElement("my_order_page1"), "Failed to find the My order popup heading after clicking view order from Landing page");
		String strItemToRemove = getUILocator("btn_remove_food_item_checkout_popup");
		for(Object item : itemsToRemove) {
			String itemToRemove = (String)item;
			log("Removing the item:" + itemToRemove);
			String strItemToRemoveLocator = strItemToRemove.replaceAll("<REPLACE_ITEM_TO_REMOVE>", itemToRemove);
			Assert.assertTrue(clickElement(strItemToRemoveLocator), "Failed to click the Remove button of the food item:" + itemToRemove);
		}
		log("All the food items to be removed has been successfully removed");
		return this;
		
	}
	
	public KioskApp quantityMyorderPage(JSONArray itemNames,String foodType, String Quantity, String strExpectedTotal) {
		if  (foodType.equals("Customize")) {
			Assert.assertTrue(clickElement("btn_checkout_from_main_menu"), "Failed to click the Checkout button in the Landing page");
			Assert.assertNotNull(waitForElement("my_order_page1"), "Failed to find the My order popup heading after clicking view order from Landing page");
			Assert.assertNotNull(waitForElement("btn_cancel_checkout_popup1"), "Failed to find the Checkout Cancel button in Checkout Screen");
			Assert.assertNotNull(waitForElement("btn_continue_checkout_popup1"), "Failed to find the Checkout Continue button in Checkout Screen");
			log("in if");
		}
		else {
			Assert.assertTrue(clickElement("btn_checkout_from_main_menu"), "Failed to click the Checkout button in the Landing page");
			Assert.assertNotNull(waitForElement("my_order_page1"), "Failed to find the My order popup heading after clicking view order from Landing page");
			Assert.assertNotNull(waitForElement("btn_cancel_checkout_popup1"), "Failed to find the Checkout Cancel button in Checkout Screen");
			Assert.assertNotNull(waitForElement("btn_continue_checkout_popup1"), "Failed to find the Checkout Continue button in Checkout Screen");
		}
		String QuantityofItem = getUILocator("btn_quantity_food_item_checkout_popup");
		for(Object item : itemNames) {
			String itemName = (String)item;
			String strItemQuantityLocator = QuantityofItem.replaceAll("<REPLACE_ITEM_NAME>", itemName);
			MobileElement OrderQuantity = waitForElement(strItemQuantityLocator);
			String strOrderQuantityNumber = OrderQuantity.getText();
			log("The quantity number string is: "+strOrderQuantityNumber);
			String[] OrderQuantityArray = strOrderQuantityNumber.split("\\s+");
			String OrderQuantityNumber = OrderQuantityArray[2];
			log("The order quantity number is: "+OrderQuantityNumber);
			log("The quantity is: "+Quantity);
			Assert.assertEquals(OrderQuantityNumber, Quantity);
		}
		log("The strExpectedTotal is: "+strExpectedTotal);
		String itemValue = getUILocator("static_total_value_checkout_popup").replaceAll("<REPLACE_ORDER_TOTAL>", strExpectedTotal);
		Assert.assertNotNull(waitForElement(itemValue), "Failed to find the total amount field");
		log("Quantity has matched");
		return this;
	
	}
	//Added by Chithra
	public KioskApp totalOrderValidation() {
		Assert.assertTrue(clickElement("check_out_button"), "Failed to click the Checkout button in the Landing page");
		Assert.assertNotNull(waitForElement("myorder_header"), "Failed to find the My order popup heading after clicking view order from Landing page");
		Assert.assertNotNull(waitForElement("cancel_button_myorder_page"), "Failed to find the Checkout Cancel button in Checkout Screen");
		Assert.assertNotNull(waitForElement("continue_button_myorder_page"), "Failed to find the Checkout Continue button in Checkout Screen");
				
		//Get Order data from My Order screen
		List<WebElement> quantityDetails = waitForElements("quantity_myorder_page");
		int totalQuantity=0;
		List<WebElement> priceDetails = waitForElements("price_data_myorder_page");
		double totalPrice=0.00;
		if(quantityDetails.size()>0) {
			for(int i=0;i<quantityDetails.size();i++) {
				log(quantityDetails.get(i).getText());
				String[] quantityStrings = quantityDetails.get(i).getText().split(" ");
				log(quantityStrings[quantityStrings.length-1]);
				totalQuantity = Integer.parseInt(quantityStrings[quantityStrings.length-1]);
				
				log(priceDetails.get(i).getText());
				String[] priceStrings = priceDetails.get(i).getText().split(",");
				log(priceStrings[1]);
				Double price = Double.parseDouble(priceStrings[1].substring(2));
				log("Price:"+ price);
				totalPrice = totalPrice+(price*totalQuantity);
			}
		}
		log("Final Total quantity from list items added in cart:" + totalQuantity);
		log("Final Total Price  from list items added in cart:" + totalPrice);
		
		Assert.assertTrue(waitForElement("check_out_button").getText().contains(Integer.toString(totalQuantity)), "Failed to validate the total quantity data");	
		Assert.assertTrue(waitForElement("total_price_myorder_page").getText().contains(Double.toString(totalPrice)), "Failed to validate the total price data");
		AppUtilities.delay(2000);
		//Click on Cancel button
		Assert.assertTrue(clickElement("cancel_button_myorder_page"), "Failed to click Cancel button in My Order page");
		
		return this;
	
	}
	
	 public KioskApp ChangeOrderQuantity(String numberOfItems)
	    {
	        String myOrderButton = getUILocator("tabbtn_myorder_homepage");
	        Assert.assertTrue(clickElement(myOrderButton), "Failed to find the My Order tab btn after clicking the item btn add ");
	        //Assert.assertNotNull(waitForElement("SelectQuantity_my_order_page"), "Failed to Open My Order page");
	        AppUtilities.delay(4000);
	        Assert.assertTrue(clickElement("SelectQuantityBtn_my_order_page"), "Failed to click the Select Quantity button in My order page");
	        
	        MobileElement PickerWheel1 = waitForElement("IncreaseNoOfItems_my_order_page");
	        log("Able to identify the picker wheel");
	        PickerWheel1.sendKeys(numberOfItems);
	        log("Picker.....");
	        return this;
	    }
	    
	
	public KioskApp togo(JSONArray itemNames) {
		//Assert.assertTrue(clickElement("btn_checkout_from_main_menu"), "Failed to click the Checkout button in the Landing page");
		Assert.assertNotNull(waitForElement("my_order_page1"), "Failed to find the My order popup heading after clicking view order from Landing page");
		Assert.assertTrue(clickElement("my_order_page1"), "Failed to find the My order popup heading after clicking view order from Landing page");
		//Assert.assertNotNull(waitForElement("btn_cancel_checkout_popup"), "Failed to find the Checkout Cancel button in Checkout Screen");
		//Assert.assertNotNull(waitForElement("btn_continue_checkout_popup"), "Failed to find the Checkout Continue button in Checkout Screen");
		String togoitem = getUILocator("label_togo_checkout_popup");
		for(Object item : itemNames) {
			JSONObject itemName = (JSONObject)item;
			String foodItemName = (String)itemName.get("food_item_name");
			log("The item name is : "+foodItemName);
			String strItemtogoLabelLocator = togoitem.replaceAll("<REPLACE_ITEM_TO_SELECT>", foodItemName);
			Assert.assertNotNull(waitForElement(strItemtogoLabelLocator), "Failed to find to go button of the food item:" + foodItemName);
			/*
			String toGoSwitchLocator = getUILocator("switch_togo_checkout_popup").replaceAll("<REPLACE_ITEM_TO_SELECT>", foodItemName);
			MobileElement toGoSwitch = waitForElement(toGoSwitchLocator);
			boolean toGoSwitchValue = toGoSwitch.isSelected();
			log("The value of to go swtich is: "+toGoSwitchValue);
			if (toGoSwitchValue == true) {
				Assert.assertTrue(true);
			}
			*/
		}
		log("Found To go label");
		return this;
		
	}
	
	public KioskApp validateEmailfield(String email, String Name) {
		Assert.assertTrue(clickElement("btn_continue_checkout_popup1"), "Failed to find the Checkout Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("static_heading_checkout_popup"), "Failed to find the Checkout Continue button in Checkout Screen");
		Assert.assertNotNull(waitForElement("label_name_checkout_popup"), "Failed to find the Checkout Continue button in Checkout Screen");
		validateNoCardDeviceAttachalert();
		MobileElement txtFieldName = waitForElement("text_name_checkout_popup");
		txtFieldName.sendKeys(Name);
		
		Assert.assertNotNull(waitForElement("text_email_checkout_popup"), "Failed to find the Checkout Continue button in Checkout Screen");

		MobileElement txtFieldEmail = waitForElement("text_email_checkout_popup");
		txtFieldEmail.sendKeys(Name);
		
		
		log("Successfully validated Email address field");
		return this;
		
	}
	
	public KioskApp validateClearOrderDisable() {
		String clearOrderLocator = getUILocator("btn_clear_order");
		MobileElement clearOrder = waitForElement(clearOrderLocator);
		boolean clearOrderStatus = clearOrder.isEnabled();
		Assert.assertFalse(clearOrderStatus, "The Clear order is enabled when there are no items added to the cart");
		log("The clear order button is disabled when there are no items added to the cart");
		return this;
	}
	
	public KioskApp validateViewMyOrderDisable() {
		String viewMyOrderLocator = getUILocator("btn_checkout_from_main_menu");
		MobileElement viewMyOrder = waitForElement(viewMyOrderLocator);
		boolean viewMyOrderStatus = viewMyOrder.isEnabled();
		Assert.assertFalse(viewMyOrderStatus, "The View my order button is enabled when there are no items added to the cart");
		log("The View my order button is disabled when there are no items added to the cart");
		return this;
	}
	
	public KioskApp validateClearOrderEnable() {
		String clearOrderLocator = getUILocator("btn_clear_order");
		MobileElement clearOrder = waitForElement(clearOrderLocator);
		boolean clearOrderStatus = clearOrder.isEnabled();
		Assert.assertTrue(clearOrderStatus, "The Clear order is disabled when there are items added to the cart");
		log("The clear order button is enabled when there are items added to the cart");
		return this;
	}
	
	public KioskApp validateViewMyOrderEnable() {
		String viewMyOrderLocator = getUILocator("btn_checkout_from_main_menu");
		MobileElement viewMyOrder = waitForElement(viewMyOrderLocator);
		boolean viewMyOrderStatus = viewMyOrder.isEnabled();
		Assert.assertTrue(viewMyOrderStatus, "The View my order button is disbaled when there are items added to the cart");
		log("The View my order button is enabled when there are items added to the cart");
		return this;
	}
	
	public KioskApp clearOrderButtonAlert()	{
		String clearOrderLocator = getUILocator("btn_clear_order");
		MobileElement clearOrder = waitForElement(clearOrderLocator);
		boolean clearOrderStatus = clearOrder.isEnabled();
		Assert.assertTrue(clearOrderStatus, "The Clear order is disabled when there are items added to the cart");
		Assert.assertTrue(clickElement(clearOrderLocator), "Failed to click Clear order button");
		Assert.assertNotNull(waitForElement("alert_clear_order"), "Alert message for clear order is not present");
		log("The clear order alert is shown when clicked on clear order button");
		return this;
	}

	public KioskApp validateLandingPage() {
		AppUtilities.delay(32000);
		Assert.assertNotNull(waitForElement("landing_page_kiosk"), "The landing page is not displayed after idle");
		log("Validated the Kiosk Landing page");
		return this;
	}
	
	public KioskApp validateKioskResetAlert() {
		AppUtilities.delay(22000);
		Assert.assertNotNull(waitForElement("alert_kiosk_idle"), "The Kiosk Reset Alert is not displayed after idle");
		AppUtilities.delay(10000);
		Assert.assertNotNull(waitForElement("landing_page_kiosk"), "The landing page is not displayed after idle");
		log("Validated the Kiosk Reset Alert message");
		return this;
	}
	
	public KioskApp validateSpecialsFromLandingPage() {
		Assert.assertTrue(clickElement("landing_page_kiosk"), "Failed To click the landing page");
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement("cell_all_specials"), "The specials is not loaded when tapped on landing page");
		log("Validated the Kiosk Specials from landing page");
		return this;
	}
	
	public KioskApp validateMyOrderPage() {
		Assert.assertTrue(clickElement("btn_checkout_from_main_menu"), "Failed to click the view my order button");
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement("my_order_page1"), "Failed to find My order page");
		log("Validated my order page");
		return this;
	}
	
	public KioskApp validateCheckoutPage() {
		Assert.assertTrue(clickElement("btn_continue_checkout_popup1"), "Failed to click Continue button in My order page");
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement("static_heading_checkout_popup"), "Failed to find Checkout page");
		log("Validated checkout page");
		return this;
	}
	
	public KioskApp validateNoCardDeviceAttachalert() {
		MobileElement alertText = isElementPresent("alert_card_device_not_attached");
		if(alertText != null) {
			String text = alertText.getText();
			if(StringUtils.containsIgnoreCase(text, getUILocator("no_device_attached_for_payment"))) {
				log("No device attached alert has been shown. Dismissing it now..");
				clickElement("btn_ok_no_payment_alert");
				log("OK button of No Device attached has been clicked");
			}
		else {
			log("The no device attached alert has not been shown");
			}
		}
		return this;
	}
	
	public KioskApp validateVoucherDisableNoName() {
		String useVoucherLocator = getUILocator("btn_use_voucher");
		MobileElement useVoucher = waitForElement(useVoucherLocator);
		boolean useVoucherStatus = useVoucher.isEnabled();
		Assert.assertFalse(useVoucherStatus, "The Use voucher button is enabled when no name entered.");
		log("The Use voucher button is disabled when no name entered.");
		log("Validated Voucher button disabled when no name is present");
		return this;
	}
	
	public KioskApp validatePayDisableNoName() {
		String payButtonLocator = getUILocator("btn_pay_checkout_popup");
		MobileElement payButton = waitForElement(payButtonLocator);
		boolean payButtonStatus = payButton.isEnabled();
		Assert.assertFalse(payButtonStatus, "The Pay button is enabled when no name entered.");
		log("The Pay button is disabled when no name entered.");
		log("Validated Pay button disabled when no name is present");
		return this;
	}
	
	public KioskApp validateVoucherWithName() {
		Assert.assertTrue(typeText("text_name_checkout_popup", "Santhanalakshmi"), "Failed to type name in the Checkout Screen");
		String useVoucherLocator = getUILocator("btn_use_voucher");
		MobileElement useVoucher = waitForElement(useVoucherLocator);
		boolean useVoucherStatus = useVoucher.isEnabled();
		Assert.assertFalse(useVoucherStatus, "The Use voucher button is enabled when no name entered.");
		log("The Use voucher button is disabled when name entered.");
		return this;
	}
	
	public KioskApp validatePayWithName() {
		Assert.assertTrue(typeText("text_name_checkout_popup", "Santhanalakshmi"), "Failed to type name in the Checkout Screen");
		String payButtonLocator = getUILocator("btn_pay_checkout_popup");
		MobileElement payButton = waitForElement(payButtonLocator);
		boolean payButtonStatus = payButton.isEnabled();
		Assert.assertFalse(payButtonStatus, "The Pay button is enabled when entered name");
		log("The Pay button is disabled when entered name.");
		return this;
	}
	
	public KioskApp validateEmailIdPresent() {
		String emailId = "santhanalakshmi_k@apple.com";
		Assert.assertNotNull(waitForElement("text_email_checkout_popup"), "Failed to find the Checkout Continue button in Checkout Screen");
		MobileElement txtFieldEmail = waitForElement("text_email_checkout_popup");
		txtFieldEmail.sendKeys(emailId);
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("btn_back_checkout_popup"), "Failed to click the back button");
		Assert.assertTrue(clickElement("btn_cancel_checkout_popup1"), "Failed to click the back button");
		Assert.assertTrue(clickElement("btn_checkout_from_main_menu"), "Failed to click View my order button");
		Assert.assertTrue(clickElement("btn_continue_checkout_popup1"), "Failed to click Continue button in My order page");
		MobileElement emailIdField = waitForElement("text_email_checkout_popup");
		String emailIdFieldValue = emailIdField.getText();
		log("Email id value is: "+emailIdFieldValue);
		boolean comparsionResult = emailId.equals(emailIdFieldValue);
		Assert.assertEquals(comparsionResult, true);
		log("The Email id is present when user navigated back to food items screen");
		return this;
	}
	
	public KioskApp soldOutValidation(JSONArray itemNames) {
		String station = null;
		String itemToOrder = null;
		for(Object o : itemNames) {
            JSONObject item = (JSONObject)o;
            itemToOrder = (String)item.get("food_item_name");
            station = (String)item.get("select_station"); 
		}
		Assert.assertNotNull(waitForElement("static_app_heading"), "Failed to find the App Heading in the Landing page");
		String strItem = getUILocator("cell_item_to_select_in_left_menu");
		
		String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
		Assert.assertTrue(clickElement(selectStationItem), "Failed to select the left side of the station:" + station);
		log("The items to be ordered is: "+itemToOrder);
		
		//Click customize on the item
		String foodItemToSelectLocator = getUILocator("food_item_on_right_side");
		String foodItemToSelect = foodItemToSelectLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToOrder);
		Assert.assertTrue(clickElement(foodItemToSelect), "Failed to select the food item");
		
		String soldOutLocator = getUILocator("btn_sold_out_my_order_page");
		Assert.assertNotNull(waitForElement(soldOutLocator), "Failed to find the sold out locator in Kiosk");
		
		return this;
	}
	
	
	public KioskApp validateStationDisplayOrder(JSONObject caffeDetail, HashMap<String, Integer> menumakerStationDispOrder) {
		
		String aStationName = (String) caffeDetail.get("select_caffe_location");
		Assert.assertTrue(clickElement("cell_app_settings_select_cafe"), "Failed to select the Cafe Location");
		Assert.assertNotNull(waitForElement("btn_back_to_cafe_stations_in_select_cafe_location"), "Failed to find the Back button in selecting the cafe locations");
		
		String cafeLocator = getUILocator("cell_select_cafe_location").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
		Assert.assertNotNull(waitForElement(cafeLocator), "Failed to find the Cafe Location of:" + aStationName);
		Assert.assertTrue(clickElement(cafeLocator), "Failed to select the Cafe Location:" + aStationName);
		
		//make sure it it selected
		//cafeLocator = getUILocator("cell_default_cafe_selected").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
		//Assert.assertNotNull(waitForElement(cafeLocator), "Failed to find the Selected Cafe Location of:" + aStationName);
		
		log(menumakerStationDispOrder.toString());
    	AppUtilities.delay(7000);
    	List<WebElement>items =  waitForElements("cell_station_xpath");
    	log(Integer.toString(items.size()));
    	int value1,value2 = 0;
    	for (int i= 3; i <=  items.size(); i++){

    	   String strItem1 = getUILocator("cell_station_xpath");
    	   strItem1 = strItem1.replaceAll("@enabled= 'true'", Integer.toString(i));
    	   MobileElement r =  waitForElement(strItem1);
    	   log(r.getAttribute("name"));
    	   
    	   value1= (int) menumakerStationDispOrder.get(r.getAttribute("name"));
    	   
    	   if (value1>value2){
    	   value2 = value1;
    	   log("Displayed in correct order");
    	   } else {
    		   log ("Displayed in incorrect order");
    		   Assert.assertTrue(false, "Incorrect order displayed");
    	   }
      }
		return this;
	}
	
public KioskApp validateMenuDisplayOrder(JSONObject foodItem, HashMap<Integer,String> menumakerDispOrder){
    	
    	log(menumakerDispOrder.toString());
    	  String strStationToSelect = (String)foodItem.get("select_station");
    	  String strItem = getUILocator("cell_item_to_select_in_left_menu");
          String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect);
          Assert.assertTrue(clickElement(selectStationItem), "Failed to select the station:" + strStationToSelect);
        
          AppUtilities.delay(5000);
          HashMap <String, Integer > foodItemList = new HashMap<String,Integer>(); 
          for (int i= 1; i <=  menumakerDispOrder.size(); i++){

    	   strItem = getUILocator("food_items_on_right_side");
           strItem = strItem.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
    	   MobileElement r =  waitForElement(strItem);
    	   //log(r.getAttribute("path"));
    	   log(r.getAttribute("name"));
    	   foodItemList.put(r.getAttribute("name"),i);
          }
      
     log(foodItemList.toString());
     /*To be fixed for correct validation
      * int c=0,d=0;
      
     for (int i = 1 ; i<=menumakerDispOrder.size(); i++)
     {
    	 String foodItemName = menumakerDispOrder.get(i);
    	 c = foodItemList.get(foodItemName);
    	 if(c>d){
    		 log("Displayed in right order");
    	 }
    	 d= c;
     }*/
    	return this;
    }

	public KioskApp validateStationWaitTime(JSONArray items, String aCaffeLocation) {
	log("Items to be ordered is:" + items.toJSONString());
	JSONObject itemDetails = null;
	for(Object item : items) {
        itemDetails = (JSONObject)item;
	}
    String strStationToSelect = (String)itemDetails.get("select_station");
   

    String strItem = getUILocator("cell_item_to_select_in_left_menu");
    String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect);
    Assert.assertNotNull(waitForElement(selectStationItem), "Failed to select the station:" + strStationToSelect);
    
    strItem = getUILocator("cell_item_wait_time_in_left_menu");
    strItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect);
    WebElement e = waitForElement(strItem);
    String waitTime = e.getText();
    log(waitTime);
    temp = waitTime;
    return this;
}
	public KioskApp validateIncreaseInStationWaitTime(String waitTime, JSONArray items, String aCaffeLocation){

		validateStationWaitTime(items,aCaffeLocation);
		Assert.assertTrue(temp.contains(waitTime),"Failed to have the wait time specified in kds: "+waitTime +" in kiosk: "+temp);
		return this;
	}
	public KioskApp assertWaitTime(String waitTime){
    	
    	Boolean e = temp.contains(waitTime);
    	log(e.toString());
    	return this;
    }
}
