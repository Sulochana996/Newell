#! /bin/bash
./kill-server.sh "Appium"
