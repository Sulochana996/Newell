package com.apple.ist.caffemac.test;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;

public class MenuMakerAppFunctionalTestsGroup extends MenuMakerApp {

	
	@Test(dataProvider = "loadTestData")
	public void createMenu(JSONObject testData)  {
		String testCaseName = (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::createMenu-"+testCaseName);
		try {
			
			/*Test data configure: 
			 * createSpecialNonCustomizedMenu - SpecialNonCustomizedMenuData
			 * createSpecialCustomizedMenu - SpecialCustomizedMenuData
			 * createStandardNonCustomizedMenu- StandardNonCustomizedMenuData
			 * createStandardNonCustomizedMenuDifferentMealTime-createStandardNonCustomizedMenuDifferentMealTime
			 * createStandardCustomizedMenu - StandardCustomizedMenuData
			 * verifyCustomizationOption	-StandardCustomizedMenuDataTest
			 * validateCreateMenuFutureDate	-StandardCustomizedMenuDataTestFutureDate
			 * validateServingTypeTogo		-GrabAndGo_Existing_UAT
			 * 
			 */
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Special non-customized menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void createSharedMenu(JSONObject testData)  {
		String testCaseName = (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::createMenu-"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.createSharedFoodItem((JSONObject)foodItemsList.get(0))
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Special non-customized menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void CreateMenuWithSpecificUser(JSONObject testData) throws Exception {
		//CreateMenuWithSpecificUser
		String testCaseName = (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::CreateMenuWithSpecificUser" + testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			String username = (String)testData.get("username");
			String password = (String)testData.get("password");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			
			launch(username, password)
				.login(username, password)
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the lead chef creating menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void createVoucherInVoucherTab(JSONObject testData) throws Exception {
		String testCaseName = (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::createVoucherInVoucherTab" +testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.createVouchers(voucherDetails, empName)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for meal program. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void userDetailRequestInfo(JSONObject testData) throws Exception {
		String testCaseName = (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::userDetailRequestInfo" +testCaseName);
		try {
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			String voucherType = (String) testData.get("voucher_type");
			launch(username,password)
				.login(username,password)
				.validateUserDetail(username,empName,voucherType)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for user details in Meal voucher screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void defaultOptionRequestFor(JSONObject testData) throws Exception {
		String testCaseName = (String)testData.get("testcase_name");
		
		log("Test:MenuMakerAppFunctionalTests::defaultOptionRequestFor"+testCaseName);
		try {
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			//String empName = (String) testData.get("employee_name");
			String voucherType = (String) testData.get("voucher_type");
			
			launch(username,password)
				.login(username,password)
				.validateDefaultValueRequestFor(voucherType)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for default option request for in Meal voucher screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void cancelRequestOnBehalfPopUp(JSONObject testData) throws Exception {
		String testCaseName = (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::cancelRequestOnBehalfPopUp"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyRequestOnBehalf(voucherDetail, empName)
				.cancelRequestForUser()
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing cancel request on behalf pop upfor meal program. Error:" + e);
		}
	}
	

	@Test(dataProvider = "loadTestData")
	public void businessJustificationRequired(JSONObject testData) throws Exception {
		String testCaseName = (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::businessJustificationRequired"+testCaseName);
		try {
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String voucherType = (String) testData.get("voucher_type");
			String dollarLimit = (String) testData.get("dollar_limit");
			launch(username,password)
				.login(username,password)
				.validateBusinessJustifcation(voucherType,dollarLimit)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Business Justification field is Required for in Meal program screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void nameRequired(JSONObject testData) throws Exception {
		String testCaseName = (String)testData.get("testcase_name");
		
		log("Test:MenuMakerAppFunctionalTests::nameRequired"+testCaseName);
		try {
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			launch(username,password)
				.login(username,password)
				.validateVoucherName(testData)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Required fields for in Meal program screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateCancelVoucher(JSONObject testData) throws Exception {
		String testCaseName = (String)testData.get("testcase_name");
		
		log("Test:MenuMakerAppFunctionalTests::validateCancelVoucher");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.cancelCreateVouchers(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing cancelling meal voucher. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void modifySavedVoucher(JSONObject testData) throws Exception {
		String testCaseName = (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::modifySavedVoucher"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			String modifyVoucherBJ = (String) testData.get("change_business_justification");
			launch(username,password)
				.login(username,password)
				.submitSavedVoucher(voucherDetails, empName,modifyVoucherBJ)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing submitting the saved voucher my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCategoryDetails(JSONObject testData)  {
		String testCaseName = (String)testData.get("testcase_name");
		
		log("Test:MenuMakerAppFunctionalTests::verifyCategoryDetails"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateMyRequest(JSONObject testData) throws Exception {
		String testCaseName= (String)testData.get("testcase_name");
		
		log("Test:MenuMakerAppFunctionalTests::validateMyRequest"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void unableToAddOtherTypeEmployeeAsDelegate(JSONObject testData) throws Exception {
		String testCaseName= (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::unableToAddOtherTypeEmployeeAsDelegate"+testCaseName);
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			String testDataKey = (String) testData.get("testdata_key");
			testData = (JSONObject)getData(testDataKey);
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeMealProgram(voucherDetails, empName)
				.addOtherTypeDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyMinQTyIfRequiredCustomizeScreen(JSONObject testData)  {
		String testCaseName= (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::verifyMinQTyIfRequiredNoCustomizeScreen"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateRequiredField(foodItem)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category button. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyTheExistingDelegate(JSONObject testData) throws Exception {
		String testCaseName= (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::verifyTheExistingDelegate"+testCaseName);
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.addDelegates(delegateDetails)
				.verifyExistingDelegate(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateDelegateDetails(JSONObject testData) throws Exception {
		//validateMyRequest
		log("Test:MenuMakerAppFunctionalTests::validateDelegateDetails");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			String testDataKey = (String) testData.get("testdata_key");

			testData = (JSONObject)getData(testDataKey);
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.addDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateApprovalFlow(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateApprovalFlow");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			String testDataKey = (String) testData.get("testdata_key");

			testData = (JSONObject)getData(testDataKey);
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateApprovalFlow(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	
	
	//-----------------------------------------------------------------------------------------------------------//

	@Test(dataProvider = "loadTestData")
	public void createSpecialNonCustomizedMenu(JSONObject testData)  {
		log("createMenu");
		log("Test:MenuMakerAppFunctionalTests::createSpecialNonCustomizedMenu");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Special non-customized menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void createStandardNonCustomizedMenu(JSONObject testData) throws Exception {
		log("createMenu");
		log("Test:MenuMakerAppFunctionalTests::createStandardNonCustomizedMenu");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.createGivenFoodItems(foodItemsList)
				.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Standard non-customized menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void deleteFoodMenu(JSONObject testData) throws Exception {
		log("same");
		log("Test:MenuMakerAppFunctionalTests::deleteFoodMenu");
		try {
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_delete");
			launch()
				.login()
				.removeFoodItems(foodItemsList)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing delete menu. Error:" + e);
		}
	}


	@Test(dataProvider = "loadTestData")
	public void createSpecialCustomizedMenu(JSONObject testData) throws Exception {
		log("createMenu");
		log("Test:MenuMakerAppFunctionalTests::createSpecialCustomizedMenu");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Special customized menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void createStandardCustomizedMenu(JSONObject testData) throws Exception {
		log("createMenu");
		log("Test:MenuMakerAppFunctionalTests::createStandardCustomizedMenu");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Standard Customized menu. Error:" + e);
		}
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void createStandardNonCustomizedMenuDifferentMealTime(JSONObject testData) throws Exception {
		log("createMenu");
		log("Test:MenuMakerAppFunctionalTests::createStandardNonCustomizedMenuDifferentMealTime");
		try {
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Stanard non-customized menu for different meal time. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateCaffeDetails(JSONObject testData) throws Exception {
		//new
		
		log("Test:MenuMakerAppFunctionalTests::validateCaffeDetails");
		try {
	
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.checkCaffeNameInCaffeInfoPage(caffeDetails)
				.checkCaffeAddressInCaffeInfoPage(caffeDetails)
				.checkCaffeEmailInCaffeInfoPage(caffeDetails)
				.checkCaffeTeamInCaffeInfoPage(caffeDetails)
				.checkCaffeNameInCaffeInfoPage(caffeDetails)
				.verifySaveButtonInCaffePage(caffeDetails)
				.verifyDateAndTime()
				.verifyCancelButtonInCaffePage(caffeDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	

	@Test(dataProvider = "loadTestData")
	public void validateNavigOtherTabFromCaffePage(JSONObject testData) throws Exception {
		//same
		log("Test:MenuMakerAppFunctionalTests::validateNavigOtherTabFromCaffePage");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.checkCaffeNameInCaffeInfoPage(caffeDetails)
				.validateAlertWhenNavigatedToOtherTabsFromCaffe()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateSelectCaffeInStationPage(JSONObject testData) throws Exception {
		//Try to handle in stations page case
		log("Test:MenuMakerAppFunctionalTests::validateSelectCaffeInStationPage");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToStationPage(caffeDetails)
				.verifyChosenCaffeInStationsPage(caffeDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateStationDetails(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateAddStationButton");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToStationPage(caffeDetails)
				.verifyChosenCaffeInStationsPage(caffeDetails)
				.verifyAddStationButton()
				.validateNameFieldNewStation()
				.validateActiveFieldNewStation(caffeDetails)
				.validateDisplayOrderFieldNewStation()
				.validateDefaultPriceFieldNewStation()
				.checkStationNameFieldMandatory()
				.checkStationPriceFieldMandatory()
				.checkStationNameDuplicate()
				.checkDisplayOrderDuplicate()
				.validateAlertWhenNavigatedToOtherTabsFromStation()
				.verifyCancelButton()
				//.verifyStationNameInLeftPane()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateSaveButtonInStationPage(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateDisplayOrderStation");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToStationPage(caffeDetails)
				.verifySaveButton()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyStationFieldsAnditsValidation(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateActiveStationAndSave");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			String stationName = (String) testData.get("inactiveStation");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.getDisplayOrderStation(caffeDetails)
				.checkItemsAvailablityForStations(caffeDetails)
				.navigateToStationPage(caffeDetails)
				.verifySaveButton()
				.verifyDateAndTime()
				.checkUploadingImageStation(caffeDetails)
				.checkActiveStationAndSave(caffeDetails)
				.checkInactiveStationAndSave(stationName)
				.verifySaveButton()
				.verifyStationNameInLeftPane()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateInactiveStationAndSave(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateInactiveStationAndSave");
		try {
			log("Data:" + testData.toJSONString());
			String stationName = (String) testData.get("inactiveStation");
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToStationPage(caffeDetails)
				.checkInactiveStationAndSave(stationName)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateImageUploadForStation(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateDisplayOrderStation");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			//String imagePath = (String)testData.get("food_item_image_path");
			launch()
				.login()
				.navigateToStationPage(caffeDetails)
				.checkUploadingImageStation(caffeDetails)
				.verifySaveButton()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateDefaultPriceStation(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateDefaultPriceStation");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			//String imagePath = (String)testData.get("food_item_image_path");
			launch()
				.login()
				.navigateToStationPage(caffeDetails)
				.checkActiveStationAndSave(caffeDetails)
				.verifyStationInMenuTab(caffeDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateStationNameInLeftPane(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateStationNameInLeftPane");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToStationPage(caffeDetails)
				.verifyStationNameInLeftPane()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateNewStationInMenu(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateNewStationInMenu");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToStationPage(caffeDetails)
				.verifySaveButton()
				.verifyStationInMenuTab(caffeDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateScheduleForNewStation(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateNewStationInMenu");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToStationPage(caffeDetails)
				.verifySaveButton()
				.verifyStationInMenuTab(caffeDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateStationSaveDateAndTime(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateStationSaveDateAndTime");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToStationPage(caffeDetails)
				.verifySaveButton()
				.verifyDateAndTime()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Name. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateMenuDetails(JSONObject testData) throws Exception {
		log("createMenu");
		log("Test:MenuMakerAppFunctionalTests::validateMenuDetails");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.validateMenuPage(foodItemsList)
				.validateNewMenuItem(foodItemsList)
				//.validateNutritionInfoFields(foodItemsList)
				.validateServingType(foodItemsList)
				.validateComponentDetails(foodItemsList)
				//.validateServingDetails(foodItemsList)
				//.validateCancelButton(foodItemsList)
				
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Add dish button in menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateServingTypeTogo(JSONObject testData) throws Exception {
		log("covered under createMenu Test case");
		log("Test:MenuMakerAppFunctionalTests::validateServingTypeTogo");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.validateMenuPage(foodItemsList)
				.validateServingType(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for serving type to go in menu creation. Error:" + e);
		}
	}
	
	public void validateServingTypeForHere(JSONObject testData) throws Exception {
		log("covered under createMenu Test case");
		log("Test:MenuMakerAppFunctionalTests::validateServingTypeForHere");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.validateMenuPage(foodItemsList)
				.validateServingType(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for serving type for here in menu creation. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateMultipleComponentDetails(JSONObject testData) throws Exception {
		log("covered under createMenu Test case");
		log("Test:MenuMakerAppFunctionalTests::validateMultipleComponentDetails");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.validateMenuPage(foodItemsList)
				.validateComponentDetails(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for ComponentDetails in menu creation. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void validateNewMenuItemStatusDetails(JSONObject testData) throws Exception {
		log("covered under createMenu Test case");
		log("Test:MenuMakerAppFunctionalTests::validateSaveNewMenuItem");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for ComponentDetails in menu creation. Error:" + e);
		}
	}

	
	@Test(dataProvider = "loadTestData")
	public void verifyCustomizationOption(JSONObject testData) throws Exception {
		log("createMenu");
		log("Test:MenuMakerAppFunctionalTests::verifyCustomizationOption");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for customization option in menu creation. Error:" + e);
		}
	} 
	@Test(dataProvider = "loadTestData")
	public void validateCreateMenuSameDate(JSONObject testData) throws Exception {
		log("createMenu");
		
		try {
			String testDataKey = (String)testData.get("testdata_key");
			String testName = (String)testData.get("testcase_name");
			log("The test data to be taken is from:" + testDataKey);
			log("Test:MenuMakerAppFunctionalTests::"+testName);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for customization option in menu creation. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateScheduleDetails(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateRemoveMenuItem");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.verifyAddSchedule()
				.verifyScheduleNameMandatory()
				.verifyDaysFieldSchedule()
				.verifyTimeFieldSchedule()
				.verifyStartEndSchedule()
				.verifySaveSchedule()
				//.validateScheduleInCaffePage(caffeDetails)
				.verifyScheduleInStationsPage(caffeDetails)
				.verifyRemoveSchedule()
				.verifyScheduleRemoveInStationsPage(caffeDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for ComponentDetails in menu creation. Error:" + e);
		}
	}

	
	@Test(dataProvider = "loadTestData")
	public void validateStationPresentInSchedule(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateRemoveMenuItem");
		try {
			log("Data:" + testData.toJSONString());
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.verifyAddSchedule()
				.verifySaveSchedule()
				//.verifyScheduleCheckStationsPage(caffeDetails)
				//.verifyStationInSchedule(caffeDetails)
				//.verifyRemoveSchedule()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for ComponentDetails in menu creation. Error:" + e);
		}
	}
	
	@Test(dataProvider= "loadTestData")
	public void expandFoodItemMenu(JSONObject testdata) throws Exception{
		//same
		log("Test:MenuMakerFunctionalTests:expandFoodItemMenu");
		try{
			log("Data: "+testdata.toJSONString());
			JSONArray FoodItems = (JSONArray)testdata.get("food_items_to_expand");
			launch()
				.login()
				.expandCollapseMenuItems(FoodItems)
			.quitApp();
			
		}
		catch(Exception e)
		{
			Assert.assertTrue(false, "Exception occured while testing for expand food item menu" +e);
		}
	}
	
	@Test(dataProvider= "loadTestData")
	public void collapseFoodItemMenu(JSONObject testdata) throws Exception{
		//expandFoodItemMenu
		log("Test:MenuMakerFunctionalTests:collapseFoodItemMenu");
		try{
			log("Data: "+testdata.toJSONString());
			JSONArray FoodItems = (JSONArray)testdata.get("food_items_to_collapse");
			launch()
				.login()
				.expandCollapseMenuItems(FoodItems)
			.quitApp();
			
		}
		catch(Exception e)
		{
			Assert.assertTrue(false, "Exception occured while testing for collapse food item menu" +e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateActivatingStations(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateActivatingStations");
		try {

			log("Data:" + testData.toJSONString());
			JSONArray itemDetails = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.activateStations(itemDetails)
				.createGivenFoodItems(itemDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing activating stations. Error:" + e);
		}
	}

	@Test(dataProvider = "loadTestData")
	public void validateDeActivatingStations(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateActivatingStations");
		try {

			log("Data:" + testData.toJSONString());
			JSONArray itemDetails = (JSONArray)testData.get("food_items_to_create");
			launch()
				.login()
				.deActivateStations(itemDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing activating stations. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateLeadChefCaffePage(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateLeadChefCaffePage");
		try {
			log("Data:" + testData.toJSONString());
			String username = (String)testData.get("leadchef_username");
			String password = (String)testData.get("leadchef_password");
			launch(username, password)
				.login(username, password)
				.verifyCaffeAccessLeadChef()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing activating stations. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateLeadChefCreateMenu(JSONObject testData) throws Exception {
		//CreateMenuWithSpecificUser
		log("Test:MenuMakerAppFunctionalTests::validateLeadChefCreateMenu");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			String username = (String)testData.get("leadchef_username");
			String password = (String)testData.get("leadchef_password");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			log("Data:" + testData.toJSONString());
			
			launch(username, password)
				.login(username, password)
				.saveFoodItem(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the lead chef creating menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateLeadChefPublishMenu(JSONObject testData) throws Exception {
		//CreateMenuWithSpecificUser
		log("Test:MenuMakerAppFunctionalTests::validateLeadChefCreateMenu");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			String username = (String)testData.get("leadchef_username");
			String password = (String)testData.get("leadchef_password");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			log("Data:" + testData.toJSONString());
			
			launch(username, password)
				.login(username, password)
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the lead chef creating menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateSuperAdminCreateMenu(JSONObject testData) throws Exception {
		//CreateMenuWithSpecificUser
		log("Test:MenuMakerAppFunctionalTests::validateLeadChefCreateMenu");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			String username = (String)testData.get("leadchef_username");
			String password = (String)testData.get("leadchef_password");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			log("Data:" + testData.toJSONString());
			
			launch(username, password)
				.login(username, password)
				.saveFoodItem(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the lead chef creating menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateSuperAdminPublishMenu(JSONObject testData) throws Exception {
		//CreateMenuWithSpecificUser
		log("Test:MenuMakerAppFunctionalTests::validateLeadChefCreateMenu");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			String username = (String)testData.get("leadchef_username");
			String password = (String)testData.get("leadchef_password");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			log("Data:" + testData.toJSONString());
			
			launch(username, password)
				.login(username, password)
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the lead chef creating menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateSuperAdminCaffePage(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateLeadChefCaffePage");
		try {
			log("Data:" + testData.toJSONString());
			String username = (String)testData.get("leadchef_username");
			String password = (String)testData.get("leadchef_password");
			launch(username, password)
				.login(username, password)
				.verifyCaffeAccessSuperAdmin()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing activating stations. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateCaffeAdminCreateMenu(JSONObject testData) throws Exception {
		//OutOfScope
		log("Test:MenuMakerAppFunctionalTests::validateCaffeAdminCreateMenu");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			String username = (String)testData.get("leadchef_username");
			String password = (String)testData.get("leadchef_password");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			log("Data:" + testData.toJSONString());
			
			launch(username, password)
				.login(username, password)
				.saveFoodItem(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the lead chef creating menu. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateCaffeAdminPublishMenu(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateLeadChefCreateMenu");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			String username = (String)testData.get("leadchef_username");
			String password = (String)testData.get("leadchef_password");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			log("Data:" + testData.toJSONString());
			
			launch(username, password)
				.login(username, password)
				.createGivenFoodItems(foodItemsList)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing the lead chef creating menu. Error:" + e);
		}
	}
	
	@Test(dataProvider= "loadTestData")
	public void displayOrderFoodItemMenu(JSONObject testdata) throws Exception{
		log("Test:MenuMakerFunctionalTests:displayOrderFoodItemMenu");
		try{
			log("Data: "+testdata.toJSONString());
			JSONArray FoodItems = (JSONArray)testdata.get("food_items_to_display");
			launch()
				.login()
				.verifyDisplayOrderMenu(FoodItems)
			.quitApp();
		}
		catch(Exception e)
		{
			Assert.assertTrue(false, "Exception occured while testing for display order food item menu" +e);
		
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void addStationsVariableMealTime(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::addStationsVariableMealTime");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray itemDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToStationPage(itemDetails)
				.addStations(itemDetails)
				.createGivenFoodItems(itemDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing add stations for variable meal time. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void requestMealProgramAndValidateItsField(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::requestMealProgramAndValidateItsField");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONObject voucherDetail = (JSONObject)testData.get("vouchers_to_create");
			String voucherType = (String) testData.get("voucher_type");
			String dollarLimit = (String) testData.get("dollar_limit");
			launch(username,password)
				.login(username,password)
				.createVouchers(voucherDetails, empName)
				.validateVoucherName(testData)
				.verifyRequestOnBehalf(voucherDetail, empName)
				.validateDefaultValueRequestFor(voucherType)
				.validateBusinessJustifcation(voucherType,dollarLimit)
				.cancelCreateVouchers(voucherDetails, empName)
				.verifyRequestOnBehalf(voucherDetail, empName)
				.cancelRequestForUser()
				.validateMyRequest(voucherDetails, empName)
				.validateUserDetail(username,empName,voucherType)
				.validateApprovalFlow(voucherDetails, empName)
				//.verifyChargeDepartmentDetails(voucherDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for meal program. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void requestMealVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::requestMealVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONObject voucherDetail = (JSONObject)testData.get("vouchers_to_create");
			String voucherType = (String) testData.get("voucher_type");
			String dollarLimit = null;
			String modifyVoucherBJ = null;
			launch(username,password)
				.login(username,password)
				.createVouchers(voucherDetails, empName)
				.verifyChargeDepartmentDetails(voucherDetail)
				.validateDefaultValueRequestFor(voucherType)
				.validateVoucherName(testData)
				.cancelCreateVouchers(voucherDetails, empName)
				.validateBusinessJustifcation(voucherType,dollarLimit)
				.validateUserDetail(username,empName,voucherType)
				.validateMyRequest(voucherDetails, empName)
				.submitSavedVoucher(voucherDetails, empName, modifyVoucherBJ)
				.validateMyRequest(voucherDetails, empName)
				.validateMinusButtonForaVoucher(voucherType)
				.createDeleteVouchers(voucherDetails, empName)
				.deleteVoucher(voucherDetail)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void requestMealProgramOnBehalf(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::requestMealProgramOnBehalf");
		try {

			//Updated by Chithra
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONObject voucherDetail = (JSONObject)testData.get("vouchers_to_create");
			launch(username,password)
				.login(username,password)
				.createVouchers(voucherDetails, empName)
				.verifyRequestOnBehalf(voucherDetail, empName)
				.validateRequestForUser(voucherDetail)
				.validateApprovalFlow(voucherDetails, empName)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for meal program. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void requestMealVoucherOnBehalf(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::requestMealVoucherOnBehalf");
		try {

			//Updated by Chithra
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONObject voucherDetail = (JSONObject)testData.get("vouchers_to_create");
			launch(username,password)
				.login(username,password)
				.createVouchers(voucherDetails, empName)
				.verifyRequestOnBehalf(voucherDetail, empName)
				.validateRequestForUser(voucherDetail)
				.cancelRequestForUser()
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtUserDetailRequestInfo(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtUserDetailRequestInfo");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			String voucherType = (String) testData.get("voucher_type");
			launch(username,password)
				.login(username,password)
				.validateUserDetail(username,empName,voucherType)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for user details in Meal voucher screen. Error:" + e);
		}
	}
	

	@Test(dataProvider = "loadTestData")
	public void mpUserDetailRequestInfo(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpUserDetailRequestInfo");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			String voucherType = (String) testData.get("voucher_type");
			
			launch(username,password)
				.login(username,password)
				.validateUserDetail(username,empName,voucherType)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for user details in Meal program screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtDefaultOptionRequestFor(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtDefaultOptionRequestFor");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			//String empName = (String) testData.get("employee_name");
			String voucherType = (String) testData.get("voucher_type");
			
			launch(username,password)
				.login(username,password)
				.validateDefaultValueRequestFor(voucherType)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for default option request for in Meal voucher screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpDefaultOptionRequestFor(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpDefaultOptionRequestFor");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			//String empName = (String) testData.get("employee_name");
			String voucherType = (String) testData.get("voucher_type");
			
			launch(username,password)
				.login(username,password)
				.validateDefaultValueRequestFor(voucherType)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for default option request for in Meal program screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtMinusButtonNotDisplayed(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtMinusButtonNotDisplayed");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String voucherType = (String) testData.get("voucher_type");
			
			launch(username,password)
				.login(username,password)
				.validateMinusButtonForaVoucher(voucherType)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for minus button not displayed in Meal voucher screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpRequestOnBehalfPopUp(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpRequestOnBehalfPopUp");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyRequestOnBehalf(voucherDetail, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing request on behalf pop upfor meal program. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtRequestOnBehalfPopUp(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpRequestOnBehalfPopUp");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyRequestOnBehalf(voucherDetail, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing request on behalf pop upfor meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpValidateRequestOnBehalf(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpValidateRequestOnBehalf");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyRequestOnBehalf(voucherDetail, empName)
				.validateRequestForUser(voucherDetail) //-- To be added once defect is fixed
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing request on behalf details for meal program. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtValidateRequestOnBehalf(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateRequestOnBehalf");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyRequestOnBehalf(voucherDetail, empName)
				.validateRequestForUser(voucherDetail)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing request on behalf details for meal voucher. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpCancelRequestOnBehalfPopUp(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpCancelRequestOnBehalfPopUp");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyRequestOnBehalf(voucherDetail, empName)
				.cancelRequestForUser()
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing cancel request on behalf pop upfor meal program. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtCancelRequestOnBehalfPopUp(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtCancelRequestOnBehalfPopUp");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyRequestOnBehalf(voucherDetail, empName)
				.cancelRequestForUser()
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing cancel request on behalf pop upfor meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtValidateCancelButton(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::requestMealProgram");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			launch(username,password)
				.login(username,password)
				.verifyMTCancelButton()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for meal Voucher Cancel button. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpValidateCancelButton(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::requestMealProgram");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			launch(username,password)
				.login(username,password)
				.verifyMPCancelButton()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for meal Voucher Cancel button. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtDeptCompanyCode(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtDeptCompanyCode");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyChargeDepartmentDetails(voucherDetail)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing department and company code for meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpDollarLimit(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpDollarLimit");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyChargeDepartmentDetails(voucherDetail)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing dollar limit for meal Program. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpDeptCode(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpDeptCode");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyChargeDepartmentDetails(voucherDetail)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing department code for meal voucher. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpSvpCode(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtDeptCompanyCode");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONObject voucherDetail = (JSONObject)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.verifyChargeDepartmentDetails(voucherDetail)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing department and company code for meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpBusinessJustificationRequired(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpBusinessJustificationRequired");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String voucherType = (String) testData.get("voucher_type");
			String dollarLimit = (String) testData.get("dollar_limit");
			launch(username,password)
				.login(username,password)
				.validateBusinessJustifcation(voucherType,dollarLimit)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Business Justification field is Required for in Meal program screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtBusinessJustificationRequired(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtBusinessJustificationRequired");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String voucherType = (String) testData.get("voucher_type");
			String dollarLimit = null;
			launch(username,password)
				.login(username,password)
				.validateBusinessJustifcation(voucherType,dollarLimit)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Business Justification field is Required for in Meal voucher screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtPlannedUseQtyRequired(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtPlannedUseQtyRequired");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			launch(username,password)
				.login(username,password)
				.validateVoucherName(testData)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Required fields for in Meal voucher screen. Error:" + e);
		}
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void mpProgramNameRequired(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpProgramNameRequired");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			launch(username,password)
				.login(username,password)
				.validateVoucherName(testData)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing Required fields for in Meal program screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtAddVouchers(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtAddVouchers");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.createVouchers(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while adding meal vouchers. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void deleteAMealVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::deleteAMealVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONObject voucherToDelete = (JSONObject)testData.get("vouchers_to_delete");
			log(voucherToDelete.toJSONString());
			launch(username,password)
				.login(username,password)
				.createDeleteVouchers(voucherDetails, empName)
				.deleteVoucher(voucherToDelete)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing deleting a meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateTotalAftDeleteMealVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateTotalAftDeleteMealVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONObject voucherToDelete = (JSONObject)testData.get("vouchers_to_delete");
			log(voucherToDelete.toJSONString());
			launch(username,password)
				.login(username,password)
				.createDeleteVouchers(voucherDetails, empName)
				.deleteVoucher(voucherToDelete)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing total after deleting a meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateTotalForAllVouchers(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateTotalForAllVouchers");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.createVouchers(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while validating total after adding meal vouchers. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void validateTotalForVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateTotalForVouchers");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.createVouchers(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing total for a single meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtValidateCancelVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateCancelVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.cancelCreateVouchers(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing cancelling meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpValidateCancelVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpValidateCancelVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.cancelCreateVouchers(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing cancelling meal program. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpValidateProgramHour(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpValidateProgramHour");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.createVouchers(voucherDetails,empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing meal program hour format. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtValidateMyRequest(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateMyRequest");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtSubmitSavedVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtSubmitSavedVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			String modifyVoucherBJ = null;
			launch(username,password)
				.login(username,password)
				.submitSavedVoucher(voucherDetails, empName, modifyVoucherBJ)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing submitting the saved voucher my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtModifySavedVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtSubmitSavedVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			String modifyVoucherBJ = (String) testData.get("change_business_justification");
			launch(username,password)
				.login(username,password)
				.submitSavedVoucher(voucherDetails, empName,modifyVoucherBJ)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing submitting the saved voucher my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtUnableToModifySubmittedVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtUnableToModifySubmittedVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			String modifyVoucherBJ = null;
			launch(username,password)
				.login(username,password)
				.submitSavedVoucher(voucherDetails, empName, modifyVoucherBJ)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing submitting the saved voucher my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtVerifyNumberOfRequest(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateMyRequest");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtValidateVoucherDetailsMyRequest(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateMyRequest");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpSubmitSavedVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpSubmitSavedVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			String modifyVoucherBJ = null;
			launch(username,password)
				.login(username,password)
				.submitSavedVoucher(voucherDetails, empName, modifyVoucherBJ)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing submitting the saved meal program from my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpValidateMyRequest(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpValidateMyRequest");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing meal program values in my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpModifySavedVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpSubmitSavedVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			String modifyVoucherBJ = (String) testData.get("change_business_justification");
			launch(username,password)
				.login(username,password)
				.submitSavedVoucher(voucherDetails, empName,modifyVoucherBJ)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing submitting the saved meal program from my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpUnableToModifySubmittedVoucher(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpUnableToModifySubmittedVoucher");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			String modifyVoucherBJ = null;
			launch(username,password)
				.login(username,password)
				.submitSavedVoucher(voucherDetails, empName, modifyVoucherBJ)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing submitting the saved meal program from my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void customisationOptionEnabledAfterSave(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::customisationOptionEnabledAfterSave");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for customisation option enabled after save. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void tapOnCustomisationOption(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::tapOnCustomisationOption");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.validateCustomisationScreen()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for customisation option clicked. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyAddNewCategoryButton(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyAddNewCategoryButton");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.validateCustomisationScreen()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for add new category button. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyRequiredYesCustomizeScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyRequiredYesCustomizeScreen");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateRequiredField(foodItem)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyRequiredNoCustomizeScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyRequiredNoCustomizeScreen");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateRequiredField(foodItem)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category button. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyMinQTyIfRequiredYesCustomizeScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyMinQTyIfRequiredYesCustomizeScreen");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateRequiredField(foodItem)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyMinQTyIfRequiredNoCustomizeScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyMinQTyIfRequiredNoCustomizeScreen");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateRequiredField(foodItem)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category button. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCategoryName(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyCategoryName");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category name. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyCategoryDescription(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyCategoryDescription");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category description. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyCategoryDisplayOder(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyCategoryDisplayOder");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category display order. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyCategoryPriceIncrease(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyCategoryPriceIncrease");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category price increase. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyAddItemButtonCategoryScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyCategoryPriceIncrease");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category price increase. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyCreateButtonCategoryScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyCategoryPriceIncrease");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new category price increase. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void verifyAddItemNameCategory(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyAddItemNameCategory");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void displayOrderStations(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::displayOrderStations");
		try {
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			JSONObject caffeDetail = (JSONObject)caffeDetails.get(0);
			log("The caffe details" +caffeDetail.toJSONString());
		
			launch()
				.login()
				.getDisplayOrderStation(caffeDetails)
				.checkItemsAvailablityForStations(caffeDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing display order for stations. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void validateMinAndMaxQty(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateMinAndMaxQty");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateCancelButtonCustomizeScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateCancelButtonCustomizeScreen");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.cancelCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateEditButtonCustomizeScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateEditButtonCustomizeScreen");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(customItemDetail.toJSONString());
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
				.cancelModifyCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void validateCancelButtonModifyCustomScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateCancelButtonModifyCustomScreen");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
				.cancelModifyCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void validateRemoveButtonRemovesItemInCustomizeScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateRemoveButtonRemovesItemInCustomizeScreen");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
				.removeModifyCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void validateRemoveButtonModifyCustomScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateRemoveButtonModifyCustomScreen");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
				.removeModifyCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateCategryPriceIncreaseZero(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateCategryPriceIncreaseZero");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateUploadImageCustomizeItem(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateUploadImageCustomizeItem");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validatePriceIncreaseFieldCustomizeItem(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validatePriceIncreaseFieldCustomizeItem");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateMaxServingFieldCustomizeItem(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateMaxServingFieldCustomizeItem");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}	
	
	@Test(dataProvider = "loadTestData")
	public void validateDisplayOrderFieldCustomizeItem(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateDisplayOrderFieldCustomizeItem");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}	
	
	@Test(dataProvider = "loadTestData")
	public void validateCancelButtonCustomizeItem(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateCancelButtonCustomizeItem");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
				.cancelCustomItemCreation()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}	
	
	@Test(dataProvider = "loadTestData")
	public void validateSaveButtonCustomizeItem(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateSaveButtonCustomizeItem");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
				.saveCustomItemCreation()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateRemoveCustomizeItem(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateRemoveCustomizeItem");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail)
				.removeCustomItemCreation()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}

	@Test(dataProvider = "loadTestData")
	public void validateEscButtonCustomizationPopup(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateEscButtonCustomizationPopup");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			log(customItemDetail.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.validateEscapeButtonInCustomizationPopup(customItemDetail)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtDistrubeVoucherInMyRequest(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtDistrubeVoucherInMyRequest");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtNoOfTicketsDisplayedAfterApprovalMyRequest(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtNoOfTicketsDisplayedAfterApprovalMyRequest");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtValidateVoucherExpiryDate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateVoucherExpiryDate");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.voucherExpiryDate()
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtValidateVoucherDetailsDistributePage(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateVoucherDetailsDistributePage");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.voucherDetailDistributePage(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtValidateTotalsVoucherListDistributePage(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateVoucherDetailsDistributePage");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.voucherDetailDistributePage(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtValidateAddEmailDistributePage(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateVoucherDetailsDistributePage");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			//String email = (String) testData.get("email");
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.addEmailIdDistributeScreen(voucherDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtValidateBusinessJustificationValues(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateVoucherDetailsDistributePage");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			//String email = (String) testData.get("email");
			launch(username,password)
				.login(username,password)
				.validateRequestVoucherPage(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtShowMatchingUsersOnBehalf(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateVoucherDetailsDistributePage");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			//String email = (String) testData.get("email");
			launch(username,password)
				.login(username,password)
				.validateRequestVoucherPage(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtSearchedUserDetailsOnBehalf(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateVoucherDetailsDistributePage");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			//String email = (String) testData.get("email");
			launch(username,password)
				.login(username,password)
				.validateRequestVoucherPage(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtValidateChoosenUserDetailsOnBehalfRequestScreen(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateVoucherDetailsDistributePage");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			//String email = (String) testData.get("email");
			launch(username,password)
				.login(username,password)
				.validateRequestVoucherPage(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtValidateAllUserDetailsOnBehalfRequestScreen(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateVoucherDetailsDistributePage");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			//String email = (String) testData.get("email");
			launch(username,password)
				.login(username,password)
				.validateRequestVoucherPage(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtValidateApprovalFlow(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateApprovalFlow");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateApprovalFlow(voucherDetails, empName)
				//.distributeVoucher(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpValidateApprovalFlow(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpValidateApprovalFlow");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateApprovalFlow(voucherDetails, empName)
				//.distributeVoucher(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtValidateApprovalFlowIsDisplayed(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateApprovalFlow");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateApprovalFlow(voucherDetails, empName)
				//.distributeVoucher(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpValidateApprovalFlowIsDisplayed(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpValidateApprovalFlow");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateApprovalFlow(voucherDetails, empName)
				//.distributeVoucher(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtValidateApprovalFlowOnBehalf(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateApprovalFlow");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateApprovalFlow(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpValidateApprovalFlowOnBehalf(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpValidateApprovalFlow");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.validateApprovalFlow(voucherDetails, empName)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtSearchDelegate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtSearchDelegate");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.addDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mtValidateDelegateDetails(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateDelegateDetails");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.addDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtUnableToAddType4EmployeeAsDelegate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateDelegateDetails");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.addOtherTypeDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtUnableToAddType3EmployeeAsDelegate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateDelegateDetails");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.addOtherTypeDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtUnableToAddType2EmployeeAsDelegate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateDelegateDetails");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.addOtherTypeDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mtVerifyExistingDelegate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateDelegateDetails");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeVoucher(voucherDetails, empName)
				.addDelegates(delegateDetails)
				.verifyExistingDelegate(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpVerifyExistingDelegate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mpVerifyExistingDelegate");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeMealProgram(voucherDetails, empName)
				.addDelegates(delegateDetails)
				.verifyExistingDelegate(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpSearchDelegate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtSearchDelegate");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeMealProgram(voucherDetails, empName)
				.addDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mpValidateDelegateDetails(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateDelegateDetails");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeMealProgram(voucherDetails, empName)
				.addDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpUnableToAddType4EmployeeAsDelegate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateDelegateDetails");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeMealProgram(voucherDetails, empName)
				.addOtherTypeDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpUnableToAddType3EmployeeAsDelegate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateDelegateDetails");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeMealProgram(voucherDetails, empName)
				.addOtherTypeDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void mpUnableToAddType2EmployeeAsDelegate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mtValidateDelegateDetails");
		try {

			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.validateMyRequest(voucherDetails, empName)
				.distributeMealProgram(voucherDetails, empName)
				.addOtherTypeDelegates(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateIngredientDetailsPopulatedInCategory(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateIngredientDetailsPopulatedInCategory");
		try {

			//Updated by Chithra
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String caffeRegion= (String) testData.get("caffe_region");
			JSONArray ingredientDetails = (JSONArray)testData.get("ingredients");
			
			launch(username,password)
				.login(username,password)
				.addNewIngredients(ingredientDetails, caffeRegion)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void validateCreateMenuWithNewIngredients(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateCreateMenuWithNewIngredients");
		try {
			
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String caffeRegion= (String) testData.get("caffe_region");
			JSONArray ingredientDetails = (JSONArray)testData.get("ingredients");
			JSONArray itemList = (JSONArray)testData.get("food_items_to_create");
			
			launch(username,password)
				.login(username,password)
				.addNewIngredients(ingredientDetails, caffeRegion)
				.navigateToMenuPage()
				.createGivenFoodItems(itemList)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	@Test(dataProvider = "loadTestData")
	public void validateDeleteIngredient(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateDeleteIngredient");
		try {
			//Updated by Chithra
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String caffeRegion= (String) testData.get("caffe_region");
			JSONArray ingredientDetails = (JSONArray)testData.get("ingredients");
			
			launch(username,password)
				.login(username,password)
				.deleteIngredients(ingredientDetails, caffeRegion)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateMultipleLabels(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validatemultiplelabels");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			String label1 = (String)testData.get("label1");
			String label2 = (String)testData.get("label2");
			String Price2 = (String)testData.get("Price2");
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.createLabels(super.foodStationRuntimeId, label1, label2, Price2)
				.validateLabels(super.foodStationRuntimeId, label1, label2)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for customisation option clicked. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateComponentInCustomizationScreen(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateComponentInCustomizationScreen");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.chooseComponentAsCustomize(super.foodStationRuntimeId)
				.removeComponentCustomize(super.foodStationRuntimeId)
				//.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				//.validateCustomisationScreen()
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for customisation option clicked. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateCopyFromLabel1(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateCopyFromLabel1");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			String label1 = (String)testData.get("label1");
			String label2 = (String)testData.get("label2");
			String Price2 = (String)testData.get("Price2");
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.createLabels(super.foodStationRuntimeId, label1, label2, Price2)
				.validateLabels(super.foodStationRuntimeId, label1, label2)
				.validateCopyFromLabel1(super.foodStationRuntimeId, label1, label2)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for customisation option clicked. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateCustomizationType(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::validateCopyFromLabel1");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			String label1 = (String)testData.get("label1");
			String label2 = (String)testData.get("label2");
			String Price2 = (String)testData.get("Price2");
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.createLabels(super.foodStationRuntimeId, label1, label2, Price2)
				.validateLabels(super.foodStationRuntimeId, label1, label2)
				.validateCopyFromLabel1(super.foodStationRuntimeId, label1, label2)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for customisation option clicked. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyListTypeCategoryDetails(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyCategoryDetails");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			JSONArray customizeType = (JSONArray)testData.get("CustomizeType");
			String number_of_list_ingredient1 = (String)testData.get("numberOfListIngredient");
			int number_of_list_ingredient = Integer.parseInt(number_of_list_ingredient1);
			String priceIncrease = (String)testData.get("priceIncrease");
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail, customizeType, number_of_list_ingredient, priceIncrease)
				//.createListTypeCategory(number_of_list_ingredient)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyOptionTypeCategoryDetails(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyOptionTypeCategoryDetails");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			JSONArray customizeType = (JSONArray)testData.get("CustomizeType");
			String number_of_list_ingredient1 = (String)testData.get("numberOfListIngredient");
			int number_of_list_ingredient = Integer.parseInt(number_of_list_ingredient1);
			String priceIncrease = (String)testData.get("priceIncrease");
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail, customizeType, number_of_list_ingredient, priceIncrease)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyQuantityTypeCategoryDetails(JSONObject testData)  {
		
		log("Test:MenuMakerAppFunctionalTests::verifyOptionTypeCategoryDetails");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			JSONArray customizeType = (JSONArray)testData.get("CustomizeType");
			String number_of_list_ingredient1 = (String)testData.get("numberOfListIngredient");
			int number_of_list_ingredient = Integer.parseInt(number_of_list_ingredient1);
			String priceIncrease = (String)testData.get("priceIncrease");
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			JSONArray foodItemsList = (JSONArray)testData.get("food_items_to_create");
			JSONObject foodItem = (JSONObject) foodItemsList.get(0);
			JSONArray customItemDetails = (JSONArray) foodItem.get("customize_food_item");
			JSONObject customItemDetail = (JSONObject)customItemDetails.get(0);
			log(foodItem.toJSONString());
			launch()
				.login()
				.createItemCustomized(foodItem)
				.validateCustomiseOptionAfterSave(super.foodStationRuntimeId,foodItem)
				.createCategory(customItemDetail, customizeType, number_of_list_ingredient, priceIncrease)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for adding new item name in category. Error:" + e);
		}
	}
	
	//Added by Chithra
	@Test(dataProvider = "loadTestData")
	public void mealVoucherRequestAndApprovalForMySelf(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mealVoucherRequestAndApprovalForMySelf");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.createVoucherAndApprove(voucherDetails, empName)
				
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for meal voucher. Error:" + e);
		}
	}
	
	//Added by Chithra
	@Test(dataProvider = "loadTestData")
	public void mealProgramRequestAndApprovalForMySelf(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mealVoucherRequestAndApprovalForMySelf");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.createVoucherAndApprove(voucherDetails, empName)
				
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void mealVoucherRequestAndApprovalForMySelfWithMultipleVoucherType(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::mealVoucherRequestAndApprovalForMySelfWithMultipleVoucherType");
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			launch(username,password)
				.login(username,password)
				.createVoucherAndApprove(voucherDetails, empName)
				
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for meal voucher. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyMealVoucherDelegate(JSONObject testData) throws Exception {
		String testCaseName= (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::verifyMealVoucherDelegate"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			String status = (String) testData.get("request_status");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.createVoucherAndApprove(voucherDetails, empName)
				.validateMyRequestDelegate(voucherDetails, empName, status)
				.addDelegates(delegateDetails)
				.verifyExistingDelegate(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyMealVoucherDistribute(JSONObject testData) throws Exception {
		String testCaseName= (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::verifyMealVoucherDistribute"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			String status = (String) testData.get("request_status");
			String emailForDistribute = (String) testData.get("email_to_distribute");
			String empNameForDistribute = (String) testData.get("employee_name_to_distribute");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
						
			launch(username,password)
				.login(username,password)
				.createVoucherAndApprove(voucherDetails, empName)
				.validateMealVoucherDistribute(voucherDetails, empNameForDistribute, status, emailForDistribute)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyMealProgramDelegate(JSONObject testData) throws Exception {
		String testCaseName= (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::verifyMealVoucherDelegate"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			String status = (String) testData.get("request_status");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			JSONArray delegateDetails = (JSONArray)testData.get("delegates");
			
			launch(username,password)
				.login(username,password)
				.createVoucherAndApprove(voucherDetails, empName)
				.validateMyRequestDelegate(voucherDetails, empName, status)
				.addDelegates(delegateDetails)
				.verifyExistingDelegate(delegateDetails)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyMealProgramDistribute(JSONObject testData) throws Exception {
		String testCaseName= (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::verifyMealProgramDistribute"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String empName = (String) testData.get("employee_name");
			String status = (String) testData.get("request_status");
			JSONArray voucherDetails = (JSONArray)testData.get("voucher_to_create");
			String distributeTo = (String) testData.get("distribute_to");
						
			launch(username,password)
				.login(username,password)
				.createVoucherAndApprove(voucherDetails, empName)
				.validateMealProgramDistribute(voucherDetails, status, distributeTo)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void validateIngredientDetailsUpdated(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::validateIngredientDetailsUpdated");
		try {

			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String caffeRegion= (String) testData.get("caffe_region");
			JSONArray ingredientDetails = (JSONArray)testData.get("ingredients");
			
			launch(username,password)
				.login(username,password)
				.removeAttachment(ingredientDetails, caffeRegion)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void createNewAnnouncement(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::createNewAnnouncement");
		try {

			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String caffeRegion= (String) testData.get("caffe_region");
			JSONArray announcementDetail = (JSONArray)testData.get("announcements");
			
			launch(username,password)
				.login(username,password)
				.createAnnouncement(announcementDetail, caffeRegion, false)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	@Test(dataProvider = "loadTestData")
	public void createNewAnnouncementForFutureDate(JSONObject testData) throws Exception {

		log("Test:MenuMakerAppFunctionalTests::createNewAnnouncementForFutureDate");
		try {

			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			
			log("Data:" + testData.toJSONString());
			String username = (String) testData.get("employee_username");
			String password = (String) testData.get("employee_password");
			String caffeRegion= (String) testData.get("caffe_region");
			JSONArray announcementDetail = (JSONArray)testData.get("announcements");
			
			launch(username,password)
				.login(username,password)
				.createAnnouncement(announcementDetail, caffeRegion, true)
			.quitApp();	
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing my request screen. Error:" + e);
		}
	}
	
	//To validate CaffeDetails in CaffeInfo Tab
	@Test(dataProvider = "loadTestData")
	public void validateCaffeDetailsCaffeInfoTab(JSONObject testData) throws Exception {
		
		log("Test:MenuMakerAppFunctionalTests::validateCaffeDetailsCaffeInfoTab");
		try {
	
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.checkCaffeNameInCaffeInfoPage(caffeDetails)
				.verifyCaffeOfferingsInCaffePage(caffeDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Info tab validation. Error:" + e);
		}
	}
	
	//To validate CaffeDetails in CaffeInfo Tab
	@Test(dataProvider = "loadTestData")
	public void validateServingTypeDataCaffeInfoTab(JSONObject testData) throws Exception {
			log("Test:MenuMakerAppFunctionalTests::validateServingTypeDataCaffeInfoTab");
			try {
		
				String testDataKey = (String)testData.get("testdata_key");
				log("The test data to be taken is from:" + testDataKey);
				testData = (JSONObject)getData(testDataKey);
				
				log("Data:" + testData.toJSONString());
				JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
				launch()
					.login()
					.navigateToCaffePage(caffeDetails)
					.checkCaffeNameInCaffeInfoPage(caffeDetails)
					.verifyCaffeServingInCaffePage(caffeDetails)
				.quitApp();		
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Caffe Info tab validation. Error:" + e);
			}
		}
	
	// To update CaffeDetails in CaffeInfo Tab
	@Test(dataProvider = "loadTestData")
	public void validateCaffeOfferingUpdationCaffeInfoTab(JSONObject testData) throws Exception {
		log("Test:MenuMakerAppFunctionalTests::validateCaffeOfferingUpdationCaffeInfoTab");
		try {
	
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject)getData(testDataKey);
			
			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.checkCaffeNameInCaffeInfoPage(caffeDetails)
				.verifyCaffeOfferingsUpdationInCaffePage(caffeDetails)
			.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Info tab validation. Error:" + e);
		}
	}

	//To update CaffeDetails in CaffeInfo Tab
	@Test(dataProvider = "loadTestData")
	public void validateCaffeDetailUpdateInCaffeInfoTab(JSONObject testData) throws Exception {
			log("Test:MenuMakerAppFunctionalTests::validateCaffeDetailUpdateInCaffeInfoTab");
			try {
		
				String testDataKey = (String)testData.get("testdata_key");
				log("The test data to be taken is from:" + testDataKey);
				testData = (JSONObject)getData(testDataKey);
				
				log("Data:" + testData.toJSONString());
				JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
				launch()
					.login()
					.navigateToCaffePage(caffeDetails)
					.checkCaffeNameInCaffeInfoPage(caffeDetails)
					.checkCaffeStreetAddressUpdateInCaffeInfoPage(caffeDetails)
					.addCaffeLayoutAttachment(caffeDetails)
				.quitApp();		
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Caffe Info tab validation. Error:" + e);
			}
		}
	
	//To validate Order Type in Stations Tab Caffe Page
	@Test(dataProvider = "loadTestData")
	public void validateOrderTypeInStationsTab(JSONObject testData) throws Exception {
			log("Test:MenuMakerAppFunctionalTests::validateOrderTypeInStationsTab");
			try {
		
				String testDataKey = (String)testData.get("testdata_key");
				log("The test data to be taken is from:" + testDataKey);
				testData = (JSONObject)getData(testDataKey);
				
				log("Data:" + testData.toJSONString());
				JSONArray caffeDetails = (JSONArray)testData.get("caffe_details");
				launch()
					.login()
					.navigateToCaffePage(caffeDetails)
					.stationDataValidationAndUpdation(caffeDetails)
					.quitApp();		
			} catch(Exception e) {
				Assert.assertTrue(false, "Exception while testing for Caffe Station tab order type update validation. Error:" + e);
			}
	}
	
	//To validate Order Type in Stations Tab Caffe Page
	@Test(dataProvider = "loadTestData")
	public void validateServingTypeOverrideActionStationsTab(JSONObject testData) throws Exception {
		log("Test:MenuMakerAppFunctionalTests::validateServingTypeOverrideActionStationsTab");
		try {

			String testDataKey = (String) testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject) getData(testDataKey);

			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray) testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.verifyCaffeServingInCaffePage(caffeDetails)
				.servingTypeDataUpdation(caffeDetails)
				.quitApp();
		} catch (Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Station tab station type override update validation. Error:" + e);
		}
	}
	
	//To validate Station configuration in Caffe Page
	@Test(dataProvider = "loadTestData")
	public void validateStationsConfigurationCaffePage(JSONObject testData) throws Exception {
		log("Test:MenuMakerAppFunctionalTests::validateStationsConfigurationCaffePage");
		try {

			String testDataKey = (String) testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject) getData(testDataKey);

			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray) testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.addNewStationInStationTab(caffeDetails)
				.saveStationDetailsStationsTab()
				.quitApp();
		} catch (Exception e) {
			Assert.assertTrue(false, "Exception while testing for Caffe Station tab station type override update validation. Error:" + e);
		}
	}
	
	// To validate Station configuration in Caffe Page
	@Test(dataProvider = "loadTestData")
	public void validateStationTypeUpdationCaffePage(JSONObject testData) throws Exception {
		log("Test:MenuMakerAppFunctionalTests::validateStationTypeUpdationCaffePage");
		try {

			String testDataKey = (String) testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject) getData(testDataKey);

			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray) testData.get("caffe_details");
			launch()
			.login()
			.navigateToCaffePage(caffeDetails)
			.updateStationTypeInStationsTab(caffeDetails)
			.saveStationDetailsStationsTab()
			.quitApp();
		} catch (Exception e) {
			Assert.assertTrue(false,
					"Exception while testing for Caffe Station tab station type override update validation. Error:"
							+ e);
		}
	}

	// To validate Caffe Info configuration in Caffe Page
	@Test(dataProvider = "loadTestData")
	public void validateCaffeInfoConfigurationCaffePage(JSONObject testData) throws Exception {
		log("Test:MenuMakerAppFunctionalTests::validateCaffeInfoConfigurationCaffePage");
		try {

			String testDataKey = (String) testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject) getData(testDataKey);

			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray) testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.checkCaffeNameUpdateInCaffeInfoPage(caffeDetails)
				.validateCaffeInfoUpdation(caffeDetails)
				.verifyAddSchedule()
				.verifyDaysFieldSchedule()
				.verifyTimeFieldSchedule()
				.verifySaveScheduleCaffeinfo(caffeDetails)
				.verifyRemoveSchedule()
				.quitApp();
		} catch (Exception e) {
			Assert.assertTrue(false,
					"Exception while testing for Caffe Info update validation. Error:"
							+ e);
		}
	}
	
	//End To End Caffe Name and Address Info validation in GuestApp
	@Test(dataProvider = "loadTestData")
	public void validateCaffeAddressUpdateCaffePage(JSONObject testData) throws Exception {
		log("Test:MenuMakerAppFunctionalTests::validateCaffeAddressUpdateCaffePage");
		try {

			String testDataKey = (String) testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject) getData(testDataKey);

			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray) testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.checkCaffeNameUpdateInCaffeInfoPage(caffeDetails)
				.validateCaffeAddressUpdation(caffeDetails)
				.quitApp();
		} catch (Exception e) {
			Assert.assertTrue(false,
					"Exception while testing for Caffe Address update validation. Error:"
							+ e);
		}
	}
	
	//End to End Smoke test case for Caffe Schedule and Station Configuration
	@Test(dataProvider = "loadTestData")
	public void validateCaffeScheduleAndStationConfiguration(JSONObject testData) throws Exception {
		log("Test:MenuMakerAppFunctionalTests::validateCaffeScheduleAndStationConfiguration");
		try {

			String testDataKey = (String) testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			testData = (JSONObject) getData(testDataKey);

			log("Data:" + testData.toJSONString());
			JSONArray caffeDetails = (JSONArray) testData.get("caffe_details");
			launch()
				.login()
				.navigateToCaffePage(caffeDetails)
				.checkCaffeNameUpdateInCaffeInfoPage(caffeDetails)
				.validateCaffeInfoUpdation(caffeDetails)
				.verifyAddSchedule()
				.verifySaveScheduleCaffeinfo(caffeDetails)
				.addNewStationInStationTab(caffeDetails)
				.saveStationDetailsStationsTab()
				.quitApp();
		} catch (Exception e) {
			Assert.assertTrue(false,
					"Exception while testing for Caffe Address update validation. Error:"
							+ e);
		}
	}
	
	//Smoke Test script for User role select
	@Test(dataProvider = "loadTestData")
	public void selectUserRole(JSONObject testData)  {
		String testCaseName = (String)testData.get("testcase_name");
		log("Test:MenuMakerAppFunctionalTests::selectUserRole-"+testCaseName);
		try {
			String testDataKey = (String)testData.get("testdata_key");
			log("The test data to be taken is from:" + testDataKey);
			
			testData = (JSONObject)getData(testDataKey);
			log("Data:" + testData.toJSONString());
			String caffeRegion = (String) testData.get("caffe_region");
			String leadChef = (String) testData.get("lead_chef");
			String caffeAdmin = (String) testData.get("caffe_admin");
			String refundAdmin = (String) testData.get("refund_admin");
			launch()
				.login()
				.selectUserRole(caffeRegion,leadChef,caffeAdmin,refundAdmin)
				.quitApp();		
		} catch(Exception e) {
			Assert.assertTrue(false, "Exception while testing for Special non-customized menu. Error:" + e);
		}
	}

}