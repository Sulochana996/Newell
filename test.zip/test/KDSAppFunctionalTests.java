package com.apple.ist.caffemac.test;

import java.io.File;
import java.io.FileReader;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.Test;

import com.apple.ist.caffemac.test.util.AppUtilities;

public class KDSAppFunctionalTests extends KDSApp {
	
	@Test(dataProvider = "loadTestData")
	public void verifyRegisteringStation(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
		.quitApp();	
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void verifyCompleteOrder(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_1");
		Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCheck = (JSONArray)prevRunData.get("order_list");
		}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCheck)
			.completeGivenOrders(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifySearchForOrderRefund(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
	//	String station =  (String)testData.get("configure_caffe_station");
		String  userName=  (String)testData.get("admin_username");
		String  password=  (String)testData.get("admin_password");
		JSONArray orderDetails = (JSONArray)testData.get("orders");
		JSONObject orderDetail = (JSONObject)orderDetails.get(0);
		launch()
			.login(userName,password)
			.enableSecuritySettings()
			.selectRefundAndSearch(orderDetail)
		.quitApp();	
	}
	
	
	@Test(dataProvider = "loadTestData")
	public  void ValidateAvailabilityScenarios(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyCapValue(ordersToCheck)
			.validateCapField(ordersToCheck)
			.validateCapFieldWithSplChar(ordersToCheck)
			.validateAvailabilityButton(ordersToCheck)
			.validateStationsAvailability(menuItemsToSelect)
			.selectStationIn2Up(menuItemsToSelect)
			.validateStationsAvailability1(menuItemsToSelect)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void VerifyNoStationChoosen2Up(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		JSONArray stationIn2Up = (JSONArray)testData.get("station_to_choose_in_2_up");
		JSONArray deselectStationNames = (JSONArray)testData.get("station_to_deSelect_in_2_up");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.selectStationIn2Up(stationIn2Up)
			.deselectStationsIn2Up(deselectStationNames)
		.quitApp();	
	}

	@Test(dataProvider = "loadTestData", dependsOnMethods = {"verifyCaffeAndStationsConfiguration"})
	public void verifyCompleteOrdersinPendingOrdersPageCustomize(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		log("Data 1 " + ordersToCheck);
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYCUSTOMIZINGITEM_KIOSK_SPECIAL_CUSTOMIZED_1");
		log("Data 2 " + prevData);
		Assert.assertNotNull(prevData, "Failed to verify the pending customized orders as the previous order details are found to be null");
		JSONObject prevRunData = convertPrevRunData("CUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCheck = (JSONArray)prevRunData.get("order_list");
		}
		String station =  (String)testData.get("configure_caffe_station");
		String OrderNumber =  (String)testData.get("orderid");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCheck)
			.givenOrderCompletedInOrderHistory(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData", dependsOnMethods = {"verifyPendingCustomizedOrders"})
	public void verifyPendingStandardOrders(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");

		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_1");
		Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCheck = (JSONArray)prevRunData.get("order_list");
		}
		
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");

		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData", dependsOnMethods = {"verifyPendingStandardOrders"})
	public void verifyCompleteOrders(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_1");
		Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCheck = (JSONArray)prevRunData.get("order_list");
		}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCheck)
			.completeGivenOrders(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCompleteOrdersinPendingOrdersPageStandard(JSONObject testData) throws Exception {
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		log("Data 1 " + ordersToCheck);
		String station =  (String)testData.get("configure_caffe_station");
		String OrderNumber =  (String)testData.get("orderid");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.completePendingOrders(ordersToCheck)
			.givenOrderCompletedInOrderHistory(ordersToCheck)
		.quitApp();	
	}
	
	
	
	@Test(dataProvider = "loadTestData")
	public void verifyNotifyUser(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		log("Data 1 " + ordersToCheck);
		
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.OpenLandingPageOrders(ordersToCheck)
			.NotifyCustomer()
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyPrinterbutton(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		log("Data 1 " + ordersToCheck);
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.OpenLandingPageOrders(ordersToCheck)
			.ValidatePrinterButton()
		.quitApp();	
	}
	
	
	@Test(dataProvider = "loadTestData", dependsOnMethods = {"verifyCompleteOrders"})
	public void verifyDisplayCompletedOrders(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_1");
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCheck = (JSONArray)prevRunData.get("order_list");
		}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyGivenOrdersAreCompleted(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCancelOrderFromOrderHistoryPage(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");

		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.OpenLandingPageOrders(ordersToCheck)
			.CancelOrder()
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validateUpto2Settings(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateStationsin2up(menuItemsToSelect)
			.validate2UpOrderTotalWithDashboard(menuItemsToSelect)
			.validate2UpOrderWaitTimeObject(menuItemsToSelect)
			.validate2UpMoreThan2Sta(menuItemsToSelect)
		.quitApp();	
	}

	
	@Test(dataProvider = "loadTestData")
	public  void validateWaitTime(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateNoToggleStationNoWaitTimeDashBoard(menuItemsToSelect)
			.validateDashboardWaitTimeObjectStationName(menuItemsToSelect)
			.reduceWaitTimeUntilMinusButtonDisabled(menuItemsToSelect)
			.validateDashboardWaitTimeObjectPlus(menuItemsToSelect)
			.validateDashboardWaitTimeObjectMinus(menuItemsToSelect)
		.quitApp();	
	}
	
	private JSONObject convertPrevRunData(String category, JSONObject source) {
		if(source == null) {
			log("The source while converting the prev rundata found to be null");
			return null;
		}
		log("Prev run data found as:" + source.toJSONString());
		
		JSONObject result = new JSONObject();
		
		JSONArray foodItems = new JSONArray();
		String orderid = (String)source.get("orderid");
		if(StringUtils.isNotBlank(orderid)) {
			orderid = orderid.replaceAll("Order #", "");
			orderid = orderid.replaceAll("#", "");
		}
		source.put("order_id", orderid);
		source.put("order_by", (String)source.get("order_person_name"));
		source.put("food_item_count", 1);
		source.put("is_order_from_kiosk", false);
		source.remove("orderid");
		
		foodItems.add(source);
		
		result.put("order_list", foodItems);
				
		return result;
	}
	
	private JSONObject getTempData(String aKey) {
		
		JSONObject j = null;
		
		try {
			JSONParser p = new JSONParser();
			Properties prop = new Properties();
			FileReader reader = new FileReader(AppUtilities.getFile(strBaseDir + File.separator + "run_data.txt"));
			prop.load(reader);
			j = (JSONObject)p.parse(prop.getProperty(aKey));
		} catch(Exception e) {
			e.printStackTrace();
		}
		return j;
	}
	
	
	
}
