package com.apple.ist.caffemac.test;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.apple.ist.caffemac.test.common.MobileApplicationTestBase;
import com.apple.ist.caffemac.test.util.AppUtilities;
import com.apple.ist.caffemac.test.util.JDBCUtil;

import bsh.ParseException;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import oracle.net.aso.p;

public class GuestApp extends MobileApplicationTestBase {

	public static final String APPNAME = "guestapp";
	public JSONArray itemListFromPage = new JSONArray();
	public Double OrderTotal;
	public String temp;
	public String caffeVersion;
	

	public GuestApp() {
		super(APPNAME);
	}

	public GuestApp(JSONObject dataObject, JSONObject runParams) {
		super(APPNAME);
		appObject = dataObject;
		initWithParams(runParams);
	}

	public GuestApp launch() throws Exception {
		 launchAppleConnect_iPhone();
		 appleConnectLogin();
		// quitApp();
		Assert.assertTrue(launchApp(), "Failed in launching the App:" + APPNAME);
		return this;
	}
	public GuestApp launch(String username, String password) throws Exception {
		 launchAppleConnect_iPhone();
		 appleConnectLogin(username, password);
		// quitApp();
		Assert.assertTrue(launchApp(), "Failed in launching the App:" + APPNAME);
		return this;
	}


	public void quitApp() {
		closeApp();
	}

	public GuestApp login() {
		// AppUtilities.delay(10000);
		// Assert.assertNotNull(waitForElement("static_apple_connect_username"), "Failed
		// to find the apple connect username field");
		String userNam1 = getUILocator("textfield_appleconnect_username");
		AppUtilities.delay(5000);
		MobileElement userName = waitForElement("textfield_appleconnect_username", 10);
		if (userName != null) {
			boolean userNameValue = userName.isEnabled();
			log("The value of usernamevalue is: " + userNameValue);
			if (userNameValue == true) {
				Assert.assertTrue(clickElement("textfield_appleconnect_username"),
						"Failed to find the apple connect username field");
				Assert.assertTrue(clickElement("button_appleconnect_username_clear"), "Failed to click clear button");
				Assert.assertTrue(typeText("textfield_appleconnect_username", getAppLoginUsername()),
						"Failed to type the login username");
				Assert.assertTrue(typeText("textfield_appleconnect_password", getAppLoginPassword()),
						"Failed to type the login username");
				MobileElement passwordField = waitForElement("textfield_appleconnect_password");
				passwordField.sendKeys(Keys.RETURN);
				AppUtilities.delay(4000);

			}
		} else {

			MobileElement welcomeMsg = waitForElement("browse_menu_onboarding", 20);
			if (welcomeMsg != null) {
				if (welcomeMsg.isDisplayed() == true) {
					Assert.assertTrue(clickElement("browse_menu_onboarding"), "Failed to find the browse menu button");
					AppUtilities.delay(3000);
					//driver.switchTo().alert().accept();
				}
			}
		}
		Assert.assertNotNull(waitForElement("browse_menu", 120), "Failed to find the browser menu option");
		log(driver.getPageSource());
		return this;
	}

	public GuestApp appleConnectLogin() {
		setupAppleConnect();
		// Assert.assertTrue(clickElement("button_appleconnect_username_clear"), "Failed to click clear button");
		Assert.assertTrue(typeText("textfield_appleconnect_username", getAppLoginUsername()),
				"Failed to type the login username");
		Assert.assertTrue(typeText("textfield_appleconnect_password", getAppLoginPassword()),
				"Failed to type the login password");
		MobileElement passwordField = waitForElement("textfield_appleconnect_password");
		passwordField.sendKeys(Keys.RETURN);
		AppUtilities.delay(4000);
		return this;

	}
	public GuestApp appleConnectLogin(String username, String password){
		setupAppleConnect();
		Assert.assertTrue(typeText("textfield_appleconnect_username", username),
				"Failed to type the login username");
		Assert.assertTrue(typeText("textfield_appleconnect_password", password),
				"Failed to type the login password");
		MobileElement passwordField = waitForElement("textfield_appleconnect_password");
		passwordField.sendKeys(Keys.RETURN);
		AppUtilities.delay(4000);
		return this;	
	}
	public GuestApp setupAppleConnect(){
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("button_appleconnect_settings"), "Failed to find the settings button");
		Assert.assertTrue(clickElement("button_appleconnect_advanced_settings"),
				"Failed to find the advanced settins screen");
		Assert.assertTrue(clickElement("button_appleconnect_reset"), "Failed to click the appleconnect reset button");

		String alertResetAppleConnectLocator = getUILocator("alert_reset_appleconnect_button");
		MobileElement alertResetAppleConnect = isElementPresent(alertResetAppleConnectLocator);
		if (alertResetAppleConnect != null) {
			Assert.assertTrue(clickElement(alertResetAppleConnectLocator),
					"Failed to click reset appleconnect alert message");
		}
		Assert.assertTrue(clickElement("switchbutton_appleconnect_prompt_environment"),
				"Failed to click the prompt for environment button");
		/*
		 * MobileElement environmentSwitch =
		 * waitForElement("switchbutton_appleconnect_prompt_environment"); String
		 * environmentSwitchValue = environmentSwitch.getAttribute("value"); if
		 * (environmentSwitchValue.equals("false")) {
		 * Assert.assertTrue(clickElement("switchbutton_appleconnect_prompt_environment"
		 * ), "Failed to click the prompt for environment button"); }
		 */
		Assert.assertTrue(clickElement("button_appleconnect_accounts"), "Failed to find the accounts button");
		// Assert.assertTrue(clickElement("button_appleconnect_signin_when_signedin"), "Failed to find the isgn in button");
		Assert.assertTrue(clickElement("button_appleconnect_signin"), "Failed to find the sign in button");
		Assert.assertTrue(clickElement("button_appleconnect_useracceptance"),
				"Failed to find the user acceptance popup");
		AppUtilities.delay(5000);
		driver.getKeyboard();
		Assert.assertTrue(clickElement("textfield_appleconnect_username"),
				"Failed to find the apple connect username field");
		return this;
	}

	public GuestApp login(String username, String password) {
		AppUtilities.delay(10000);
		// Assert.assertNotNull(waitForElement("static_apple_connect_username"), "Failed to find the apple connect username field");
		MobileElement userName = waitForElement("textfield_appleconnect_username");
		boolean userNameValue = userName.isDisplayed();
		if (userNameValue == true) {
			Assert.assertTrue(clickElement("textfield_appleconnect_username"),
					"Failed to find the apple connect username field");
			Assert.assertTrue(clickElement("button_appleconnect_username_clear"), "Failed to click clear button");
			Assert.assertTrue(typeText("textfield_appleconnect_username", getAppLoginUsername()),
					"Failed to type the login username");
			Assert.assertTrue(typeText("textfield_appleconnect_password", getAppLoginPassword()),
					"Failed to type the login username");
		}
		Assert.assertNotNull(waitForElement("tabbtn_profile_homepage"), "Failed to find the Cafe stations after login");
		return this;
	}

	public GuestApp selectCaffeLocation(String caffe_location, String caffe_version, String stationType) {
		if (caffe_version.equals("4")) {
			selectCaffeLocation(caffe_location, stationType);
			log("caffeelocation and station type picked" + caffe_location + " and " + stationType);
		} else {
			selectCaffeLocation(caffe_location);

		}
		return this;
	}

	public GuestApp Debugwait(String caffe_location, String caffe_version, String stationType) {
		AppUtilities.delay(30000);
		log(driver.getPageSource());
		return this;
	}

	public GuestApp selectCaffeLocation(String aCaffeLocation, String stationType) {

		log("Selecting the Caffe as:" + aCaffeLocation);
		Assert.assertTrue(clickElement("change_caffe_location"), "Failed to click change Caffe location button in home page");

		Assert.assertNotNull(waitForElement("search_caffeLocation"), "Failed to find the search field");
		Assert.assertNotNull(clickElement("search_caffeLocation"), "Failed to enter value in the search field");
		AppUtilities.delay(4000);
		Assert.assertNotNull(waitForElements("menu_item_table"));
		Assert.assertNotNull(typeText("search_caffeLocation",aCaffeLocation), "Failed to enter value in the search field");
		//Assert.assertNotNull(clickElement("search_caffeLocation"), "Failed to enter value in the search field");
		driver.hideKeyboard();
		int result = waitForElements("menu_item_table").size();
		log("Number of elements"+result);
		for (int i=1; i<= result;i++){
			String caffeName = getUILocator("caffe_in_search_result");
			caffeName = caffeName.replaceAll("<REPLACE_CAFFE>", aCaffeLocation);
			caffeName = caffeName.replaceAll("<REPLACE_INDEX>", i+"");
			log(caffeName);
			if (waitForElement(caffeName,4)!= null){
				Assert.assertTrue(clickElement(caffeName), "Failed to select the Cafe Location:" + aCaffeLocation);
				break;
			}
		}
		log("Caffe Location selected successfully");

		return this;
	}
	
	public GuestApp validateCaffeOfferings(String aCaffeLocation, String stationType, JSONArray offeringDetails) {

		log("Selecting the Caffe as:" + aCaffeLocation);
		Assert.assertTrue(clickElement("change_caffe_location"), "Failed to click change Caffe location button in home page");

		Assert.assertNotNull(waitForElement("search_caffeLocation"), "Failed to find the search field");
		Assert.assertNotNull(clickElement("search_caffeLocation"), "Failed to enter value in the search field");
		AppUtilities.delay(4000);
		Assert.assertNotNull(waitForElements("menu_item_table"));
		Assert.assertNotNull(typeText("search_caffeLocation",aCaffeLocation), "Failed to enter value in the search field");
		//Assert.assertNotNull(clickElement("search_caffeLocation"), "Failed to enter value in the search field");
		driver.hideKeyboard();
		int result = waitForElements("menu_item_table").size();
		log("Number of elements"+result);
		for (int i=1; i<= result;i++){
			String caffeName = getUILocator("caffe_in_search_result");
			caffeName = caffeName.replaceAll("<REPLACE_CAFFE>", aCaffeLocation);
			caffeName = caffeName.replaceAll("<REPLACE_INDEX>", i+"");
			log(caffeName);
			if (waitForElement(caffeName,4)!= null){
				for(int j=0;j<offeringDetails.size();j++) {					
					log("Validation for Caffe Offering:"+ offeringDetails.get(j));
					String caffeOfferingLoc = getUILocator("caffe_offering_in_search_result").replaceAll("<REPLACE_INDEX>", i+"");
					caffeOfferingLoc = getUILocator("caffe_offering_in_search_result").replaceAll("<REPLACE_TEXT>",offeringDetails.get(j).toString());
					Assert.assertNotNull(waitForElement(caffeOfferingLoc), "Failed to find the Caffe Offering Checkbox in Caffe Info screen");	
				}
				
				Assert.assertTrue(clickElement(caffeName), "Failed to select the Cafe Location:" + aCaffeLocation);
				break;
			}
		}
		log("Caffe Location selected successfully");

		return this;
	}
	
	public GuestApp validateCaffeStations(JSONArray stationDetails, String defaultStation) {

		upScrollTo();
		Offshoredelay();

		AppUtilities.delay(3000);
		AppUtilities.delay(3000);

		if(stationDetails.size()>0) {
			for(int j=0;j<stationDetails.size();j++) {	
				String strStationType = getUILocator("station_type_other");
				strStationType = strStationType.replaceAll("<REPLACE_STATION_TYPE>", stationDetails.get(j).toString());
				log("station_type_other  " + strStationType);
				Assert.assertNotNull(waitForElement(strStationType), "Fail to wait the element");
			}
		} else {
			log("Default Caffe Station setup validation");
			String strStationType = getUILocator("station_type_other");
			strStationType = strStationType.replaceAll("<REPLACE_STATION_TYPE>", defaultStation);
			log("station_type_other  " + strStationType);
			Assert.assertNotNull(waitForElement(strStationType), "Fail to wait the element");
		}
		log("Caffe Stations validated successfully");
		
		return this;
	}
	

	public GuestApp selectCaffeLocation(String aCaffeLocation) {
		// getUILocator("change_caffe_location").replaceAll(regex, replacement)
		if (waitForElement("selected_cafe_location_homepage_default") != null) {
			log("Selecting the station as:" + aCaffeLocation);
			AppUtilities.delay(10000);
			Assert.assertTrue(clickElement("selected_cafe_location_homepage_default"),
					"Failed to click the Caffe location button in home page");

			Assert.assertNotNull(waitForElement("static_heading_cafe_station_selection_page"),
					"Failed to find the heading of the Select Caffe page");
			Assert.assertNotNull(waitForElement("btn_done_cafe_station_selection_page"),
					"Failed to find the done button of the Select Caffe page");
			Offshoredelay();
			String cafeLocator = getUILocator("cell_cafe_location_select_cafe_station_selection_page")
					.replaceAll("<REPLACE_CAFE_LOCATION>", aCaffeLocation);
			Assert.assertNotNull(waitForElement(cafeLocator), "Failed to find the Cafe Location of:" + aCaffeLocation);
			Assert.assertTrue(clickElement(cafeLocator), "Failed to select the Cafe Location:" + aCaffeLocation);

			Assert.assertTrue(clickElement("btn_done_cafe_station_selection_page"),
					"Failed to click the done button of the Select Caffe page");

			String cafeSelectedLocator = getUILocator("selected_cafe_location_homepage")
					.replaceAll("<REPLACE_CAFE_LOCATION>", aCaffeLocation);
			Assert.assertNotNull(waitForElement(cafeSelectedLocator),
					"Failed to find the Selected Cafe Location of:" + aCaffeLocation + " after selecting it");
			Assert.assertNotNull(waitForElement("tabbtn_profile_homepage"),
					"Failed to find the Cafe stations after login");

			log("Successfully selected the Caffe location:" + aCaffeLocation);
		} else if (waitForElement("change_caffe_location").isDisplayed()) {
			log("Selecting the station as:" + aCaffeLocation);
		}
		return this;
	}

	// Select the cafee location from homepage
	public GuestApp selectCaffeLocationHomePage(String aCaffeLocation, String caffe_version) {
		log("Selecting the Caffe as:" + aCaffeLocation);
		Assert.assertTrue(clickElement("change_caffe_location"),
				"Failed to click change Caffe location button in home page");

		Assert.assertNotNull(waitForElement("search_caffeLocation"), "Failed to find the search field");

		Assert.assertNotNull(clickElement("search_caffeLocation"), "Failed to enter value in the search field");
		AppUtilities.delay(4000);
		Assert.assertNotNull(waitForElements("menu_item_table"));
		Assert.assertNotNull(typeText("search_caffeLocation", aCaffeLocation),
				"Failed to enter value in the search field");
		// Assert.assertNotNull(clickElement("search_caffeLocation"), "Failed to enter
		// value in the search field");
		driver.hideKeyboard();
		int result = waitForElements("menu_item_table").size();
		log("Number of elements" + result);
		for (int i = 1; i <= result; i++) {
			String caffeName = getUILocator("caffe_in_search_result");
			caffeName = caffeName.replaceAll("<REPLACE_CAFFE>", aCaffeLocation);
			caffeName = caffeName.replaceAll("<REPLACE_INDEX>", i + "");
			log(caffeName);
			if (waitForElement(caffeName, 4) != null) {
				Assert.assertTrue(clickElement(caffeName), "Failed to select the Cafe Location:" + aCaffeLocation);
				break;
			}
		}
		log("Caffe Location selected successfully");
		return this;
	}

	public GuestApp verifyCaffeClosed() {

		Assert.assertNotNull(waitForElement("caffe_closed"), "Failed to find the Cafe stations status");

		log("Caffe is not open at the moment");
		return this;
	}

	public GuestApp orderGivenItems(JSONArray items, String aCaffeLocation, String station_type) {
		log("-----------------------OrderGivenItems1----------------------------");
		log("Items to be ordered is:" + items.toJSONString());
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		int orderIndex = 0;
		for (Object item : items) {
			JSONObject itemDetails = (JSONObject) item;
			orderIndex++;
			Assert.assertNotNull(orderGivenItem(orderIndex, itemDetails, aCaffeLocation, station_type),
					"Failed while ordering the item:" + itemDetails.toJSONString());
		}
		return this;
	}

	public GuestApp orderGivenItems(JSONArray items, String aCaffeLocation) {
		log("-----------------------OrderGivenItems 2----------------------------");
		log("Items to be ordered is:" + items.toJSONString());
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		int orderIndex = 0;
		for (Object item : items) {
			JSONObject itemDetails = (JSONObject) item;
			orderIndex++;
			Assert.assertNotNull(orderGivenItem(orderIndex, itemDetails, aCaffeLocation),
					"Failed while ordering the item:" + itemDetails.toJSONString());
		}
		return this;
	}

	public GuestApp orderGivenItem(int orderIndex, JSONObject item, String aCaffeLocation, String station_type) {
		log("-----------------------OrderGivenItems 3----------------------------");
		String strStationToSelect = (String) item.get("select_station");
		Boolean isCustomizedItem = (Boolean) item.get("is_custom_item");
		log("value of custom item   line 297 " + isCustomizedItem);
		log("value of custom item " + isCustomizedItem);

		String strItemToOrder = (String) item.get("food_item_name");
		String strItemPrice = (String) item.get("food_item_price");
		String strFoodItemType = (String) item.get("food_type");
		String strToppingType = (String) item.get("customize_food_item_category_type_state");

		String strStationType = getUILocator("station_type_other");
		strStationType = strStationType.replaceAll("<REPLACE_STATION_TYPE>", station_type);

		log("food_item_name " + strItemToOrder);
		log("food_item_price " + strItemPrice);
		log("food_type " + strFoodItemType);
		log("station_type_other  " + strStationType);
		// String strToppingType= (String)item.get("customize_food_item_category_type");
		//log("Customize topping type  " + strToppingType);

		Assert.assertNotNull(waitForElement(strStationType), "Fail to wait the element");
		upScrollTo();
		Offshoredelay();
		

		AppUtilities.delay(3000);
		AppUtilities.delay(3000);

		// Write Script to select different station type
		driver.findElementByAccessibilityId(station_type).click();
		AppUtilities.delay(3000);
		Offshoredelay();
		
		String station_type_display = "//XCUIElementTypeNavigationBar[contains(@name,'" + station_type + "')]";
		driver.findElementByXPath(station_type_display);
		driver.findElementByAccessibilityId(strStationToSelect).click();
		AppUtilities.delay(3000);
		log("Successfully clicked on strStationToSelect:  " + strStationType);
		// System.out.println(" Sulo - Checkd custom 2*****************SRATION
		// Clicked*****");
		AppUtilities.delay(3000);
		if (isCustomizedItem) {
			log("Current food item is a customized one..");
			JSONArray customItems = (JSONArray) item.get("customize_food_item");
			System.out.println("cutomized_food_item " + customItems);
			System.out.println(
					"******************* Sulo   - Checkd custom  Customized order item added to order********************************");
			return customizeItemAndAddToOrder(orderIndex, strFoodItemType, aCaffeLocation, strStationToSelect,
					strItemToOrder, strItemPrice, strToppingType, customItems);
		}
		// log("99999999999999999999999 control passed:");
		return addItemToOrder(orderIndex, strFoodItemType, aCaffeLocation, strStationToSelect, strItemToOrder,
				strItemPrice);
	}

	public GuestApp orderGivenItem(int orderIndex, JSONObject item, String aCaffeLocation) {
		log("-----------------------OrderGivenItems 4----------------------------");
		String strStationToSelect = (String) item.get("select_station");
		Boolean isCustomizedItem = (Boolean) item.get("is_custom_item");
		log("value of custom item Line no 335 " + isCustomizedItem);

		String strItemToOrder = (String) item.get("food_item_name");
		String strItemPrice = (String) item.get("food_item_price");
		String strFoodItemType = (String) item.get("food_type");
		String strToppingType = (String) item.get("customize_food_item_category_type");
		log("Customize topoping type  " + strToppingType);

		Assert.assertNotNull(waitForElement("station_type_full_menu"), "Failed to wait for Add to Order button ");
		upScrollTo();
		// upScrollTo(waitForElement("station_type_full_menu"));

		try {
			Thread.sleep(4000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

		if (isCustomizedItem) {

			log("Current food item is a customized one..");
			JSONArray customItems = (JSONArray) item.get("customize_food_item");
			return customizeItemAndAddToOrder(orderIndex, strFoodItemType, aCaffeLocation, strStationToSelect,
					strItemToOrder, strItemPrice, strToppingType, customItems);
		}
		return addItemToOrder(orderIndex, strFoodItemType, aCaffeLocation, strStationToSelect, strItemToOrder,
				strItemPrice);
	}

	public GuestApp addItemToOrder(int orderIndex, String aFoodItemType, String aCaffeLocation, String station,
			String itemToOrder, String itemPrice) {

		log("The food type given is:" + aFoodItemType + ", Caffe location:" + aCaffeLocation);

		AppUtilities.delay(10000);
		log(driver.getPageSource());
		log("Food to be ordered is from Standard menu");
		AppUtilities.delay(2000);
		log("number of elements in menu page" + waitForElements("menu_item_table1").size());
		List<WebElement> allTexts = driver.findElementsByXPath("//XCUIElementTypeStaticText");
		int a = allTexts.size();

		for (int i = 0; i < a; i++) {

			System.out.println(allTexts.get(i).getText());
		}

		String strItemName = getUILocator("menupage_item_name_by_name").replaceAll("<REPLACE_TEXT>", itemToOrder);
		String strItemPrice = getUILocator("menupage_item_price").replaceAll("<REPLACE_PRICE>", itemPrice);
		Assert.assertNotNull(waitForElement(strItemName), "Fail to wait the element");
		upScrollTo();
		upScrollTo();
		waitForElement(strItemName + strItemPrice);
		String selectMenu = getUILocator("menu_item_selection_to_order").replaceAll("<REPLACE_TEXT>", itemToOrder);
		Assert.assertTrue(clickElement(selectMenu), "failed to click the menu item name");
		//Commented below code to change the locator - Chithra
		//Assert.assertTrue(clickElement(strItemName), "failed to click the menu item name");
		Assert.assertTrue(clickElement("add_to_order_btn"), "Failed to click Add to order button");
		Assert.assertTrue(clickElement("pay"), "Failed to click pay button");
		
		//Commented below piece of code, will be handled in clickPayrollDeduction method separately - CHITHRA
		/*Assert.assertTrue(clickElement("order_total"), "Failed to click pay button");
		AppUtilities.delay(2000);
		
		Assert.assertTrue(clickElement("payroll_deduction_btn"), "Failed to click pay button");*/

		AppUtilities.delay(2000);

		Offshoredelay();

		return this;

	}
	
	public GuestApp clickPayrollDeduction() {
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("order_total"), "Failed to click pay button");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("payroll_deduction_btn"), "Failed to click pay button");

		AppUtilities.delay(2000);

		return this;
	}
	

	public GuestApp validateMenuDetails(JSONArray items, String aCaffeLocation) {
		log("Items to be ordered is:" + items.toJSONString());
		JSONObject itemDetails = null;
		for (Object item : items) {
			itemDetails = (JSONObject) item;
		}
		String strStationToSelect = (String) itemDetails.get("select_station");
		String strItemToOrder = (String) itemDetails.get("food_item_name");
		String strItemPrice = (String) itemDetails.get("food_item_price");
		String strFoodItemType = (String) itemDetails.get("food_type");
		String strFoodItemDesc = (String) itemDetails.get("food_item_desc");
		JSONArray components = (JSONArray) itemDetails.get("components");
		JSONObject componentDetails = null;
		for (Object componentDetail : components) {
			componentDetails = (JSONObject) componentDetail;
		}
		String strComponentName = (String) componentDetails.get("component_name");
		JSONArray strCompIngredients = (JSONArray) componentDetails.get("ingredients");

		JSONObject nutrition = (JSONObject) itemDetails.get("food_item_nutrition");
		String strCalorie = (String) nutrition.get("calorie");
		String strFat = (String) nutrition.get("fat");
		String strCarbs = (String) nutrition.get("carbs");
		String strSugar = (String) nutrition.get("sugar");
		String strProtein = (String) nutrition.get("protein");
		String strFiber = (String) nutrition.get("fiber");

		log(strStationToSelect);
		log(strItemToOrder);
		log(strItemPrice);
		log(strFoodItemType);
		log(strFoodItemDesc);
		log(strComponentName);
		log(strCalorie);
		log(strFat);
		log(strCarbs);
		log(strSugar);
		log(strProtein);
		log(strFiber);

		String strItem = getUILocator("cell_select_station_homepage");
		Offshoredelay();
		String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect);
		Assert.assertTrue(clickElement(selectStationItem), "Failed to select the station:" + strStationToSelect);

		// wait for the food items list
		strItem = getUILocator("static_selected_station_food_list_page");
		String strItemStation = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect);
		Assert.assertNotNull(waitForElement(strItemStation), "Failed to find the station name on the food list");

		Offshoredelay();
		String strItemNameLocator = getUILocator("cell_food_item_to_select_food_list_page")
				.replaceAll("<REPLACE_ITEM_TO_SELECT>", strItemToOrder);
		Assert.assertNotNull(waitForElement(strItemNameLocator), "Failed to find the item name");
		String strItemPriceLocator = getUILocator("cell_food_item_price_to_select_food_list_page")
				.replaceAll("<REPLACE_ITEM_TO_SELECT>", strItemToOrder);
		String strItemPriceButton = strItemPriceLocator.replaceAll("<REPLACE_ITEM_PRICE>", strItemPrice);
		Assert.assertNotNull(waitForElement(strItemPriceButton), "Failed to find the item's price");
		Assert.assertTrue(clickElement(strItemNameLocator), "Failed to click the item name");
		String strComponentLocator = getUILocator("cell_food_item_component_name_details_page")
				.replaceAll("<REPLACE_COMPONENT_NAME>", strComponentName);
		String strComponentNameLocator = strComponentLocator.replaceAll("<REPLACE_COMPONENT_NAME>", strComponentName);
		Assert.assertNotNull(waitForElement(strComponentNameLocator), "Failed to find the component Name");
		String ingredient = null;
		for (Object ing : strCompIngredients) {
			ingredient = (String) ing;
			log("The ingredient is:" + ingredient);
			String strComponentIngredientsLocator = getUILocator("cell_food_item_component_ingredients_details_page")
					.replaceAll("<REPLACE_COMPONENT_INGREDIENTS>", ingredient);
			Assert.assertNotNull(waitForElement(strComponentIngredientsLocator),
					"Failed to find the components ingredeints");
		}
		Assert.assertTrue(clickElement("back_button_food_item_details_page"), "failed to click back button");
		Assert.assertTrue(clickElement("back_button_food_item_details_page"), "failed to click back button");
		/*
		 * String stritemDescLocator =
		 * getUILocator("cell_food_item_description_details_page").replaceAll(
		 * "<REPLACE_ITEM_DESC>", strFoodItemDesc);
		 * Assert.assertNotNull(waitForElement(stritemDescLocator),
		 * "Failed to find the item description");
		 */
		return this;

	}


	public GuestApp addfavouriteItem(String station_type,String selectStation) {
		String strStationType = getUILocator("station_type_other").replaceAll("<REPLACE_STATION_TYPE>", station_type);
		log("station_type_other  " + strStationType);
		Assert.assertNotNull(waitForElement(strStationType), "Fail to wait the element");
		upScrollTo();
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement(strStationType),"Fail to find the station type select element ");
		Offshoredelay();
		log("Successfully loaded station_Type is "+station_type);
		Offshoredelay();
	
		String strStationToSelect = getUILocator("lbl_selcted_station_type").replaceAll("<REPLACE_STATION_TYPE>", selectStation);
		Assert.assertNotNull(waitForElement(strStationToSelect),"Failed to find the station type select element ");
		Assert.assertTrue(clickElement(strStationToSelect),"Failed to find the station type select element ");
		 log("Successfully loaded station_type_display is "+strStationToSelect);
		 Offshoredelay();
		log("*********Successfully loaded station for favourite*****************");
		return this;
	}

	public GuestApp validateMenuDisplayOrder(String caffe, JSONObject foodItem,
			HashMap<Integer, String> menumakerDispOrder) {

		log(menumakerDispOrder.toString());

		String strStationToSelect = (String) foodItem.get("select_station");
		String strItem = getUILocator("cell_select_station_homepage");
		String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect);
		Assert.assertTrue(clickElement(selectStationItem), "Failed to select the station:" + strStationToSelect);

		AppUtilities.delay(5000);
		List<WebElement> items = waitForElements("number_of_items_station");
		log(Integer.toString(items.size()));

		/*
		 * for (WebElement item: items){ log("I am here");
		 * log(item.getAttribute("path")); log(item.getAttribute("name")); }
		 */
		HashMap<String, Integer> foodItemList = new HashMap<String, Integer>();
		for (int i = 1; i <= items.size(); i++) {

			String strItem1 = getUILocator("item_name_station");
			strItem1 = strItem1.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			MobileElement r = waitForElement(strItem1);
			// log(r.getAttribute("path"));
			log(r.getAttribute("name"));
			foodItemList.put(r.getAttribute("name"), i);

		}

		log(foodItemList.toString());
		int menumakerItemsSize = menumakerDispOrder.size(); // 3
		log("The menu maker item size is: " + menumakerItemsSize);
		int guestAppItemsSize = foodItemList.size(); // 4
		log("The guestapp item size is: " + guestAppItemsSize);
		int difference = guestAppItemsSize - menumakerItemsSize; // 1
		log("The difference is: " + difference);

		/*
		 * Assert.assertTrue(clickElement("btn_caffe_homepage")); String caffeLocator =
		 * getUILocator("btn_caffe_another_in_caffe_page").replaceAll(
		 * "<REPLACE_CAFFE_TO_SELECT>", caffe);
		 * Assert.assertTrue(clickElement(caffeLocator), "failed to click the caffe");
		 * Assert.assertTrue(clickElement("static_caffe_detail_mealtype_in_caffe_page"),
		 * "Failed to click the meal time");
		 * 
		 * for (int i=1; i<=foodItemList.size(); i++) { String caffeItem1 =
		 * foodItemList.get(""); String itemNameLocator =
		 * getUILocator("static_food_item_name_in_food_item_detail_page").replaceAll(
		 * "<REPLACE_ITEM_TO_SELECT>", caffeItem1); String itemName =
		 * itemNameLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem1);
		 * MobileElement itemName1 = waitForElement(itemName); String strMenuItemName =
		 * itemName1.getText();
		 * log("The first Item in food table is: "+strMenuItemName); }
		 */

		log("The size of the list is: " + menumakerDispOrder.size());
		int c = 0, d = 0;
		for (int i = difference + 1; i <= guestAppItemsSize; i++) {
			String foodItemName = menumakerDispOrder.get(i - 2);
			log("The fooditemname is: " + foodItemName);
			c = foodItemList.get(foodItemName);
			log("The value of c is: " + c);
			if (c > d) {
				log("Displayed in right order");
			}
			d = c;
		}

		/*
		 * String strItem1 = getUILocator("item_name_station"); strItem1 =
		 * strItem1.replaceAll("<REPLACE_INDEX>", "@path='/0/0/1/2'"); MobileElement r =
		 * waitForElement( strItem1); log( r.getText());
		 */
		return this;
	}

	public GuestApp validateStationDisplayOrder(JSONObject foodItem,
			HashMap<String, Integer> menumakerStationDispOrder) {

		log(menumakerStationDispOrder.toString());
		AppUtilities.delay(5000);
		List<WebElement> items = waitForElements("number_of_items_station");
		log(Integer.toString(items.size()));
		int value1, value2 = 0;
		for (int i = 1; i <= items.size(); i++) {

			String strItem1 = getUILocator("item_name_station");
			strItem1 = strItem1.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			MobileElement r = waitForElement(strItem1);
			log(r.getAttribute("name"));

			value1 = (int) menumakerStationDispOrder.get(r.getAttribute("name"));

			if (value1 > value2) {
				value2 = value1;
				log("Displayed in correct order");
			} else {
				log("Displayed in incorrect order");
				Assert.assertTrue(false, "Incorrect order displayed");
			}
		}
		return this;
	}

	public void Offshoredelay() {
		AppUtilities.delay(5000);

	}

	public GuestApp customizeItemAndAddToOrder(int orderIndex, String aFoodItemType, String aCaffeLocation,
			String station, String itemToCustomize, String itemPrice, String strToppingType, JSONArray customItems) {
		// log(driver.getPageSource());
		log("The food type given is: " + aFoodItemType + ", Caffe location: " + aCaffeLocation);
		String strItem = "";
		// String JsonPara=menu_item_selected;
	if(StringUtils.equalsIgnoreCase(aFoodItemType, "special")) {
		  log("Food to be ordered is from Special menu");

		if (StringUtils.equalsIgnoreCase(strToppingType, "list")) {
			log("Food to be ordered is from list menu");

			System.out.println("orderIndex " + orderIndex);
			System.out.println("aFoodItemType " + aFoodItemType);
			System.out.println("aCaffeLocation " + aCaffeLocation);
			System.out.println("station " + station);
			System.out.println("itemToCustomize " + itemToCustomize);
			System.out.println("itemPrice " + itemPrice);
			System.out.println("itemPrice " + strToppingType);

			AppUtilities.delay(2000);
			log("number of elements in menu page" + waitForElements("menu_item_table1").size());
			List<WebElement> allTexts = driver.findElementsByXPath("//XCUIElementTypeStaticText");
			int a = allTexts.size();

			for (int i = 0; i < a; i++) {

				System.out.println(allTexts.get(i).getText());
			}
			Offshoredelay();
		//	strItem = getUILocator("menu_item_selected").replaceAll("<REPLACE_FOOD_ITEM_SELECTED>", itemToCustomize);
		//	Assert.assertNotNull(waitForElement(strItem), "Failed to wait for selected menu button ");
			log(driver.getPageSource());
			driver.findElementByXPath("//XCUIElementTypeCell/XCUIElementTypeOther[1]").click();
			//Assert.assertTrue(clickElement(strItem), " Failed to click the selected menu item");
			//Assert.assertNotNull(waitForElement(strItem), "Failed to wait for selected menu item");
			log("Successfully clicked on meunu items as per request:  " + strItem);
			Offshoredelay();
			
		/*	Offshoredelay();
			// REPLACE_FOOD_ITEM_SELECTED
			strItem = getUILocator("menu_item_selected").replaceAll("<REPLACE_FOOD_ITEM_SELECTED>", itemToCustomize);
		
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for selected menu button ");
			Assert.assertTrue(tapElement(strItem), " Failed to click the selected menu item");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for selected menu item");
			log("Successfully clicked on meunu items as per request:  " + strItem);
			Offshoredelay();*/

			strItem = getUILocator("btn_customize");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Customize button ");
			Assert.assertTrue(clickElement(strItem), " failed to click the Customize button");
			Offshoredelay();

			strItem = getUILocator("btn_more_info");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for arrow mark ");
			Assert.assertTrue(clickElement(strItem), " failed to click the More information  button  action");
			Offshoredelay();

			strItem = getUILocator("verify_blue_check_mark");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for blue check mark ");
			// Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Customize
			// button ");
			log("Successfully verified the blue check mark ticked  on selected as per the given test data");
			Offshoredelay();

			strItem = getUILocator("btn_customize_back");
			Assert.assertTrue(clickElement(strItem), " failed to click on Back button");
			log("Successfully clicked on Back button as per the given test data");
			Offshoredelay();

			strItem = getUILocator("btn_customize_add_to_order");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Add to Order button ");
			Assert.assertTrue(clickElement(strItem), " failed to click on Add to Order button");
			log("Successfully clicked on Add to Order button for customized order");
/*
			strItem = getUILocator("lbl_additional_info");
			if(strItem.contains("Additional Information")) {
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Add to Order button ");
			upScrollTo();
			}*/

			strItem = getUILocator("customize_pay");
			Assert.assertTrue(clickElement(strItem), " failed to click on Pay button");
			log("Successfully clicked on Pay button for for customized List order ");
		} else if (StringUtils.equalsIgnoreCase(strToppingType, "option")) {
			log("Food to be ordered is from option menu ");

			System.out.println("orderIndex " + orderIndex);
			System.out.println("aFoodItemType " + aFoodItemType);
			System.out.println("aCaffeLocation " + aCaffeLocation);
			System.out.println("station " + station);
			System.out.println("itemToCustomize " + itemToCustomize);
			System.out.println("itemPrice " + itemPrice);

			AppUtilities.delay(2000);
			log("number of elements in menu page" + waitForElements("menu_item_table1").size());
			List<WebElement> allTexts = driver.findElementsByXPath("//XCUIElementTypeStaticText");
			int a = allTexts.size();

			for (int i = 0; i < a; i++) {

				System.out.println(allTexts.get(i).getText());
			}
			Offshoredelay();
			// REPLACE_FOOD_ITEM_SELECTED
//			strItem = getUILocator("menu_item_selected").replaceAll("<REPLACE_FOOD_ITEM_SELECTED>", itemToCustomize);
			//	Assert.assertNotNull(waitForElement(strItem), "Failed to wait for selected menu button ");
				log(driver.getPageSource());
				driver.findElementByXPath("//XCUIElementTypeCell/XCUIElementTypeOther[1]").click();
				//Assert.assertTrue(clickElement(strItem), " Failed to click the selected menu item");
				//Assert.assertNotNull(waitForElement(strItem), "Failed to wait for selected menu item");
				log("Successfully clicked on meunu items as per request:  " + strItem);
				Offshoredelay();

			strItem = getUILocator("btn_customize");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Customize button ");
			Assert.assertTrue(clickElement(strItem), " failed to click the Customize button");
			Offshoredelay();
			
			//XCUIElementTypeStaticText[@name="Baby spinach List"]
			strItem = getUILocator("click_item_opiton_tick");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Customize button ");
			Assert.assertTrue(clickElement(strItem), " failed to click the Customize button");
			Offshoredelay();

			strItem = getUILocator("verify_blue_check_mark");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for blue check mark ");
			// Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Customize
			// button ");
			log("Successfully verified the blue check mark ticked  on selected as per the given test data");
			Offshoredelay();

			strItem = getUILocator("btn_customize_add_to_order");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Add to Order button ");
			Assert.assertTrue(clickElement(strItem), " failed to click on Add to Order button");
			log("Successfully clicked on Add to Order button for customized order");

			/*strItem = getUILocator("lbl_additional_info");
			if(strItem.contains("Additional Information")) {
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Add to Order button ");
			upScrollTo();
			}*/

			strItem = getUILocator("customize_pay");
			Assert.assertTrue(clickElement(strItem), " failed to click on Pay button");
			log("Successfully clicked on Pay button for for customized Option order d");
		} else if (StringUtils.equalsIgnoreCase(strToppingType, "Quantity")) {
			log("Food to be ordered is from option menu ");

			System.out.println("orderIndex " + orderIndex);
			System.out.println("aFoodItemType " + aFoodItemType);
			System.out.println("aCaffeLocation " + aCaffeLocation);
			System.out.println("station " + station);
			System.out.println("itemToCustomize " + itemToCustomize);
			System.out.println("itemPrice " + itemPrice);

			AppUtilities.delay(2000);
			log("number of elements in menu page" + waitForElements("menu_item_table1").size());
			List<WebElement> allTexts = driver.findElementsByXPath("//XCUIElementTypeStaticText");
			int a = allTexts.size();

			for (int i = 0; i < a; i++) {

				System.out.println(allTexts.get(i).getText());
			}
			Offshoredelay();
			// REPLACE_FOOD_ITEM_SELECTED
//			strItem = getUILocator("menu_item_selected").replaceAll("<REPLACE_FOOD_ITEM_SELECTED>", itemToCustomize);
			//	Assert.assertNotNull(waitForElement(strItem), "Failed to wait for selected menu button ");
				log(driver.getPageSource());
				driver.findElementByXPath("//XCUIElementTypeCell/XCUIElementTypeOther[1]").click();
				//Assert.assertTrue(clickElement(strItem), " Failed to click the selected menu item");
				//Assert.assertNotNull(waitForElement(strItem), "Failed to wait for selected menu item");
				log("Successfully clicked on meunu items as per request:  " + strItem);
				Offshoredelay();

			strItem = getUILocator("btn_customize");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Customize button ");
			Assert.assertTrue(clickElement(strItem), " failed to click the Customize button");
			Offshoredelay();

			strItem = getUILocator("btn_customize_add_to_order");
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Add to Order button ");
			Assert.assertTrue(clickElement(strItem), " failed to click on Add to Order button");
			log("Successfully clicked on Add to Order button for customized order");

			/*strItem = getUILocator("lbl_additional_info");
			if(strItem.contains("Additional Information")) {
			Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Add to Order button ");
			upScrollTo();
			}*/

			strItem = getUILocator("customize_pay");
			Assert.assertTrue(clickElement(strItem), " failed to click on Pay button");
			log("Successfully clicked on Pay button for customized Quantity order ");
			}
	}

		return this;
	}

	/*
	 * public GuestApp clickOnTotalOrder(String Uilocator) { String strItemclick =
	 * getUILocator("btn_order_total");
	 * Assert.assertTrue(clickElement(strItemclick),
	 * "failed to click on Total order button");
	 * log("Successfully clicked on Total order button "); return this; }
	 */

	public GuestApp customizeOrderedItemAndUpdate(String updateItem) {

		String strItem = "";
		log("Food item to update is :  " + updateItem);

		strItem = getUILocator("lbl_update_item_cust").replaceAll("<REPLACE_ITEM_SELECTED>", updateItem);
		AppUtilities.delay(9000);
		//driver.findElementByXPath("//XCUIElementTypeCell[1]").click();
		log("The selected food item is updating some changes : " + strItem);
		Assert.assertNotNull(waitForElements("lbl_update_item_cust"),"Failed to to select the menu item from the cart ");
		Assert.assertTrue(clickElement(strItem), "Failed to select the menu item from the cart");
		AppUtilities.delay(9000);
		/*
		 * System.out.println("Food item to update is :  "+ updateItem); //
		 * System.out.println("Catogary is:  "+ updateFoodItem); //
		 * System.out.println("Type of item is : "+ updateFoodItemType); //
		 * System.out.println("Item to update is :  "+ customUpdateItems);
		 * 
		 * 
		 * 
		 * strItem=getUILocator("lbl_update_item_cust").replaceAll(
		 * "<REPLACE_ITEM_SELECTED>",updateItem);; AppUtilities.delay(9000);
		 * log("The selected food item is updating some changes : " + strItem);
		 * Assert.assertTrue(clickElement(strItem),"Failed to click on the menu item");
		 * Assert.assertNotNull(waitForElements("lbl_update_item_cust"),
		 * "Failed to display the menu items selected in customized list ");
		 */

		/*
		 * TouchAction ta = new TouchAction(driver); int x=352,y=215,x1=163,y1=215;
		 * ta.longPress(x, y).moveTo(x1, y1).release().perform();
		 * 
		 * String strDeleteItem=getUILocator("swipe_delete");
		 * log("The  pay menu is selected to update is : " + strItem);
		 * Assert.assertTrue(clickElement(strDeleteItem)
		 * ,"Failed to click on the menu item to delete ");
		 * Assert.assertNotNull(waitForElements("swipe_delete"),
		 * "Failed to display the menu items selected in customized list ");
		 */

		strItem = getUILocator("btn_customize");
		Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Customize button ");
		Assert.assertTrue(clickElement(strItem), " failed to click the Customize button");
		Offshoredelay();

		strItem = getUILocator("btn_customize_update_order");
		Assert.assertNotNull(waitForElement(strItem), "Failed to wait for update the Order button ");
		Assert.assertTrue(clickElement(strItem), " failed to click on update the Order button");
		log("Successfully clicked on Updated button - Order updated ");
		Offshoredelay();
	
		

		strItem = getUILocator("customize_pay");
		Assert.assertTrue(clickElement(strItem), " failed to click on Pay button");
		log("Successfully clicked on Pay button for for customized List order ");
		Offshoredelay();
		return this;
	}

	public GuestApp customizeOrderAsFavourite(String favouritemItem) {
		//log(driver.getPageSource());
		log("*********next method started*****************");
		String strItem = "";

		System.out.println("Food item to update is :  " + favouritemItem);
		
	

		strItem = getUILocator("menu_item_selected").replaceAll("<REPLACE_FOOD_ITEM_SELECTED>",favouritemItem);
		log("The  pay menu is selected to update is : " + strItem);
		Assert.assertNotNull(waitForElements(strItem),"Failed to display the menu items selected in customized list ");
		Assert.assertTrue(clickElement(strItem), "Failed to click on the menu item");
		//driver.findElementByXPath("//XCUIElementTypeCell[1]").click();
		log("Successfully clicked on meunu items as per request:  " + strItem);
		Offshoredelay();
		
		strItem = getUILocator("icon_heart_shape");
		Assert.assertNotNull(waitForElement(strItem), "Failed to wait for favourite button element to display ");
		Assert.assertTrue(clickElement(strItem), " failed to click the favourite button enabled ");
		Offshoredelay();

		strItem = getUILocator("btn_add_to_order_fav");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on Add to order button ");
		Assert.assertTrue(clickElement(strItem), " failed to click on Add to order button ");
		Offshoredelay();

		strItem = getUILocator("btn_browse");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on Browse button ");
		Assert.assertTrue(clickElement(strItem), " failed to click on Browse button ");
		Offshoredelay();

		strItem = getUILocator("lbl_home_myfavorites");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on My Favorites button ");
		Assert.assertTrue(clickElement(strItem), " failed to click on My Favorites button ");
		Offshoredelay();

		String strVerifyItem = getUILocator("verify_lbl_item_fav");
		strVerifyItem = waitForElement("verify_lbl_item_fav").getText();
		log("Value :"+strVerifyItem);
		
		if(strVerifyItem.equalsIgnoreCase("PastaAutomationNonCustomized-Standard")) {
		
		log("Successfully added the item of same meunu  as per request:  " +strVerifyItem);
		}
		
		log("Successfully added the item of same meunu  as per request:  " +strVerifyItem);
		Offshoredelay();
		// Done of fav element Jan 30th enclosed

		return this;
	}
	
	public GuestApp customizeOrderAsUnCheckFavourite(String favouritemItem) {
		//log(driver.getPageSource());
		log("*********next method started*****************");
		String strItem = "";

		System.out.println("Food item to update is :  " + favouritemItem);
		
		strItem = getUILocator("btn_browse");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on Browse button ");
		Assert.assertTrue(clickElement(strItem), "failed to click on Browse button ");
		Offshoredelay();

		strItem = getUILocator("lbl_home_myfavorites");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on My Favorites button ");
		Assert.assertTrue(clickElement(strItem), "failed to click on My Favorites button ");
		Offshoredelay();
		
		strItem = getUILocator("btn_favourite_food_item_name").replaceAll("<REPLACE_FOOD_ITEM_SELECTED>",favouritemItem);
		log("The  favourite menu is selected as : " + strItem);
		
		Assert.assertNotNull(waitForElements(strItem),"Failed to display the menu items selected in customized list ");
		Assert.assertTrue(clickElement(strItem), "Failed to click on the menu item");
		log("Successfully clicked on favourite meunu items as per request:  "+strItem);
		Offshoredelay();
		
		strItem = getUILocator("icon_heart_shape");
		Assert.assertNotNull(waitForElement(strItem), "Failed to wait for favourite button element to display ");
		Assert.assertTrue(clickElement(strItem), " failed to click the favourite button enabled ");
		Offshoredelay();


		strItem = getUILocator("btn_browse");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on Browse button ");
		Assert.assertTrue(clickElement(strItem), " failed to click on Browse button ");
		Offshoredelay();

		strItem = getUILocator("lbl_home_myfavorites");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on My Favorites button ");
		Assert.assertTrue(clickElement(strItem), " failed to click on My Favorites button ");
		Offshoredelay();
		
		log("Successfully removed the item from cart");

		
		
		
	/*	String strVerifyText=getUILocator("lbl_favourite_page_text");
		Assert.assertNotNull(waitForElement(strVerifyText), "Failed to click on food item name");
		if(strVerifyText.equalsIgnoreCase("Your favorites are not available.")){
			log("No items on cart as favorite");
		}
		else if(strVerifyText.equalsIgnoreCase("House-made potato chips ")) { 
			
		String strVerifyItem = getUILocator("verify_lbl_item_fav");
		Assert.assertNotEquals(favouritemItem, waitForElement(strVerifyItem).getText(),"Failed to removed the item to My Favorites food item name in cart ");
		}*/
		
		Offshoredelay();

		return this;
	}
	

	// @Sulo - resuseable
	public String findElementXpathAndReplaceText(String uiLocatorKeyCus, String jSonParamter) {
		String strItem1 = "";
		try {
			strItem1 = getUILocator(jSonParamter).replaceAll("<REPLACE_TEXT>", uiLocatorKeyCus);
			System.out.println("JSon paramater is : " + jSonParamter);
			System.out.println("uilocatorkeyCus is : " + uiLocatorKeyCus);
			AppUtilities.delay(5000);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return strItem1;
	}


	public GuestApp verifyDefaultCaffeLocation(String setStationName) {
		//log(driver.getPageSource());

		String strItem = "";

		log("Choose the default station name to be selected:  " + setStationName);


		strItem = getUILocator("btn_my_information");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on More information button ");
		Assert.assertTrue(clickElement(strItem), "failed to click on More information button ");
		Offshoredelay();
		upScrollTo();
		Offshoredelay();

		strItem = getUILocator("lbl_default_station");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on Default station button ");
		Assert.assertTrue(clickElement(strItem), " failed to click onDefault stationbutton ");
		Offshoredelay();
		upScrollTo();
		upScrollTo();


		log("element of setStationName is :"+setStationName);
		upScrollTo();
		upScrollTo();
		upScrollTo();
		upScrollTo();
		
		log("element of setStationName is :"+setStationName);
	

		strItem = getUILocator("lbl_first_caffe_as_default_station").replaceAll("<REPLACE_STATION_NAME>", setStationName);
		Assert.assertNotNull(waitForElement(strItem), "Failed  to find on first/selected station label ");
	
		//Scroll until
		while(!(waitForElement(strItem).isDisplayed())) {
			upScrollTo();
			Offshoredelay();
			if(waitForElement(strItem).isDisplayed()) {
				break;
			}
		}
		Assert.assertNotNull(waitForElement(strItem), "Failed  to find on first/selected station label ");
		Assert.assertTrue(clickElement(strItem), "Failed to click on first/selected station label ");
		Offshoredelay();
		

		strItem = getUILocator("back_button_my_info");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on Back button ");
		Assert.assertTrue(clickElement(strItem), " failed to click on Back button ");
		Offshoredelay();

		strItem = ("btn_browse");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on Browse button ");
		Assert.assertTrue(clickElement(strItem), " failed to click on Browse button ");
		Offshoredelay();

		String strVerifyItem = getUILocator("verify_lbl_caffe_home_page");
		Assert.assertNotNull(waitForElement(strVerifyItem), "Failed to click on Browse button ");
		Assert.assertEquals(setStationName,waitForElement(strVerifyItem).getText(),"Successfully verified the caffe name is same ");

		log("Successfully verified the caffe name is same"+waitForElement(strVerifyItem).getText());

		Offshoredelay();

		return this;
	}
	public GuestApp verifyVoucherPaymentModesAsMealPrgOrMealVoucher(String setStationName) {
		//log(driver.getPageSource());

		String strItem = "";

		log("Choose the default station name to be selected:  " + setStationName);


		strItem = getUILocator("btn_my_info");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on More information button ");
		Assert.assertTrue(clickElement(strItem), "failed to click on More information button ");
		Offshoredelay();
		upScrollTo();
		Offshoredelay();

		strItem = getUILocator("myinfo_voucher");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on  my info voucher ");
		Assert.assertTrue(clickElement(strItem), " failed to click my info voucher ");
		Offshoredelay();
		
		
	

		strItem = getUILocator("myinfo_voucher_enroll_meal");
		Assert.assertNotNull((waitForElement(strItem).isDisplayed()), "Failed to  display Meal Program label");
			
			
		
		
		strItem = getUILocator("myinfo_voucher_meal_program");
		Assert.assertNotNull((waitForElement(strItem).isDisplayed()), "Failed to  display Meal Voucher label ");
			
			
		
		return this;
	}
	
	

	public GuestApp clickPayVoucher(String amount) {
		AppUtilities.delay(5000);
		// Click on total order button to choose the mode of pay
		Assert.assertTrue(clickElement("btn_order_to"), "Failed to click Available vouchers");
		AppUtilities.delay(10000);
		log("Total order layout is open to choose the mode of payment - Vouchers");

		// Click on voucher in list as per the amount in distribution
		System.out.println("Element to the amount is : " + amount);
		String strItemClick = getUILocator("select_click_voucher");
		
		String strItem = getUILocator("select_click_voucher");
		Assert.assertNotNull(waitForElement(strItem), "Failed  to find the voucher ");
		
		//Scroll until
		while(!(waitForElement(strItem).isDisplayed())) {
			upScrollTo();
			Offshoredelay();
			if(waitForElement(strItem).isDisplayed()) {
				break;
			}
		}
		
		Assert.assertTrue(clickElement(strItemClick), "Failed to click vouchers btn");
		Offshoredelay();
		log("Vouchers is selected is " + strItemClick);

		// Click on button Pay with Voucher
		String strItem2 = getUILocator("click_btn_pay_voucher");
		Assert.assertTrue(clickElement(strItem2), "Failed to click vouchers btn");
		log("Successfully Paid the amount with the mode of Pay with Voucher selected.");
		Offshoredelay();
		return this;
	}
	public GuestApp clickToPayVoucherAgain() {
		String strItems="";
		AppUtilities.delay(5000);
		// Click on total order button to choose the mode of pay
		Assert.assertTrue(clickElement("btn_order_to"), "Failed to click Available vouchers");
		AppUtilities.delay(10000);
		log("Total order layout is open to choose the mode of payment - Vouchers");

		// Click on voucher in list as per the amount in distribution
		
		String strItemClick = getUILocator("select_click_voucher");
		System.out.println("Element to select voucher is " + strItemClick);
		Assert.assertTrue(clickElement(strItemClick), "Failed to click vouchers btn");
		Offshoredelay();
		log("Vouchers is selected is " + strItemClick);
		
		String strItem = getUILocator("select_click_voucher_two");
		System.out.println("Element to select voucher is " + strItem);
		Assert.assertTrue(clickElement(strItem), "Failed to click vouchers btn");
		Offshoredelay();
		log("Second Vouchers is selected : " + strItem);

		// Click on button Pay with Voucher
		String strItem2 = getUILocator("click_btn_pay_voucher");
		Assert.assertTrue(clickElement(strItem2), "Failed to click vouchers btn");
		log("Successfully Paid the amount with the mode of Pay with Voucher selected.");
		Offshoredelay();
		
	
		strItems=getUILocator("msg_thank_you");
		if(strItems.equalsIgnoreCase("Thank You")) {
		Assert.assertNotNull(waitForElementAndGetText(strItems),"Failed to show the message as Thank You");
		log("Order placed successfully and landed to Thank you message");
		}
		
		strItems=getUILocator("msg_ready_to_pickup_notification");
		Assert.assertNotNull(waitForElementAndGetText(strItems),"Failed to show the notification message ");
		
		
		strItems=getUILocator("click_btn_show_order_status");
		Assert.assertNotNull(waitForElement(strItems),"Failed to click the element as show  order status ");
		
		
		strItems=getUILocator("btn_done_info");
		Assert.assertNotNull(waitForElement(strItems),"Failed to click the OK element  ");
		Assert.assertTrue(clickElement(strItems), "failed to click the OK element");
				Offshoredelay();

		return this;
	}

	//Added by Chithra
	public GuestApp clickPayVoucherFromListAvailable() {
		AppUtilities.delay(5000);
		// Click on total order button to choose the mode of pay
		Assert.assertTrue(clickElement("btn_order_to"), "Failed to click Available vouchers");
		AppUtilities.delay(10000);
		log("Total order layout is open to choose the mode of payment - Vouchers");

		// Click on voucher in list as per the amount in distribution
		
		String strItemClick = getUILocator("select_available_voucher_my_order_page");
		System.out.println("The Voucher amount selected is : " + waitForElement(strItemClick).getText());
		Assert.assertTrue(clickElement(strItemClick), "Failed to click vouchers btn");
		Offshoredelay();
		log("Vouchers is selected successfully");

		// Click on button Pay with Voucher
		String strItem2 = getUILocator("click_btn_pay_voucher");
		//String strItem2 = getUILocator("click_btn_pay_voucher_acc");
		
		// strItem2 = strItem2.replaceAll("<REPLACE_AMOUNT>", amount);
		Assert.assertTrue(clickElement(strItem2), "Failed to click vouchers btn");
		log("Successfully Paid the amount with the mode of Pay with Voucher selected.");
		Offshoredelay();
		return this;
	}
	
	public GuestApp orderGivenGrabAndGoItems(JSONArray items, String aCaffeLocation, String station_type) {
		log("-----------------------OrderGivenItems1----------------------------");
		log("Items to be ordered is:" + items.toJSONString());
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		int orderIndex = 0;
		for (Object item : items) {
			JSONObject itemDetails = (JSONObject) item;
			orderIndex++;
			Assert.assertNotNull(orderGivenGrabAndGoItem(orderIndex, itemDetails, aCaffeLocation, station_type),
					"Failed while ordering the item:" + itemDetails.toJSONString());
		}
		return this;
	}
	
	public GuestApp orderGivenGrabAndGoItem(int orderIndex, JSONObject item, String aCaffeLocation, String station_type) {
		
		log("-----------------------OrderGivenItems 3----------------------------");
		String strStationToSelect = (String) item.get("select_station");
		Boolean isCustomizedItem = (Boolean) item.get("is_custom_item");
		log("value of custom item   line 297 " + isCustomizedItem);
		log("value of custom item " + isCustomizedItem);

		String strItemToOrder = (String) item.get("food_item_name");
		String strItemPrice = (String) item.get("food_item_price");
		String strFoodItemType = (String) item.get("food_type");
		String strToppingType = (String) item.get("customize_food_item_category_type_state");

		String strStationType = getUILocator("station_type_other");
		strStationType = strStationType.replaceAll("<REPLACE_STATION_TYPE>", station_type);

		log("food_item_name " + strItemToOrder);
		log("food_item_price " + strItemPrice);
		log("food_type " + strFoodItemType);
		log("station_type_other  " + strStationType);
		// String strToppingType= (String)item.get("customize_food_item_category_type");
		//log("Customize topping type  " + strToppingType);

		Assert.assertNotNull(waitForElement(strStationType), "Fail to wait the element");
		upScrollTo();
		Offshoredelay();
		

		AppUtilities.delay(3000);
		AppUtilities.delay(3000);

		// Write Script to select different station type
		driver.findElementByAccessibilityId(station_type).click();
		AppUtilities.delay(3000);
		Offshoredelay();
		
		String station_type_display = "//XCUIElementTypeNavigationBar[contains(@name,'" + station_type + "')]";
		driver.findElementByXPath(station_type_display);
		driver.findElementByAccessibilityId(strStationToSelect).click();
		AppUtilities.delay(3000);
		log("Successfully clicked on strStationToSelect:  " + strStationType);
		
		AppUtilities.delay(3000);
		
		log("The food type given is:" + strFoodItemType + ", Caffe location:" + aCaffeLocation);

		AppUtilities.delay(10000);
		log(driver.getPageSource());
		log("Food to be ordered is from Standard menu");
		AppUtilities.delay(2000);
		log("number of elements in menu page" + waitForElements("menu_item_table1").size());
		List<WebElement> allTexts = driver.findElementsByXPath("//XCUIElementTypeStaticText");
		int a = allTexts.size();

		for (int i = 0; i < a; i++) {

			System.out.println(allTexts.get(i).getText());
		}

		String strItemName = getUILocator("grab_and_go_item_name").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		String strItemAddButton = getUILocator("add_item_grab_and_go").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		Assert.assertNotNull(waitForElement(strItemName), "Fail to wait the element");
		upScrollTo();			
		Assert.assertTrue(clickElement(strItemAddButton), "Failed to click Add button");
		
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("pay"), "Failed to click pay button");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("btn_apple_pay"), "Failed to click Apple pay button");	

		AppUtilities.delay(2000);

		Offshoredelay();

		
		return this;
	}
	
	public GuestApp clickToDeSelectVoucher() {
		AppUtilities.delay(5000);	
		String strItemClick = getUILocator("select_click_voucher");
		Assert.assertTrue(clickElement(strItemClick), "Failed to click vouchers btn");
		System.out.println("Element deselected the same voucher " + strItemClick);
		return this;
	}
	
	public GuestApp clickToSelectPayVoucher() {
		AppUtilities.delay(5000);
		// Click on total order button to choose the mode of pay
		Assert.assertTrue(clickElement("btn_order_to"), "Failed to click Available vouchers");
		AppUtilities.delay(10000);
		log("Total order layout is open to choose the mode of payment - Vouchers");

		// Click on voucher in list as per the amount in distribution

		String strItemClick = getUILocator("select_click_voucher");
		String voucherDetail= waitForElement(strItemClick).getText();
		writeDataInRunStore("voucher_detail", voucherDetail);
		System.out.println("Element to select voucher is " + strItemClick);
		Assert.assertTrue(clickElement(strItemClick), "Failed to click vouchers btn");


		log("Vouchers is selected is " + strItemClick);

		return this;
	}
	
	public GuestApp landHomePageDeSelect() {
		AppUtilities.delay(5000);	
		
		String stritemone = getUILocator("landing_browser_page");
		Assert.assertNotNull(waitForElement(stritemone), "Failed to land in browser caffee home page");
		Assert.assertTrue(clickElement(stritemone),"Failed to click on done button");
		log("Successfully landed to browser caffee home page");
		Offshoredelay();
		
		
	return this;
}

	

	/*
	 * Assert.assertTrue(clickElement("btn_special_homepage"),
	 * "Failed to click on the special button");
	 * Assert.assertNotNull(waitForElement("static_heading_special_food_list_page"),
	 * "Failed to wait for special heading");
	 * 
	 * strItem =
	 * getUILocator("btn_selected_cafe_location_special_food_list_page").replaceAll(
	 * "<REPLACE_CAFE_LOCATION>", aCaffeLocation);
	 * Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to wait for selected station:" + station + " in specials listing");
	 * 
	 * strItem = getUILocator("cell_food_item_special_food_list_page").replaceAll(
	 * "<REPLACE_STATION_TO_SELECT>", station); strItem =
	 * strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToCustomize);
	 * Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to wait for selected food item:" + itemToCustomize +
	 * " in specials listing");
	 * 
	 * strItem =
	 * getUILocator("btn_food_item_price_special_food_list_page").replaceAll(
	 * "<REPLACE_STATION_TO_SELECT>", station); strItem =
	 * strItem.replaceAll("<REPLACE_ITEM_PRICE>",itemPrice);
	 * 
	 * Assert.assertTrue(clickElement(strItem), "Failed to click on the food item:"
	 * + itemToCustomize + " with price:" + itemPrice + " under special food list");
	 * 
	 * strItem = getUILocator("btn_selected_station_food_custom_page"); strItem =
	 * strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", "Specials"); strItem =
	 * getUILocator("btn_food_item_price_special_food_list_page").replaceAll(
	 * "<REPLACE_STATION_TO_SELECT>", station); strItem =
	 * strItem.replaceAll("<REPLACE_ITEM_PRICE>","Customize");
	 * 
	 * Assert.assertTrue(clickElement(strItem), "Failed to click on the food item:"
	 * + itemToCustomize + " with price:" + itemPrice + " under special food list");
	 * 
	 */
	// Assert.assertNotNull(waitForElement(strItem), "Failed to find the Specials
	// name on the custom food item view");
	/*
	 * } else {
	 * 
	 * // strItem = getUILocator("cell_select_station_homepage");
	 * AppUtilities.delay(5000); strItem =
	 * getUILocator("menu_item_name_full_menu_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT>", itemToCustomize);
	 * Assert.assertTrue(clickElement(strItem), "failed to click the menu item");
	 * AppUtilities.delay(5000);
	 * 
	 * for(Object o : customItems) { JSONObject customItem = (JSONObject)o; boolean
	 * option_type = (boolean)customItem.get("customize_food_type_option"); boolean
	 * list_type = (boolean)customItem.get("customize_food_type_list"); String
	 * itemCategoryToChange =
	 * (String)customItem.get("customize_food_item_category");
	 * 
	 * if (option_type == true) { JSONArray a =
	 * (JSONArray)customItem.get("customize_food_items_option"); for(Object i : a) {
	 * JSONObject customizeItemSelectDetails = (JSONObject)i; String itemToBeChanged
	 * = (String)customizeItemSelectDetails.get("customize_food_item_name"); strItem
	 * = getUILocator("option_type_customize_detail_menu_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>", itemToBeChanged);
	 * Assert.assertTrue(clickElement(strItem), "Failed to click option type");
	 * String itemSelected =
	 * getUILocator("option_type_customize_detail_menu_page_selection").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>",itemToBeChanged);
	 * Assert.assertNotNull(waitForElement(itemSelected),
	 * "Failed to add option type customize"); } } if (option_type == true) {
	 * JSONArray a = (JSONArray)customItem.get("customize_food_items_list");
	 * for(Object i : a) { JSONObject customizeItemSelectDetails = (JSONObject)i;
	 * String listOption =
	 * (String)customizeItemSelectDetails.get("customize_food_item_name"); String
	 * itemToBeChanged1 =
	 * (String)customizeItemSelectDetails.get("customize_food_item_list_option1");
	 * //String itemToBeChanged2 =
	 * (String)customizeItemSelectDetails.get("customize_food_item_list_option2");
	 * strItem = getUILocator("list_type_customize_detail_menu_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>", listOption);
	 * Assert.assertTrue(clickElement(strItem), "Failed to click option type");
	 * strItem =
	 * getUILocator("list_type_customize_detail_option_menu_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>", itemToBeChanged1);
	 * Assert.assertTrue(clickElement(strItem), "Failed to click option type"); //
	 * strItem =
	 * getUILocator("list_type_customize_detail_option_menu_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>", itemToBeChanged2);
	 * //Assert.assertTrue(clickElement(strItem), "Failed to click list type"); //
	 * Assert.assertTrue(clickElement("back_button_food_item_details_page"),
	 * "Failed to click Back button"); String itemSelected1 =
	 * getUILocator("option_type_customize_detail_menu_page_selection").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>",itemToBeChanged1);
	 * Assert.assertNotNull(waitForElement(itemSelected1),
	 * "Failed to add option type customize"); //String itemSelected2 =
	 * getUILocator("option_type_customize_detail_menu_page_selection").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>",itemToBeChanged2);
	 * //Assert.assertNotNull(waitForElement(itemSelected2),
	 * "Failed to add option type customize"); } }
	 * Assert.assertTrue(clickElement("cell_food_item_price_to_add_to_order_page"),
	 * "Failed to click Add to order button");
	 */
	// Assert.assertTrue(clickElement("cell_food_item_price_to_add_to_order_page"),
	// "Failed to click Add to order button");
	/*
	 * String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>",
	 * station); Assert.assertTrue(clickElement(selectStationItem),
	 * "Failed to select the station:" + station);
	 * 
	 * //wait for the food items list strItem =
	 * getUILocator("static_selected_station_food_list_page"); String strItemStation
	 * = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
	 * Assert.assertNotNull(waitForElement(strItemStation),
	 * "Failed to find the station name on the food list");
	 * 
	 * 
	 * //Click customize on the item strItem =
	 * getUILocator("cell_food_item_price_to_select_food_list_page"); String
	 * strItemPriceButton = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>",
	 * itemToCustomize); strItemPriceButton =
	 * strItemPriceButton.replaceAll("<REPLACE_ITEM_PRICE>", itemPrice);
	 * Assert.assertTrue(clickElement(strItemPriceButton),
	 * "Failed to select the Item price for the item:" + itemToCustomize);
	 * 
	 * strItem = getUILocator("customize_button_standard_in_food_item_page"); String
	 * strItemCustomizeButton = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>",
	 * itemToCustomize); Assert.assertTrue(clickElement(strItemCustomizeButton),
	 * "Failed to select the Item price for the item:" + itemToCustomize);
	 * Assert.assertTrue(clickElement("customize_button_label_in_food_detail_page"),
	 * "failed to click label"); Assert.assertNotNull(waitForElement(
	 * "customize_label_price_in_food_detail_page"),
	 * "failed to find the label price"); AppUtilities.delay(5000); }
	 * 
	 * strItem = getUILocator("btn_selected_station_food_custom_page"); strItem =
	 * strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
	 * Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to find the station name on the custom food item view");
	 * 
	 * 
	 * 
	 * strItem =
	 * getUILocator("static_selected_food_price_food_custom_page").replaceAll(
	 * "<REPLACE_ITEM_PRICE>", itemPrice);
	 * log("static_selected_food_price_food_custom_page entry");
	 * Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to find the item price details on the custom food item view");
	 * log("static_selected_food_price_food_custom_page exit");
	 * 
	 * //Offshoredelay();
	 * //Assert.assertNotNull(waitForElement("btn_add_to_order_food_custom_page"),
	 * "Failed to find the Add to Order button on the custom food item view");
	 * 
	 * for(Object o : customItems) { JSONObject customItem = (JSONObject)o; String
	 * itemCategoryToChange =
	 * (String)customItem.get("customize_food_item_category");
	 * 
	 * JSONArray a = (JSONArray)customItem.get("customize_food_items");
	 * 
	 * for(Object i : a) { JSONObject customizeItemSelectDetails = (JSONObject)i;
	 * 
	 * String itemToBeChanged =
	 * (String)customizeItemSelectDetails.get("customize_food_item_name");
	 * 
	 * String itemstoSelect =
	 * (String)customizeItemSelectDetails.get("customize_food_item_count");
	 * log("Inside Custom page"); strItem =
	 * getUILocator("static_food_item_name_food_custom_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT>", itemToCustomize);
	 * Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to find the food item name:" + itemToCustomize +
	 * " custom food item view"); int items = Integer.parseInt(itemstoSelect); while
	 * ( items > 0) { if (items == Integer.parseInt(itemstoSelect)) { strItem =
	 * getUILocator("cell_select_item_to_customize_food_custom_page").replaceAll(
	 * "<REPLACE_CUSTOM_CATEGORY_TO_CHANGE>", itemCategoryToChange); strItem =
	 * strItem.replaceAll("<REPLACE_CUSTOM_ITEM_TO_SELECT>", itemToBeChanged);
	 * Assert.assertTrue(clickElement(strItem), "Failed to click the option:" +
	 * itemToBeChanged + " of category:"+ itemCategoryToChange +
	 * " in custom food item view"); }
	 * 
	 * //strItem =
	 * getUILocator("cell_Category_Add_Customize_food_list_page_name").replaceAll(
	 * "<REPLACE_CUSTOM_CATEGORY_TO_CHANGE>", itemCategoryToChange); //strItem =
	 * strItem.replaceAll("<REPLACE_CUSTOM_ITEM_TO_SELECT>", itemToBeChanged);
	 * //Assert.assertTrue(clickElement(strItem), "Failed to click the plus button:"
	 * );
	 * 
	 * items--; } }
	 * 
	 * }
	 * 
	 * //time to add order
	 * Assert.assertTrue(clickElement("btn_add_to_order_food_custom_page"),
	 * "Failed to click the Add to Order button after customing the selected food item"
	 * ); AppUtilities.delay(2000);
	 * 
	 * MobileElement myOrderBtn =
	 * waitForElementWithCustomAttribute("tabbtn_myorder_homepage", "value",
	 * orderIndex + " item", StringVerification.CONTAINS,
	 * StringCase.CASE_INSENSITIVE); Assert.assertNotNull(myOrderBtn,
	 * "Failed to find the My Order tab btn after clicking the item btn add ");
	 * 
	 * 
	 * //make sure that menu is loaded. After add to order, it is loading the My
	 * order page -delete Assert.assertTrue(clickElement("tabbtn_menu_homepage"),
	 * "Failed to click the menu option after customizng the given food item");
	 */
	/*
	 * } } Assert.assertTrue(clickElement("my_pay"), "Failed to click Pay button");
	 * Offshoredelay(); //make sure that menu is loaded. After add to order, it is
	 * loading the My order page -delete
	 * Assert.assertTrue(clickElement("tabbtn_menu_homepage"),
	 * "Failed to click the menu option after customizng the given food item");
	 * 
	 * log("Successfully added the item as per the given test data");
	 * Assert.assertTrue(clickElement("back_button_food_item_details_page"));
	 * Offshoredelay();
	 * log("Successfully customized the item as per the given test data"); return
	 * this; }
	 */

	/*
	 * public GuestApp customizeItemAndAddToOrderQuantity(int orderIndex, String
	 * aFoodItemType, String aCaffeLocation, String station, String itemToCustomize,
	 * String itemPrice, JSONArray customItems) { AppUtilities.delay(10000);
	 * log(driver.getPageSource());
	 * 
	 * log("The food type given is: " + aFoodItemType + ", Caffe location: " +
	 * aCaffeLocation); String strItem = "";
	 * if(StringUtils.equalsIgnoreCase(aFoodItemType, "special")) {
	 * 
	 * log("Food to be ordered is from Special menu"); } for(Object item : items) {
	 * JSONObject itemDetails = (JSONObject)item; orderIndex++;
	 * Assert.assertNotNull(orderGivenItem(orderIndex, itemDetails,
	 * aCaffeLocation,station_type), "Failed while ordering the item:" +
	 * itemDetails.toJSONString()); }
	 * 
	 * String strItemToOrder = (String)item.get("food_item_name"); String
	 * strItemPrice = (String)item.get("food_item_price"); String strFoodItemType =
	 * (String)item.get("food_type"); String strStationType =
	 * getUILocator("station_type_other"); strStationType =
	 * strStationType.replaceAll("<REPLACE_STATION_TYPE>", station_type);
	 * 
	 * 
	 * String strFoodItem = getUILocator("add_new_item_save_existing").replaceAll(
	 * "<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
	 * 
	 * Assert.assertTrue(clickElement("btn_special_homepage"),
	 * "Failed to click on the special button");
	 * Assert.assertNotNull(waitForElement("static_heading_special_food_list_page"),
	 * "Failed to wait for special heading");
	 * 
	 * strItem =
	 * getUILocator("btn_selected_cafe_location_special_food_list_page").replaceAll(
	 * "<REPLACE_CAFE_LOCATION>", aCaffeLocation);
	 * Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to wait for selected station:" + station + " in specials listing");
	 * 
	 * strItem = getUILocator("cell_food_item_special_food_list_page").replaceAll(
	 * "<REPLACE_STATION_TO_SELECT>", station); strItem =
	 * strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToCustomize);
	 * Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to wait for selected food item:" + itemToCustomize +
	 * " in specials listing");
	 * 
	 * strItem =
	 * getUILocator("btn_food_item_price_special_food_list_page").replaceAll(
	 * "<REPLACE_STATION_TO_SELECT>", station); strItem =
	 * strItem.replaceAll("<REPLACE_ITEM_PRICE>",itemPrice);
	 * 
	 * Assert.assertTrue(clickElement(strItem), "Failed to click on the food item:"
	 * + itemToCustomize + " with price:" + itemPrice + " under special food list");
	 * 
	 * strItem = getUILocator("btn_selected_station_food_custom_page"); strItem =
	 * strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", "Specials"); strItem =
	 * getUILocator("btn_food_item_price_special_food_list_page").replaceAll(
	 * "<REPLACE_STATION_TO_SELECT>", station); strItem =
	 * strItem.replaceAll("<REPLACE_ITEM_PRICE>","Customize");
	 * 
	 * Assert.assertTrue(clickElement(strItem), "Failed to click on the food item:"
	 * + itemToCustomize + " with price:" + itemPrice + " under special food list");
	 * 
	 * 
	 * //Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to find the Specials name on the custom food item view");
	 * 
	 * } else {
	 * 
	 * // strItem = getUILocator("cell_select_station_homepage");
	 * AppUtilities.delay(5000); strItem =
	 * getUILocator("menu_item_name_full_menu_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT>", itemToCustomize);
	 * Assert.assertTrue(clickElement(strItem), "failed to click the menu item");
	 * AppUtilities.delay(5000);
	 * 
	 * for(Object o : customItems) { JSONObject customItem = (JSONObject)o; boolean
	 * option_type = (boolean)customItem.get("customize_food_type_option"); boolean
	 * list_type = (boolean)customItem.get("customize_food_type_list"); String
	 * itemCategoryToChange =
	 * (String)customItem.get("customize_food_item_category");
	 * 
	 * if (option_type == true) { JSONArray a =
	 * (JSONArray)customItem.get("customize_food_items_option"); for(Object i : a) {
	 * JSONObject customizeItemSelectDetails = (JSONObject)i; String itemToBeChanged
	 * = (String)customizeItemSelectDetails.get("customize_food_item_name"); strItem
	 * = getUILocator("option_type_customize_detail_menu_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>", itemToBeChanged);
	 * Assert.assertTrue(clickElement(strItem), "Failed to click option type");
	 * String itemSelected =
	 * getUILocator("option_type_customize_detail_menu_page_selection").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>",itemToBeChanged);
	 * Assert.assertNotNull(waitForElement(itemSelected),
	 * "Failed to add option type customize"); } } if (option_type == true) {
	 * JSONArray a = (JSONArray)customItem.get("customize_food_items_list");
	 * for(Object i : a) { JSONObject customizeItemSelectDetails = (JSONObject)i;
	 * String listOption =
	 * (String)customizeItemSelectDetails.get("customize_food_item_name"); String
	 * itemToBeChanged1 =
	 * (String)customizeItemSelectDetails.get("customize_food_item_list_option1");
	 * //String itemToBeChanged2 =
	 * (String)customizeItemSelectDetails.get("customize_food_item_list_option2");
	 * strItem = getUILocator("list_type_customize_detail_menu_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>", listOption);
	 * Assert.assertTrue(clickElement(strItem), "Failed to click option type");
	 * strItem =
	 * getUILocator("list_type_customize_detail_option_menu_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>", itemToBeChanged1);
	 * Assert.assertTrue(clickElement(strItem), "Failed to click option type"); //
	 * strItem =
	 * getUILocator("list_type_customize_detail_option_menu_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>", itemToBeChanged2);
	 * //Assert.assertTrue(clickElement(strItem), "Failed to click list type"); //
	 * Assert.assertTrue(clickElement("back_button_food_item_details_page"),
	 * "Failed to click Back button"); String itemSelected1 =
	 * getUILocator("option_type_customize_detail_menu_page_selection").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>",itemToBeChanged1);
	 * Assert.assertNotNull(waitForElement(itemSelected1),
	 * "Failed to add option type customize"); //String itemSelected2 =
	 * getUILocator("option_type_customize_detail_menu_page_selection").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT_OPTION>",itemToBeChanged2);
	 * //Assert.assertNotNull(waitForElement(itemSelected2),
	 * "Failed to add option type customize"); } }
	 * Assert.assertTrue(clickElement("cell_food_item_price_to_add_to_order_page"),
	 * "Failed to click Add to order button"); //
	 * Assert.assertTrue(clickElement("cell_food_item_price_to_add_to_order_page"),
	 * "Failed to click Add to order button");
	 * 
	 * String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>",
	 * station); Assert.assertTrue(clickElement(selectStationItem),
	 * "Failed to select the station:" + station);
	 * 
	 * //wait for the food items list strItem =
	 * getUILocator("static_selected_station_food_list_page"); String strItemStation
	 * = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
	 * Assert.assertNotNull(waitForElement(strItemStation),
	 * "Failed to find the station name on the food list");
	 * 
	 * 
	 * //Click customize on the item strItem =
	 * getUILocator("cell_food_item_price_to_select_food_list_page"); String
	 * strItemPriceButton = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>",
	 * itemToCustomize); strItemPriceButton =
	 * strItemPriceButton.replaceAll("<REPLACE_ITEM_PRICE>", itemPrice);
	 * Assert.assertTrue(clickElement(strItemPriceButton),
	 * "Failed to select the Item price for the item:" + itemToCustomize);
	 * 
	 * strItem = getUILocator("customize_button_standard_in_food_item_page"); String
	 * strItemCustomizeButton = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>",
	 * itemToCustomize); Assert.assertTrue(clickElement(strItemCustomizeButton),
	 * "Failed to select the Item price for the item:" + itemToCustomize);
	 * Assert.assertTrue(clickElement("customize_button_label_in_food_detail_page"),
	 * "failed to click label"); Assert.assertNotNull(waitForElement(
	 * "customize_label_price_in_food_detail_page"),
	 * "failed to find the label price"); AppUtilities.delay(5000); }
	 * 
	 * strItem = getUILocator("btn_selected_station_food_custom_page"); strItem =
	 * strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
	 * Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to find the station name on the custom food item view");
	 * 
	 * 
	 * 
	 * strItem =
	 * getUILocator("static_selected_food_price_food_custom_page").replaceAll(
	 * "<REPLACE_ITEM_PRICE>", itemPrice);
	 * log("static_selected_food_price_food_custom_page entry");
	 * Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to find the item price details on the custom food item view");
	 * log("static_selected_food_price_food_custom_page exit");
	 * 
	 * //Offshoredelay();
	 * //Assert.assertNotNull(waitForElement("btn_add_to_order_food_custom_page"),
	 * "Failed to find the Add to Order button on the custom food item view");
	 * 
	 * for(Object o : customItems) { JSONObject customItem = (JSONObject)o; String
	 * itemCategoryToChange =
	 * (String)customItem.get("customize_food_item_category");
	 * 
	 * JSONArray a = (JSONArray)customItem.get("customize_food_items");
	 * 
	 * for(Object i : a) { JSONObject customizeItemSelectDetails = (JSONObject)i;
	 * 
	 * String itemToBeChanged =
	 * (String)customizeItemSelectDetails.get("customize_food_item_name");
	 * 
	 * String itemstoSelect =
	 * (String)customizeItemSelectDetails.get("customize_food_item_count");
	 * log("Inside Custom page"); strItem =
	 * getUILocator("static_food_item_name_food_custom_page").replaceAll(
	 * "<REPLACE_ITEM_TO_SELECT>", itemToCustomize);
	 * Assert.assertNotNull(waitForElement(strItem),
	 * "Failed to find the food item name:" + itemToCustomize +
	 * " custom food item view"); int items = Integer.parseInt(itemstoSelect); while
	 * ( items > 0) { if (items == Integer.parseInt(itemstoSelect)) { strItem =
	 * getUILocator("cell_select_item_to_customize_food_custom_page").replaceAll(
	 * "<REPLACE_CUSTOM_CATEGORY_TO_CHANGE>", itemCategoryToChange); strItem =
	 * strItem.replaceAll("<REPLACE_CUSTOM_ITEM_TO_SELECT>", itemToBeChanged);
	 * Assert.assertTrue(clickElement(strItem), "Failed to click the option:" +
	 * itemToBeChanged + " of category:"+ itemCategoryToChange +
	 * " in custom food item view"); }
	 * 
	 * //strItem =
	 * getUILocator("cell_Category_Add_Customize_food_list_page_name").replaceAll(
	 * "<REPLACE_CUSTOM_CATEGORY_TO_CHANGE>", itemCategoryToChange); //strItem =
	 * strItem.replaceAll("<REPLACE_CUSTOM_ITEM_TO_SELECT>", itemToBeChanged);
	 * //Assert.assertTrue(clickElement(strItem), "Failed to click the plus button:"
	 * );
	 * 
	 * items--; } }
	 * 
	 * }
	 * 
	 * //time to add order
	 * Assert.assertTrue(clickElement("btn_add_to_order_food_custom_page"),
	 * "Failed to click the Add to Order button after customing the selected food item"
	 * ); AppUtilities.delay(2000);
	 * 
	 * MobileElement myOrderBtn =
	 * waitForElementWithCustomAttribute("tabbtn_myorder_homepage", "value",
	 * orderIndex + " item", StringVerification.CONTAINS,
	 * StringCase.CASE_INSENSITIVE); Assert.assertNotNull(myOrderBtn,
	 * "Failed to find the My Order tab btn after clicking the item btn add ");
	 * 
	 * 
	 * //make sure that menu is loaded. After add to order, it is loading the My
	 * order page -delete Assert.assertTrue(clickElement("tabbtn_menu_homepage"),
	 * "Failed to click the menu option after customizng the given food item");
	 * 
	 * } } Assert.assertTrue(clickElement("my_pay"), "Failed to click Pay button");
	 * Offshoredelay(); //make sure that menu is loaded. After add to order, it is
	 * loading the My order page -delete
	 * Assert.assertTrue(clickElement("tabbtn_menu_homepage"),
	 * "Failed to click the menu option after customizng the given food item");
	 * 
	 * log("Successfully added the item as per the given test data");
	 * Assert.assertTrue(clickElement("back_button_food_item_details_page"));
	 * Offshoredelay();
	 * log("Successfully customized the item as per the given test data"); return
	 * this; }
	 */

	public GuestApp removeFoodItemsIfEnabled(JSONArray itemsToRemove, String strExpectedTotalAfterRemovingFoodItems) {

		if (itemsToRemove == null || itemsToRemove.size() <= 0) {
			log("Looks like no items have been configured to remove from the order list.");
			return this;
		}

		// Goto my order tab
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click on my order tab");

		// click Edit option
		Assert.assertTrue(clickElement("btn_edit_in_my_order_page"), "Failed to click on edit button in my order page");

		// select delete item for each given
		for (Object o : itemsToRemove) {
			String itemName = (String) o;
			Assert.assertTrue(removeGivenFoodItem(itemName),
					"Failed to delete the food item:" + itemName + " from my order page");
		}
		log("All the given items have been deleted from the my order page");

		// verify the total is same as the configured given value
		/*
		 * String strItem =
		 * getUILocator("static_food_item_total_value_in_my_order_page").replaceAll(
		 * "<REPLACE_TOTAL_PRICE>", strExpectedTotalAfterRemovingFoodItems);
		 * Assert.assertNotNull(waitForElement(strItem),
		 * "Failed to check the total order value:" +
		 * strExpectedTotalAfterRemovingFoodItems +
		 * " after removing the given food items");;
		 */
		Assert.assertTrue(clickElement("btn_done_in_my_order_page"),
				"Failed to click the Done button after removing the food items in my order page");

		log("Total order value has been verified after removing the food items configured");
		return this;
	}

	public GuestApp DeleteOrder(JSONArray itemsToRemove) {

		if (itemsToRemove == null || itemsToRemove.size() <= 0) {
			log("Looks like no items have been configured to remove from the order list.");
			return this;
		}

		// Goto my order tab
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click on my order tab");

		// click Edit option
		Assert.assertTrue(clickElement("btn_edit_in_my_order_page"), "Failed to click on edit button in my order page");

		// select delete item for each given
		for (Object o : itemsToRemove) {
			String itemName = (String) o;
			Assert.assertTrue(removeGivenFoodItem1(itemName),
					"Failed to delete the food item:" + itemName + " from my order page");
		}
		log("All the given items have been deleted from the my order page");

		// verify the items are removed and not listed

		Assert.assertNotNull(waitForElement("No_items_displayed_text_in_my_order_page"),
				"Failed to display message after removing the food items in my order page");

		log("Food Items are removed as configured");
		AppUtilities.delay(10000);
		Assert.assertTrue(clickElement("tabbtn_menu_homepage"), "Failed to click menu tab");
		return this;
	}

	private boolean removeGivenFoodItem(String aItemName) {
		log("Removing the food item:" + aItemName + " from the my order page");
		boolean status = false;
		List<WebElement> list = waitForElements("cells_list_items_my_order_page");
		log("Total number of order entries:" + list.size());
		JSONArray foodItemsList = new JSONArray();
		for (WebElement e : list) {

			// List<WebElement> staticList = e.findElements(By.className("UIAStaticText"));

			// log("Number of subelements found as:" + staticList.size());
			JSONObject o = new JSONObject();
			String itemName = e.getText();
			log(itemName);
			o.put("food_item_name", itemName);
			// o.put("food_item_togo", staticList.get(1).getText());
			// o.put("food_item_price", staticList.get(2).getText());
			foodItemsList.add(o);
		}
		log("Order details list:" + foodItemsList.toJSONString());
		int foodItemIndex = -1;

		int index = -1;
		for (Object o : foodItemsList) {
			JSONObject item = (JSONObject) o;
			index++;
			String name = (String) item.get("food_item_name");
			if (StringUtils.contains(name, aItemName)) {
				foodItemIndex = index;
				break;
			}
		}
		log("The food item index in my order page is:" + foodItemIndex);
		Assert.assertTrue(foodItemIndex != -1, "Failed to find the given food item:" + aItemName + " in my order page");

		String strItem = getUILocator("btn_left_delete_food_item_my_order_page").replaceAll("<REPLACE_FOODITEM_INDEX>",
				Integer.toString(foodItemIndex));
		Assert.assertTrue(clickElement(strItem),
				"Failed to click the delete button(left side) for the food item:" + aItemName + " to be deleted");

		// xpath deals with 1 based index.
		strItem = getUILocator("btn_right_delete_food_item_my_order_page").replaceAll("<REPLACE_FOODITEM_INDEX>",
				Integer.toString(foodItemIndex + 1));
		Assert.assertTrue(clickElement(strItem),
				"Failed to click the delete button(right side) for the food item:" + aItemName + " to be deleted");
		AppUtilities.delay(2000);
		log("The food item:" + aItemName + " has been deleted successfully");
		status = true;

		return status;
	}

	private boolean removeGivenFoodItem1(String aItemName) {
		log("Removing the food item:" + aItemName + " from the my order page");
		boolean status = false;
		List<WebElement> list = waitForElements("cells_list_items_my_order_page");
		log("Total number of order entries:" + list.size());
		JSONArray foodItemsList = new JSONArray();
		for (WebElement e : list) {

			// List<WebElement> staticList = e.findElements(By.className("UIAStaticText"));

			// log("Number of subelements found as:" + staticList.size());
			JSONObject o = new JSONObject();
			String itemName = e.getText();
			log(itemName);
			o.put("food_item_name", itemName);
			// o.put("food_item_togo", staticList.get(1).getText());
			// o.put("food_item_price", staticList.get(2).getText());
			foodItemsList.add(o);
		}
		log("Order details list:" + foodItemsList.toJSONString());
		int foodItemIndex = -1;

		int index = -1;
		for (Object o : foodItemsList) {
			JSONObject item = (JSONObject) o;
			index++;
			String name = (String) item.get("food_item_name");
			if (StringUtils.contains(name, aItemName)) {
				foodItemIndex = index;
				break;
			}
		}
		log("The food item index in my order page is:" + foodItemIndex);
		Assert.assertTrue(foodItemIndex != -1, "Failed to find the given food item:" + aItemName + " in my order page");

		String strItem = getUILocator("btn_left_delete_food_item_my_order_page").replaceAll("<REPLACE_FOODITEM_INDEX>",
				Integer.toString(foodItemIndex));
		Assert.assertTrue(clickElement(strItem),
				"Failed to click the delete button(left side) for the food item:" + aItemName + " to be deleted");

		// xpath deals with 1 based index.
		strItem = getUILocator("btn_right_delete_food_item_my_order_page1").replaceAll("<REPLACE_FOODITEM_INDEX>",
				Integer.toString(foodItemIndex + 1));
		Assert.assertTrue(clickElement(strItem),
				"Failed to click the delete button(right side) for the food item:" + aItemName + " to be deleted");
		AppUtilities.delay(2000);
		log("The food item:" + aItemName + " has been deleted successfully");
		status = true;

		return status;
	}

	public GuestApp validateFoodItemType(String aCaffeLocation, JSONArray foodItems) {

		JSONObject item = (JSONObject) foodItems.get(0);
		String station = (String) item.get("select_station");
		Boolean isCustomizedItem = (Boolean) item.get("is_custom_item");
		log("value of custom item " + isCustomizedItem);

		String itemToCustomize = (String) item.get("food_item_name");
		String itemPrice = (String) item.get("food_item_price");
		String strFoodItemType = (String) item.get("food_type");

		log("The food type given is:" + strFoodItemType + ", Caffe location:" + aCaffeLocation);
		String strItem = "";
		if (StringUtils.equalsIgnoreCase(strFoodItemType, "special")) {

			log("Food to be ordered is from Special menu");

			Assert.assertTrue(clickElement("btn_special_homepage"), "Failed to click on the special button");
			Assert.assertNotNull(waitForElement("static_heading_special_food_list_page"),
					"Failed to wait for special heading");

			strItem = getUILocator("btn_selected_cafe_location_special_food_list_page")
					.replaceAll("<REPLACE_CAFE_LOCATION>", aCaffeLocation);
			Assert.assertNotNull(waitForElement(strItem),
					"Failed to wait for selected station:" + station + " in specials listing");

			strItem = getUILocator("cell_food_item_special_food_list_page").replaceAll("<REPLACE_STATION_TO_SELECT>",
					station);
			strItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToCustomize);
			Assert.assertNotNull(waitForElement(strItem),
					"Failed to wait for selected food item:" + itemToCustomize + " in specials listing");

			strItem = getUILocator("btn_food_item_price_special_food_list_page")
					.replaceAll("<REPLACE_STATION_TO_SELECT>", station);
			strItem = strItem.replaceAll("<REPLACE_ITEM_PRICE>", itemPrice);

			Assert.assertTrue(clickElement(strItem), "Failed to click on the food item:" + itemToCustomize
					+ " with price:" + itemPrice + " under special food list");

			/*
			 * strItem = getUILocator("btn_selected_station_food_custom_page"); strItem =
			 * strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", "Specials");
			 */

			if (isCustomizedItem) {
				strItem = getUILocator("btn_food_item_price_special_food_list_page")
						.replaceAll("<REPLACE_STATION_TO_SELECT>", station);
				strItem = strItem.replaceAll("<REPLACE_ITEM_PRICE>", "Customize");

				Assert.assertTrue(clickElement(strItem), "Failed to click on the food item:" + itemToCustomize
						+ " with price:" + itemPrice + " under special food list");
			}

			// Assert.assertNotNull(waitForElement(strItem), "Failed to find the Specials
			// name on the custom food item view");
		} else {

			strItem = getUILocator("cell_select_station_homepage");

			String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
			Assert.assertTrue(clickElement(selectStationItem), "Failed to select the station:" + station);

			// wait for the food items list
			strItem = getUILocator("static_selected_station_food_list_page");
			String strItemStation = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
			Assert.assertNotNull(waitForElement(strItemStation), "Failed to find the station name on the food list");

			// Click customize on the item

			Assert.assertNotNull(waitForElement("cell_food_items_standard_food_list_page"),
					"Failed to find the food item type");

			strItem = getUILocator("cell_food_item_price_to_select_food_list_page");
			String strItemPriceButton = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", itemToCustomize);
			strItemPriceButton = strItemPriceButton.replaceAll("<REPLACE_ITEM_PRICE>", itemPrice);
			Assert.assertTrue(clickElement(strItemPriceButton),
					"Failed to select the Item price for the item:" + itemToCustomize);
		}

		return this;
	}

	public GuestApp checkOut() {
		Assert.assertTrue(clickElement("my_pay"), "Failed to click on my order tab");
		Assert.assertNotNull(clickElement("btn_payroll_deduction_in_my_order_page"),
				"Failed to click the payroll deduction button in the my order");
		AppUtilities.delay(5000);
		Assert.assertNotNull(waitForElement("static_thankyou_thankyou_page"),
				"Failed to check the thank you text after clicking on payroll-dediction");
		// Assert.assertNotNull(waitForElement("static_desc_thankyou_page"), "Failed to
		// check the thank you description after clicking on payroll-dediction");
		return this;
	}

	public GuestApp checkOut(String totalExpectedOrderValue) {

		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click on my order tab");

		String strItem = getUILocator("static_food_item_total_value_in_my_order_page")
				.replaceAll("<REPLACE_TOTAL_PRICE>", totalExpectedOrderValue);
		Assert.assertNotNull(waitForElement(strItem),
				"Failed to check the total order value:" + totalExpectedOrderValue);

		Assert.assertNotNull(clickElement("btn_payroll_deduction_in_my_order_page"),
				"Failed to click the payroll deduction button in the my order");
		Assert.assertNotNull(waitForElement("static_thankyou_thankyou_page"),
				"Failed to check the thank you text after clicking on payroll-dediction");
		Assert.assertNotNull(waitForElement("static_desc_thankyou_page"),
				"Failed to check the thank you description after clicking on payroll-dediction");
		return this;
	}

	public GuestApp checkOutforstandardItems(String totalExpectedOrderValue) {

		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click on my order tab");
		Assert.assertTrue(clickElement("tabbtn_menu_homepage"),
				"Failed to click the menu option after customizng the given food item");
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click on my order tab");

		String strItem = getUILocator("static_food_item_total_value_in_my_order_page")
				.replaceAll("<REPLACE_TOTAL_PRICE>", totalExpectedOrderValue);
		Assert.assertNotNull(waitForElement(strItem),
				"Failed to check the total order value:" + totalExpectedOrderValue);

		Assert.assertNotNull(clickElement("btn_payroll_deduction_in_my_order_page"),
				"Failed to click the payroll deduction button in the my order");
		Assert.assertNotNull(waitForElement("static_thankyou_thankyou_page"),
				"Failed to check the thank you text after clicking on payroll-dediction");
		Assert.assertNotNull(waitForElement("static_desc_thankyou_page"),
				"Failed to check the thank you description after clicking on payroll-dediction");
		return this;
	}

	public GuestApp ValidateOrder(String totalExpectedOrderValue) {
		log("Items read from Order Thank you page:" + itemListFromPage.toJSONString());
		String strItem = getUILocator("static_food_item_total_value_in_my_order_page")
				.replaceAll("<REPLACE_TOTAL_PRICE>", totalExpectedOrderValue);
		Assert.assertNotNull(waitForElement(strItem),
				"Failed to check the total order value:" + totalExpectedOrderValue);
		Assert.assertNotNull(clickElement("btn_done_thankyou_page"),
				"Failed to click the payroll deduction button in the my order");
		Assert.assertNotNull(clickElement("Status_tab_Completed_Page"), "Failed to click the Status tab");

		int orderIndex = 0;
		for (Object item : itemListFromPage) {
			JSONObject itemDetails = (JSONObject) item;
			String ordernumber = (String) itemDetails.get("orderid");
			ordernumber = ordernumber.replaceFirst("Order #", "#");
			log(ordernumber);
			// strItem =
			// getUILocator("Order_Number_Completed_Page").replaceAll("<REPLACE_ORDER_INDEX>",
			// Integer.toString(orderIndex));
			strItem = getUILocator("Order_Number_Completed_Page").replaceAll("<REPLACE_ORDER>", ordernumber);
			strItem = strItem.replaceAll("<REPLACE_ORDER_INDEX>", ordernumber);
			log(strItem);
			Assert.assertNotNull(waitForElement(strItem), "Ordernumber not found at this position");
			log(ordernumber + "found");
			orderIndex++;
		}
		/*
		 * for (int i=0; i<= list.size(); i++) { String Index = String.valueOf(i);
		 * strItem =
		 * getUILocator("static_food_item_total_value_in_my_order_page").replaceAll(
		 * "<REPLACE_ORDER_INDEX>", Index); strItem.replaceAll("<REPLACE_ORDER>", );
		 * Assert.assertNotNull(waitForElement(strItem),
		 * "Failed to check the total order value:" + totalExpectedOrderValue);
		 * 
		 * }
		 */
		return this;
	}

	public GuestApp modifyCustomize(String ChangeItem) throws InterruptedException {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to open the my order page");
		Assert.assertTrue(clickElement("cell_food_item_in_my_order_page_Modify"),
				"Failed to change the Items:" + ChangeItem);
		Assert.assertNotNull(waitForElement("back_button_food_item_details_page"), "Failed to Land in edit screen");
		Assert.assertTrue(clickElement("btn_food_item_price_food_item_details_page_modify"),
				"Failed to change the Items:" + ChangeItem);
		// Thread.sleep(500);
		// Assert.assertTrue(clickElement("cell_Category_Add_Customize_food_list_page_name"),
		// "Failed to change the Items:" + ChangeItem);
		Assert.assertTrue(clickElement("btn_add_to_order_food_custom_page"),
				"Failed to click the Add to Order button after customing the selected food item");
		AppUtilities.delay(2000);
		// AddtoOrderButton- Unableto capture
		return this;
	}

	public GuestApp reteriveorderdetails() {

		String strItem = getUILocator("orders_in_thank_you_page");
		List<WebElement> list = waitForElements(strItem);
		log("No. of element:" + list.size());
		// boolean found = false;
		// JSONArray itemListFromPage = new JSONArray();
		for (WebElement e : list) {
			// MobileElement cell = (MobileElement)e;
			JSONObject itemDetails = new JSONObject();
			List<WebElement> staticList = e.findElements(By.className("UIAStaticText"));
			int index = 0;
			for (WebElement staticItem : staticList) {
				String value = staticItem.getAttribute("value");
				log("Reading the item of:" + value);
				switch (index) {
				case 0:
					itemDetails.put("orderid", value);
					break;
				case 1:
					itemDetails.put("Menu Name", value);
					break;
				case 2:
					itemDetails.put("Add on", value);
					break;
				case 3:
					itemDetails.put("price", value);
					break;
				case 4:
					itemDetails.put("ForHere/Togo", value);
					break;
				}
				index++;
			}
			itemListFromPage.add(itemDetails);

			// MobileElement orderedItem =
			// (MobileElement)cell.findElementByXPath("//UIAStaticText[contains(@value, '" +
			// item_selected_for_order + "')]");
			// Assert.assertNotNull(orderedItem, "Failed to find the item ordered:" +
			// item_selected_for_order + " in thank you page");
		}
		log("Items read from Order Thank you page:" + itemListFromPage.toJSONString());
		return this;
	}

	public GuestApp checkOut(JSONArray itemsToOrder) {

		int itemsCount = itemsToOrder.size();

		// MobileElement myOrderBtn =
		// waitForElementWithCustomAttribute("tabbtn_myorder_homepage", "value",
		// itemsCount + " item", StringVerification.CONTAINS,
		// StringCase.CASE_INSENSITIVE);
		// Assert.assertNotNull(myOrderBtn, "Failed to find the My Order tab btn after
		// adding the food items");
		String myOrderBtnLocator = getUILocator("my_pay");
		MobileElement myOrderBtn = waitForElement(myOrderBtnLocator);
		myOrderBtn.click();
		AppUtilities.delay(2000);

		// Assert.assertTrue(clickElement("tabbtn_menu_homepage"), "Failed to click the
		// menu button the tab");
		// AppUtilities.delay(1000);

		// myOrderBtn.click();
		// AppUtilities.delay(2000);

		Assert.assertNotNull(waitForElement("Order_tab_Completed_Page"), "Failed to find the My Order View heading");

		double foodOrderTotal = 0;
		for (Object o : itemsToOrder) {
			JSONObject item = (JSONObject) o;

			String strItemToOrder = (String) item.get("food_item_name");

			String strItemPrice = (String) item.get("food_item_price");
			boolean isCustomItem = (Boolean) item.get("is_custom_item");
			if (isCustomItem) {
				log("The curren item is customized. Taking the total final one for my order page");
				strItemPrice = (String) item.get("select_food_item_price_final");
			}
			String strStation = (String) item.get("select_station");

			String strItem = getUILocator("cell_food_item_in_my_order_page").replaceAll("<REPLACE_ITEM_TO_SELECT>",
					strItemToOrder);
			Assert.assertNotNull(waitForElement(strItem),
					"Failed to find the food item:" + strItemToOrder + " in the my order view");

			strItem = getUILocator("cell_food_item_price_in_my_order_page").replaceAll("<REPLACE_ITEM_TO_SELECT>",
					strItemToOrder);
			strItem = strItem.replaceAll("<REPLACE_ITEM_PRICE>", strItemPrice);
			Assert.assertNotNull(waitForElement(strItem), "Failed to find the food item price:" + strItemPrice
					+ " for the food item:" + strItemToOrder + " in the my order view");

			strItem = getUILocator("static_selected_station_in_my_order_page").replaceAll("<REPLACE_ITEM_TO_SELECT>",
					strStation.toUpperCase());
			Assert.assertNotNull(waitForElement(strItem), "Failed to find the food station:" + strStation
					+ " for food item:" + strItemToOrder + " in the my order view");

			log("Successfully verified the food item:" + strItemToOrder + " under my order");

			foodOrderTotal += Double.parseDouble(strItemPrice);
		}

		DecimalFormat formatter = new DecimalFormat("0.00");
		String strTotalPrice = formatter.format(foodOrderTotal);
		System.out.println("Total food price:" + strTotalPrice);

		String strItem = getUILocator("static_food_item_total_value_in_my_order_page")
				.replaceAll("<REPLACE_TOTAL_PRICE>", strTotalPrice);
		Assert.assertNotNull(waitForElement(strItem),
				"Failed to find the order total value:" + foodOrderTotal + " in my order view");

		Assert.assertNotNull(clickElement("btn_payroll_deduction_in_my_order_page"),
				"Failed to click the payroll deduction button in the my order");
		Assert.assertNotNull(waitForElement("static_thankyou_thankyou_page"),
				"Failed to check the thank you text after clicking on payroll-dediction");
		Assert.assertNotNull(waitForElement("static_desc_thankyou_page"),
				"Failed to check the thank you description after clicking on payroll-dediction");

		int foodItemIndex = -1;
		for (Object o : itemsToOrder) {
			foodItemIndex++;
			JSONObject item = (JSONObject) o;

			String strItemToOrder = (String) item.get("food_item_name");
			String strItemPrice = (String) item.get("food_item_price");
			boolean isCustomItem = (Boolean) item.get("is_custom_item");
			if (isCustomItem) {
				log("The curren item is customized. Taking the total final one for thank-you page");
				strItemPrice = (String) item.get("select_food_item_price_final");
			}
			strItem = getUILocator("static_orderid_thankyou_page").replaceAll("<REPLACE_FOODITEM_INDEX>",
					Integer.toString(foodItemIndex));
			MobileElement orderIDElement = waitForElement(strItem);
			Assert.assertNotNull(orderIDElement, "Failed to find the order id element in thank you page");

			String orderID = orderIDElement.getText();
			log("The order id found as:" + orderID);

			strItem = getUILocator("static_order_food_item_name_thankyou_page").replaceAll("<REPLACE_ITEM_TO_SELECT>",
					strItemToOrder);
			strItem = strItem.replaceAll("<REPLACE_FOODITEM_INDEX>", Integer.toString(foodItemIndex));
			Assert.assertNotNull(waitForElement(strItem),
					"Failed to find the food item:" + strItemToOrder + " in the thank you page");

			strItem = getUILocator("static_order_food_item_price_thankyou_page").replaceAll("<REPLACE_ITEM_PRICE>",
					strItemPrice);
			strItem = strItem.replaceAll("<REPLACE_FOODITEM_INDEX>", Integer.toString(foodItemIndex));
			Assert.assertNotNull(waitForElement(strItem), "Failed to find the food item price:" + strItemPrice
					+ " for the food item:" + strItemToOrder + " in the thank you page");

			log("Successfully verified the food item:" + strItemToOrder + " under thank you page");
			item.put("orderid", orderID);

			storeOrderIdDetailsToRunStore((foodItemIndex + 1), item);
		}
		strItem = getUILocator("static_food_item_total_value_in_thankyou_page").replaceAll("<REPLACE_TOTAL_PRICE>",
				strTotalPrice);
		Assert.assertNotNull(waitForElement(strItem),
				"Failed to find the order total value:" + foodOrderTotal + " in thank you page");

		Assert.assertTrue(clickElement("btn_done_thankyou_page"), "Failed to click the Done button in Thank you page");
		log("Thank you page has been verified");

		return this;
	}

	public GuestApp isMyOrderEnabled() {
		MobileElement myOrderBtn = waitForElement("tabbtn_myorder_homepage");
		Assert.assertNull(myOrderBtn, "Failed as My Order tab is found");
		log("Looks like MyOrder tab btn is not found");
		return this;
	}

	public GuestApp checkoutThroughApplePay() {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("tabbtn_menu_homepage"),
				"Failed to click the menu option after customizng the given food item");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		String strMyOrder = getUILocator("btn_applepay_in_my_order_page");
		Assert.assertNotNull(waitForElement(strMyOrder), "Failed to find the Apple Pay button");
		Assert.assertTrue(clickElement("btn_applepay_in_my_order_page"), "Failed to click the Apple pay button");
		log("Successfully paid through apple pay option");
		return this;
	}

	public GuestApp checkoutThroughPayrollDeduction() {
		
		Assert.assertTrue(clickElement("order_total"), "Failed to click pay button");
		Offshoredelay();
		String strMyOrder = getUILocator("btn_payroll_deduction_in_my_order_page");
		Assert.assertNotNull(waitForElement(strMyOrder), "Failed to find the Payroll Deduction button");
		Assert.assertTrue(clickElement("btn_payroll_deduction_in_my_order_page"),
				"Failed to click the Payroll Deduction button");
		Offshoredelay();
		String strThankYou = getUILocator("static_thankyou_thankyou_page");
		Assert.assertNotNull(waitForElement(strThankYou), "Failed to find the Order Confirmation page");
		log("Successfully paid through Payroll deduction option");
		Assert.assertTrue(clickElement("btn_ok"), "Failed to click Done button in thank you page");
		Offshoredelay();
		
		return this;
	}
	
	// Added by Chithra
	public GuestApp soldOutMenuValidationForGivenItems(JSONArray items, String aCaffeLocation, String station_type) {
		log("Items to be ordered is:" + items.toJSONString());
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		int orderIndex = 0;
		for (Object item : items) {
			JSONObject itemDetails = (JSONObject) item;
			orderIndex++;
			Assert.assertNotNull(
					soldOutMenuValidationForGivenItem(orderIndex, itemDetails, aCaffeLocation, station_type),
					"Failed while sold out validation for the item:" + itemDetails.toJSONString());
		}
		return this;
	}

	public GuestApp soldOutMenuValidationForGivenItem(int orderIndex, JSONObject item, String aCaffeLocation,
			String station_type) {

		String strStationToSelect = (String) item.get("select_station");
		Boolean isCustomizedItem = (Boolean) item.get("is_custom_item");
		log("value of custom item " + isCustomizedItem);

		String strItemToOrder = (String) item.get("food_item_name");
		String strItemPrice = (String) item.get("food_item_price");
		String strFoodItemType = (String) item.get("food_type");

		String strStationType = getUILocator("station_type_other");
		strStationType = strStationType.replaceAll("<REPLACE_STATION_TYPE>", station_type);

		log("food_item_name " + strItemToOrder);
		log("food_item_price " + strItemPrice);
		log("food_type " + strFoodItemType);
		log("station_type_other  " + strStationType);

		Assert.assertNotNull(waitForElement(strStationType), "Fail to wait the element");
		upScrollTo();
		Offshoredelay();

		AppUtilities.delay(3000);
		AppUtilities.delay(3000);

		// Write Script to select different station type
		driver.findElementByAccessibilityId(station_type).click();
		AppUtilities.delay(3000);
		Offshoredelay();

		String station_type_display = "//XCUIElementTypeNavigationBar[contains(@name,'" + station_type + "')]";
		driver.findElementByXPath(station_type_display);
		driver.findElementByAccessibilityId(strStationToSelect).click();
		AppUtilities.delay(3000);
		log("Successfully clicked on strStationToSelect:  " + strStationType);

		AppUtilities.delay(3000);
		// Station Type Selected and Main Page of Station to select Menu Item
		log("The food type given is:" + strFoodItemType + ", Caffe location:" + aCaffeLocation);

		AppUtilities.delay(10000);

		log("Food to be ordered is from Standard menu");
		AppUtilities.delay(2000);

		log("number of elements in menu page" + waitForElements("menu_item_table1").size());
		List<WebElement> allTexts = driver.findElementsByXPath("//XCUIElementTypeStaticText");
		int a = allTexts.size();

		for (int i = 0; i < a; i++) {

			System.out.println(allTexts.get(i).getText());
		}

		String strItemNameLoc = getUILocator("menupage_item_name_by_name").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		Assert.assertNotNull(waitForElement(strItemNameLoc), "Fail to wait the element");

		String strMenuSoldOutLoc = getUILocator("menu_item_sold_out");
		Assert.assertNotNull(waitForElement(strMenuSoldOutLoc), "Fail to wait for sold out element");

		String selectMenu = getUILocator("menu_item_sold_out_select").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		Assert.assertTrue(clickElement(selectMenu), "failed to click the menu item name");

		strMenuSoldOutLoc = getUILocator("menu_item_sold_out_menu_page");
		Assert.assertNotNull(waitForElement(strMenuSoldOutLoc), "Fail to wait for sold out message in Menu Page");

		AppUtilities.delay(2000);

		if (!waitForElement("add_to_order_btn").isEnabled()) {
			log("Successfully validated Sold Out scenario");
		}

		Offshoredelay();

		return this;
	}

	public GuestApp soldOutFavoritesMenuValidationForGivenItems(JSONArray items, String aCaffeLocation,
			String station_type) {
		log("Items to be ordered is:" + items.toJSONString());
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		int orderIndex = 0;
		for (Object item : items) {
			JSONObject itemDetails = (JSONObject) item;
			orderIndex++;
			Assert.assertNotNull(
					soldOutFavoritesMenuValidationForGivenItem(orderIndex, itemDetails, aCaffeLocation, station_type),
					"Failed while sold out validation for the item:" + itemDetails.toJSONString());
		}
		return this;
	}

	public GuestApp soldOutFavoritesMenuValidationForGivenItem(int orderIndex, JSONObject item, String aCaffeLocation,
			String station_type) {

		String strStationToSelect = (String) item.get("select_station");
		Boolean isCustomizedItem = (Boolean) item.get("is_custom_item");
		log("value of custom item " + isCustomizedItem);

		String strItemToOrder = (String) item.get("food_item_name");
		String strItemPrice = (String) item.get("food_item_price");
		String strFoodItemType = (String) item.get("food_type");

		String strStationType = getUILocator("station_type_other");
		strStationType = strStationType.replaceAll("<REPLACE_STATION_TYPE>", station_type);

		log("food_item_name " + strItemToOrder);
		log("food_item_price " + strItemPrice);
		log("food_type " + strFoodItemType);
		log("station_type_other  " + strStationType);

		Assert.assertNotNull(waitForElement(strStationType), "Fail to wait the element");
		upScrollTo();
		Offshoredelay();

		AppUtilities.delay(3000);
		AppUtilities.delay(3000);

		// Write Script to select different station type
		driver.findElementByAccessibilityId(station_type).click();
		AppUtilities.delay(3000);
		Offshoredelay();

		String station_type_display = "//XCUIElementTypeNavigationBar[contains(@name,'" + station_type + "')]";
		driver.findElementByXPath(station_type_display);
		driver.findElementByAccessibilityId(strStationToSelect).click();
		AppUtilities.delay(3000);
		log("Successfully clicked on strStationToSelect:  " + strStationType);

		AppUtilities.delay(3000);
		// Station Type Selected and Main Page of Station to select Menu Item
		log("The food type given is:" + strFoodItemType + ", Caffe location:" + aCaffeLocation);

		AppUtilities.delay(10000);

		log("Food to be ordered is from Standard menu");
		AppUtilities.delay(2000);

		String strItemNameLoc = getUILocator("menupage_item_name_by_name").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		Assert.assertNotNull(waitForElement(strItemNameLoc), "Fail to wait the element");

		String strMenuSoldOutLoc = getUILocator("menu_item_sold_out");
		Assert.assertNotNull(waitForElement(strMenuSoldOutLoc), "Fail to wait for sold out element");

		String selectMenu = getUILocator("menu_item_sold_out_select").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		Assert.assertTrue(clickElement(selectMenu), "failed to click the menu item name");

		// Favorite click
		String menuItemFavorite = getUILocator("menu_item_favorite_menu_page").replaceAll("<REPLACE_TEXT>",
				strStationToSelect);
		Assert.assertNotNull(waitForElement(menuItemFavorite), "Fail to wait for favorite button");
		Assert.assertTrue(clickElement(menuItemFavorite), "Fail to click on favorite button");
		AppUtilities.delay(2000);

		// To Navigate back to Main Station screen
		Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in station page");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button to Main screen");

		// My Favorites Click
		Assert.assertTrue(clickElement("my_favorites_main_screen"), "Fail to click on favorite button");
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement("my_favorites_header"), "Fail to wait for favorite header");
		Assert.assertNotNull(waitForElement(strItemNameLoc), "Fail to wait the element");
		Assert.assertNotNull(waitForElement(strMenuSoldOutLoc), "Fail to wait for sold out element");

		if (!waitForElement("add_to_order_btn").isEnabled()) {
			log("Successfully validated Sold Out scenario");
		}

		Offshoredelay();

		return this;
	}
	
	//Sold Out Label validation
	public GuestApp soldOutLabelValidationForGivenItems(JSONArray items, String aCaffeLocation,
			String station_type) {
		log("Items to be ordered is:" + items.toJSONString());
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		int orderIndex = 0;
		for (Object item : items) {
			JSONObject itemDetails = (JSONObject) item;
			orderIndex++;
			Assert.assertNotNull(
					soldOutLabelValidation(orderIndex, itemDetails, aCaffeLocation, station_type),
					"Failed while sold out validation for the item:" + itemDetails.toJSONString());
		}
		return this;
	}

	public GuestApp soldOutLabelValidation(int orderIndex, JSONObject item, String aCaffeLocation,
			String station_type) {

		String strStationToSelect = (String) item.get("select_station");
		Boolean isCustomizedItem = (Boolean) item.get("is_custom_item");
		log("value of custom item " + isCustomizedItem);

		String strItemToOrder = (String) item.get("food_item_name");
		String strFoodItemType = (String) item.get("food_type");
		
		JSONArray labelDetails = (JSONArray) item.get("label_sold_out");

		String strStationType = getUILocator("station_type_other");
		strStationType = strStationType.replaceAll("<REPLACE_STATION_TYPE>", station_type);

		log("food_item_name " + strItemToOrder);
		log("food_type " + strFoodItemType);
		log("station_type_other  " + strStationType);

		Assert.assertNotNull(waitForElement(strStationType), "Fail to wait the element");
		upScrollTo();
		Offshoredelay();

		AppUtilities.delay(3000);
		AppUtilities.delay(3000);

		// Write Script to select different station type
		driver.findElementByAccessibilityId(station_type).click();
		AppUtilities.delay(3000);
		Offshoredelay();

		String station_type_display = "//XCUIElementTypeNavigationBar[contains(@name,'" + station_type + "')]";
		driver.findElementByXPath(station_type_display);
		driver.findElementByAccessibilityId(strStationToSelect).click();
		AppUtilities.delay(3000);
		log("Successfully clicked on strStationToSelect:  " + strStationType);

		AppUtilities.delay(3000);
		// Station Type Selected and Main Page of Station to select Menu Item
		log("The food type given is:" + strFoodItemType + ", Caffe location:" + aCaffeLocation);

		AppUtilities.delay(10000);

		String strItemNameLoc = getUILocator("menupage_item_name_by_name").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		Assert.assertNotNull(waitForElement(strItemNameLoc), "Fail to wait the element");

		String stritemLoc = getUILocator("menu_item_selection_to_order").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		Assert.assertTrue(clickElement(stritemLoc), "Fail to click the Menu item");
		
		//Menu Item Page to validate Label Sold Out
		for (Object soldOutLabels : labelDetails) {
			JSONObject labelDetail = (JSONObject) soldOutLabels;
			String labelName = (String) labelDetail.get("label_name");
			
			log("Sold out validation for Label:" + labelName);
			
			String labelSoldOutLoc = getUILocator("label_sold_out_main_page").replaceAll("<REPLACE_TEXT>", labelName);
			Assert.assertNotNull(waitForElement(labelSoldOutLoc), "Fail to wait for sold out label element");
			
			log("Successfully completed validation for Sold out Label " + labelName);
		}
		
		Offshoredelay();

		return this;
	}
	
	

	public GuestApp soldOutValidation(JSONArray itemsToOrder) {

		Assert.assertTrue(clickElement("tabbtn_menu_homepage"), "Failed to click the menu button the tab");

		AppUtilities.delay(1000);
		String menuItemName = null;
		String station = null;
		for (Object o : itemsToOrder) {
			JSONObject item = (JSONObject) o;
			menuItemName = (String) item.get("food_item_name");
			station = (String) item.get("select_station");
		}

		/*
		 * String strItem = getUILocator("cell_select_station_homepage");
		 * Offshoredelay(); String selectStationItem =
		 * strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
		 * Assert.assertTrue(clickElement(selectStationItem),
		 * "Failed to select the station:" + station);
		 */
		// wait for the food items list
		String strItem = getUILocator("cell_select_station_homepage");
		String strItemStation = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
		Assert.assertTrue(clickElement(strItemStation), "Failed to click Station");
		Assert.assertNotNull(waitForElement(strItemStation), "Failed to find the station name on the food list");
		String strSoldOutLocator = getUILocator("cell_sold_out_in_food_list_page")
				.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItemName);
		Assert.assertNotNull(waitForElement(strSoldOutLocator), "Failed to find the sold out menu");
		return this;
	}

	public GuestApp toGoValidation() {
		String strToGo = getUILocator("static_To_Go_in_thankyou_page");
		Assert.assertNotNull(waitForElement(strToGo), "Failed to find the To Go option in confirmation page");
		log("Successfully Verified To Go for Grab and Go stations");
		return this;
	}

	public GuestApp forHereValidation() {
		String strToGo = getUILocator("station_For_Here_in_thankyou_page");
		Assert.assertNotNull(waitForElement(strToGo), "Failed to find the For Here option in confirmation page");
		log("Successfully Verified For here in Confirmation page ");
		return this;
	}

	public GuestApp validatetoGoInMyOrderPage() {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");

		return this;
	}

	public GuestApp validateQuantityIncreaseStandard(JSONArray items) {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		log("Items to be ordered is:" + items.toJSONString());
		for (Object i : items) {
			JSONObject itemsToChoose = (JSONObject) i;
			String menuItem = (String) itemsToChoose.get("food_item_name");
			log("Food item name is: " + menuItem);
			String strQuantityLocator = getUILocator("btn_quantity_value_in_my_order_page")
					.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			log("Quantity for the added menu item is: " + strQuantityLocator);
			// String orderID = orderIDElement.getText();
			MobileElement strQuantity = waitForElement(strQuantityLocator);
			String strQuantityValue = strQuantity.getText();
			log("Quantity value is: " + strQuantityValue);
		}

		AppUtilities.delay(2000);
		// Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click
		// the My order option");
		return this;
	}

	public GuestApp validatePriceStandard() {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		String strPriceLocator = getUILocator("static_food_item_price_in_my_order_page");
		MobileElement strPrice = waitForElement(strPriceLocator);
		String strPriceValueText = strPrice.getText();
		String[] strPriceCart_array = strPriceValueText.split(",");
		String strPriceCart_array1 = strPriceCart_array[1];
		String strPriceCartValue = strPriceCart_array1.replaceAll("\\s", "");
		log("Menu price in cart is: " + strPriceCartValue);

		Assert.assertTrue(clickElement("tabbtn_menu_homepage"),
				"Failed to click the menu option after customizng the given food item");
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		Assert.assertTrue(clickElement("btn_payroll_deduction_in_my_order_page"),
				"Failed to click the Payroll Deduction button");
		AppUtilities.delay(2000);
		String strPriceInConfirmationPageLocator = getUILocator("static_food_item_price_in_thankyou_page");
		MobileElement strPriceInConfirmationPage = waitForElement(strPriceInConfirmationPageLocator);
		String strPriceInConfirmationPageValue = strPriceInConfirmationPage.getText();
		String[] strPriceConfirm_array = strPriceValueText.split(",");
		String strPriceConfirm_array1 = strPriceConfirm_array[1];
		String strPriceConfirmValue = strPriceConfirm_array1.replaceAll("\\s", "");
		log("Menu price in cart is: " + strPriceConfirmValue);
		log("Menu price in confirmation page is" + strPriceInConfirmationPageValue);
		// Comparing values
		boolean comparsionResult = strPriceCartValue.equals(strPriceConfirmValue);
		Assert.assertEquals(comparsionResult, true);
		log("The price value in cart and confirmation page is same");
		return this;
	}

	public GuestApp validateHidePayrollOff() {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		Assert.assertTrue(clickElement("tabbtn_menu_homepage"),
				"Failed to click the menu option after customizng the given food item");
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		Assert.assertTrue(clickElement("tabbtn_profile_homepage"), "Failed to click the Profile button");
		String strHidePayrollLocator = getUILocator("btn_hide_payroll_profile_page");
		MobileElement strHidePayroll = waitForElement(strHidePayrollLocator);
		String strHidePayrollValue = strHidePayroll.getText();
		log("The value of hide payroll option is: " + strHidePayrollValue);
		// Assert.assertTrue(clickElement("btn_hide_payroll_profile_page"), "Failed to
		// click the Hide Payroll button");

		return this;
	}

	public GuestApp validatevoucher() {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		Assert.assertTrue(clickElement("tabbtn_menu_homepage"),
				"Failed to click the menu option after customizng the given food item");
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		Assert.assertTrue(clickElement("tabbtn_profile_homepage"), "Failed to click the Profile button");

		Boolean Vouchers = waitForElementWithText("btn_vouchers_profile_page", "Vouchers");
		if (Vouchers) {
			log("User has vouchers available");
			Assert.assertTrue(clickElement("btn_vouchers_profile_page"), "Failed to click the Vouchers button");

		} else {
			log("User Doesnt have available vouchers");
		}

		return this;
	}

	public GuestApp validateVouchers(JSONArray vouchersList) {

		log("Inside Parameterised Function");

		for (Object o : vouchersList) {
			String voucherdetails = o.toString();
			log(voucherdetails);
			JSONObject voucher = (JSONObject) o;
			String Amount = (String) voucher.get("voucher_amount");
			String voucherType = (String) voucher.get("voucher_type");
			String voucherExpiryDate = (String) voucher.get("voucher_expiry_date");
			log("Voucher Amount is" + Amount + " " + voucherType + " " + voucherExpiryDate);
			if (waitForElementWithText("static_meal_vouchers_vouchers_page", "MEAL VOUCHERS")) {
				vouchersDetails(Amount, voucherType, voucherExpiryDate);
			} else {
				Assert.assertTrue(clickElement("btn_back_vouchers_page"),
						"Failed to find the Back button in vouchers page");
				vouchersDetails(Amount, voucherType, voucherExpiryDate);
			}
		}

		return this;
	}

	public GuestApp vouchersInAscendingOrder() throws Exception, ParseException {

		Assert.assertNotNull(waitForElement("btn_back_vouchers_page"),
				"Failed to find the Back button in vouchers page");
		Assert.assertNotNull(waitForElement("btn_profile_vouchers_page"),
				"Failed to find the Profile button in vouchers page");

		Boolean MealVouchers = waitForElementWithText("static_meal_vouchers_vouchers_page", "MEAL VOUCHERS");

		if (MealVouchers) {
			List<WebElement> voucherTable = waitForElements("voucher_list_profile_page");
			int noOfCells = voucherTable.size();

			if (noOfCells > 1) {
				log((Integer.toString(noOfCells)));

				log("User has voucher available");
				// JSONArray vouchersExpDates = new JSONArray();
				ArrayList<String> ExpDates = new ArrayList<String>();

				for (int i = 0; i < noOfCells; i++) {

					String ExpiryDateValue = null;
					// String voucherExpDate =
					// getUILocator("static_vouchers_expirydate_profile_page2");
					// Boolean ExpdatePresent =
					// String voucherAmount = getUILocator("btn_voucher_profile_page2");
					// voucherAmount = voucherAmount.replaceAll("<REPLACE_INDEX>",
					// Integer.toString(i));
					// Boolean voucherIsPresent = waitForElementWithText(voucherAmount, Amount);
					try {
						String voucherExpDate = getUILocator("static_vouchers_expirydate_profile_page");
						voucherExpDate = voucherExpDate.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
						// Boolean ExpiryDateOfVoucher = waitForElementWithText(voucherExpDate,
						// voucherExpiryDate);
						ExpiryDateValue = waitForElement(voucherExpDate).getText();
						log(ExpiryDateValue + " at Index " + i);
						ExpDates.add(ExpiryDateValue);
					} catch (Exception e) {
						log("Meal Program is found at this position" + e);
						// break;
					}
				}

				int sizeOfList = ExpDates.size();

				log(Integer.toString(sizeOfList));

				DateFormat df = new SimpleDateFormat("MMM dd, yyyy");
				Date Date1, Date2;

				for (int i = 0; i < sizeOfList; i++) {

					int j = i + 1;
					if (j < sizeOfList) {
						String expdate = ExpDates.get(i);
						log(expdate);
						Date1 = df.parse(expdate);
						System.out.println(Date1);
						String expdateNextNode = ExpDates.get(j);
						Date2 = df.parse(expdateNextNode);
						System.out.println(Date2);
						int Validate = Date1.compareTo(Date2);

						System.out.println(Validate);
						if (Validate < 0) {
							log("Date is smaller than previous date");
						} else if (Validate > 0) {
							log("Date is greater than previous date");
						} else if (Validate == 0) {
							log("Dates are equal");
							Validate = -1;
						}
						Assert.assertEquals(Validate, -1);
					}
				}
			} else {
				log("Only One Voucher Available for the user");
			}

		}

		return this;
	}

	public String voucherAmt;

	public GuestApp vouchersDetails(String Amount, String voucherType, String voucherExpiryDate) {
		Assert.assertNotNull(waitForElement("btn_back_vouchers_page"),
				"Failed to find the Back button in vouchers page");
		Assert.assertNotNull(waitForElement("btn_profile_vouchers_page"),
				"Failed to find the Profile button in vouchers page");

		Boolean MealVouchers = waitForElementWithText("static_meal_vouchers_vouchers_page", "MEAL VOUCHERS");
		long timeOut = 10;
		if (MealVouchers) {
			List<WebElement> voucherTable = waitForElements("voucher_list_profile_page");
			int noOfCells = voucherTable.size();
			log((Integer.toString(noOfCells)));
			for (int i = 0; i < noOfCells; i++) {
				voucherAmt = Amount;
				String voucherAmount = getUILocator("btn_voucher_profile_page2");
				voucherAmount = voucherAmount.replaceAll("<REPLACE_AMOUNT>", Amount);
				voucherAmount = voucherAmount.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
				Boolean voucherIsPresent = waitForElementWithText(voucherAmount, Amount, timeOut);

				// AppUtilities.delay(2000);
				String voucherExpDate = getUILocator("static_vouchers_expirydate_profile_page2");
				voucherExpDate = voucherExpDate.replaceAll("<REPLACE_DATE>", voucherExpiryDate);
				voucherExpDate = voucherExpDate.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
				Boolean ExpiryDateOfVoucher = waitForElementWithText(voucherExpDate, voucherExpiryDate, timeOut);

				if (voucherIsPresent && ExpiryDateOfVoucher) {
					log("User has voucher available");
					// Assert.assertNotNull(waitForElement("static_vouchers_expirydate_profile_page"),
					// "Failed to find the Expiry date in Vouchers list");
					// Offshoredelay();
					Assert.assertTrue(clickElement(voucherAmount), "Failed to click the Voucher button");

					Assert.assertNotNull(waitForElement("static_vouchertype_profile_page"),
							"Failed to find the Voucher type label");
					Assert.assertNotNull(waitForElement("static_balance_profile_page"),
							"Failed to find the balance label in voucher page");
					Assert.assertNotNull(waitForElement("static_expires_profile_page"),
							"Failed to find the expires label in the voucher page");

					String strItem = getUILocator("static_vouchertype_selected_profile_page1");
					strItem = strItem.replaceAll("<REPLACE_TYPE>", voucherType);

					Boolean typeExists = waitForElementWithText(strItem, voucherType, timeOut);
					if (typeExists) {
						Assert.assertNotNull(waitForElement(strItem), "Failed to find the Voucher type for voucher");

						strItem = getUILocator("static_balance_amount_selected_profile_page1");
						strItem = strItem.replaceAll("<REPLACE_AMOUNT>", Amount);
						Assert.assertNotNull(waitForElement(strItem), "Failed to find the Voucher type for voucher");

						strItem = getUILocator("static_expiry_date_selected_profile_page1");
						strItem = strItem.replaceAll("<REPLACE_DATE>", voucherExpiryDate);
						Assert.assertNotNull(waitForElement(strItem), "Failed to find the Voucher type for voucher");
						Assert.assertNotNull(waitForElement("btn_back_vouchers_page"),
								"Failed to find the Back button");
						Assert.assertNotNull(waitForElement("btn_share_voucher_page"),
								"Failed to find the Share button in voucher page");
						Assert.assertNotNull(waitForElement("static_about_voucher_page"),
								"Failed to find about text label");
						// Assert.assertNotNull(waitForElement("about_voucher_profile_page"), "Failed to
						// find the about text");
						break;
					} else {
						Assert.assertNotNull(clickElement("btn_back_vouchers_page"), "Failed to find the Back button");
					}

				}
			}
		} else {
			log("User Doesnt have any voucher");
		}
		return this;
	}

	public GuestApp transferVoucher(String transferAddress, String employeeType) {

		transferVoucher1();
		if (transferAddress.contains("@apple.com")) {
			if (employeeType.equals("Type1")) {
				Assert.assertTrue(typeText("textfield_to_transfer_page", transferAddress),
						"Failed to type the Transfer email address");
				Assert.assertTrue(clickElement("btn_send_transfer_page"), "Failed to click the send button");
				Assert.assertTrue(clickElement("incorrect_email_alert_transfer_page"),
						"Failed to click the ok button in alert");
				AppUtilities.delay(10000);
				// Assert.assertTrue(clickElement("btn_back_vouchers_page"), "Failed to find the
				// Back button");
			} else {
				log("for other type emails");
				Assert.assertTrue(typeText("textfield_to_transfer_page", transferAddress),
						"Failed to type the Transfer email address");
				Assert.assertTrue(clickElement("btn_send_transfer_page"), "Failed to click the send button");
				Assert.assertTrue(clickElement("incorrect_email_alert_transfer_page"),
						"Failed to click the ok button in alert");
				// Assert.assertTrue(clickElement("btn_back_vouchers_page"), "Failed to find the
				// Back button");
			}
		} else {
			log("for non apple emails");
			Assert.assertTrue(typeText("textfield_to_transfer_page", transferAddress),
					"Failed to type the Transfer email address");
			Assert.assertTrue(clickElement("btn_send_transfer_page"), "Failed to click the send button");
			Assert.assertNotNull(waitForElement("transfer_failed_alert_transfer_page"),
					"The invalid email address mess is not present");
			Assert.assertTrue(clickElement("incorrect_email_alert_transfer_page"),
					"Failed to click the ok button in alert");
		}
		return this;
	}

	public GuestApp validateStationName(JSONArray foodItems) {

		JSONObject foodItem = (JSONObject) foodItems.get(0);
		String station = (String) foodItem.get("select_station");
		String strItem = getUILocator("cell_station_food_list_page").replaceAll("<REPLACE_STATION_TO_SELECT>", station);
		// strItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>",itemToOrder);
		Assert.assertNotNull(waitForElement(strItem), "Failed to wait for station listing");
		return this;
	}

	public GuestApp transferVoucher() {

		Assert.assertTrue(clickElement("btn_share_voucher_page"), "Failed to click the Voucher button");

		Assert.assertNotNull(waitForElement("btn_cancel_transfer_page"),
				"Failed to find the Cancel button in voucher transfer page");
		Assert.assertNotNull(waitForElement("btn_send_transfer_page"),
				"Failed to find the Send button in voucher transfer page");
		Assert.assertNotNull(waitForElement("static_to_transfer_page"),
				"Failed to find the to label in voucher transfer page");
		Assert.assertNotNull(waitForElement("textfield_to_transfer_page"),
				"Failed to find the to text field in transfer page");
		Assert.assertNotNull(waitForElement("static_amount_transfer_page"),
				"Failed to find the Back button in vouchers page");
		return this;
	}

	public GuestApp transferVoucher1() {

		Assert.assertNotNull(waitForElement("btn_cancel_transfer_page"),
				"Failed to find the Cancel button in voucher transfer page");
		Assert.assertNotNull(waitForElement("btn_send_transfer_page"),
				"Failed to find the Send button in voucher transfer page");
		Assert.assertNotNull(waitForElement("static_to_transfer_page"),
				"Failed to find the to label in voucher transfer page");
		Assert.assertNotNull(waitForElement("textfield_to_transfer_page"),
				"Failed to find the to text field in transfer page");
		Assert.assertNotNull(waitForElement("static_amount_transfer_page"),
				"Failed to find the Back button in vouchers page");
		return this;
	}

	public GuestApp voucherAmountTransferPage() {

		transferVoucher();
		String strAmount = getUILocator("static_amount_value_transfer_page");
		strAmount = strAmount.replaceAll("<REPLACE_AMOUNT>", voucherAmt);
		Assert.assertNotNull(waitForElement(strAmount), "Failed to find the Profile button in vouchers page");
		Assert.assertTrue(clickElement("btn_cancel_transfer_page"),
				"Failed to find the Cancel button in voucher transfer page");
		log("Validated the transfer page");
		return this;
	}

	public GuestApp verifyPayrollButtonAuthScreen() {
		// String strProfileLocator = getUILocator("tabbtn_profile_homepage");
		Assert.assertTrue(clickElement("tabbtn_profile_homepage"), "Failed to click the Profile button");
		Assert.assertTrue(clickElement("btn_payroll_deduct_profile_page"), "Failed to choose Payroll Deduct button");
		String strPayrollLocator = getUILocator("btn_payroll_deduct_profile_page");
		MobileElement strPayrollDeduction = waitForElement(strPayrollLocator);
		String strPayrollDeductValue = strPayrollDeduction.getText();
		log("The value of Payroll Deduction button is: " + strPayrollDeductValue);
		return this;
	}

	public GuestApp verifyItemFromSpecialsScreen(JSONArray items) {
		Assert.assertTrue(clickElement("btn_special_homepage"), "Failed to click specials button");
		log("Items to be ordered is:" + items.toJSONString());
		for (Object i : items) {
			JSONObject itemsToChoose = (JSONObject) i;
			String menuItem = (String) itemsToChoose.get("food_item_name");
			String strItemLocator = getUILocator("cell_food_item_in_specials_page")
					.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertNotNull(waitForElement(strItemLocator), "Unable to find Meal time in Caffe Detail page ");
		}
		return this;
	}

	public GuestApp orderFromSpecialsScreen(JSONArray items) {
		// Assert.assertTrue(clickElement("btn_special_homepage"), "Failed to click
		// specials button");
		log("Items to be ordered is:" + items.toJSONString());
		for (Object i : items) {
			JSONObject itemsToChoose = (JSONObject) i;
			String menuItem = (String) itemsToChoose.get("food_item_name");
			String menuPrice = (String) itemsToChoose.get("food_item_price");
			String strItemLocator = getUILocator("cell_food_price_in_specials_page")
					.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			String strItemPriceLocator = strItemLocator.replaceAll("<REPLACE_ITEM_PRICE>", menuPrice);
			Assert.assertTrue(clickElement(strItemPriceLocator), "Failed to choose item price from Specials screen");
			String strAddToOrder = getUILocator("cell_food_item_price_to_add_to_order_page")
					.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertTrue(clickElement(strAddToOrder), "Failed to choose Add to Order from Specials screen");
		}
		return this;
	}

	public GuestApp verifySpecialMenu(JSONArray items) {
		Assert.assertTrue(clickElement("btn_special_homepage"), "Failed to click specials button");
		log("Items to be ordered is:" + items.toJSONString());
		for (Object i : items) {
			JSONObject itemsToChoose = (JSONObject) i;
			String menuItem = (String) itemsToChoose.get("food_item_name");
			log("The menu item name is: " + menuItem);
			String menuPrice = (String) itemsToChoose.get("food_item_price");
			log("The menu item price is: " + menuPrice);
			String strItemLocator = getUILocator("cell_food_item_in_specials_page")
					.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertNotNull(waitForElement(strItemLocator), "Failed to validate the Item name in Specials menu");
			String strItemPriceLocator = strItemLocator.replaceAll("<REPLACE_ITEM_PRICE>", menuPrice);
			Assert.assertNotNull(waitForElement(strItemPriceLocator),
					"Failed to validate the Item price in Specials menu");
		}
		return this;
	}

	public GuestApp verifyApplePayForType4() {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		AppUtilities.delay(2000);

		Assert.assertTrue(clickElement("tabbtn_menu_homepage"),
				"Failed to click the menu option after customizng the given food item");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		String strMessageType4Locator = getUILocator("static_message_for_type4_user_in_my_order_page");
		MobileElement strMessageType4 = waitForElement(strMessageType4Locator);
		String strMessageText = strMessageType4.getText();
		// Assert.assertNotNull(waitForElement(strMessageType4Locator), "Failed to find
		// the Payroll Deduction button");
		// Assert.assertTrue(clickElement("btn_payroll_deduction_in_my_order_page"),
		// "Failed to click the Payroll Deduction button");
		// String strThankYou=getUILocator("static_thankyou_thankyou_page");
		// Assert.assertNotNull(waitForElement(strThankYou), "Failed to find the Order
		// Confirmation page");
		log("The message for Type 4 user is: " + strMessageText);
		return this;
	}

	public GuestApp validateCaffeBriefAddress(JSONArray caffe) {
		Assert.assertTrue(clickElement("btn_caffe_homepage"), "Failed to click the Caffe button");
		AppUtilities.delay(2000);
		log("Caffe details is: " + caffe.toJSONString());
		for (Object i : caffe) {
			JSONObject caffeToChoose = (JSONObject) i;
			String caffeName = (String) caffeToChoose.get("select_caffe");
			String caffeAddress = (String) caffeToChoose.get("Brief_Address");
			String strCaffeName = getUILocator("static_caffe_name_in_caffe_page")
					.replaceAll("<REPLACE_CAFFE_TO_SELECT>", caffeName);
			String strCaffeAddressLocator = getUILocator("static_caffe_brief_address_in_caffe_page")
					.replaceAll("<REPLACE_CAFFE_BRIEF_ADDRESS>", caffeAddress);
			Assert.assertNotNull(waitForElement(strCaffeAddressLocator), "Failed to find brief address of caffe");
			log("Successfully verified the caffe brief address");
		}
		return this;
	}

	public GuestApp validateCaffeNameAndCaffeAddress(String caffename, String caffeadress) {
		log("Before validateCaffeNameAndCaffeAddress the caffe name" + caffeadress + " name" + caffename);

		String locator = getUILocator("m_caffe_station_name");
		locator = locator.replaceAll("<REPLACE_NAME>", caffename);
		Assert.assertNotNull(locator, "Failed to find caffe name data");
		Assert.assertTrue(waitForElementWithText(locator, caffename), "Failed to match the content of caffe name");
		log("Successfully verified the caffe name is matching " + locator);

		String addresslocator = getUILocator("m_caffe_address");
		addresslocator = addresslocator.replaceAll("<REPLACE_ADDRESS>", caffeadress);
		Assert.assertNotNull(addresslocator, "Failed to find caffe address data");
		Assert.assertTrue(waitForElementWithText(addresslocator, caffeadress),
				"Failed to match the content of caffe name");
		log("Successfully verified the caffe brief address");

		String strdone = getUILocator("btn_done_info");
		Assert.assertNotNull(waitForElement(strdone), "Failed to find done button data");
		Assert.assertTrue(clickElement(strdone), "Failed to click on done button");
		log("Successfully verified the caffe brief address");
		Offshoredelay();
		//Offshoredelay();

		String stritemone = getUILocator("landing_browser_page");
		Assert.assertNotNull(waitForElement(stritemone), "Failed to land in browser caffee home page");
		// Assert.assertTrue(clickElement(stritemone),"Failed to click on done button");
		log("Successfully landed to browser caffee home page");
		Offshoredelay();
		//Offshoredelay();

		return this;
	}

	public GuestApp selectMoreInfo(String uimoreinfo) {
		String locator = getUILocator("station_more_info");
		Assert.assertNotNull(waitForElement("browse_menu"), "Failed to find the browser menu option");
		Assert.assertNotNull(waitForElement(locator), "Failed to find More Information label");
		Assert.assertTrue(clickElement(locator), "Failed to click on More Information label");
		log("Successfully clicked on more Information button to view the caffe name");
		Offshoredelay();
		return this;
	}

	public GuestApp validateCaffeDetailAddress(JSONArray caffe) {
		Assert.assertTrue(clickElement("btn_caffe_homepage"), "Failed to click the Caffe button");
		AppUtilities.delay(2000);
		log("Caffe details is: " + caffe.toJSONString());
		for (Object i : caffe) {
			JSONObject caffeToChoose = (JSONObject) i;
			String caffeName = (String) caffeToChoose.get("select_caffe");
			String caffeAddress = (String) caffeToChoose.get("Detailed_Address");
			Assert.assertTrue(clickElement("btn_caffe_in_caffe_page"), "Failed to choose the caffe from caffe page");
			String strCaffeAddressLocator = getUILocator("static_caffe_detail_address_in_caffe_page")
					.replaceAll("<REPLACE_CAFFE_DETAIL_ADDRESS>", caffeAddress);
			Assert.assertNotNull(waitForElement(strCaffeAddressLocator), "Failed to find detail address of caffe");
			log("Successfully verified the caffe detail address");
		}
		return this;
	}

	public GuestApp validateCaffeBriefMealTime(JSONArray caffe) {
		Assert.assertTrue(clickElement("btn_caffe_homepage"), "Failed to click the Caffe button");
		AppUtilities.delay(2000);
		log("Caffe details is: " + caffe.toJSONString());
		for (Object i : caffe) {
			JSONObject caffeToChoose = (JSONObject) i;
			String caffeName = (String) caffeToChoose.get("select_caffe");
			String caffeMealTime = (String) caffeToChoose.get("meal_time_brief");
			log("The caffe meal time is: " + caffeMealTime);
			String strCaffeMealTimeLocator = getUILocator("static_caffe_brief_mealtime_in_caffe_page")
					.replaceAll("<REPLACE_CAFFE_MEAL_TIME>", caffeMealTime);
			Assert.assertNotNull(waitForElement(strCaffeMealTimeLocator),
					"Unable to find Meal time in Caffe Detail page ");
			log("Successfully verified the caffe brief Meal time");
		}
		return this;
	}

	public GuestApp validateCaffeDetailMealTime(JSONArray caffe) {
		Assert.assertTrue(clickElement("btn_caffe_homepage"), "Failed to click the Caffe button");
		AppUtilities.delay(2000);
		log("Caffe details is: " + caffe.toJSONString());
		for (Object i : caffe) {
			JSONObject caffeToChoose = (JSONObject) i;
			String caffeName = (String) caffeToChoose.get("select_caffe");
			String caffeMealTime = (String) caffeToChoose.get("meal_time_detail");
			log("The caffe meal time is: " + caffeMealTime);
			Assert.assertTrue(clickElement("btn_caffe_in_caffe_page"), "Failed to choose the caffe from caffe page");
			String strCaffeMealTimeLocator = getUILocator("static_caffe_detail_mealtime_in_caffe_page")
					.replaceAll("<REPLACE_CAFFE_MEAL_TIME>", caffeMealTime);
			Assert.assertNotNull(waitForElement(strCaffeMealTimeLocator),
					"Unable to find Meal time in Caffe Detail page ");
			log("Successfully verified the caffe detail meal time");
		}
		return this;
	}

	public GuestApp validateCaffeMealTimeLink(JSONArray caffe) {
		Assert.assertTrue(clickElement("btn_caffe_homepage"), "Failed to click the Caffe button");
		AppUtilities.delay(2000);
		log("Caffe details is: " + caffe.toJSONString());
		for (Object i : caffe) {
			JSONObject caffeToChoose = (JSONObject) i;
			String caffeName = (String) caffeToChoose.get("select_caffe");
			String caffeMealTime = (String) caffeToChoose.get("meal_name_brief");
			log("caffeMealTime is: " + caffeMealTime);
			Assert.assertTrue(clickElement("btn_caffe_in_caffe_page"), "Failed to choose the caffe from caffe page");
			Assert.assertTrue(clickElement("static_caffe_detail_mealtype_in_caffe_page"),
					"Failed to choose Caffe meal time link");
			String strCaffeMealTimeLocator = getUILocator("static_caffe_detail_mealtype_in_caffemeal_page");
			Assert.assertNotNull(waitForElement(strCaffeMealTimeLocator), "Failed to choose the caffe meal time link");
			log("Successfully verified the caffe meal time link");
		}
		return this;
	}

	public GuestApp validateMenuItemInCaffePage(JSONArray caffe) {
		log("Caffe details is: " + caffe.toJSONString());
		for (Object i : caffe) {
			JSONObject caffeToChoose = (JSONObject) i;
			String caffeMealName = (String) caffeToChoose.get("meal_item_name");
			String caffeMealTime = (String) caffeToChoose.get("meal_item_price");
			String strCaffeMealNameLocator = getUILocator("static_food_item_name_in_caffe_detailed_page")
					.replaceAll("<REPLACE_ITEM_NAME>", caffeMealName);
			Assert.assertNotNull(waitForElement(strCaffeMealNameLocator),
					"Failed to find the Item name in Caffe Detailed page");
			String strCaffeMealTimeLocator = getUILocator("static_food_item_price_in_caffe_detailed_page")
					.replaceAll("<REPLACE_ITEM_PRICE>", caffeMealTime);
			Assert.assertNotNull(waitForElement(strCaffeMealTimeLocator),
					"Failed to find the Item Price in Caffe Detailed Page");
			log("Successfully verified the menu item in caffe page");
		}
		return this;
	}

	public GuestApp validateSpecials(JSONArray caffe) {
		log("Caffe details is: " + caffe.toJSONString());
		for (Object i : caffe) {
			JSONObject caffeToChoose = (JSONObject) i;
			String caffeStation1 = (String) caffeToChoose.get("select_station1");
			String caffeStation2 = (String) caffeToChoose.get("select_station2");
			String caffeItem1 = (String) caffeToChoose.get("specials1");
			String caffeItem2 = (String) caffeToChoose.get("specials2");

			Assert.assertTrue(clickElement("tabbtn_menu_homepage"));
			String strItem = getUILocator("cell_select_station_homepage");
			String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeStation1);
			Assert.assertTrue(clickElement(selectStationItem), "Failed to select the station:" + caffeStation1);
			String strItem1 = getUILocator("static_food_item_name_in_food_item_page")
					.replaceAll("<REPLACE_STATION_TO_SELECT>", caffeItem1);
			strItem1 = strItem1.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem1);
			Assert.assertTrue(clickElement(strItem1));
			Assert.assertTrue(clickElement("btn_caffe_homepage"));
			String itemNameLocator = getUILocator("static_food_item_name_in_food_item_detail_page")
					.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem1);
			String itemName = itemNameLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem1);
			MobileElement itemName1 = waitForElement(itemName);
			String strMenuItemName = itemName1.getText();
			log("The first Item in food table is: " + strMenuItemName);

			Assert.assertTrue(clickElement("tabbtn_menu_homepage"));
			Assert.assertTrue(clickElement("back_button_food_item_details_page"), "Failed to find back button");
			Assert.assertTrue(clickElement("back_button_food_item_details_page"), "Failed to find back button");
			String strStationLocator = getUILocator("cell_select_station_homepage");
			String selectStationItem1 = strStationLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeStation2);
			Assert.assertTrue(clickElement(selectStationItem1), "Failed to select the station:" + caffeStation2);
			String strItem2 = getUILocator("static_food_item_name_in_food_item_page")
					.replaceAll("<REPLACE_STATION_TO_SELECT>", caffeItem2);
			strItem2 = strItem2.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem2);
			Assert.assertTrue(clickElement(strItem2));
			Assert.assertTrue(clickElement("btn_caffe_homepage"));
			String itemNameLocator1 = getUILocator("static_food_item_name_in_food_item_detail_page")
					.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem2);
			String itemName2 = itemNameLocator1.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem2);
			MobileElement itemName3 = waitForElement(itemName2);
			String strMenuItemName1 = itemName3.getText();
			log("The second Item in food table is: " + strMenuItemName1);

			Assert.assertTrue(clickElement("btn_caffe_homepage"));
			Assert.assertTrue(clickElement("btn_caffe_in_caffe_page"), "Failed to choose the caffe from caffe page");
			Assert.assertTrue(clickElement("static_caffe_detail_mealtype_in_caffe_page"),
					"Failed to choose Caffe meal time link");
			String strCaffeMealNameLocator = getUILocator("static_food_item_name_in_caffe_detailed_page")
					.replaceAll("<REPLACE_ITEM_NAME>", strMenuItemName);
			Assert.assertNotNull(waitForElement(strCaffeMealNameLocator),
					"Failed to find the Specials Item1 in Caffe Detailed page");

			String strCaffeMealNameLocator1 = getUILocator("static_food_item_name_in_caffe_detailed_page")
					.replaceAll("<REPLACE_ITEM_NAME>", strMenuItemName1);
			Assert.assertNotNull(waitForElement(strCaffeMealNameLocator1),
					"Failed to find the Specials Item1 in Caffe Detailed page");

		}
		log("Successfully validated Specials in caffe page");
		return this;
	}

	public GuestApp validateStandards(JSONArray caffe) {
		log("Caffe details is: " + caffe.toJSONString());
		for (Object i : caffe) {
			JSONObject caffeToChoose = (JSONObject) i;
			String caffeStation1 = (String) caffeToChoose.get("select_station1");
			String caffeStation2 = (String) caffeToChoose.get("select_station2");
			String caffeItem1 = (String) caffeToChoose.get("standards1");
			String caffeItem2 = (String) caffeToChoose.get("standards2");

			Assert.assertTrue(clickElement("tabbtn_menu_homepage"));
			Assert.assertTrue(clickElement("back_button_food_item_details_page"), "Failed to find back button");
			Assert.assertTrue(clickElement("back_button_food_item_details_page"), "Failed to find back button");
			String strItem = getUILocator("cell_select_station_homepage");
			String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeStation1);
			Assert.assertTrue(clickElement(selectStationItem), "Failed to select the station:" + caffeStation1);
			String strItem1 = getUILocator("static_food_item_name_in_food_item_page")
					.replaceAll("<REPLACE_STATION_TO_SELECT>", caffeItem1);
			strItem1 = strItem1.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem1);
			Assert.assertTrue(clickElement(strItem1));
			Assert.assertTrue(clickElement("btn_caffe_homepage"));
			Assert.assertTrue(clickElement("btn_standard_food_item_in_caffe_detailed_page"),
					"Failed to choose Standard option in Caffe page");
			String itemNameLocator = getUILocator("static_food_item_name_in_food_item_detail_page")
					.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem1);
			String itemName = itemNameLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem2);
			MobileElement itemName1 = waitForElement(itemName);
			String strMenuItemName = itemName1.getText();
			log("The first Standard Item in food table is: " + strMenuItemName);

			Assert.assertTrue(clickElement("tabbtn_menu_homepage"));
			Assert.assertTrue(clickElement("back_button_food_item_details_page"), "Failed to find back button");
			Assert.assertTrue(clickElement("back_button_food_item_details_page"), "Failed to find back button");
			String strStationLocator = getUILocator("cell_select_station_homepage");
			String selectStationItem1 = strStationLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeStation2);
			Assert.assertTrue(clickElement(selectStationItem1), "Failed to select the station:" + caffeStation2);
			String strItem2 = getUILocator("static_food_item_name_in_food_item_page")
					.replaceAll("<REPLACE_STATION_TO_SELECT>", caffeItem2);
			strItem2 = strItem2.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem2);
			Assert.assertTrue(clickElement(strItem2));
			Assert.assertTrue(clickElement("btn_caffe_homepage"));
			String itemNameLocator1 = getUILocator("static_food_item_name_in_food_item_detail_page")
					.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem2);
			String itemName2 = itemNameLocator1.replaceAll("<REPLACE_ITEM_TO_SELECT>", caffeItem2);
			MobileElement itemName3 = waitForElement(itemName2);
			String strMenuItemName1 = itemName3.getText();
			log("The second Standard Item in food table is: " + strMenuItemName1);

			Assert.assertTrue(clickElement("btn_caffe_homepage"));
			Assert.assertTrue(clickElement("btn_caffe_in_caffe_page"), "Failed to choose the caffe from caffe page");
			Assert.assertTrue(clickElement("static_caffe_detail_mealtype_in_caffe_page"),
					"Failed to choose Caffe meal time link");
			Assert.assertTrue(clickElement("btn_standard_food_item_in_caffe_detailed_page"),
					"Failed to choose Standard option in Caffe page");
			String strCaffeMealNameLocator = getUILocator("static_food_item_name_in_caffe_detailed_page")
					.replaceAll("<REPLACE_ITEM_NAME>", strMenuItemName);
			Assert.assertNotNull(waitForElement(strCaffeMealNameLocator),
					"Failed to find the Specials Item1 in Caffe Detailed page");

			String strCaffeMealNameLocator1 = getUILocator("static_food_item_name_in_caffe_detailed_page")
					.replaceAll("<REPLACE_ITEM_NAME>", strMenuItemName1);
			Assert.assertNotNull(waitForElement(strCaffeMealNameLocator1),
					"Failed to find the Specials Item1 in Caffe Detailed page");

		}
		log("Successfully validated standard in caffe page");
		return this;
	}

	public GuestApp StatusofOrder() {
		log("Items read from Order Thank you page:" + itemListFromPage.toJSONString());
		Assert.assertNotNull(clickElement("btn_done_thankyou_page"),
				"Failed to click the payroll deduction button in the my order");
		Assert.assertNotNull(clickElement("Status_tab_Completed_Page"), "Failed to click the Status tab");
		int orderIndex = 0;
		for (Object item : itemListFromPage) {
			JSONObject itemDetails = (JSONObject) item;
			String ordernumber = (String) itemDetails.get("orderid");
			ordernumber = ordernumber.replaceFirst("Order #", "#");
			log(ordernumber);
			// strItem =
			// getUILocator("Order_Number_Completed_Page").replaceAll("<REPLACE_ORDER_INDEX>",
			// Integer.toString(orderIndex));
			String strItem = getUILocator("Order_Time_Completed_Page").replaceAll("<REPLACE_ORDER>", ordernumber);
			strItem = strItem.replaceAll("<REPLACE_ORDER_INDEX>", Integer.toString(orderIndex));
			log(strItem);
			Assert.assertNotNull(waitForElement(strItem), "Order Status not found at this position");
			log("Status for" + ordernumber + "found");
			orderIndex++;
		}
		return this;
	}

	public GuestApp ChangeOrderQuantity(String numberOfItems) {
		String myOrderButton = getUILocator("tabbtn_myorder_homepage");
		Assert.assertTrue(clickElement(myOrderButton),
				"Failed to find the My Order tab btn after clicking the item btn add ");
		// Assert.assertNotNull(waitForElement("SelectQuantity_my_order_page"), "Failed
		// to Open My Order page");
		Offshoredelay();
		Assert.assertTrue(clickElement("SelectQuantityBtn_my_order_page"),
				"Failed to click the Select Quantity button in My order page");

		MobileElement PickerWheel1 = waitForElement("IncreaseNoOfItems_my_order_page");
		log("Able to identify the picker wheel");
		PickerWheel1.sendKeys(numberOfItems);
		log("Picker.....");
		return this;
	}

	public GuestApp ChangeOrderQuantityWhenLimited(String numberOfItems) {
		String myOrderButton = getUILocator("tabbtn_myorder_homepage");
		Assert.assertTrue(clickElement(myOrderButton),
				"Failed to find the My Order tab btn after clicking the item btn add ");
		// Assert.assertNotNull(waitForElement("SelectQuantity_my_order_page"), "Failed
		// to Open My Order page");
		Offshoredelay();
		Assert.assertTrue(clickElement("SelectQuantityBtn_my_order_page"),
				"Failed to click the Select Quantity button in My order page");

		MobileElement PickerWheel1 = waitForElement("IncreaseNoOfItems_my_order_page");
		log("Able to identify the picker wheel");
		// Assert.assertNull(PickerWheel1.sendKeys(numberOfItems));
		PickerWheel1.getAttribute("");
		PickerWheel1.sendKeys(numberOfItems);
		log("Picker.....");
		return this;
	}

	public GuestApp voucherAvailablity() throws Exception {
		String myOrderButton = getUILocator("btn_order_to");
		Assert.assertTrue(clickElement(myOrderButton),
				"Failed to find the My Order tab btn after clicking the item btn add ");
		AppUtilities.delay(10000);
	log("Total order layout is open to choose the mode of payment -Meal Vouchers/Apple Payroll Deduction/Meal Program");


		Boolean Displ = false;
		try {
			MobileElement Avail = waitForElement("available_list_of_vouchers_my_order_page");
			Displ = Avail.isDisplayed();
		} catch (Exception e) {
			log("unable to find Voucher element" + e);
		}
		
		
		if (Displ) {
			log("User has vouchers available in the checkout page");
			Assert.assertNotNull(waitForElement("btn_payroll_deduction_in_my_order_page"),
					"Payroll deduction button not found at this position when vouchers are available");
		} else {
			log("User Doesnt have available vouchers");
			Assert.assertNotNull(waitForElement("btn_payroll_deduction_in_my_order_page"),
					"Payroll deduction button not found at this position when vouchers are not available");
		}
		log("Validated the vouchers are available to place the order! ");
		return this;
	}

	public GuestApp voucherDetails() {

		Assert.assertTrue(clickElement("label_available_vouchers_my_order_page"),
				"Failed to click available voucher label");
		List<WebElement> voucherList = waitForElements("available_list_of_vouchers");
		int numberOfVouchers = voucherList.size();
		log(Integer.toString(numberOfVouchers));

		HashMap<Integer, String> VoucherTypeAndAmount = new HashMap<Integer, String>();
		HashMap<Integer, String> VoucherValidation = new HashMap<Integer, String>();

		for (int i = 1; i <= voucherList.size(); i++) {
			
			String voucherTitleAndAmount = getUILocator("available_voucher_title_amount_my_order_page");
			voucherTitleAndAmount = voucherTitleAndAmount.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			String voucherExpire = getUILocator("available_voucher_detail_my_order_page");
			voucherExpire = voucherExpire.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			VoucherTypeAndAmount.put(i, waitForElementAndGetText(voucherTitleAndAmount));
			VoucherValidation.put(i, waitForElementAndGetText(voucherExpire));
		}
		for (int i = 1; i <= voucherList.size(); i++) {
			log(VoucherTypeAndAmount.get(i));
			log(VoucherValidation.get(i));
			
			
		}
		return this;
	}

	public GuestApp voucherDetailsMealProgram() {

		/*Assert.assertTrue(clickElement("label_available_vouchers_my_order_page"),
				"Failed to click available voucher label");*/
		List<WebElement> voucherList = waitForElements("available_list_of_Meal_program_my_order_page");
		int numberOfVouchers = voucherList.size();
		log(Integer.toString(numberOfVouchers));

		//JSONObject voucherListApp = null;

		for (int i = 1; i <= voucherList.size(); i++) {
			String voucherTitle = getUILocator("available_meal_program_amount_and_title");
			voucherTitle = voucherTitle.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			log(voucherTitle);
		
			
			String voucherUsageTime = getUILocator("available_meal_program_expire_date");
			voucherUsageTime = voucherUsageTime.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			log(voucherUsageTime);

			String title = waitForElementAndGetText(voucherTitle);
			log(title);
			String usageTime = null;

			MobileElement uTime = waitForElement(voucherUsageTime);
			usageTime = uTime.getAttribute("value");
			log(usageTime);
			String amount = waitForElementAndGetText(voucherTitle);
			log(amount);
			JSONObject detailApp = new JSONObject();
			detailApp.put("vouchername", title);
			detailApp.put("amount", amount);

			if (usageTime.contains("$")) {
				usageTime = null;
				detailApp.put("time", usageTime);
				detailApp.put("vouchertype", "Meal Voucher");
			} else {
				detailApp.put("time", usageTime);
				detailApp.put("vouchertype", "Meal Program");
			}
			log(detailApp.toJSONString());
			/*
			 * JSONArray fullDetail = new JSONArray(); fullDetail.add(detailApp);
			 * voucherListApp.put("VouchersList", fullDetail);
			 */
		}
		//log(detailApp.toJSONString());

		/*Assert.assertTrue(clickElement("label_available_vouchers_my_order_page"),
				"Failed to click available voucher label");*/
		List<WebElement> voucherList1 = waitForElements("available_list_of_Meal_vouchers_my_order_page");
		int numberOfVouchers1 = voucherList1.size();
		log(Integer.toString(numberOfVouchers));

		//JSONObject voucherListApp = null;

		for (int i = 1; i <= voucherList.size(); i++) {
			String voucherTitle = getUILocator("available_meal_voucher_amount_and_title");
			voucherTitle = voucherTitle.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			log(voucherTitle);
		
			
			String voucherUsageTime = getUILocator("available_meal_voucher_expire_date");
			voucherUsageTime = voucherUsageTime.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			log(voucherUsageTime);

			String[] voucherAmtText = voucherTitle.split(" ");
			
			String amount=voucherAmtText[0];
			String type=voucherAmtText[1]+voucherAmtText[voucherAmtText.length-1];
			
			String[] voucherUsageTimeText = voucherUsageTime.split(" ");
			String time=voucherUsageTimeText[3]+voucherUsageTimeText[voucherUsageTimeText.length-1];
			
			log("The xpath of element "+voucherTitle+" : and amount is "+amount);
			log("The xpath of element "+voucherTitle+" : and type is "+type);
			log("The xpath of element "+voucherTitle+" : and expire time is "+time);
			
	}
			
			
			
			
		return this;
	}

	public GuestApp selectVoucher(JSONArray vouchersList) {

		Assert.assertTrue(clickElement("available_list_of_vouchers_my_order_page"), "Failed to click Available vouchers");

		log("Vouchers are displayed");
		// Assert.assertTrue(clickElement("btn_payroll_deduction_in_my_order_page"),
		// "Failed to click vouchers btn");
		Double voucherTotalAmount = 0.00;
		for (Object o : vouchersList) {
			String voucherdetails = o.toString();
			log(voucherdetails);
			JSONObject voucher = (JSONObject) o;
			String Amount = (String) voucher.get("voucher_amount");
			selectVoucher(Amount);
			voucherTotalAmount = voucherTotalAmount + Double.parseDouble(Amount);
			log(Double.toString(voucherTotalAmount));
		}
		return this;

	}

	public GuestApp selectVoucherAfterMP(JSONArray vouchersList) {

		Assert.assertTrue(clickElement("label_applied_vouchers_my_order_page"), "Failed to click Available vouchers");

		log("Vouchers are displayed");
		// Assert.assertTrue(clickElement("btn_payroll_deduction_in_my_order_page"),
		// "Failed to click vouchers btn");
		Double voucherTotalAmount = 0.00;
		for (Object o : vouchersList) {
			String voucherdetails = o.toString();
			log(voucherdetails);
			JSONObject voucher = (JSONObject) o;
			String Amount = (String) voucher.get("voucher_amount");
			String strItem = getUILocator("available_voucher_my_order_page1");
			strItem = strItem.replaceAll("<REPLACE_AMOUNT>", Amount);
			Assert.assertTrue(clickElement(strItem), "Failed to click vouchers btn");
			voucherTotalAmount = voucherTotalAmount + Double.parseDouble(Amount);
			log(Double.toString(voucherTotalAmount));
		}
		return this;

	}

	public GuestApp selectVoucher(String Amount) {
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("available_list_of_vouchers_my_order_page"), "Failed to click Available vouchers");
		log("Vouchers are displayed");
		String strItem = getUILocator("available_voucher_title_amount_my_order_page");
		strItem = strItem.replaceAll("<REPLACE_AMOUNT>", Amount);
		Assert.assertTrue(clickElement(strItem), "Failed to click vouchers btn");
		Offshoredelay();
		return this;

	}

	public GuestApp toCloseSelectVoucher() {
		Assert.assertTrue(clickElement("label_available_vouchers_my_order_page"), "Failed to click Available vouchers");
		return this;
	}

	public GuestApp selectVoucherToUncheck(String Amount) {
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("label_applied_vouchers_my_order_page"), "Failed to click Available vouchers");
		log("Vouchers are displayed");
		String strItem = getUILocator("available_voucher_my_order_page1");
		strItem = strItem.replaceAll("<REPLACE_AMOUNT>", Amount);
		// log(strItem);
		// MobileElement Total_due_amount_Element =waitForElement(strItem);

		Assert.assertTrue(clickElement(strItem), "Failed to click vouchers btn");
		/*
		 * MobileElement Total_due_amount_Element =waitForElement(strItem);
		 * MobileElement cell= (MobileElement)
		 * Total_due_amount_Element.findElementByXPath(Total_due_amount_Element.
		 * getAttribute("xpath") + "/.."); String value =cell.getAttribute("value");
		 * 
		 * if (value != null){ log("Selected voucher"); }else{ do{
		 * Assert.assertTrue(clickElement(strItem), "Failed to click vouchers btn");
		 * }while(value != null); log("Selected voucher"); }
		 */
		Offshoredelay();
		return this;

	}

	public GuestApp selectMealProgram(JSONArray vouchersList) {

		Assert.assertTrue(clickElement("available_list_of_vouchers_my_order_page"), "Failed to click Available vouchers");

		log("Vouchers are displayed");
		// Assert.assertTrue(clickElement("btn_payroll_deduction_in_my_order_page"),
		// "Failed to click vouchers btn");
		Double voucherTotalAmount = 0.00;
		for (Object o : vouchersList) {
			String voucherdetails = o.toString();
			log(voucherdetails);
			JSONObject voucher = (JSONObject) o;
			String Amount = (String) voucher.get("voucher_amount");
			String voucherName = (String) voucher.get("voucher_name");
			String voucherUsage = (String) voucher.get("usage");

			/*
			 * String strItem = getUILocator("available_voucher_my_order_page1"); strItem =
			 * strItem.replaceAll("<REPLACE_AMOUNT>", Amount);
			 * Assert.assertTrue(clickElement(strItem), "Failed to click vouchers btn");
			 */

			String strItem = getUILocator("available_list_of_Meal_vouchers_my_order_page");
			strItem = strItem.replaceAll("<REPLACE_MP_NAME>", voucherName);
			strItem = strItem.replaceAll("<REPLACE_AMOUNT>", voucherUsage);

			strItem = getUILocator("available_list_of_Meal_vouchers_my_order_page");
			strItem = strItem.replaceAll("<REPLACE_MP_NAME>", voucherName);
			strItem = strItem.replaceAll("<REPLACE_AMOUNT>", Amount);

			Assert.assertTrue(clickElement(strItem), "Failed to click vouchers btn");
			voucherTotalAmount = voucherTotalAmount + Double.parseDouble(Amount);
			log(Double.toString(voucherTotalAmount));
		}

		Assert.assertTrue(clickElement("available_list_of_vouchers_my_order_page"), "Failed to click Available vouchers");

		return this;

	}

	public GuestApp validateMPIsNotPresent(JSONArray vouchersList) {

		Assert.assertTrue(clickElement("label_available_vouchers_my_order_page"), "Failed to click Available vouchers");

		log("Vouchers are displayed");
		// Assert.assertTrue(clickElement("btn_payroll_deduction_in_my_order_page"),
		// "Failed to click vouchers btn");
		Double voucherTotalAmount = 0.00;
		for (Object o : vouchersList) {
			String voucherdetails = o.toString();
			log(voucherdetails);
			JSONObject voucher = (JSONObject) o;
			String Amount = (String) voucher.get("voucher_amount");
			String voucherName = (String) voucher.get("voucher_name");
			String voucherUsage = (String) voucher.get("usage");

			/*
			 * String strItem = getUILocator("available_voucher_my_order_page1"); strItem =
			 * strItem.replaceAll("<REPLACE_AMOUNT>", Amount);
			 * Assert.assertTrue(clickElement(strItem), "Failed to click vouchers btn");
			 */

			String strItem = getUILocator("available_meal_program_my_order_page");
			strItem = strItem.replaceAll("<REPLACE_MP_NAME>", voucherName);
			strItem = strItem.replaceAll("<REPLACE_AMOUNT>", voucherUsage);
			Assert.assertNull(waitForElement(strItem), "Meal program and VoucherUsage is present");

			/*
			 * strItem = getUILocator("available_meal_program_my_order_page"); strItem =
			 * strItem.replaceAll("<REPLACE_MP_NAME>", voucherName); strItem =
			 * strItem.replaceAll("<REPLACE_AMOUNT>", Amount);
			 * 
			 * Assert.assertNull(waitForElement(strItem), "Meal program amount is present");
			 * voucherTotalAmount = voucherTotalAmount + Double.parseDouble(Amount);
			 * log(Double.toString(voucherTotalAmount));
			 */
		}

		Assert.assertTrue(clickElement("label_available_vouchers_my_order_page"), "Failed to click Available vouchers");

		return this;

	}

	public GuestApp validateMealProgram(JSONArray mealProgramList) {

		Boolean mealProgram = waitForElementWithText("static_enrolled_meal_program", "ENROLLED MEAL PROGRAMS");
		if (mealProgram) {
			log("User has meal program available");
			// Assert.assertTrue(clickElement("btn_vouchers_profile_page"), "Failed to click
			// the Vouchers button");

		} else {
			log("User has no meal program available");
		}

		for (Object o : mealProgramList) {
			String voucherdetails = o.toString();
			log(voucherdetails);
			JSONObject voucher = (JSONObject) o;
			String Amount = (String) voucher.get("voucher_amount");
			String voucherName = (String) voucher.get("voucher_name");
			String voucherUsageTime = (String) voucher.get("usage");
			// log("Voucher Amount is"+Amount+" "+voucherType+" "+voucherExpiryDate);
			displayVoucher(Amount, voucherName, voucherUsageTime);

			// log(Double.toString(voucherTotalAmount));
		}
		return this;
	}

	public GuestApp displayVoucher(String Amount, String voucherName, String voucherUsageTime) {

		String strItem = getUILocator("btn_meal_program");
		strItem = strItem.replaceAll("<REPLACE_MEAL_PROGRAM>", voucherName);
		Assert.assertTrue(clickElement(strItem), "Failed to click the Meal program");

		Assert.assertNotNull(waitForElement("static_meal_program_header"), "meal voucher header not available");
		Assert.assertNotNull(waitForElement("static_name_of_program_selected"),
				"Name label of the voucher program is not available");
		Assert.assertNotNull(waitForElement("static_amount_of_program_selected"),
				"Amount label of the voucher program is not available");
		Assert.assertNotNull(waitForElement("static_use_of_program_selected"),
				"Usage label of the voucher program are not available");

		strItem = getUILocator("name_of_program_selected");
		strItem = strItem.replaceAll("<REPLACE_MEAL_PROGRAM>", voucherName);
		Assert.assertNotNull(waitForElement(strItem), "Name of the voucher program is not available");

		strItem = getUILocator("amount_of_program_selected");
		strItem = strItem.replaceAll("<REPLACE_AMOUNT_MEAL_PROGRAM>", Amount);
		Assert.assertNotNull(waitForElement(strItem), "Amount of the voucher program is not available");

		strItem = getUILocator("use_of_program_selected");
		strItem = strItem.replaceAll("<REPLACE_USAGE>", voucherUsageTime);
		Assert.assertNotNull(waitForElement(strItem), "Usage of the voucher program are not available");

		return this;
	}

	public GuestApp payVoucherBtnValidation(JSONArray voucherList, String totalExpectedOrderValue) {

		String strItem = getUILocator("static_total_amount_my_order_page");
		strItem = strItem.replaceAll("<REPLACE_TOTAL_AMOUNT>", totalExpectedOrderValue);

		MobileElement Total_amount_Element = waitForElement(strItem);
		// MobileElement Total_due_amount_Element
		// =waitForElement("static_total_due_amount_my_order_page");
		String totalAmount = Total_amount_Element.getText();
		log("the total amount: " + totalAmount);
		String totalAmount1[] = totalAmount.split(",");
		totalAmount = totalAmount1[1].replaceAll("\\s", "");
		totalAmount = totalAmount.substring(1);
		log("The substring is: " + totalAmount);

		Double totalOrderAmount = Double.parseDouble(totalAmount);
		OrderTotal = totalOrderAmount;

		// Assert.assertTrue(clickElement("label_available_vouchers_my_order_page"),
		// "Failed to click avaiable voucher btn");
		Double voucherTotalAmount = 0.00;
		for (Object o : voucherList) {
			String voucherdetails = o.toString();
			log(voucherdetails);
			JSONObject voucher = (JSONObject) o;
			String Amount = (String) voucher.get("voucher_amount");
			String voucherType = (String) voucher.get("voucher_type");
			String voucherExpiryDate = (String) voucher.get("voucher_expiry_date");
			log("Voucher Amount is" + Amount + " " + voucherType + " " + voucherExpiryDate);
			selectVoucher(Amount);
			voucherTotalAmount = voucherTotalAmount + Double.parseDouble(Amount);
			log(Double.toString(voucherTotalAmount));
		}
		Assert.assertTrue(clickElement("label_available_vouchers_my_order_page"),
				"Failed to click avaiable voucher btn");
		log("The total order amount is: " + totalOrderAmount);
		log("The voucher order amount is: " + voucherTotalAmount);

		if (totalOrderAmount <= voucherTotalAmount) {

			Assert.assertNotNull(waitForElement("btn_pay_voucher_in_my_order_page"),
					"Payroll vouchers button is displayed");
			String amount_after_voucher_applied = waitForElementAndGetText("static_total_due_amount_my_order_page");
			log("The amount after voucher applied is: " + amount_after_voucher_applied);
			amount_after_voucher_applied.equals("$0.00");

			log("Pay voucher button is displayed");

		} else {
			Assert.assertNotNull(waitForElement("btn_payroll_deduction_in_my_order_page"),
					"Payroll deduction button not found at this position when vouchers are not available");
			String amount_after_voucher_applied = waitForElementAndGetText("static_total_due_amount_my_order_page");
			Double amountdue = Double.parseDouble(amount_after_voucher_applied.substring(1));
			Assert.assertEquals(amountdue, totalOrderAmount - voucherTotalAmount);
			log("Due amount is properly displayed");
		}

		return this;
	}

	public GuestApp payVoucherBtnLessAmount(String totalExpectedOrderValued) {
		double voucherAmount = 10.00;
	//	double mealProgramvoucherAmount = 12.00;
		String strItem = "";
		
		strItem = getUILocator("customize_pay");
		Assert.assertTrue(clickElement(strItem), " failed to click on Pay button");
		log("Successfully clicked on Pay button for for customized List order ");
		Offshoredelay();
		
		strItem = getUILocator("btn_order_to");
		Assert.assertTrue(clickElement(strItem), " failed to click on Order total button");
		log("Successfully clicked on Order total button for customized List order ");
		Offshoredelay();
				
				
				
		strItem	=getUILocator("static_total_amount_my_order_page");
		String getStrItem=(waitForElement(strItem)).getText();
		log("getStrItem: "+getStrItem);
		String uIArrayStrItemEndAmount=getStrItem.replaceAll("[^0-9]", "");
		log("Before split: uIArrayStrItemEndAmount: "+uIArrayStrItemEndAmount);
		String uIArrayStrItemBeginAmountWhole = uIArrayStrItemEndAmount.substring(0, uIArrayStrItemEndAmount.length()-2);
		String uIArrayStrItemEndAmountDecimal=".00";
		String orderAmountString=uIArrayStrItemBeginAmountWhole+uIArrayStrItemEndAmountDecimal;
		
		log("orderAmount:"+orderAmountString);
		Offshoredelay();
	

		
		double totalAmount = Double.parseDouble(orderAmountString); 
		if (totalAmount <= voucherAmount) {
			
			log("Total amount is : "+totalAmount+" greater than the Meal Program amount "+voucherAmount);
			
			log("*************** Member choosed Meal Program *******************************");
		//	Assert.assertNotNull(waitForElement("available_list_of_vouchers_my_order_page"),"Failed to click avaiable voucher btn");
			//selectVoucher(Double.toString(voucherAmount));
			Assert.assertNotNull(waitForElement("available_list_of_Meal_program_my_order_page"),"Payroll vouchers button is displayed");
		//	Assert.assertTrue(clickElement("available_list_of_Meal_program_my_order_page"),"Failed to click Payroll vouchers btn");
			Assert.assertNotNull(waitForElement("select_click_voucher_twelve"),"Payroll vouchers button is displayed");
			Assert.assertTrue(clickElement("select_click_voucher_twelve"),"Failed to click Payroll vouchers btn");
			Offshoredelay();
		}
		else {
			log("No voucher available");
			
		
			
		}
		
	//	checkoutThroughPayrollDeduction();
		
		String strItem2 = getUILocator("click_btn_pay_voucher");
		Assert.assertTrue(clickElement(strItem2), "Failed to click vouchers btn");
		log("Successfully Paid the amount with the mode of Pay with Voucher.");
		Offshoredelay();
		
		return this;
	}

	public GuestApp payMealVoucherBtnLessAmount(String totalExpectedOrderValued) {
		double voucherAmount = 10.00;
	//	double mealProgramvoucherAmount = 12.00;
		String strItem = "";
		
		strItem = getUILocator("customize_pay");
		Assert.assertTrue(clickElement(strItem), " failed to click on Pay button");
		log("Successfully clicked on Pay button for for customized List order ");
		Offshoredelay();
		
		strItem = getUILocator("btn_order_to");
		Assert.assertTrue(clickElement(strItem), " failed to click on Order total button");
		log("Successfully clicked on Order total button for customized List order ");
		Offshoredelay();
				
			
		
	
	
		strItem	=getUILocator("static_total_amount_my_order_page");
		String getStrItem=(waitForElement(strItem)).getText();
		log("getStrItem: "+getStrItem);
		String uIArrayStrItemEndAmount=getStrItem.replaceAll("[^0-9]", "");
		log("Before split: uIArrayStrItemEndAmount: "+uIArrayStrItemEndAmount);
		String uIArrayStrItemBeginAmountWhole = uIArrayStrItemEndAmount.substring(0, uIArrayStrItemEndAmount.length()-2);
		String uIArrayStrItemEndAmountDecimal=".00";
		String orderAmountString=uIArrayStrItemBeginAmountWhole+uIArrayStrItemEndAmountDecimal;
		
		log("orderAmount:"+orderAmountString);
		
	

		
		double totalAmount = Double.parseDouble(orderAmountString); 
		if (totalAmount <= voucherAmount) {
			
			log("Total amount is : "+totalAmount+" less than the Meal Voucher amount "+voucherAmount);
			log("*************** Member choosed Meal Voucher *******************************");
		//	Assert.assertNotNull(waitForElement("available_list_of_vouchers_my_order_page"),"Payroll vouchers button is displayed");
			Assert.assertNotNull(waitForElement("available_list_of_Meal_vouchers_my_order_page"),"Payroll vouchers button is not displayed");
		//	Assert.assertTrue(clickElement("available_list_of_Meal_vouchers_my_order_page"),"Failed to click avaiable voucher btn");
			Assert.assertNotNull(waitForElement("select_click_voucher"),"Failed to find payroll voucher btn");
			Assert.assertTrue(clickElement("select_click_voucher"),"Failed to click Payroll vouchers btn");
			
	
			
			
		}
		else {
			log("No voucher available");
		}
		
	//	checkoutThroughPayrollDeduction();
		
		String strItem2 = getUILocator("click_btn_pay_voucher");
		Assert.assertTrue(clickElement(strItem2), "Failed to click vouchers btn");
		log("Successfully Paid the amount with the mode of Pay with Voucher.");
		Offshoredelay();
		
		return this;
	}


	public GuestApp payMealProgramAndMealVoucherBtnLessAmount(String totalExpectedOrderValuedMP,String totalExpectedOrderValuedMV) {
		double voucherAmount = 10.00;
		double mealProgramvoucherAmount = 12.00;
		String strItem = "";
		
		strItem = getUILocator("customize_pay");
		Assert.assertTrue(clickElement(strItem), " failed to click on Pay button");
		log("Successfully clicked on Pay button for for customized List order ");
		Offshoredelay();
		
		strItem = getUILocator("btn_order_to");
		Assert.assertTrue(clickElement(strItem), " failed to click on Order total button");
		log("Successfully clicked on Order total button for customized List order ");
		Offshoredelay();
				
				
				
		strItem	=getUILocator("static_total_amount_my_order_page");
		String getStrItem=(waitForElement(strItem)).getText();
		log("getStrItem: "+getStrItem);
		String uIArrayStrItemEndAmount=getStrItem.replaceAll("[^0-9]", "");
		log("Before split: uIArrayStrItemEndAmount: "+uIArrayStrItemEndAmount);
		String uIArrayStrItemBeginAmountWhole = uIArrayStrItemEndAmount.substring(0, uIArrayStrItemEndAmount.length()-2);
		String uIArrayStrItemEndAmountDecimal=".00";
		String orderAmountString=uIArrayStrItemBeginAmountWhole+uIArrayStrItemEndAmountDecimal;
		
		log("orderAmount:"+orderAmountString);
		Offshoredelay();
		
	

		
		double totalAmount = Double.parseDouble(orderAmountString); 
		if(totalAmount <= voucherAmount){
			log("Total amount is : "+totalAmount+" less than the Meal Voucher amount "+voucherAmount);
			log("*************** Member choosed Meal Voucher *******************************");
		//	Assert.assertNotNull(waitForElement("available_list_of_vouchers_my_order_page"),"Payroll vouchers button is displayed");
			Assert.assertNotNull(waitForElement("available_list_of_Meal_vouchers_my_order_page"),"Payroll vouchers button is displayed");
		//	Assert.assertTrue(clickElement("available_list_of_Meal_vouchers_my_order_page"),"Failed to click avaiable voucher btn");
			Assert.assertNotNull(waitForElement("select_click_voucher"),"Payroll vouchers button is displayed");
			Assert.assertTrue(clickElement("select_click_voucher"),"Failed to click Payroll vouchers btn");
			
		}
		
		else if (totalAmount > mealProgramvoucherAmount) {
			
			log("Total amount is : "+totalAmount+" lesser than or equal the Meal Program amount "+mealProgramvoucherAmount);
			
			log("*************** Member choosed Meal Program *******************************");
		//	Assert.assertTrue(clickElement("available_list_of_vouchers_my_order_page"),"Failed to click avaiable voucher btn");
			//selectVoucher(Double.toString(voucherAmount));
			Assert.assertNotNull(waitForElement("available_list_of_Meal_program_my_order_page"),"Payroll vouchers button is displayed");
		//	Assert.assertTrue(clickElement("available_list_of_Meal_program_my_order_page"),"Failed to click Payroll vouchers btn");
			Assert.assertNotNull(waitForElement("select_click_voucher_twelve"),"Payroll vouchers button is displayed");
			Assert.assertTrue(clickElement("select_click_voucher_twelve"),"Failed to click Payroll vouchers btn");
			Offshoredelay();
			
			
		}
		else {
			log("No voucher available");
		}
		
		String strItem2 = getUILocator("click_btn_pay_voucher");
		Assert.assertTrue(clickElement(strItem2), "Failed to click vouchers btn");
		log("Successfully Paid the amount with the mode of Pay with Voucher.");
		Offshoredelay();
		
		return this;
	}

	
	public GuestApp validateTotalaftUncheck(String unCheckVoucher) {
		selectVoucherToUncheck(unCheckVoucher);
		Assert.assertNotNull(waitForElement("btn_payroll_deduction_in_my_order_page"),
				"Payroll deduction button not found at this position when vouchers are not available");
		String amount_after_voucher_applied = waitForElementAndGetText("static_total_due_amount_my_order_page");
		log("The amount_after_voucher_applied: " + amount_after_voucher_applied);
		Double amountdue = Double.parseDouble(amount_after_voucher_applied.substring(1));
		Assert.assertEquals(amountdue, OrderTotal);
		log("Due amount is properly displayed after unchecking");

		return this;

	}

	public GuestApp checkOutThroMealVoucher() {
		AppUtilities.delay(5000);
		Assert.assertNotNull(clickElement("btn_pay_voucher_in_my_order_page"),
				"Failed to click the Pay with Voucher button in the my order");
		Assert.assertNotNull(waitForElement("static_thankyou_thankyou_page"),
				"Failed to check the thank you text after clicking on payroll-dediction");
		Assert.assertNotNull(waitForElement("static_desc_thankyou_page"),
				"Failed to check the thank you description after clicking on payroll-dediction");
		resetMealProgram();
		return this;

	}

	public GuestApp checkOutThroMealVoucherAndPayroll() {
		double voucherAmount = 10.00;
		/*
		 * String totalExpectedOrderValue = "15.00";
		 * 
		 * String strItem = getUILocator("static_total_amount_my_order_page"); strItem =
		 * strItem.replaceAll("<REPLACE_TOTAL_AMOUNT>", totalExpectedOrderValue);
		 * //log(strItem); MobileElement Total_amount_Element =waitForElement(strItem);
		 * //MobileElement Total_due_amount_Element
		 * =waitForElement("static_total_due_amount_my_order_page"); String
		 * totalAmountString = Total_amount_Element.getText(); totalAmountString =
		 * totalAmountString.substring(1); double totalAmount
		 * =Double.parseDouble(totalAmountString);
		 * //Integer.parseInt(totalAmountString); if (totalAmount >= voucherAmount) {
		 */
		// Assert.assertTrue(clickElement("label_available_vouchers_my_order_page"),
		// "Failed to click avaiable voucher btn");
		// selectVoucher(Double.toString(voucherAmount));
		Assert.assertNotNull(waitForElement("btn_payroll_deduction_in_my_order_page"),
				"Payroll vouchers button is displayed");
		Assert.assertTrue(clickElement("btn_payroll_deduction_in_my_order_page"),
				"Unable to click Payroll vouchers button");
		Assert.assertNotNull(waitForElement("static_thankyou_thankyou_page"),
				"Failed to check the thank you text after clicking on payroll-dediction");
		Assert.assertNotNull(waitForElement("static_desc_thankyou_page"),
				"Failed to check the thank you description after clicking on payroll-dediction");

		return this;

	}

	public String getCurrentTimeInHhmmFormate() {
		
	/*	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm a");
		LocalDateTime now = LocalDateTime.now();
		System.out.println(dtf.format(now));
		String time= dtf.format(now);
		String timeToCheck = waitForElement(time).getText();
		writeDataInRunStore("timeToCheckKey", timeToCheck);
		*/
		
	
		Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("h:mm a");
        String time = sdf.format(cal.getTime());
		log("Current time logged as : "+time);
		return time;
	} 
	
	
	
public GuestApp validateThankyouPageAndOrderStatusContent(String caffe_location,String station_type_s,String food_type) {
		
		String strItems="";
		
		String getTime=  getCurrentTimeInHhmmFormate() ;

	//	log("****Fetched last ordered time from the backend method************"+getTime);
		
		strItems=getUILocator("msg_thank_you");
		if(strItems.equalsIgnoreCase("Thank You")) {
		Assert.assertNotNull(waitForElementAndGetText(strItems),"Failed to show the message as Thank You");
		log("Order placed successfully and landed to Thank you message");
		}
		
		strItems=getUILocator("msg_ready_to_pickup_notification");
		Assert.assertNotNull(waitForElementAndGetText(strItems),"Failed to show the notification message ");
		
		
		strItems=getUILocator("click_btn_show_order_status");
		Assert.assertNotNull(waitForElement(strItems),"Failed to click the element as show  order status ");
		Assert.assertTrue(clickElement(strItems), "failed to click the element as show  order status");
		log(" Show  order status is clicked "+strItems);
		
		//Added - 23 March
		strItems=getUILocator("btn_my_info");
		Assert.assertNotNull(waitForElement(strItems),"Failed to click the element as show  order status ");
		Assert.assertTrue(clickElement(strItems), "failed to click the element as show  order status");
		Offshoredelay();
		Offshoredelay();
		
		strItems=getUILocator("lbl_order_status");
		Assert.assertNotNull(waitForElement(strItems),"Failed to click the element as Order status ");
		Assert.assertTrue(clickElement(strItems), "failed to click the element as show order status");
		Offshoredelay();
		Offshoredelay();
	
		//read the value of time  hh mm a
		/*String timeData=readDataFromRunStore("timeToCheckKey");
		log("The ordered item is placed at the time status content is  : "+timeData);
		*/

		//verify the caffe name is same
		String strVerifyItem=getUILocator("order_status_caffe_name");
		String strItemValue=(waitForElement(strVerifyItem).getText());
		Assert.assertNotNull(waitForElement(strVerifyItem),"Failed to show the caffe name");
		Assert.assertEquals(caffe_location,waitForElement(strVerifyItem).getText(),"Successfully verified the caffe name is same "+strVerifyItem);
		log("List of Caffe name from order status :"+strItemValue+" and ordered items caffe is :"+caffe_location);
	
		
		
		//Search the order number is same or not
		if(strItemValue.equalsIgnoreCase(caffe_location)) {
			
			List <WebElement> OrderofItems = waitForElements("loop_find_order_placed");
			log("List of Order placed in list : "+OrderofItems.size());
			
						for (int i = 0; i < OrderofItems.size();i++) {
							log(OrderofItems.get(i).getText());
							
							log("**************Searching the ordered placed on particular time processing..*********");
								String textFromUI= OrderofItems.get(i).getText();
								String[] timeDetails=textFromUI.split(" ");
								String lastTwoStringTime = timeDetails[timeDetails.length-2]+" "+timeDetails[timeDetails.length-1];
								Offshoredelay();
							
								log("Latest Order placed at the "+getTime+" time");
								log("As per Caffe time of Order status is picked to verify as : "+lastTwoStringTime);
								
								
								if(getTime.equalsIgnoreCase(lastTwoStringTime)) {
										log("Latest Order was taken at :"+getTime+" and the ordered status page time fetched is : "+lastTwoStringTime);
									
									//Get the xpath of the looping element
										String orderTimeIs="Order Placed at ";
										String getOrderTimeIs=orderTimeIs.concat(lastTwoStringTime);
										
										writeDataInRunStore("Time",lastTwoStringTime);
									
									
							

									//Initialise the temp caffe time
										log("**************In list verifying the particular Order time  : "+lastTwoStringTime+" and following food details *********");
										String tempItemText="";
										String tempItem="";
										tempItem=getUILocator("order_status_menu_item_type").replaceAll("<REPLACE_TEXT>", getOrderTimeIs);
										tempItemText=(waitForElement(tempItem)).getText();
									//	log("Food item  menu name from uilocator is "+tempItemText);
									//	log("station_type_s name from uilocator is "+station_type_s);
										
										Assert.assertNotNull(waitForElement(tempItem),"Failed to show the Food Item type");
											if(station_type_s.equalsIgnoreCase(tempItemText)) {
													log("Successfully verified the Ordered Food Item type is "+station_type_s+ " and orderded status "+tempItemText+ " is same. ");
											}else {
												log("Failed to find the element of Order Menu Item Type");
											}
											Offshoredelay();
									
								
									
										String tempItem1=getUILocator("order_status_index_food_item_name").replaceAll("<REPLACE_TEXT>", getOrderTimeIs);
										String tempItemText1=(waitForElement(tempItem1)).getText();
										log("Food item from uilocator is "+tempItemText1);
										Assert.assertNotNull(waitForElement(tempItem1),"Failed to show the Food item name");
										String[] foodDetails=tempItemText1.split(" ");
										String startFromSecondString = foodDetails[foodDetails.length-1].replaceAll(foodDetails[1], foodDetails[foodDetails.length-1]);
				
						//Write the runtime store database in log
										log("Order Id is : "+foodDetails[0]);
										writeDataInRunStore("OrderId",foodDetails[0].replace("#",""));
										String orderID=foodDetails[0].replace("#","").toString();
										log("OrderId : "+orderID);
										
										writeDataInRunStore("OrderIdWithHashSymbol",foodDetails[0]);
										String orderWithHashh=foodDetails[0].toString();
										log("orderWithHashh : "+orderWithHashh);
										
										
						// Code to verify the food item name is same				
										log("After replace substring uilocator is : "+startFromSecondString);
										Offshoredelay();
										if(food_type.equalsIgnoreCase(startFromSecondString)) {
													log("Successfully verified the Ordered Food type is "+food_type+ "and orderded status "+startFromSecondString+ " is same. ");
											}
										else {
											log("Failed to find the element of food name");
										}
										Offshoredelay();
									

						// code to verify the pending status			
										String tempItem2=getUILocator("order_status_index_food_item_status").replaceAll("<REPLACE_TEXT>", getOrderTimeIs);
										String tempItemText2=(waitForElement(tempItem2)).getText();
										if(StringUtils.equalsIgnoreCase(tempItemText2, "Pending")) {
												Assert.assertNotNull(waitForElement(tempItem2),"Failed to show the Food status");
												log("Status is in pending");
												
												}
										else {
											
												log("Failed to find the element of food name");
											}
												break;
												
										}	
						}
						log("!!!!!!!!!!!!! Order Status Script completed successfully!!!!!!!!!!!!!!!!");
			}
		return this;
	}

	
public GuestApp verifyOrderHistory(String caffe_location,String station_type_s,String food_type) {
		
		String strItems="";
		
		//String setTime="10:10 AM";
		//String orderTimefromRumTime= "10:10 AM";
		//String  OrderIdWithHashSymbol="#1";
		
		
		String orderIdWithHashSymbol=readDataFromRunStore("OrderIdWithHashSymbol");
		log("Order id with hash stored in runtime database is :"+orderIdWithHashSymbol);
		
		String orderTimefromRumTime=readDataFromRunStore("Time");
		log("Order Time stored in runtime database  is :"+orderTimefromRumTime);
		
		
		
			
		strItems=getUILocator("btn_my_information");
		Assert.assertNotNull(waitForElement(strItems),"Failed to click the element my info ");
		Assert.assertTrue(clickElement(strItems), "failed to click the element  my info");
		log(" Successfully click the element my info "+strItems);
		Offshoredelay();
		
		strItems=getUILocator("lbl_order_history");
		Assert.assertNotNull(waitForElement(strItems),"Failed to click the Order history element  ");
		Assert.assertTrue(clickElement(strItems), "failed to click the Order history element ");
		log(" Successfully clicked the Order history element"+strItems);
		Offshoredelay(); 
	
		
		SwipeSlider();
		Offshoredelay();
		Offshoredelay();
		strItems=getUILocator("lbl_search_order_history");
		Assert.assertNotNull(waitForElement(strItems),"Failed to find the Order history element");
		Assert.assertTrue(clickElement(strItems),"Failed to click the Order history element");
		log("*********** before click*************");
		//Assert.assertTrue(typeText("lbl_search_order_history",orderTimefromRumTime),"failed to click the Order history search text element ");
		AppUtilities.delay(5000);
		waitForElement("lbl_search_order_history_field").sendKeys(orderTimefromRumTime);
		log("*********** after click*************");
		AppUtilities.delay(5000);
		log("Successfully clicked the Order history element "+strItems);
		Offshoredelay();
		
		
		strItems=getUILocator("btn_order_history_more_info");
		Assert.assertNotNull(waitForElement(strItems),"Failed to click the searched first record - more information element  ");
		Offshoredelay();
		//Assert.assertTrue(clickElement(strItems), "failed to click the the searched first record - more information element  ");
		waitForElement("lbl_search_order_history_field").sendKeys(orderTimefromRumTime);
		Offshoredelay();
		Offshoredelay();
		Offshoredelay();
		log("Successfully clicked the searched first record - more information element  "+strItems);

		
		
		strItems=getUILocator("btn_share_receipt");
		Assert.assertNotNull(waitForElement(strItems),"Failed to click on share receipt element");
		Assert.assertTrue(clickElement(strItems), "failed to click on share receipt element");
		log("Successfully clicked the share receipt element"+strItems);
		Offshoredelay();
		
		
		
		String strItemClick=getUILocator("btn_send_receipt");
		Assert.assertNotNull(waitForElement(strItemClick),"Failed to click on send receipt element");
		Assert.assertTrue(clickElement(strItemClick),"failed to click on send receipt element");
		log("Successfully clicked the send receipt element"+strItemClick);
		Offshoredelay();
		
		String searchedOrderTimeItems=getUILocator("order_history_order_time");
		searchedOrderTimeItems=waitForElement(searchedOrderTimeItems).getText();
		String [] allTextArray=searchedOrderTimeItems.split(" ");
		String lastTwoStringAsTime= allTextArray[allTextArray.length-2]+" "+allTextArray[allTextArray.length-1];
		
		String searchedOrderIdItems=getUILocator("order_history_order_id_number");
		searchedOrderIdItems=waitForElement(searchedOrderIdItems).getText();		
		//XCUIElementTypeStaticText[@name='Caffè Macs']/following::XCUIElementTypeStaticText
		
	//	String orderIdFromRunTime= readDataFromRunStore("OrderIdWithHashSymbol");
	//	String orderTimefromRumTime= readDataFromRunStore("Time");
		
		//verify the caffe name is same
		String strVerifyItem=getUILocator("order_history_caffe_name");
		String strItemValue=(waitForElement(strVerifyItem).getText());
		Assert.assertNotNull(waitForElement(strVerifyItem),"Failed to show the caffe name");
		Assert.assertEquals(caffe_location,waitForElement(strVerifyItem).getText(),"Successfully verified the caffe name is same "+strVerifyItem);
		log("List of Caffe name from order history :"+strItemValue+" and ordered items caffe is :"+caffe_location);
		Offshoredelay();
		
		/*log("Before if condition - orderIdWithHashSymbol " +orderIdWithHashSymbol);
		log("Before if condition -  searchedOrderIdItems " +searchedOrderIdItems);
		log("Before if condition -  searchedOrderIdItems " +orderTimefromRumTime);
		log("Before if condition -  searchedOrderIdItems " +lastTwoStringAsTime);*/
		
		Offshoredelay();
	
	
	if(orderIdWithHashSymbol.equalsIgnoreCase(searchedOrderIdItems) && orderTimefromRumTime.equalsIgnoreCase(lastTwoStringAsTime)) {
		
		
		log("Successfully loaded the same order id as :"+searchedOrderIdItems+" and ordered time as "+lastTwoStringAsTime);
		
		List <WebElement> allTexts= waitForElements("loop_text_order_history");
		log("Caffe details : "+allTexts.size());
				for (int i = 0; i < allTexts.size(); i++) {
					System.out.println(" * "+allTexts.get(i).getText());
					Offshoredelay();
					}
				
	
	}
	
	List <WebElement> allTexts= waitForElements("loop_text_order_history");
	log("Caffe details : "+allTexts.size());
			for (int i = 0; i < allTexts.size(); i++) {
				System.out.println(" * "+allTexts.get(i).getText());
				}
			
			
	/*		strVerifyItem=getUILocator("order_history_amount");
			strItemValue=(waitForElement(strVerifyItem).getText());
			Assert.assertNotNull(waitForElement(strVerifyItem),"Failed to show the food amount");
		//	Assert.assertEquals(caffe_location,waitForElement(strVerifyItem).getText(),"Successfully verified the food amount is same "+strVerifyItem);
		//	log("List of Caffe name from order history :"+strItemValue+" and ordered items caffe is :"+caffe_location);
			Offshoredelay();
			
			strVerifyItem=getUILocator("order_history_status");
			strItemValue=(waitForElement(strVerifyItem).getText());
			Assert.assertNotNull(waitForElement(strVerifyItem),"Failed to show the order history food status");
		//	Assert.assertEquals(caffe_location,waitForElement(strVerifyItem).getText(),"Successfully verified the caffe name is same "+strVerifyItem);
		//	log("List of Caffe name from order history :"+strItemValue+" and ordered items caffe is :"+caffe_location);
			Offshoredelay();
			
			strVerifyItem=getUILocator("order_history_food_name");
			strItemValue=(waitForElement(strVerifyItem).getText());
			Assert.assertNotNull(waitForElement(strVerifyItem),"Failed to show the order history food name");
		//	Assert.assertEquals(caffe_location,waitForElement(strVerifyItem).getText(),"Successfully verified the caffe name is same "+strVerifyItem);
		//	log("List of Caffe name from order history :"+strItemValue+" and ordered items caffe is :"+caffe_location);
			Offshoredelay();
			
			strVerifyItem=getUILocator("order_history_total_amount");
			strItemValue=(waitForElement(strVerifyItem).getText());
			Assert.assertNotNull(waitForElement(strVerifyItem),"Failed to show the ordered food total amount");
			//Assert.assertEquals(caffe_location,waitForElement(strVerifyItem).getText(),"Successfully verified the caffe name is same "+strVerifyItem);
			//log("List of Caffe name from order history :"+strItemValue+" and ordered items caffe is :"+caffe_location);
			Offshoredelay();*/
		

	
		//read the value of time  hh mm a
		/*String timeData=readDataFromRunStore("timeToCheckKey");
		log("The ordered item is placed at the time status content is  : "+timeData);
		*/
	log("!!!!!!!!!!!!! Order Histroy Script completed successfully!!!!!!!!!!!!!!!!1");
			

		return this;
}


//Search the SwipeSlider bar with these cords 160, 82, 160, 242,
public void SwipeSlider()
{
	JavascriptExecutor js = (JavascriptExecutor) driver;
	HashMap<String, Object> params = new HashMap<String, Object>();
	params.put("duration", 2.0);
	params.put("fromX", 160);
	params.put("fromY", 82);
	params.put("toX", 160);
	params.put("toY", 242);
	js.executeScript("mobile: dragFromToForDuration", params);
	Offshoredelay();
	Offshoredelay();
}

	public GuestApp getTime(JSONArray mealProgramList, JSONArray foodItems, String caffe_location)
			throws java.text.ParseException {

		/*
		 * Boolean mealProgram = waitForElementWithText("static_enrolled_meal_program",
		 * "ENROLLED MEAL PROGRAMS"); if (mealProgram) {
		 * log("User has meal program available");
		 * //Assert.assertTrue(clickElement("btn_vouchers_profile_page"),
		 * "Failed to click the Vouchers button");
		 * 
		 * } else { log("User has no meal program available"); }
		 */

		for (Object o : mealProgramList) {
			String voucherdetails = o.toString();
			log(voucherdetails);
			JSONObject voucher = (JSONObject) o;
			String Amount = (String) voucher.get("voucher_amount");
			String voucherName = (String) voucher.get("voucher_name");
			String voucherUsageTime = (String) voucher.get("usage");
			String voucherFromUsageTime = (String) voucher.get("fromTime");
			String voucherToUsageTime = (String) voucher.get("toTime");
			// log("Voucher Amount is"+Amount+" "+voucherType+" "+voucherExpiryDate);
			// displayVoucher(Amount, voucherName,voucherUsageTime);
			try {
				convertUsageTime(voucherFromUsageTime, voucherToUsageTime, foodItems, caffe_location, mealProgramList);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			// log(Double.toString(voucherTotalAmount));
		}
		return this;
	}

	public GuestApp convertUsageTime(String voucherFromUsageTime, String voucherToUsageTime, JSONArray foodItems,
			String caffe_location, JSONArray mealProgramList) throws Exception {
		/*
		 * long a =10; long b = 20; if (a>b){
		 * 
		 * }
		 */

		String currentDate = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
		SimpleDateFormat sdf = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
		sdf.setTimeZone(TimeZone.getTimeZone("PST"));
		String timeStampFromInString = currentDate + " " + voucherFromUsageTime + ":00";
		Date fromTime = sdf.parse(timeStampFromInString);
		System.out.println(timeStampFromInString);
		System.out.println("Date - Time in milliseconds : " + fromTime.getTime());
		long mealProgramAvailableFromTime = fromTime.getTime();
		String timeStampToInString = currentDate + " " + voucherToUsageTime + ":00";
		Date toTime = sdf.parse(timeStampToInString);
		System.out.println(timeStampToInString);
		System.out.println("Date - Time in milliseconds : " + toTime.getTime());
		long mealProgramAvailableToTime = toTime.getTime();

		Calendar calendar = Calendar.getInstance();
		System.out.println("Calender - Time in milliseconds : " + calendar.getTimeInMillis());
		// System.out.println("Calender - Time in milliseconds : " + calendar.g);
		long currentTime = calendar.getTimeInMillis();

		if (currentTime > mealProgramAvailableFromTime) {
			if (currentTime < mealProgramAvailableToTime) {
				log("Meal voucher should be available");
				selectCaffeLocation(caffe_location);
				orderGivenItems(foodItems, caffe_location);
				voucherAvailablity();
				selectMealProgram(mealProgramList);
			} else {
				log("Meal program will be available tommorrow after:" + voucherFromUsageTime + "  PST");
			}

		} else {
			log("Meal program will be available after:" + voucherFromUsageTime + "  PST");
		}

		return this;
	}

	public GuestApp validateMealVoucherUnSelected() {
		String Amount = "10.00";
		Assert.assertTrue(clickElement("label_available_vouchers_my_order_page"), "Failed to click Available vouchers");
		log("Vouchers are displayed");
		String strItem = getUILocator("available_voucher_my_order_page1");
		strItem = strItem.replaceAll("<REPLACE_AMOUNT>", Amount);
		// log(strItem);
		MobileElement mealVoucher = waitForElement(strItem);
		String mealVoucherCheckStatus = mealVoucher.getAttribute("value");
		if (mealVoucherCheckStatus.equals("1")) {
			Assert.assertTrue(true);
		}
		return this;
	}

	public GuestApp orderAgainSameSession() {
		Assert.assertTrue(clickElement("btn_done_thankyou_page"), "Failed to click done in thankyoupage");
		Assert.assertTrue(clickElement("tabbtn_menu_homepage"));

		return this;
	}

	public GuestApp navigateToMyOrderPage() {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click the My order option");
		return this;
	}

	public void resetMealProgram() {

		JDBCUtil myConn = new JDBCUtil();
		myConn.CreateConn();
		myConn.activateMealProgram(81, 10);
		myConn.CloseConn();
	}

	public GuestApp validatePayrollDeductWhenHide() {
		log("In validatePayrollDeductWhenHide");
		Assert.assertTrue(clickElement("tabbtn_profile_homepage"), "Failed to click on Profile button");
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("btn_payroll_profile_page"), "Failed to click Payroll deduction option");
		String hidePayrollLocator = getUILocator("btn_hide_payroll_profile_page");
		MobileElement hidePayrollButton = waitForElement(hidePayrollLocator);
		String hidePayrollStatus = hidePayrollButton.getAttribute("value");
		if (hidePayrollStatus.equals("1")) {
			Assert.assertTrue(clickElement(hidePayrollLocator), "Failed to click the hide payroll button");
		}
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click my order page");
		String payrollDeductButtonLocator = getUILocator("btn_payroll_deduction_in_my_order_page");
		MobileElement payrollDeductButton = waitForElement(payrollDeductButtonLocator);
		boolean payrollDeductButtonStatus = payrollDeductButton.isDisplayed();
		Assert.assertFalse((payrollDeductButtonStatus), "The payroll deduction button is present in my order page");
		// Assert.assertNull(waitForElement("btn_payroll_deduction_in_my_order_page"),
		// "The payroll deduction button is present in my order page");
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("tabbtn_profile_homepage"), "Failed to click on Profile button");
		Assert.assertTrue(clickElement(hidePayrollLocator), "Failed to click the hide payroll button");
		log("Successfully validated the Payroll Deduction button when hidden");
		return this;
	}

	public GuestApp validatePayrollDeductWhenNotHide() {
		log("In validatePayrollDeductWhenNotHide");
		Assert.assertTrue(clickElement("tabbtn_profile_homepage"), "Failed to click on Profile button");
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("btn_payroll_profile_page"), "Failed to click Payroll deduction option");
		String hidePayrollLocator = getUILocator("btn_hide_payroll_profile_page");
		MobileElement hidePayrollButton = waitForElement(hidePayrollLocator);
		String hidePayrollStatus = hidePayrollButton.getAttribute("value");
		log("The hide payroll status is: " + hidePayrollStatus);
		if (hidePayrollStatus.equals("0")) {
			Assert.assertTrue(clickElement(hidePayrollLocator), "Failed to click the hide payroll button");
		}
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click my order page");
		String payrollDeductButtonLocator = getUILocator("btn_payroll_deduction_in_my_order_page");
		MobileElement payrollDeductButton = waitForElement(payrollDeductButtonLocator);
		boolean payrollDeductButtonStatus = payrollDeductButton.isDisplayed();
		Assert.assertTrue((payrollDeductButtonStatus), "The payroll deduction button is not present in my order page");
		log("Successfully validated the Payroll Deduction button when not hide");
		return this;
	}

	public GuestApp verifyStationInToGo() {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to find my order button");
		Assert.assertNotNull(waitForElement("station_grab_go_my_order_page"),
				"Failed to find Grab and go menu in My order page");
		return this;
	}

	public GuestApp verifyStationInForHere() {
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to find my order button");
		Assert.assertNull(waitForElement("station_grab_go_my_order_page"),
				"Able to find Grab and go menu in My order page");
		return this;
	}

	public GuestApp verifyStationMoreInfo() {
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("station_more_info"), "Failed to find to click More Information button");
		Assert.assertNotNull(waitForElement("station_more_info"), "Failed to load the  More Information page");
		return this;
	}

	public GuestApp validatePayrollAuthScreen() {
		log("In validatePayrollAuthScreen");
		Assert.assertTrue(clickElement("tabbtn_profile_homepage"), "Failed to click on Profile button");
		AppUtilities.delay(3000);
		// Assert.assertTrue(clickElement("btn_payroll_profile_page"), "Failed to click
		// Payroll deduction option");
		String payrollDeductLocator = getUILocator("btn_payroll_deduct_profile_page");
		MobileElement payrollDeductButton = waitForElement(payrollDeductLocator);
		String payrollDeductStatus = payrollDeductButton.getAttribute("value");
		log("The hide payroll status is: " + payrollDeductStatus);
		if (payrollDeductStatus.equals("1")) {
			Assert.assertTrue(clickElement(payrollDeductLocator), "Failed to click the hide payroll button");
		}
		Assert.assertTrue(clickElement("btn_disable_payroll_profile_page"), "Failed to click payroll deduction button");
		Assert.assertTrue(clickElement("tabbtn_myorder_homepage"), "Failed to click my order page");
		Assert.assertTrue(clickElement("btn_payroll_deduction_in_my_order_page"),
				"Failed to click payroll deduction button");
		Assert.assertNotNull(waitForElement("payroll_auth_screen"), "Failed to find payroll authentication screen");
		Assert.assertTrue(clickElement("btn_accept_payroll_auth_screen"),
				"Failed to click Accept button in payroll authentication screen");
		AppUtilities.delay(4000);
		Assert.assertTrue(clickElement("btn_payroll_deduction_in_my_order_page"),
				"Failed to click payroll deduction button");
		Assert.assertNotNull(waitForElement("static_thankyou_thankyou_page"), "Failed to place order");
		log("Successfully validated Payroll Authentication screen");
		Assert.assertTrue(clickElement("btn_done_thankyou_page"), "Failed to click Done button in confirmation page");
		Assert.assertTrue(clickElement("tabbtn_menu_homepage"), "Failed to click menu tab");
		return this;
	}

	public GuestApp validateStation(String station, String caffe_location) {

		String strItem = getUILocator("cell_select_station_homepage");
		Offshoredelay();
		String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
		Assert.assertTrue(clickElement(selectStationItem), "Failed to select the station:" + station);
		return this;
	}

	public GuestApp validateStationIsPresent(String station, String caffe_location) {

		String strItem = getUILocator("cell_select_station_homepage");

		String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", station);
		Assert.assertNull(waitForElement(selectStationItem), "Failed to deselect the station:" + station);
		return this;
	}

	public GuestApp validateIncreaseInStationWaitTime(String waitTime, JSONArray items, String aCaffeLocation) {
		validateStationWaitTime(items, aCaffeLocation);
		Assert.assertTrue(temp.contains(waitTime),
				"Failed to have the wait time specified in kds: " + waitTime + " in GuestApp: " + temp);

		return this;
	}

	public GuestApp validateStationWaitTime(JSONArray items, String aCaffeLocation) {
		log("Items to be ordered is:" + items.toJSONString());
		JSONObject itemDetails = null;
		for (Object item : items) {
			itemDetails = (JSONObject) item;
		}
		String strStationToSelect = (String) itemDetails.get("select_station");
		String strItemToOrder = (String) itemDetails.get("food_item_name");
		String strItemPrice = (String) itemDetails.get("food_item_price");
		String strFoodItemType = (String) itemDetails.get("food_type");
		String strFoodItemDesc = (String) itemDetails.get("food_item_desc");

		String strItem = getUILocator("cell_select_station_homepage");
		String selectStationItem = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect);
		Assert.assertNotNull(waitForElement(selectStationItem), "Failed to select the station:" + strStationToSelect);
		strItem = getUILocator("cell_station_wait_time");
		String stationWaitTime = strItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", strStationToSelect);

		WebElement e = waitForElement(stationWaitTime);
		String waitTime = e.getText();
		log(waitTime);
		temp = waitTime;
		return this;

	}

	public GuestApp assertWaitTime(String waitTime) {

		Assert.assertTrue(temp.contains(waitTime), "Failed to find wait time");
		/*
		 * Boolean e = temp.contains(waitTime); log(e.toString());
		 */
		return this;
	}
	
	//Sold Out Grab And Go
	public GuestApp soldOutGrabAndGoValidationForGivenItems(JSONArray items, String aCaffeLocation,
			String station_type) {

		log("Items to be ordered is:" + items.toJSONString());
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		int orderIndex = 0;
		for (Object item : items) {
			JSONObject itemDetails = (JSONObject) item;
			orderIndex++;
			Assert.assertNotNull(
					soldOutGrabAndGoValidationForGivenItem(orderIndex, itemDetails, aCaffeLocation, station_type),
					"Failed while ordering the item:" + itemDetails.toJSONString());
		}
		return this;
	}

	public GuestApp soldOutGrabAndGoValidationForGivenItem(int orderIndex, JSONObject item, String aCaffeLocation,
			String station_type) {

		String strStationToSelect = (String) item.get("select_station");
		Boolean isCustomizedItem = (Boolean) item.get("is_custom_item");
		log("value of custom item   line 297 " + isCustomizedItem);
		log("value of custom item " + isCustomizedItem);

		String strItemToOrder = (String) item.get("food_item_name");
		String strItemPrice = (String) item.get("food_item_price");
		String strFoodItemType = (String) item.get("food_type");
		String strToppingType = (String) item.get("customize_food_item_category_type_state");

		String strStationType = getUILocator("station_type_other");
		strStationType = strStationType.replaceAll("<REPLACE_STATION_TYPE>", station_type);

		log("food_item_name " + strItemToOrder);
		log("food_item_price " + strItemPrice);
		log("food_type " + strFoodItemType);
		log("station_type_other  " + strStationType);

		Assert.assertNotNull(waitForElement(strStationType), "Fail to wait the element");
		upScrollTo();
		Offshoredelay();

		AppUtilities.delay(3000);
		AppUtilities.delay(3000);

		// Write Script to select different station type
		driver.findElementByAccessibilityId(station_type).click();
		AppUtilities.delay(3000);
		Offshoredelay();

		String station_type_display = "//XCUIElementTypeNavigationBar[contains(@name,'" + station_type + "')]";
		driver.findElementByXPath(station_type_display);
		driver.findElementByAccessibilityId(strStationToSelect).click();
		AppUtilities.delay(3000);
		log("Successfully clicked on strStationToSelect:  " + strStationType);

		AppUtilities.delay(3000);

		log("The food type given is:" + strFoodItemType + ", Caffe location:" + aCaffeLocation);

		AppUtilities.delay(10000);
		log(driver.getPageSource());
		
		AppUtilities.delay(2000);
		log("number of elements in menu page" + waitForElements("menu_item_table1").size());
		List<WebElement> allTexts = driver.findElementsByXPath("//XCUIElementTypeStaticText");
		int a = allTexts.size();

		for (int i = 0; i < a; i++) {

			System.out.println(allTexts.get(i).getText());
		}

		String strItemName = getUILocator("grab_and_go_item_name").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		String strSoldOut = getUILocator("grab_and_go_menu_item_sold_out");
		Assert.assertNotNull(waitForElement(strItemName), "Fail to wait the element");
		Assert.assertNotNull(waitForElement(strSoldOut), "Fail to wait the element Sold Out");
		
		//Add Grab and Go menu to Favorites
		String strFavoriteLoc = getUILocator("grab_and_go_add_favorite").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		Assert.assertTrue(clickElement(strFavoriteLoc), "Fail to click the element Favorites button");

		AppUtilities.delay(2000);
		
		// Navigate back to Main Page
		Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in station page");
		AppUtilities.delay(2000);

		// My Favorites Click
		Assert.assertTrue(clickElement("my_favorites_main_screen"), "Fail to click on favorite button");
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement("my_favorites_header"), "Fail to wait for favorite header");
		String grabAndGoSoldOutLoc = getUILocator("my_favorites_grab_and_go_sold_out").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		Assert.assertNotNull(waitForElement(grabAndGoSoldOutLoc), "Fail to wait the element");
		
		Offshoredelay();

		return this;
	}

	public GuestApp soldOutIngredientValidationForGivenItems(JSONArray items, String aCaffeLocation,
			String station_type) {

		log("Items to be ordered is:" + items.toJSONString());
		Assert.assertNotNull(items, "Failed as the items to be ordered found to be null");
		Assert.assertTrue(items.size() > 0, "Failed as the items to be ordered found to be empty");
		int orderIndex = 0;
		for (Object item : items) {
			JSONObject itemDetails = (JSONObject) item;
			orderIndex++;
			Assert.assertNotNull(
					soldOutIngredientValidationForGivenItem(orderIndex, itemDetails, aCaffeLocation, station_type),
					"Failed while ordering the item:" + itemDetails.toJSONString());
		}
		return this;
	}

	public GuestApp soldOutIngredientValidationForGivenItem(int orderIndex, JSONObject item, String aCaffeLocation,
			String station_type) {

		String strStationToSelect = (String) item.get("select_station");
		Boolean isCustomizedItem = (Boolean) item.get("is_custom_item");
		log("value of custom item " + isCustomizedItem);
		
		JSONArray customFoodItems = (JSONArray) item.get("customize_food_item");

		String strItemToOrder = (String) item.get("food_item_name");
		String strItemPrice = (String) item.get("food_item_price");
		String strFoodItemType = (String) item.get("food_type");

		String strStationType = getUILocator("station_type_other");
		strStationType = strStationType.replaceAll("<REPLACE_STATION_TYPE>", station_type);

		log("food_item_name " + strItemToOrder);
		log("food_item_price " + strItemPrice);
		log("food_type " + strFoodItemType);
		log("station_type_other  " + strStationType);

		Assert.assertNotNull(waitForElement(strStationType), "Fail to wait the element");
		upScrollTo();
		Offshoredelay();

		AppUtilities.delay(3000);
		AppUtilities.delay(3000);

		// Write Script to select different station type
		driver.findElementByAccessibilityId(station_type).click();
		AppUtilities.delay(3000);
		Offshoredelay();

		String station_type_display = "//XCUIElementTypeNavigationBar[contains(@name,'" + station_type + "')]";
		driver.findElementByXPath(station_type_display);
		driver.findElementByAccessibilityId(strStationToSelect).click();
		AppUtilities.delay(3000);
		log("Successfully clicked on strStationToSelect:  " + strStationType);

		AppUtilities.delay(3000);
		// Station Type Selected and Main Page of Station to select Menu Item
		log("The food type given is:" + strFoodItemType + ", Caffe location:" + aCaffeLocation);

		AppUtilities.delay(10000);

		log("Food to be ordered is from menu");
		AppUtilities.delay(2000);

		log("number of elements in menu page" + waitForElements("menu_item_table1").size());
		List<WebElement> allTexts = driver.findElementsByXPath("//XCUIElementTypeStaticText");
		int a = allTexts.size();

		for (int i = 0; i < a; i++) {

			System.out.println(allTexts.get(i).getText());
		}

		String strItemNameLoc = getUILocator("menupage_item_name_by_name").replaceAll("<REPLACE_TEXT>", strItemToOrder);
		Assert.assertNotNull(waitForElement(strItemNameLoc), "Fail to wait the element");

		

		if(isCustomizedItem) {
			for(Object customFoodItem : customFoodItems) {
				JSONObject customItemDetails = (JSONObject) customFoodItem;
				
				String customizeFoodItemCategory = (String) customItemDetails.get("customize_food_item_category");
				String customizeFoodItemCategoryType = (String) customItemDetails.get("customize_food_item_category_type");
				JSONArray customizeFoodItemDetails = (JSONArray) customItemDetails.get("customize_food_items");
				
				//List Sold out validation
				if(customizeFoodItemCategoryType.equalsIgnoreCase("list")) {
					
					String menuItemClick = getUILocator("menu_item_selection_to_order").replaceAll("<REPLACE_TEXT>", strItemToOrder);

					Assert.assertTrue(clickElement(menuItemClick), "Fail to click the Menu item");
					
					log("Validation of List Sold out scenario");
					for(Object customData : customizeFoodItemDetails) {
						JSONObject customDataValidate = (JSONObject) customData;
						String strCustomListGroup = (String) customDataValidate.get("customize_list_food_group_name");
						String strCustomListName = (String) customDataValidate.get("customize_food_item_name");
						
						String strItem = getUILocator("btn_customize");
						Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Customize button ");
						Assert.assertTrue(clickElement(strItem), " failed to click the Customize button");
						Offshoredelay();
						
						strItem = getUILocator("list_option_more_info_btn").replaceAll("<REPLACE_TEXT>", strCustomListGroup);
						Assert.assertNotNull(waitForElement(strItem), "Failed to wait for arrow mark ");
						Assert.assertTrue(clickElement(strItem), " failed to click the More information  button  action");
						Offshoredelay();
						
						strItem = getUILocator("sold_out_ingredient").replaceAll("<REPLACE_TEXT>", strCustomListName);
						Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Sold Out List in More Info Screen ");
												
						
						log("Successfully validate Sold out List");
						strItem = getUILocator("list_option_more_info_back").replaceAll("<REPLACE_TEXT>", strItemToOrder);
						Assert.assertTrue(clickElement(strItem), "Failed to click fback button in More Info Screen ");
						
									
					}
					//Navigate Back to Main Station and click on Station
					Assert.assertTrue(clickElement("cancel_btn"), " failed to click the Cancel button in Customize page");
					
					Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
					AppUtilities.delay(2000);
					
					Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
					AppUtilities.delay(2000);

					Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
					AppUtilities.delay(2000);

					// Write Script to select different station type
					driver.findElementByAccessibilityId(station_type).click();
					AppUtilities.delay(3000);
					Offshoredelay();

					station_type_display = "//XCUIElementTypeNavigationBar[contains(@name,'" + station_type + "')]";
					driver.findElementByXPath(station_type_display);
					driver.findElementByAccessibilityId(strStationToSelect).click();

				}
				
				//Option Sold out validation
				if(customizeFoodItemCategoryType.equalsIgnoreCase("option")) {

					String menuItemClick = getUILocator("menu_item_selection_to_order").replaceAll("<REPLACE_TEXT>", strItemToOrder);

					Assert.assertTrue(clickElement(menuItemClick), "Fail to click the Menu item");
					log("Validation of Option Sold out scenario");
					for(Object customData : customizeFoodItemDetails) {
						JSONObject customDataValidate = (JSONObject) customData;
						String strCustomListName = (String) customDataValidate.get("customize_food_item_name");
						
						String strItem = getUILocator("btn_customize");
						Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Customize button ");
						Assert.assertTrue(clickElement(strItem), " failed to click the Customize button");
						Offshoredelay();
						
						strItem = getUILocator("sold_out_ingredient").replaceAll("<REPLACE_TEXT>", strCustomListName);
						Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Sold Out Option in More Info Screen ");
												
						log("Successfully validate Sold out Option");
													
					}
					//Navigate Back to Main Station and click on Station
					Assert.assertTrue(clickElement("cancel_btn"), " failed to click the Cancel button in Customize page");
					
					Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
					AppUtilities.delay(2000);
					
					Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
					AppUtilities.delay(2000);

					Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
					AppUtilities.delay(2000);

					// Write Script to select different station type
					driver.findElementByAccessibilityId(station_type).click();
					AppUtilities.delay(3000);
					Offshoredelay();

					station_type_display = "//XCUIElementTypeNavigationBar[contains(@name,'" + station_type + "')]";
					driver.findElementByXPath(station_type_display);
					driver.findElementByAccessibilityId(strStationToSelect).click();

				}
				
				if(customizeFoodItemCategoryType.equalsIgnoreCase("quantity")) {
					String menuItemClick = getUILocator("menu_item_selection_to_order").replaceAll("<REPLACE_TEXT>", strItemToOrder);

					Assert.assertTrue(clickElement(menuItemClick), "Fail to click the Menu item");
					
					log("Validation of Option Sold out scenario");
					for(Object customData : customizeFoodItemDetails) {
						JSONObject customDataValidate = (JSONObject) customData;
						String strCustomListName = (String) customDataValidate.get("customize_food_item_name");
						
						String strItem = getUILocator("btn_customize");
						Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Customize button ");
						Assert.assertTrue(clickElement(strItem), " failed to click the Customize button");
						Offshoredelay();
						
						strItem = getUILocator("sold_out_ingredient").replaceAll("<REPLACE_TEXT>", strCustomListName);
						Assert.assertNotNull(waitForElement(strItem), "Failed to wait for Sold Out Quantity in More Info Screen ");
												
						log("Successfully validate Sold out Quantity");
					}	
					//Navigate Back to Main Station and click on Station
					Assert.assertTrue(clickElement("cancel_btn"), " failed to click the Cancel button in Customize page");
					
					Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
					AppUtilities.delay(2000);
					
					Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
					AppUtilities.delay(2000);
					
					Assert.assertTrue(clickElement("back_buttton_to_main_screen"), "Fail to click on back button in menu page");
					AppUtilities.delay(2000);

					// Write Script to select different station type
					driver.findElementByAccessibilityId(station_type).click();
					AppUtilities.delay(3000);
					Offshoredelay();

					station_type_display = "//XCUIElementTypeNavigationBar[contains(@name,'" + station_type + "')]";
					driver.findElementByXPath(station_type_display);
					driver.findElementByAccessibilityId(strStationToSelect).click();

				}
				
			}
		}

		Offshoredelay();
		
		return this;
	}

}
/*
 * public OrderingApp checkOutAfterRemovingItem(String strOrderPersonName,
 * JSONArray itemsToOrder, JSONArray itemsToRemove, String
 * strExpectedTotalAfterRemove) {
 * 
 * Assert.assertTrue(clickElement("btn_checkout_from_main_menu"),
 * "Failed to click the Checkout button in the Landing page");
 * Assert.assertNotNull(waitForElement("static_heading_checkout_popup"),
 * "Failed to find the Checkout popup heading after clicking Checkout from Landing page"
 * ); Assert.assertNotNull(waitForElement("btn_cancel_checkout_popup"),
 * "Failed to find the Checkout Cancel button in Checkout Screen");
 * Assert.assertNotNull(waitForElement("btn_continue_checkout_popup"),
 * "Failed to find the Checkout Continue button in Checkout Screen");
 * Assert.assertNotNull(waitForElement("text_name_checkout_popup"),
 * "Failed to find the Checkout Name textbox in Checkout Screen");
 * 
 * Assert.assertTrue(typeText("text_name_checkout_popup", strOrderPersonName),
 * "Failed to type name in the Checkout Screen");
 * Assert.assertTrue(clickElement("btn_continue_checkout_popup"),
 * "Failed to click the Continue button in Checkout Screen");
 * 
 * Assert.assertNotNull(waitForElement("btn_back_checkout_popup"),
 * "Failed to find the Back button after clicking Continue button in Checkout Screen"
 * ); Assert.assertNotNull(waitForElement("btn_placeorder_checkout_popup"),
 * "Failed to find the Place Order button after clicking Continue button in Checkout Screen"
 * ); Assert.assertNotNull(waitForElement("static_total_checkout_popup"),
 * "Failed to find the Total order value static after clicking Continue button in Checkout Screen"
 * );
 * 
 * 
 * String strItemToRemove = getUILocator("btn_remove_food_item_checkout_popup");
 * for(Object item : itemsToRemove) { String itemToRemove = (String)item;
 * log("Removing the item:" + itemToRemove); String strItemToRemoveLocator =
 * strItemToRemove.replaceAll("<REPLACE_ITEM_TO_REMOVE>", itemToRemove);
 * Assert.assertTrue(clickElement(strItemToRemoveLocator),
 * "Failed to click the Remove button of the food item:" + itemToRemove); }
 * log("All the food items to be removed has been successfully removed");
 * 
 * //get the total and check String strOrderTotalValue =
 * getUILocator("static_total_value_checkout_popup"); strOrderTotalValue =
 * strOrderTotalValue.replaceAll("<REPLACE_ORDER_TOTAL>",
 * strExpectedTotalAfterRemove);
 * Assert.assertNotNull(waitForElement(strOrderTotalValue),
 * "Failed to find order total:" + strExpectedTotalAfterRemove +
 * " after removing the food item in the order page");
 * log("Total order value has been checked after removing the configured food item"
 * );
 * 
 * Assert.assertTrue(clickElement("btn_placeorder_checkout_popup"),
 * "Failed to click the Place Order button after clicking Continue button in Checkout Screen"
 * );
 * 
 * //thank you page Assert.assertNotNull(waitForElement("btn_done_thank_page"),
 * "Failed to find the Done heading after clicking Place Order");
 * 
 * String strItem = getUILocator("static_thank_you_with_name"); String
 * strNameInThankYou = strItem.replaceAll("<REPLACE_ORDER_NAME>",
 * strOrderPersonName); Assert.assertNotNull(waitForElement(strNameInThankYou),
 * "Failed to find the Thank you text with the name in Final page");
 * 
 * strItem = getUILocator("individual_item_in_thank_you_page"); List<WebElement>
 * list = waitForElements(strItem); log("No. of element:" + list.size());
 * boolean found = false; JSONArray itemListFromPage = new JSONArray();
 * for(WebElement e : list) { //MobileElement cell = (MobileElement)e;
 * JSONObject itemDetails = new JSONObject(); List<WebElement> staticList =
 * e.findElements(By.className("UIAStaticText")); int index = 0; for(WebElement
 * staticItem : staticList) { String value = staticItem.getAttribute("value");
 * log("Reading the item of:" + value); switch(index) { case 0:
 * itemDetails.put("station", value); break; case 1: itemDetails.put("orderid",
 * value); break; case 2: itemDetails.put("name", value); break; case 3:
 * itemDetails.put("food_item_to_change", value); break; case 4:
 * itemDetails.put("price", value); break; case 5:
 * itemDetails.put("ForHere/Togo", value); break; } index++; }
 * itemListFromPage.add(itemDetails);
 * 
 * //MobileElement orderedItem =
 * (MobileElement)cell.findElementByXPath("//UIAStaticText[contains(@value, '" +
 * item_selected_for_order + "')]"); //Assert.assertNotNull(orderedItem,
 * "Failed to find the item ordered:" + item_selected_for_order +
 * " in thank you page"); } log("Items read from Order Thank you page:" +
 * itemListFromPage.toJSONString());
 * 
 * 
 * JSONArray backUpItems = (JSONArray)itemsToOrder.clone(); log("Cloned Items:"
 * + backUpItems.toJSONString()); //remove the item which are removed for(Object
 * i : backUpItems) { JSONObject item = (JSONObject)i; for(Object
 * itemNameToRemove : itemsToRemove) { String itemToRemove =
 * (String)itemNameToRemove; if(
 * ((String)item.get("select_item_to_order")).equalsIgnoreCase(itemToRemove)) {
 * itemsToOrder.remove(item); break; } } }
 * log("Items to check after removing the item:" + itemsToOrder.toJSONString());
 * //store the data in runtime store writeDataInRunStore("DATA_FROM_" +
 * strCurrentTestcaseName, itemsToOrder.toJSONString());
 * 
 * 
 * for(Object i : itemsToOrder) { JSONObject item = (JSONObject)i; String
 * item_selected_for_order = (String)item.get("select_item_to_order");
 * log("Checking the item:" + item_selected_for_order); found = false;
 * for(Object itemFromUI : itemListFromPage) { JSONObject itemUI =
 * (JSONObject)itemFromUI;
 * if(((String)itemUI.get("name")).equalsIgnoreCase(item_selected_for_order)) {
 * found = true; break; } } Assert.assertTrue(found,
 * "Failed to find the item ordered:" + item_selected_for_order +
 * " in thank you page"); log("Successfully found the item:" +
 * item_selected_for_order + " in order thank you page "); }
 * log("The items in the order thank you page has been verified successfully");
 * Assert.assertTrue(clickElement("btn_done_thank_page"),
 * "Failed to click the Done heading after clicking Place Order");
 * 
 * return this; }
 * 
 * 
 * public GuestApp updateCustomizeMenu(JSONArray items) {
 * 
 * for(Object o : items) { JSONObject customItem = (JSONObject)o; String
 * itemCategoryToChange =
 * (String)customItem.get("customize_food_item_category");
 * 
 * JSONArray a = (JSONArray)customItem.get("customize_food_items2");
 * 
 * for(Object i : a) { JSONObject customizeItemSelectDetails = (JSONObject)i;
 * String itemToBeChanged =
 * (String)customizeItemSelectDetails.get("customize_food_item_name2"); String
 * itemstoSelect =
 * (String)customizeItemSelectDetails.get("customize_food_item_count2");
 * log("The customize food item 2 is: "+itemToBeChanged);
 * log("The customize food item 2 count is: "+itemstoSelect); strItem =
 * getUILocator("static_food_item_name_food_custom_page").replaceAll(
 * "<REPLACE_ITEM_TO_SELECT>", itemToCustomize);
 * Assert.assertNotNull(waitForElement(strItem),
 * "Failed to find the food item name:" + itemToCustomize +
 * " custom food item view"); int items = Integer.parseInt(itemstoSelect); while
 * ( items > 0) { if (items == Integer.parseInt(itemstoSelect)) { strItem =
 * getUILocator("cell_select_item_to_customize_food_custom_page").replaceAll(
 * "<REPLACE_CUSTOM_CATEGORY_TO_CHANGE>", itemCategoryToChange); strItem =
 * strItem.replaceAll("<REPLACE_CUSTOM_ITEM_TO_SELECT>", itemToBeChanged);
 * Assert.assertTrue(clickElement(strItem), "Failed to click the option:" +
 * itemToBeChanged + " of category:"+ itemCategoryToChange +
 * " in custom food item view"); } // strItem =
 * getUILocator("cell_Category_Add_Customize_food_list_page").replaceAll(
 * "<REPLACE_CUSTOM_CATEGORY_TO_CHANGE>", itemCategoryToChange); //strItem =
 * strItem.replaceAll("<REPLACE_CUSTOM_ITEM_TO_SELECT>", itemToBeChanged);
 * //Assert.assertTrue(clickElement(strItem), "Failed to click the plus button:"
 * ); items--; }
 * 
 * }
 * 
 * } return this; } /* public OrderingApp selectStationAndMenuItems(String
 * aStationName, JSONArray itemsToChoose) {
 * Assert.assertTrue(clickElement("cell_app_settings_select_cafe"),
 * "Failed to select the Cafe Location"); Assert.assertNotNull(waitForElement(
 * "btn_back_to_cafe_stations_in_select_cafe_location"),
 * "Failed to find the Back button in selecting the cafe locations");
 * 
 * String cafeLocator = getUILocator("cell_select_cafe_location").replaceAll(
 * "<REPLACE_CAFE_LOCATION>", aStationName);
 * Assert.assertNotNull(waitForElement(cafeLocator),
 * "Failed to find the Cafe Location of:" + aStationName);
 * Assert.assertTrue(clickElement(cafeLocator),
 * "Failed to select the Cafe Location:" + aStationName);
 * 
 * //make sure it it selected cafeLocator =
 * getUILocator("cell_default_cafe_selected").replaceAll(
 * "<REPLACE_CAFE_LOCATION>", aStationName);
 * Assert.assertNotNull(waitForElement(cafeLocator),
 * "Failed to find the Selected Cafe Location of:" + aStationName);
 * 
 * String strItemLocator = getUILocator("cell_station_to_select"); String
 * strItemLocatorEnabled = getUILocator("cell_station_enabled"); for(int i = 0;
 * i < itemsToChoose.size(); i++) { String menuItem =
 * (String)itemsToChoose.get(i); String itemLocator =
 * strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
 * Assert.assertTrue(tapElement(itemLocator), "Failed to select the Menu Item:"
 * + menuItem);
 * 
 * //wait for it to to enabled AppUtilities.delay(2000); String
 * itemLocatorEnabled =
 * strItemLocatorEnabled.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
 * Assert.assertNotNull(waitForElement(itemLocatorEnabled),
 * "Failed to select the Item:" + menuItem); AppUtilities.delay(2000); }
 * Assert.assertTrue(clickElement("btn_cafe_settings_done"),
 * "Failed to select the Done button after selecting the menu items in the station"
 * );
 * 
 * return this; }
 * 
 * public OrderingApp checkLandingPage(String aStationName, JSONArray
 * itemsToChoose) {
 * 
 * Assert.assertNotNull(waitForElement("static_app_heading"),
 * "Failed to find the App Heading in the Landing page");
 * 
 * String strItemLocator = getUILocator("cell_item_to_select_in_left_menu");
 * String strItemLocatorToCheck =
 * strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", "All Specials");
 * Assert.assertNotNull(waitForElement(strItemLocatorToCheck),
 * "Failed to find the All Specials item in the left side");
 * 
 * for(int i = 0; i < itemsToChoose.size(); i++) { String menuItem =
 * (String)itemsToChoose.get(i); String itemLocator =
 * strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
 * Assert.assertTrue(clickElement(itemLocator),
 * "Failed to find the configured Menu Item:" + menuItem + " on the left side");
 * } return this; } public GuestApp validateVouchers() {
 * //Assert.assertTrue(clickElement("btn_vouchers_profile_page"),
 * "Failed to click the Vouchers button");
 * Assert.assertNotNull(waitForElement("btn_back_vouchers_page"),
 * "Failed to find the Back button in vouchers page");
 * Assert.assertNotNull(waitForElement("btn_profile_vouchers_page"),
 * "Failed to find the Profile button in vouchers page");
 * 
 * Boolean MealVouchers =
 * waitForElementWithText("static_meal_vouchers_vouchers_page",
 * "MEAL VOUCHERS");
 * 
 * if (MealVouchers) { Boolean Voucher =
 * waitForElementWithText("btn_voucher_profile_page", "$20.00"); if (Voucher) {
 * log("User has voucher available");
 * Assert.assertNotNull(waitForElement("static_vouchers_expirydate_profile_page"
 * ), "Failed to find the Expiry date in Vouchers list"); Offshoredelay();
 * Assert.assertTrue(clickElement("btn_voucher_profile_page"),
 * "Failed to click the Voucher button");
 * Assert.assertNotNull(waitForElement("static_vouchertype_profile_page"),
 * "Failed to find the Voucher type label");
 * Assert.assertNotNull(waitForElement(
 * "static_vouchertype_selected_profile_page"),
 * "Failed to find the Voucher type for voucher");
 * Assert.assertNotNull(waitForElement("static_balance_profile_page"),
 * "Failed to find the balance label in voucher page");
 * Assert.assertNotNull(waitForElement(
 * "static_balance_amount_selected_profile_page"),
 * "Failed to find the Voucher amount");
 * Assert.assertNotNull(waitForElement("static_expires_profile_page"),
 * "Failed to find the expires label in the voucher page");
 * Assert.assertNotNull(waitForElement(
 * "static_expiry_date_selected_profile_page"),
 * "Failed to find expiry date in voucher page");
 * Assert.assertNotNull(waitForElement("btn_back_vouchers_page"),
 * "Failed to find the Back button");
 * Assert.assertNotNull(waitForElement("btn_share_voucher_page"),
 * "Failed to find the Share button in voucher page");
 * Assert.assertNotNull(waitForElement("static_about_voucher_page"),
 * "Failed to find about text label");
 * //Assert.assertNotNull(waitForElement("about_voucher_profile_page"),
 * "Failed to find the about text"); } else {
 * log("User Doesnt have any voucher"); } } return this; }
 * 
 * public OrderingApp selectStationAndCheckFoodItems(String aStationName,
 * JSONArray itemsToVerify) {
 * 
 * Assert.assertNotNull(waitForElement("static_app_heading"),
 * "Failed to find the App Heading in the Landing page");
 * 
 * String strItemLocator = getUILocator("cell_item_to_select_in_left_menu");
 * String strItemLocatorToCheck =
 * strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", aStationName);
 * Assert.assertTrue(clickElement(strItemLocatorToCheck),
 * "Failed to find the station to be selected in the left side");
 * 
 * String strFoodItem = getUILocator("food_item_on_right_side"); for(int i = 0;
 * i < itemsToVerify.size(); i++) { String menuItem =
 * (String)itemsToVerify.get(i); String itemLocator =
 * strFoodItem.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
 * Assert.assertNotNull(waitForElement(itemLocator),
 * "Failed to find the configured food Item:" + menuItem + " for station:" +
 * aStationName); } return this; }
 * 
 * }
 */
