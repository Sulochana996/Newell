package com.apple.ist.caffemac.test;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.util.TextUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.Point;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.sikuli.api.robot.Key;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;

import com.apple.ist.caffemac.test.common.WebApplicationTestBase;
import com.apple.ist.caffemac.test.util.AppUtilities;
import com.apple.ist.caffemac.test.util.JDBCUtil;

public class MenuMakerApp extends WebApplicationTestBase {

	public static final String APPNAME= "menumaker";
	public String voucherTypeInTest,voucherTypeToSelect,voucherStatus,newStationName;;	
	public String foodStationRuntimeId, temp;
	public int index, ind;
	public HashMap <String,String> foodItemCollection = new HashMap<String,String>();
	public HashMap <Integer,String> foodItemNameDisplayOrderCollection = new HashMap<Integer,String>();
	public HashMap <String, Integer> stationOrder = new HashMap<String,Integer>();
	public HashMap <String, String> existingIds= new HashMap<String, String>();
	public MenuMakerApp() {
		super(APPNAME);
		//log("Menumaker constructor complete");
	}
	
	public MenuMakerApp(JSONObject dataObject, JSONObject runParams) {
		super(APPNAME);
		appObject = dataObject;
		initWithParams(runParams);
	}
	
	public MenuMakerApp launch() throws Exception {
		
		log("Browser name is:" + getBrowserName());
		if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")) {
			Assert.assertTrue(AppUtilities.loginUATAppleConnect(strBaseDir, getAppLoginUsername(), getAppLoginPassword(), true), "Failed to login to UAT authentication");
			AppUtilities.minimiseOtherProcess(strBaseDir);
			log("Successfully authenticated to appleconnect user in UAT for Safari execution.");
		}
		Assert.assertTrue(launchApp(), "Failed in launching the App:" + APPNAME);
		return this;
	}
	
	public MenuMakerApp launch(String userName, String password) throws Exception {
		
		log("Browser name is:" + getBrowserName());
		//log(userName+ password);
		if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")) {
			Assert.assertTrue(AppUtilities.loginUATAppleConnect(strBaseDir, userName, password, true), "Failed to login to UAT authentication");
			AppUtilities.minimiseOtherProcess(strBaseDir);
			log("Successfully authenticated to appleconnect user in UAT for Safari execution.");
		}
		Assert.assertTrue(launchApp(), "Failed in launching the App:" + APPNAME);
		return this;
	}
	
	public void quitApp() {
		closeApp();
	}
	
	public MenuMakerApp login() {
		
		if(StringUtils.containsIgnoreCase(getBrowserName(), "firefox")) {
			log("Performing Apple connect authentication for firefox..");
			Assert.assertNotNull(waitForElement("apple_connect_application_name"), "Failed to find the apple connect welcome message");
			Assert.assertNotNull(waitForElement("apple_connect_username"), "Failed to find the apple connect username text field");
			WebElement p = waitForElement("apple_connect_password");
			Assert.assertNotNull(p, "Failed to find the apple connect username text field");
			Assert.assertTrue(typeText("apple_connect_username", getAppLoginUsername()), "Failed to type the login username");
			Assert.assertTrue(typeText("apple_connect_password", getAppLoginPassword()), "Failed to type the login password");
			//Assert.assertTrue(clickElement("apple_connect_btn_continue"), "Failed to click the login button");
			p.submit();
		}  else if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")) {
			log("The user has been already logged in for Safari. So check for the home page content...");
		}
		log("AppleConnect user has been successfully logged in...Awaiting for the page content to get loaded..");
		checkPageIsReady();
		waitForElement("caffemac_logo");	
		WebElement e = waitForElement("menu_page");
		if(e !=null){
		Assert.assertTrue(clickElement("menu_page"), "Failed to navigate to menu page");
		Assert.assertNotNull(waitForElement("dinner_meal_time"), "Failed to find the Dinner Menu after login");	
		}
		if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")){
			highlightSafari();
		}
		return this;
	}
	
	public MenuMakerApp login(String username, String password) {
		
		if(StringUtils.containsIgnoreCase(getBrowserName(), "firefox")) {
			log("Performing Apple connect authentication for firefox..");
			Assert.assertNotNull(waitForElement("apple_connect_application_name"), "Failed to find the apple connect welcome message");
			Assert.assertNotNull(waitForElement("apple_connect_username"), "Failed to find the apple connect username text field");
			WebElement p = waitForElement("apple_connect_password");
			Assert.assertNotNull(p, "Failed to find the apple connect username text field");
			Assert.assertTrue(typeText("apple_connect_username", username), "Failed to type the login username");
			Assert.assertTrue(typeText("apple_connect_password", password), "Failed to type the login password");
			//Assert.assertTrue(clickElement("apple_connect_btn_continue"), "Failed to click the login button");
			p.submit();
		}  else if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")) {
			log("The user has been already logged in for Safari. So check for the home page content...");
		}
		log("AppleConnect user has been successfully logged in...Awaiting for the page content to get loaded..");
		checkPageIsReady();
		Assert.assertNotNull(waitForElement("caffemac_logo"), "Failed to find the Dinner Menu after login");	
		WebElement e = waitForElement("menu_page");
		if(e !=null){
		Assert.assertTrue(clickElement("menu_page"), "Failed to navigate to menu page");
		Assert.assertNotNull(waitForElement("dinner_meal_time"), "Failed to find the Dinner Menu after login");	
		}
		if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")){
			highlightSafari();
		}
		return this;
	}
	
	public MenuMakerApp chooseCafeLocation(String aCaffeLocation) {		
		
		Assert.assertTrue(clickElement("current_caffe_location"), "Failed to click the Caffe Location menu");
		String cafeLocation = getUILocator("select_cafe_by_name");
		cafeLocation = cafeLocation.replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", aCaffeLocation);
		Assert.assertTrue(clickElement(cafeLocation), "Failed to click the Caffe Location:" + aCaffeLocation);		
		Assert.assertTrue(waitForElementWithText("current_caffe_location", aCaffeLocation), "Failed to find the current caffe location as:" + aCaffeLocation);

		//wait for special / standard buttons
		Assert.assertNotNull(waitForElement("select_special_menu"), "Failed to find the special menu after selecting the caffe location");
		Assert.assertNotNull(waitForElement("select_standard_menu"), "Failed to find the standard menu after selecting the caffe location");
		
		log("Cafe Location has been chosen..");
		return this;
	}
	
	public MenuMakerApp createGivenFoodItems(JSONArray itemList) {		
		
		Assert.assertNotNull(itemList, "Failed as the food items to be created found to be null");
		Assert.assertTrue(itemList.size() > 0, "Failed as the food items to be created found to be empty");
		
		for(Object i : itemList) {
			JSONObject foodItem = (JSONObject)i;
			Assert.assertNotNull(createFoodItem(foodItem), "Failed to create the food item with details:" + foodItem.toJSONString());
		}
		
		return this;
	}
	
	public MenuMakerApp validateMenuPage(JSONArray itemList) {		
		
		Assert.assertNotNull(itemList, "Failed as the food items to be created found to be null");
		Assert.assertTrue(itemList.size() > 0, "Failed as the food items to be created found to be empty");
		
		for(Object i : itemList) {
			JSONObject foodItem = (JSONObject)i;
			Assert.assertNotNull(selectMealTimeCaffeLocationStation(foodItem), "Failed to select the meal-time, Caffe Location and Station");
			String select_station = (String)foodItem.get("select_station");
			String strAddDishLink = getUILocator("add_dish_link");
			strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);
			
			Assert.assertTrue(clickElement(strAddDishLink), "Failed to click Add Dish on the selected Station:" + select_station);
			log("Clicked on Add Dish link");
			AppUtilities.delay(2000);
		}

		return this;
	}
	
	public MenuMakerApp validateCancelButton(JSONArray itemList) {		
		
		Assert.assertNotNull(itemList, "Failed as the food items to be created found to be null");
		Assert.assertTrue(itemList.size() > 0, "Failed as the food items to be created found to be empty");
		
		for(Object i : itemList) {
			JSONObject foodItem = (JSONObject)i;
			Assert.assertNotNull(removeGivenFoodItem(foodItem), "Failed to remove the food item");
			Assert.assertNotNull(selectMealTimeCaffeLocationStation(foodItem), "Failed to select the meal-time, Caffe Location and Station");
			String select_station = (String)foodItem.get("select_station");
			String strAddDishLink = getUILocator("add_dish_link");
			strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);
			Assert.assertTrue(clickElement(strAddDishLink), "Failed to click Add Dish on the selected Station:" + select_station);
			log("Clicked on Add Dish link");
			
			WebElement label = waitForElement("add_new_component");
			Point p = label.getLocation();
			((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() + 200) + ");");
			log("Brought the cancel button into view");
			AppUtilities.delay(2000);		
			Assert.assertTrue(clickElement("add_new_item_cancel"), "Failed to click cancel on the selected Station:" + select_station);
			log("Clicked on cancel link");
			AppUtilities.delay(2000);
		}

		return this;
	}
	
		public MenuMakerApp validateServingDetails(JSONArray itemList) {		
		
		Assert.assertNotNull(itemList, "Failed as the food items to be created found to be null");
		Assert.assertTrue(itemList.size() > 0, "Failed as the food items to be created found to be empty");
		
		for(Object i : itemList) {
			JSONObject foodItem = (JSONObject)i;
			Assert.assertNotNull(removeGivenFoodItem(foodItem), "Failed to remove the food item");
			Assert.assertNotNull(selectMealTimeCaffeLocationStation(foodItem), "Failed to select the meal-time, Caffe Location and Station");
			String select_station = (String)foodItem.get("select_station");
			String strAddDishLink = getUILocator("add_dish_link");
			strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);
			Assert.assertTrue(clickElement(strAddDishLink), "Failed to click Add Dish on the selected Station:" + select_station);
			log("Clicked on Add Dish link");
			enterServingDetails(foodItem);
		}

		return this;
	}
	
	public MenuMakerApp validateNewMenuItem(JSONArray itemList) {		
		
		for(Object i : itemList) {
			JSONObject foodItem = (JSONObject)i;
			Assert.assertNotNull(enterFoodItemNameDetails(foodItem), "Failed to select the meal-time, Caffe Location and Station");
			log("entered product details");
			AppUtilities.delay(2000);
		}

		return this;
	}
	
	private MenuMakerApp selectMealTimeCaffeLocationStationMenuPage(JSONObject itemDetails) {
		
		String select_caffe_location =  (String)itemDetails.get("select_caffe_location");
		String food_for = (String)itemDetails.get("food_for");
		String food_type = (String)itemDetails.get("food_type");

		//select the food for:
		//String strFoodForLocator = null, strFoodForLocatorVerification;
		
		String strFoodForLocator = getUILocator("variable_meal_time");	//default variable
		String strFoodForLocatorVerification = getUILocator("variable_meal_time_active");
		
		if(StringUtils.equalsIgnoreCase(food_for, "dinner")) {
			strFoodForLocator = getUILocator("dinner_meal_time");
			strFoodForLocatorVerification = getUILocator("dinner_meal_time_active");	//default variable
		} else if(StringUtils.equalsIgnoreCase(food_for, "breakfast")) {
			strFoodForLocator = getUILocator("breakfast_meal_time");
			strFoodForLocatorVerification = getUILocator("breakfast_meal_time_active");	//default variable
		} else if (StringUtils.equalsIgnoreCase(food_for, "lunch")) {
			 strFoodForLocator = getUILocator("lunch_meal_time");	
			 strFoodForLocatorVerification = getUILocator("lunch_mean_time_active");	//default variable	
		}else {
			 strFoodForLocator = getUILocator("variable_meal_time");	
			 strFoodForLocatorVerification = getUILocator("variable_meal_time_active");
		}
		
		Assert.assertTrue(clickElement(strFoodForLocator), "Failed to click the Mealtime for:" + food_for);
		Assert.assertNotNull(waitForElement(strFoodForLocatorVerification), "Failed to verify the active meal-time selected");
		log("Mealtime has been selected");
		AppUtilities.delay(10000);
		
		Assert.assertNotNull(chooseCafeLocation(select_caffe_location), "Failed to select the caffe location:" + select_caffe_location);
		log("Caffe location has been selected");
		AppUtilities.delay(2000);
		
		String strFoodType = getUILocator("select_special_menu"); // default special menu
		if(StringUtils.equalsIgnoreCase(food_type, "standard")) {
			strFoodType = getUILocator("select_standard_menu");
		}
		Assert.assertTrue(clickElement(strFoodType), "Failed to click the Food type for:" + food_type);
		String strFoodTypeSelected = getUILocator("select_special_menu_active"); // default special menu
		if(StringUtils.equalsIgnoreCase(food_type, "standard")) {
			strFoodTypeSelected = getUILocator("select_standard_menu_active");
		}
		Assert.assertNotNull(waitForElement(strFoodTypeSelected), "Failed to check the selected the Food type for:" + food_type);
		log("Food type has been selected");
		AppUtilities.delay(2000);
		return this;
	}
	public MenuMakerApp selectMealTimeCaffeLocationStation(JSONObject itemDetails) {
  		
		selectMealTimeCaffeLocationStationMenuPage(itemDetails);

		String select_station = (String)itemDetails.get("select_station");
		String strLeftStation = getUILocator("select_station_left_side");
		strLeftStation = strLeftStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		Assert.assertTrue(clickElement(strLeftStation), "Failed to click the Station:" + select_station);
		log("The station:" + select_station + " has been selected");
		AppUtilities.delay(2000);
		
		return this;
	}
	
	public MenuMakerApp validateComponentDetails(JSONArray FoodItemList ){
		
		for(Object i : FoodItemList) {
			JSONObject foodItem = (JSONObject)i;
			Assert.assertNotNull(componentDetails(foodItem), "Failed to select the meal-time, Caffe Location and Station");
			log("entered component details");
			AppUtilities.delay(2000);
		}
		return this;
	}
	
	private MenuMakerApp componentDetails(JSONObject itemDetails){
		JSONArray components = (JSONArray)itemDetails.get("components");
		String select_station = (String) itemDetails.get("select_station");
		WebElement menuContainer = driver.findElement(By.cssSelector("div#menuItemContainer"));
		int index = 0;
		for(Object c : components) {
			JSONObject component  = (JSONObject)c;
			Assert.assertNotNull(enterFoodItemComponentDetails(menuContainer,select_station,index, component), "Failed to add the component");	
			index++;
		}
		return this;
	}
	
	public MenuMakerApp saveFoodItem(JSONArray itemList) {
		for(Object i : itemList) {
			JSONObject itemDetails = (JSONObject)i;
			log("Removing the food item if it exists... before creating it ");
			removeGivenFoodItem(itemDetails);
			log("Removing the food items with the same name given completed");
			
			Assert.assertNotNull(selectMealTimeCaffeLocationStation(itemDetails), "Failed to select the meal-time, Caffe Location and Station");
			
			String select_station = (String)itemDetails.get("select_station");
			String strAddDishLink = getUILocator("add_dish_link");
			strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);
			
			Assert.assertTrue(clickElement(strAddDishLink), "Failed to click Add Dish on the selected Station:" + select_station);
			log("Clicked on Add Dish link");
			AppUtilities.delay(2000);
			WebElement menuContainer = driver.findElement(By.cssSelector("div#menuItemContainer"));
			
			Assert.assertNotNull(enterFoodItemNutritionDetails(itemDetails), "Failed while entering the new item nutrition and serving details");
			Assert.assertNotNull(enterServingDetails(itemDetails), "Failed while entering the new item nutrition and serving details");
			Assert.assertNotNull(enterFoodItemNameDetails(itemDetails), "Failed while entering the new item name / desc / price details");
			
			JSONArray components = (JSONArray)itemDetails.get("components");
			log(components.toJSONString());
			int index = 0;
			for(Object c : components) {
				JSONObject component  = (JSONObject)c;
				Assert.assertNotNull(enterFoodItemComponentDetails(menuContainer,select_station,index, component), "Failed to add the component");	
				index++;
			}
			
			Assert.assertTrue(clickElement("add_new_item_save"), "Failed to click the save button");
			
			AppUtilities.delay(2000);
			log("After 2 seconds delay");
			
			Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
			
			String stationIdPicker = getUILocator("station_food_station_menuContainer_body");
			stationIdPicker = stationIdPicker.replaceAll("<REPLACE_STATION_NAME>", select_station+ind);
			WebElement stationIDElement = waitForElement(stationIdPicker);
			Assert.assertNotNull(stationIDElement, "Failed to find the element which contains food item id");
			AppUtilities.delay(5000);
			log("After 5 seconds delay");
			foodStationRuntimeId = stationIDElement.getAttribute("data-food-station-id");
			log("Food Station run-time id:" + foodStationRuntimeId);
			Assert.assertTrue(StringUtils.isNotEmpty(foodStationRuntimeId), "Failed to get the food station run-time id");
			
			String foodStatusElement = getUILocator("add_new_item_status").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
			Assert.assertNotNull(waitForElement(foodStatusElement), "Failed to find the Draft status element");		
			Assert.assertTrue(waitForElementWithText(foodStatusElement, "DRAFT"), "Failed to find the DRAFT status after clicking save button");
			log("Saved and Draft status has been verified");
			AppUtilities.delay(2000);
		}
		return this;
	}
	public MenuMakerApp createFoodItem(JSONObject itemDetails) {	
		
		log("Removing the food item if it exists... before creating it ");
		removeGivenFoodItem(itemDetails);
		log("Removing the food items with the same name given completed");

		Assert.assertNotNull(selectMealTimeCaffeLocationStation(itemDetails), "Failed to select the meal-time, Caffe Location and Station");
		
		String select_station = (String)itemDetails.get("select_station");
		String strAddDishLink = getUILocator("add_dish_link");
		strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		Assert.assertTrue(clickElement(strAddDishLink), "Failed to click Add Dish on the selected Station:" + select_station);
		log("Clicked on Add Dish link");
		AppUtilities.delay(10000);
		
		WebElement menuContainer = driver.findElement(By.cssSelector("div#menuItemContainer"));
		Assert.assertNotNull(enterServingDetails(itemDetails), "Failed while entering the new item nutrition and serving details");
		Assert.assertNotNull(enterFoodItemNameDetails(itemDetails), "Failed while entering the new item name / desc / price details");
		
		JSONArray components = (JSONArray)itemDetails.get("components");
		int index = 0;
		for(Object c : components) {
			JSONObject component  = (JSONObject)c;
			Assert.assertNotNull(enterFoodItemComponentDetails(menuContainer, select_station,index, component), "Failed to add the component");	
			index++;
		}
		
		Assert.assertTrue(clickElement("add_new_item_save"), "Failed to click the save button");
		
		AppUtilities.delay(5000);
		log("After 5 seconds delay");
		
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
		
		String stationIdPickerU = getUILocator("station_food_station_menuContainer_body");
		stationIdPickerU = stationIdPickerU.replaceAll("<REPLACE_STATION_NAME>", select_station+ind);
		
		List<WebElement> stationIDElementU = waitForElements(stationIdPickerU);
		Assert.assertNotNull(stationIDElementU, "Failed to find the element which contains food item id");
		log("The station id element is: "+stationIDElementU);
		log("The station id size is: "+stationIDElementU.size());
		if (stationIDElementU.size()==1){
		AppUtilities.delay(15000);
		log("After 5 seconds delay");
		String stationIdPicker = getUILocator("station_food_station_menuContainer_body");
		stationIdPicker = stationIdPicker.replaceAll("<REPLACE_STATION_NAME>", select_station+ind);
		WebElement stationIDElement = waitForElement(stationIdPicker);
		foodStationRuntimeId = stationIDElement.getAttribute("data-food-station-id");
		log("Food Station run-time id:" + foodStationRuntimeId);
		Assert.assertTrue(StringUtils.isNotEmpty(foodStationRuntimeId), "Failed to get the food station run-time id");
		} else if (stationIDElementU.size()>1){
			int noOfElements = stationIDElementU.size();
			for(int i=0; i<noOfElements;i++){
				
				log(existingIds.toString());
				
				if (i<noOfElements-1){
				if (existingIds.get(Integer.toString(i)).equals(select_station+Integer.toString(i)) ) {
					log("Existing Id");
				}
				}else
				{
					//log("I am here" + Integer.toString(i));
					String indexId = Integer.toString(i);
					String stationIdPicker = getUILocator("station_food_station_menuContainer_body");
					stationIdPicker = stationIdPicker.replaceAll("<REPLACE_STATION_NAME>", select_station+indexId);
					log(stationIdPicker);
					WebElement stationIDElement1 = waitForElement(stationIdPicker);
					foodStationRuntimeId = stationIDElement1.getAttribute("data-food-station-id");
					log("Food Station run-time id:" + foodStationRuntimeId);
					Assert.assertTrue(StringUtils.isNotEmpty(foodStationRuntimeId), "Failed to get the food station run-time id");
					
					break;
				}
			}	
		}
		checkPageIsReady();
		String foodStatusElement = getUILocator("add_new_item_status").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		Assert.assertNotNull(waitForElement(foodStatusElement), "Failed to find the Draft status element");		
		AppUtilities.delay(2000);
		WebElement e = waitForElement(foodStatusElement);
		log(e.getText());
		Assert.assertTrue(e.getText().contains("DRAFT"), "Failed to find the DRAFT status after clicking save button");
		//Assert.assertTrue(waitForElementWithText(foodStatusElement, "DRAFT"), "Failed to find the DRAFT status after clicking save button");
		log("Saved and Draft status has been verified");
		AppUtilities.delay(2000);
		
		Assert.assertNotNull(enterFoodItemNutritionDetails(itemDetails), "Failed while entering the new item nutrition and serving details");
		AppUtilities.delay(2000);
		//get the food item id from add_new_item_id attribute 

		String strReviewButton = getUILocator("add_new_item_review_btn").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		WebElement reviewBtn = waitForElement(strReviewButton);
		Assert.assertNotNull(reviewBtn, "Failed to find the review button after creating food item");
		
		Assert.assertTrue(clickElement(strReviewButton), "Failed to click the review button");		
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement(foodStatusElement), "Failed to find the Draft status element");		
		Assert.assertTrue(waitForElementWithText(foodStatusElement, "REVIEWED"), "Failed to find the REVIEWED status after clicking review button");
		log("Reviewed and REVIEWED status has been verified");
		
		String strVerifyButton = getUILocator("add_new_item_verify_btn").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);

		WebElement i = waitForElement(strVerifyButton);
		Point p = i.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 600) + ");");
		log("Brought the link into view");
		AppUtilities.delay(5000);
		
		Assert.assertNotNull(uploadImageToThisFoodItemIfConfigured(foodStationRuntimeId, itemDetails), "Failed to upload the image for the food item");
		//Time to check the customized option and if so, do customize the item
		Assert.assertNotNull(customizeTheGivenFoodItemIfRequired(foodStationRuntimeId, itemDetails), "Failed while customizing the given item");
		
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement(strVerifyButton), "Failed to click the verify button");		
		AppUtilities.delay(2000);
		String strPublishButton = getUILocator("add_new_item_publish_btn").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		WebElement publishBtn = waitForElement(strPublishButton);
		Assert.assertNotNull(publishBtn, "Failed to find the publish button after creating food item");

		Assert.assertTrue(waitForElementWithText(foodStatusElement, "VERIFIED"), "Failed to find the VERIFIED status after clicking verify button");
		log("Verified status has been verified");
		AppUtilities.delay(2000);
		
		Assert.assertTrue(clickElement(strPublishButton), "Failed to click the publish button");		
		Assert.assertTrue(waitForElementWithText(foodStatusElement, "PUBLISHED"), "Failed to find the PUBLISHED status after clicking publish button");
		log("Published has been verified");
		AppUtilities.delay(2000);

		//DRAFT - > REVIEWED - > VERIFIED -> PUBLISHED
		log("Successfully added the food item details");
	
		return this;
	}
	
	public MenuMakerApp createSharedFoodItem(JSONObject itemDetails) {	
		
		log("Removing the food item if it exists... before creating it ");
		//removeGivenSharedFoodItems(itemDetails);
		log("Removing the food items with the same name given completed");

		Assert.assertNotNull(selectCaffeRegion(itemDetails), "Failed to select the meal-time, Caffe Location and Station");
		AppUtilities.delay(5000);
		String select_caffe_region = (String)itemDetails.get("select_caffe_region");
		List<WebElement> menuContainers = driver.findElements(By.cssSelector("div.accordion-container"));
		int sharedMenus= menuContainers.size();
		log(sharedMenus+"");
		Assert.assertTrue(clickElement("add_shared_dish"), "Failed to click Add Dish on the selected Station:" +select_caffe_region );
		log("Clicked on Add Dish link");
		AppUtilities.delay(5000);
		Assert.assertNotNull(enterFoodItemNameDetails(itemDetails), "Failed while entering the new item name / desc / price details");
		
		String menuid =select_caffe_region+sharedMenus;
		WebElement menuContainer = driver.findElement(By.xpath("//div[@id='"+menuid+"']"));
		
		
		JSONArray components = (JSONArray)itemDetails.get("components");
		int index = 0;
		for(Object c : components) {
			JSONObject component  = (JSONObject)c;
			Assert.assertNotNull(enterFoodItemComponentDetails(menuContainer, menuid,index, component), "Failed to add the component");	
			index++;
		}
		
		Assert.assertTrue(clickElement("add_new_item_save"), "Failed to click the save button");
		AppUtilities.delay(5000);
		log("After 5 seconds delay");
		
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
		log("Saved and Draft status has been verified");
		AppUtilities.delay(2000);
		String stationIdPicker = getUILocator("station_food_station_menuContainer_body");
		stationIdPicker = stationIdPicker.replaceAll("<REPLACE_STATION_NAME>", menuid);
		WebElement stationIDElement = waitForElement(stationIdPicker);
		Assert.assertNotNull(stationIDElement, "Failed to find the element which contains food item id");
		AppUtilities.delay(15000);
		log("After 5 seconds delay");
		foodStationRuntimeId = stationIDElement.getAttribute("data-food-station-id");
		log("Food Station run-time id:" + foodStationRuntimeId);
		Assert.assertTrue(StringUtils.isNotEmpty(foodStationRuntimeId), "Failed to get the food station run-time id");
		
		Assert.assertNotNull(enterFoodItemNutritionDetails(itemDetails), "Failed while entering the new item nutrition and serving details");
		AppUtilities.delay(2000);
		Assert.assertNotNull(uploadImageToThisFoodItemIfConfigured(foodStationRuntimeId, itemDetails), "Failed to upload the image for the food item");
		//Time to check the customized option and if so, do customize the item
		Assert.assertNotNull(customizeTheGivenFoodItemIfRequired(foodStationRuntimeId, itemDetails), "Failed while customizing the given item");
		
		//AppUtilities.delay(2000);
		//String strPublishButton = getUILocator("add_new_item_publish_btn").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		WebElement publishBtn = waitForElement("shared_publish_menu");
		Assert.assertNotNull(publishBtn, "Failed to find the publish button after creating food item");
		Assert.assertTrue(clickElement("shared_publish_menu"), "Failed to click the publish button");		
		//Assert.assertTrue(waitForElementWithText(foodStatusElement, "PUBLISHED"), "Failed to find the PUBLISHED status after clicking publish button");
		log("Published has been verified");
		AppUtilities.delay(2000);

		//DRAFT -> PUBLISHED
		log("Successfully added the food item details");
	
		return this;
	}
	
	private MenuMakerApp createSharedLocation(JSONObject itemDetails){
		
		return this;
	}
	private MenuMakerApp selectCaffeRegion(JSONObject itemDetails) {
			String caffeRegion = (String) itemDetails.get("select_caffe_region");
			log(caffeRegion);
			Assert.assertTrue(clickElement("admin_page"), "Failed to click the Caffe Location menu");
			AppUtilities.delay(2000);
			Assert.assertTrue(clickElement("region_menu"), "Failed to click the Caffe Location menu");
			Assert.assertTrue(clickElement("current_caffe_region"), "Failed to click the Caffe Location menu");
			String cafeLocationRegion = getUILocator("select_caffe_region");
			cafeLocationRegion = cafeLocationRegion.replaceAll("<REPLACE_CAFFE_REGION>", caffeRegion);
			log(caffeRegion+":"+cafeLocationRegion);
			AppUtilities.delay(2000);
			try{
			Assert.assertTrue(scrollToElement(waitForElement(cafeLocationRegion)),"Failed to find caffe region");	
			Assert.assertTrue(clickElement(cafeLocationRegion), "Failed to click the Caffe Location:" + caffeRegion);	
			}catch (Exception e){
				log(e.getMessage());
			}
			String selectedRegion = getUILocator("selected_caffe_region");
			selectedRegion = selectedRegion.replaceAll("<REPLACE_CAFFE_REGION>", caffeRegion);
			Assert.assertNotNull(waitForElement(selectedRegion), "Failed to find the current caffe location as:" + caffeRegion);
			log("Cafe Region has been chosen..");
			return this;	
	}
	

public MenuMakerApp createItemCustomized(JSONObject itemDetails) {	
		
		log("Removing the food item if it exists... before creating it ");
		removeGivenFoodItem(itemDetails);
		log("Removing the food items with the same name given completed");

		Assert.assertNotNull(selectMealTimeCaffeLocationStation(itemDetails), "Failed to select the meal-time, Caffe Location and Station");
		
		String select_station = (String)itemDetails.get("select_station");
		String strAddDishLink = getUILocator("add_dish_link");
		strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		Assert.assertTrue(clickElement(strAddDishLink), "Failed to click Add Dish on the selected Station:" + select_station);
		log("Clicked on Add Dish link");
		AppUtilities.delay(2000);
		
		WebElement menuContainer = driver.findElement(By.cssSelector("div#menuItemContainer"));
		//Assert.assertNotNull(enterFoodItemNutritionDetails(itemDetails), "Failed while entering the new item nutrition and serving details");
		Assert.assertNotNull(enterServingDetails(itemDetails), "Failed while entering the new item nutrition and serving details");
		Assert.assertNotNull(enterFoodItemNameDetails(itemDetails), "Failed while entering the new item name / desc / price details");
		AppUtilities.delay(5000);
		JSONArray components = (JSONArray)itemDetails.get("components");
		int index = 0;
		for(Object c : components) {
			JSONObject component  = (JSONObject)c;
			Assert.assertNotNull(enterFoodItemComponentDetails(menuContainer,select_station, index, component), "Failed to add the component");	
			index++;
		}
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("add_new_item_save"), "Failed to click the save button");
		
		AppUtilities.delay(2000);
		log("After 2 seconds delay");
		
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
		
		String stationIdPicker = getUILocator("station_food_station_menuContainer_body");
		stationIdPicker = stationIdPicker.replaceAll("<REPLACE_STATION_NAME>", select_station+ind);
		WebElement stationIDElement = waitForElement(stationIdPicker);
		Assert.assertNotNull(stationIDElement, "Failed to find the element which contains food item id");
		AppUtilities.delay(15000);
		log("After 5 seconds delay");
		foodStationRuntimeId = stationIDElement.getAttribute("data-food-station-id");
		log("Food Station run-time id:" + foodStationRuntimeId);
		Assert.assertTrue(StringUtils.isNotEmpty(foodStationRuntimeId), "Failed to get the food station run-time id");
		
		//componentRuntimeId = 
		
		String foodStatusElement = getUILocator("add_new_item_status").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		Assert.assertNotNull(waitForElement(foodStatusElement), "Failed to find the Draft status element");		
		Assert.assertTrue(waitForElementWithText(foodStatusElement, "DRAFT"), "Failed to find the DRAFT status after clicking save button");
		log("Saved and Draft status has been verified");
		AppUtilities.delay(2000);

		//get the food item id from add_new_item_id attribute 

		String strReviewButton = getUILocator("add_new_item_review_btn").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		WebElement reviewBtn = waitForElement(strReviewButton);
		Assert.assertNotNull(reviewBtn, "Failed to find the review button after creating food item");
		Assert.assertTrue(clickElement(strReviewButton), "Failed to click the review button");		
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement(foodStatusElement), "Failed to find the Draft status element");		
		Assert.assertTrue(waitForElementWithText(foodStatusElement, "REVIEWED"), "Failed to find the REVIEWED status after clicking review button");
		log("Reviewed and REVIEWED status has been verified");
		
		String strVerifyButton = getUILocator("add_new_item_verify_btn").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);

		WebElement i = waitForElement(strVerifyButton);
		Point p = i.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 600) + ");");
		log("Brought the link into view");
		AppUtilities.delay(5000);
		
		//Assert.assertNotNull(uploadImageToThisFoodItemIfConfigured(foodStationRuntimeId, itemDetails), "Failed to upload the image for the food item");
		log("Moving to next function");
		return this;
	}

	public MenuMakerApp validateCustomiseOptionAfterSave(String foodStationRuntimeId, JSONObject itemDetails){
		
		log(foodStationRuntimeId);
		log(itemDetails.toJSONString());
		
		String strFileSaveButton = getUILocator("add_new_item_save_existing").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		WebElement saveBtn = waitForElement(strFileSaveButton);
		Point p = saveBtn.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - (600)) + ");");
		log("Brought customize food item link into the view " + Integer.toString(600));
		
		String StrItem = getUILocator("customize_food_item_link_old");
		StrItem= StrItem.replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		Assert.assertTrue(clickElement(StrItem), "Failed to click on the customisation option link");
		AppUtilities.delay(2000);
		return this;
	}
	
	public MenuMakerApp createLabels(String foodStationRuntimeId, String label1, String label2, String price2) {
		String strAddLabelPriceButton = getUILocator("add_button_label_price_section").replaceAll("<REPLACE_ITERATION_NUMBER>", "0");
		Assert.assertTrue(clickElement(strAddLabelPriceButton), "Failed to click + button in label price field");
		
		String strLabel1PriceField = getUILocator("label_field_label_price_section").replaceAll("<REPLACE_ITERATION_NUMBER>", "0");
		Assert.assertTrue(typeText(strLabel1PriceField, label1), "Failed to type label title");
		
		String strLabel2PriceField = getUILocator("label_field_label_price_section").replaceAll("<REPLACE_ITERATION_NUMBER>", "1");
		Assert.assertTrue(typeText(strLabel2PriceField, label2), "Failed to type label title");
		String strPrice2Field = getUILocator("price_field_label_price_section").replaceAll("<REPLACE_ITERATION_NUMBER>", "1");
		Assert.assertTrue(typeText(strPrice2Field, price2), "Failed to type label title");
		
		String strModifySaveButton = getUILocator("modify_item_save").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		Assert.assertTrue(clickElement(strModifySaveButton), "Failed to click the save button");
		AppUtilities.delay(5000);
		
		return this;
	}
	
	public MenuMakerApp validateLabels(String foodStationRuntimeId, String label1, String label2) {
		String StrItem = getUILocator("customize_food_item_link_old");
		StrItem= StrItem.replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		Assert.assertTrue(clickElement(StrItem), "Failed to click on the customisation option link");
		AppUtilities.delay(2000);
		String strLabel1 = getUILocator("label_button_customizable_popup").replaceAll("<REPLACE_ITERATION_NUMBER>", "0");
		Assert.assertNotNull(waitForElement(strLabel1), "Failed to find Label1");
		String strLabel2 = getUILocator("label_button_customizable_popup").replaceAll("<REPLACE_ITERATION_NUMBER>", "1");
		Assert.assertNotNull(waitForElement(strLabel2), "failed to find Label2");
		return this;
	}
	
	
	public MenuMakerApp validateCopyFromLabel1(String foodStationRuntimeId, String label1, String label2) {
		String categoryName = "Category1";
		String strLabel1 = getUILocator("label_button_customizable_popup").replaceAll("<REPLACE_ITERATION_NUMBER>", "0");
		Assert.assertTrue(clickElement(strLabel1), "Failed to click Label1");
		Assert.assertTrue(clickElement("customize_food_item_add_category"), "Failec to click add category link");
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_heading_dialog"), "The add new category popup is not opened");
		Assert.assertTrue(typeText("customize_food_item_add_category_name_dialog", categoryName), "Failed to type Category name");
		Assert.assertTrue(clickElement("customize_food_item_add_category_create_btn_dialog"), "Failed to click Create button");
		AppUtilities.delay(2000);
		String strLabel2 = getUILocator("label_button_customizable_popup").replaceAll("<REPLACE_ITERATION_NUMBER>", "1");
		Assert.assertTrue(clickElement(strLabel2), "Failed to click Label2");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("copy_customize_customizable_popup"), "Failed to click copy customize popup");
		AppUtilities.delay(2000);
		String strCopyCustomizeLocator = getUILocator("copy_customize_dropdown_customizable_popup").replaceAll("<REPLACE_LABEL1_NAME>", label1);
		Assert.assertTrue(clickElement(strCopyCustomizeLocator), "Failed to click copy customize popup");
		Assert.assertTrue(clickElement("copy_customize_ok_button_customizable_popup"), "Failed to click ok button in copy customize");
		AppUtilities.delay(10000);
		String strCopyCustomizeCategoryName = getUILocator("category_name_customizable_popup").replaceAll("<REPLACE_CATEGORY_NAME>", categoryName);
		Assert.assertNotNull(waitForElement(strCopyCustomizeCategoryName), "Failed to find the Copied category");
		return this;
	}
	
	public MenuMakerApp createListTypeCategory(int number_of_list_ingredient, String priceIncrease) {
		
		Assert.assertTrue(clickElement("customize_food_item_category_add_item"), "Failed to click add category ingredient button");
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("customize_list_type_category_item"), "Failed to choose list type category");
		List<WebElement> myList_ingredientCount=driver.findElements(By.xpath("//div[contains(@class, 'cust-modal-body-container')]//div[contains(@ng-repeat, 'fg.ingredientGroup')]"));
		//List<String> allStations_afterNewStation=new ArrayList<>();
		log("The myList_ingredientCount: "+myList_ingredientCount.size());
		int foodItemPresent = myList_ingredientCount.size()-1;
		String foodItemName = getUILocator("customize_food_item_category_component_food_name").replaceAll("<INDEX_NUMBER_LIST_INGREDIENT>", Integer.toString(foodItemPresent));
		Assert.assertTrue(typeText(foodItemName, "fooditem"+foodItemPresent), "Failed to type the text");
		for (int j=0;j<number_of_list_ingredient;j++) {
			log("j is "+j);
			String strAddIngredientListType = getUILocator("customize_add_list_type_ingredients_category_item").replaceAll("<INDEX_NUMBER_LIST_INGREDIENT>", Integer.toString(j));
			Assert.assertTrue(clickElement(strAddIngredientListType), "Failed to click add button in list type ingredients");
		}
		for (int i=00; i<number_of_list_ingredient+1; i++) {
			log("i is "+i);
			String strListTypeIngredient = getUILocator("customize_list_type_ingredients_category_item").replaceAll("<INDEX_NUMBER_LIST_INGREDIENT>", Integer.toString(i));
			Assert.assertTrue(typeText(strListTypeIngredient, "List"+i), "Failed to type name in category");
			log("The value of price increase is: "+priceIncrease);
			if (priceIncrease.length() == 0) {
				String foodGroupPriceIncrease = getUILocator("customize_food_item_category_component_ingredient_food_price_increase").replaceAll("<INDEX_NUMBER_LIST_INGREDIENT>", Integer.toString(i));
				Assert.assertTrue(typeText(foodGroupPriceIncrease, "1.00"), "Failed to type the text");
			}
		}
		Assert.assertTrue(clickElement("customize_food_item_save_btn"), "Failed to click create button");
		return this;
	}
	
	public MenuMakerApp createOptionTypeCategory(String priceIncrease) {
		log("In option type category");
		Assert.assertTrue(clickElement("customize_food_item_category_add_item"), "Failed to click add category ingredient button");
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("customize_option_type_category_item"), "Failed to choose list type category");
		List<WebElement> myList_ingredientCount=driver.findElements(By.xpath("//div[contains(@class, 'cust-modal-body-container')]//div[contains(@ng-repeat, 'fg.ingredientGroup')]"));
		log("The myList_ingredientCount: "+myList_ingredientCount.size());
		int foodItemPresent = myList_ingredientCount.size()-1;
		String foodItemName = getUILocator("customize_food_item_category_component_food_name").replaceAll("<INDEX_NUMBER_LIST_INGREDIENT>", Integer.toString(foodItemPresent));
		Assert.assertTrue(typeText(foodItemName, "fooditem1"+foodItemPresent), "Failed to type the text");
		log("The value of price increase is: "+priceIncrease);
		if (priceIncrease.length() == 0) {
			String foodGroupPriceIncrease = getUILocator("customize_food_item_category_component_food_price_increase").replaceAll("<INDEX_NUMBER_LIST_INGREDIENT>", Integer.toString(foodItemPresent));
			Assert.assertTrue(typeText(foodGroupPriceIncrease, "1.00"), "Failed to type the text");
		}
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("customize_food_item_save_btn"), "Failed to click create button");
		return this;
	}
	
	public MenuMakerApp createQuantityTypeCategory(String componentMaxQuantity) {
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("customize_food_item_category_add_item"), "Failed to click the Add Category Create button while customizing the food item in new window");
		AppUtilities.delay(2000);
		
		/*
		List<WebElement> myList_ingredientCount=driver.findElements(By.xpath("//div[contains(@class, 'cust-modal-body-container')]//div[contains(@ng-repeat, 'fg.ingredientGroup')]"));
		log("The myList_ingredientCount: "+myList_ingredientCount.size());
		int foodItemPresent = myList_ingredientCount.size()-1;
		String foodItemName = getUILocator("customize_food_item_category_component_food_name").replaceAll("<INDEX_NUMBER_LIST_INGREDIENT>", Integer.toString(foodItemPresent));
		Assert.assertNotNull(waitForElement("customize_quantity_type_category_item"), "failed to find quantity radio button");
		Assert.assertTrue(typeText(foodItemName, "fooditem1"+foodItemPresent), "Failed to type the text");*/
		

		//String foodItemName = getUILocator("customize_food_item_category_component_food_name");
		Assert.assertNotNull(waitForElement("customize_quantity_type_category_item"), "failed to find quantity radio button");
		Assert.assertTrue(typeText("customize_food_item_category_component_food_name", "fooditem1"), "Failed to type the text");
		Assert.assertTrue(clickElement("customize_food_item_save_btn"), "Failed to click create button");
		return this;
	}
	
	public MenuMakerApp chooseComponentAsCustomize(String foodStationRuntimeId) {
		int componentIndex= 0;
		String strCustomizeItem = getUILocator("customizable_checkbox_component_section").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		String strCustomizeItemName = strCustomizeItem.replaceAll("<REPLACE_COMPONENT_INDEX>", (componentIndex + 1) + "");
		WebElement strCustomizeButtonElement = waitForElement(strCustomizeItemName);
		boolean strCustomizeButtonValue = strCustomizeButtonElement.isSelected();
		log("The strCustomizeButtonElement is: "+strCustomizeButtonValue);
		if (strCustomizeButtonValue==false) {
			Assert.assertTrue(clickElement(strCustomizeItemName), "Failed to check Customizable checkbox");
		}
		String strModifySaveButton = getUILocator("modify_item_save").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		Assert.assertTrue(clickElement(strModifySaveButton), "Failed to click the save button");
		AppUtilities.delay(5000);
		String strFileSaveButton = getUILocator("add_new_item_save_existing").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		WebElement saveBtn = waitForElement(strFileSaveButton);
		Point p = saveBtn.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - (600)) + ");");
		log("Brought customize food item link into the view " + Integer.toString(600));
		String StrItem = getUILocator("customize_food_item_link_old");
		StrItem= StrItem.replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		Assert.assertTrue(clickElement(StrItem), "Failed to click customize link");
		AppUtilities.delay(5000);
		Assert.assertNotNull(waitForElement("component_section_customizable_popup"), "Component section in custom not available");
		WebElement strComponentCustomize = waitForElement("component_name_customizable_popup");
		boolean strDisabledAttributeValue = strComponentCustomize.isEnabled();
		Assert.assertFalse(strDisabledAttributeValue, "Component Name in Customizable popup is enabled");
		Assert.assertNotNull(clickElement("customize_food_item_cancel_btn"), "Failed to click cancel in the Add Category while customizing the food item in new window");
		AppUtilities.delay(3000);
		return this;
	}
	
	public MenuMakerApp removeComponentCustomize(String foodStationRuntimeId) {
		int componentIndex= 0;
		log("In remove component function");
		String expectedAlertText = "components deleted";
		String strCustomizeItem = getUILocator("customizable_checkbox_component_section").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		String strCustomizeItemName = strCustomizeItem.replaceAll("<REPLACE_COMPONENT_INDEX>", (componentIndex + 1) + "");
		WebElement strCustomizeButtonElement = waitForElement(strCustomizeItemName);
		boolean strCustomizeButtonValue = strCustomizeButtonElement.isSelected();
		log("The strCustomizeButtonElement is: "+strCustomizeButtonValue);
		if (strCustomizeButtonValue==true) {
			Assert.assertTrue(clickElement(strCustomizeItemName), "Failed to check Customizable checkbox");
		}
		String strModifySaveButton = getUILocator("modify_item_save").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		
		if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")) {
			try{
				//Assert.assertTrue(typeText(strStationNameFieldLocator, stationNameBeforeAdd), "Failed to keyin the station name");
				//Validating the error message
			
				Assert.assertTrue(clickElement(strModifySaveButton), "Failed to click the save button");
			
			} catch (UnhandledAlertException e){
				try {
					Alert alert = driver.switchTo().alert();
					String alertText = alert.getText();
					System.out.println("Alert data: " + alertText);
					alert.accept();
				}
				catch (NoAlertPresentException ex) { 
					log("No Alert"); 
				}
			}	
		}
		/*String exceptionContent = "Exception"+e;
					log(exceptionContent);
					Assert.assertTrue(exceptionContent.contains(expectedAlertText),"Failed to contain text");*/
			 //else if (StringUtils.containsIgnoreCase(getBrowserName(), "firefox")){
				//Assert.assertTrue(clickElement(strModifySaveButton), "Failed to click the save button");
			/*	
			//Safari unhandled alert exception is thrown. Working fine for fireFox
			AppUtilities.delay(2000);
			//Validating the error message
			driver.switchTo().alert();
			String actualAlertText = driver.switchTo().alert().getText();
			boolean compareResult  = actualAlertText.equalsIgnoreCase(expectedAlertText);
			Assert.assertTrue(compareResult, "The duplicate display order alert is not displayed");
	        driver.switchTo().alert().accept();
	      */
		AppUtilities.delay(5000);
		/*
		try{
			Assert.assertTrue(clickElement(strModifySaveButton), "Failed to click the save button");
			AppUtilities.delay(5000);
		}catch(UnhandledAlertException ex){
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			log("Alert text is: "+alertText);
			alert.accept();
		}
		*/
			AppUtilities.delay(2000);
			
		log("Validating the error message");
        AppUtilities.delay(5000);
		String strFileSaveButton = getUILocator("add_new_item_save_existing").replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		WebElement saveBtn = waitForElement(strFileSaveButton);
		Point p = saveBtn.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - (600)) + ");");
		log("Brought customize food item link into the view " + Integer.toString(600));
		String StrItem = getUILocator("customize_food_item_link_old");
		StrItem= StrItem.replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		Assert.assertTrue(clickElement(StrItem), "Failed to click customize link");
		AppUtilities.delay(5000);
		Assert.assertNull(waitForElement("component_section_customizable_popup"), "Component section in custom is available when customize checkbox is unchecked");
		Assert.assertNotNull(clickElement("customize_food_item_cancel_btn"), "Failed to click cancel in the Add Category while customizing the food item in new window");
		return this;
	}
	
	public MenuMakerApp validateCustomisationScreen(){
		
		Assert.assertNotNull(waitForElement("customize_food_item_add_category"), "Failed to find the Add Category link while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_save_btn"), "Failed to find the save button while customizing the component");
		
		Assert.assertTrue(clickElement("customize_food_item_add_category"), "Failed to click the Add Category link while customizing the food item in new window");
		
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_heading_dialog"), "Failed to find the heading while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_required_yes_dialog"), "Failed to find the Required Yes option while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_required_no_dialog"), "Failed to find the Required No option while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_name_dialog"), "Failed to find the Add Category Name while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_additional_description"), "Failed to find the Additional description while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_display_order"), "Failed to find the display order while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_price_increase_dialog"), "Failed to find the Add Category price increase while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_min_quantity_dialog"), "Failed to find the Add Category min quantity while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_max_quantity_dialog"), "Failed to find the Add Category max quantity while customizing the food item in new window");
	
		return this;
	}
	
	public MenuMakerApp validateRequiredField(JSONObject foodItem){
		
		validateCustomiseOptionAfterSave(foodStationRuntimeId,foodItem);
		//validateCustomisationScreen();
		JSONArray customizeFoodItems  = (JSONArray) foodItem.get("customize_food_item");
		createCategory((JSONObject)customizeFoodItems.get(0));
		
		return this;
	}
	
	public MenuMakerApp changeFoodItemName(JSONObject itemDetails) {	
		
		
		Assert.assertNotNull(selectMealTimeCaffeLocationStation(itemDetails), "Failed to select the meal-time, Caffe Location and Station");
		
		//String select_station = (String)itemDetails.get("select_station");
		String select_foodItem = (String)itemDetails.get("food_item_name_to_be_modified");
		String strSelectFoodItemLink = getUILocator("select_food_item");
		strSelectFoodItemLink = strSelectFoodItemLink.replaceAll("<REPLACE_FOOD_ITEM_NAME>", select_foodItem);
		
		Assert.assertTrue(clickElement(strSelectFoodItemLink), "Failed to click food item on the selected Station:" + select_foodItem);
		
		log(foodStationRuntimeId);
		String strItem = getUILocator("modify_menu_title");

		strItem = strItem.replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		log(strItem);
		
		String modifiedFoodItem = (String)itemDetails.get("food_item_name");
		
		Assert.assertTrue(typeText(strItem, modifiedFoodItem), "Failed to enter modified food Item name");
		
		strItem = getUILocator("modify_item_save");
		strItem = strItem.replaceAll("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		Assert.assertTrue(clickElement(strItem), "Failed to click the save button");
		
		AppUtilities.delay(5000);
		log("After 5 seconds delay");
		
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
		return this;
	}
	
public MenuMakerApp validateNutritionInfoFields(JSONArray itemList) {	
		
	
	for(Object i : itemList) {
		JSONObject foodItem = (JSONObject)i;
		Assert.assertNotNull(enterFoodItemNutritionDetails(foodItem), "Failed while entering the new item nutrition details");
		
		log("entered product details");
		AppUtilities.delay(2000);
	}
		return this;
	}

public MenuMakerApp validateServingType(JSONArray itemList) {	
		
	
	for(Object i : itemList) {
		JSONObject foodItem = (JSONObject)i;
		Assert.assertNotNull(enterServingDetails(foodItem), "Failed while entering the new item serving details");
		
		log("entered product details");
		AppUtilities.delay(2000);
	}
		return this;
	}
	
	private MenuMakerApp uploadImageToThisFoodItemIfConfigured(String foodId, JSONObject itemDetails) {
		
		String strImageFilePath =(String)itemDetails.get("food_item_image_path");
		if(StringUtils.isBlank(strImageFilePath)) {
			log("Image file path is not configured for this food item. Ignoring the file upload");
			return this;
		}
		log("Checking availability of the given file:" + strImageFilePath);
		
		strImageFilePath = strBaseDir + strImageFilePath; 
		
		log(strImageFilePath);
		
		File f = new File(strImageFilePath);
		
		if(! (f.exists() && f.isFile())) {
			strImageFilePath = strBaseDir + strImageFilePath;
			log("File doesnt exist. Checking with the framework base dir:" + strImageFilePath);
			f = new File(strImageFilePath);
		}
		Assert.assertTrue(f.exists() && f.isFile(), "Failed to check the given image file");
		
		String strFoodItemImage = getUILocator("add_new_menu_image_after_save").replaceAll("<REPLACE_FOOD_STATION_ID>", foodId);
		WebElement i = waitForElement(strFoodItemImage);
		Assert.assertNotNull(i, "Failed to find the image section for the new food item after save");
		Point p = i.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 150) + ");");
		log("Brought the image into view");
		AppUtilities.delay(5000);
		
		String strFileUploadButton = getUILocator("add_new_item_upload_image").replaceAll("<REPLACE_FOOD_STATION_ID>", foodId);
		WebElement e = waitForElement(strFileUploadButton);
		Assert.assertNotNull(e, "Failed to find the file upload button for the food item");
		//e.sendKeys(strImageFilePath);
		e.click();	
		keyboard.type(Key.ENTER);
		log("The upload button has been clicked");
		AppUtilities.delay(20000);
		
		StringSelection selection = new StringSelection(strImageFilePath);
	    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	    clipboard.setContents(selection, selection);
		log("data has been copied to clipboard");
	
		//keyboard.type(Key.CMD + Key.SHIFT + "g");
		
		
		r.keyPress(KeyEvent.VK_META);
		r.keyPress(KeyEvent.VK_SHIFT);
		r.keyPress(KeyEvent.VK_G);
		AppUtilities.delay(500);
		r.keyRelease(KeyEvent.VK_G);
		r.keyRelease(KeyEvent.VK_SHIFT);
		r.keyRelease(KeyEvent.VK_META);
		
		
		log("CMD + SHIFT key has been clicked");
		AppUtilities.delay(5000);
		
		keyboard.paste(strImageFilePath);
		/*
		r.keyPress(KeyEvent.VK_META);
		r.keyPress(KeyEvent.VK_V);
		AppUtilities.delay(500);
		r.keyRelease(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_META);
		*/
		log("Paste action has been simulated");

		/*
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		*/
		keyboard.type(Key.ENTER);
		log("Simulated Enter #1");
		
		AppUtilities.delay(2000);
		
		/*
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		*/

		keyboard.type(Key.ENTER);
		log("Simualted Enter #2");
		AppUtilities.delay(5000);
		
		//TODO::Need to work on this as sikuli fails now to find the image in the browser
		//check the given file is shown
		//Assert.assertTrue(isImageFoundInScreen(strImageFilePath), "Failed to find the uploaded image in the screen");
		
		
		String strFileSaveButton = getUILocator("add_new_item_save_existing").replaceAll("<REPLACE_FOOD_STATION_ID>", foodId);
		WebElement saveBtn = waitForElement(strFileSaveButton);
		p = saveBtn.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 150) + ");");
		log("Brought the save btn into view");
		AppUtilities.delay(5000);

		Assert.assertTrue(clickElement(strFileSaveButton), "Failed to click the save button");
		AppUtilities.delay(5000);
		
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"), "Failed as the save status is found after clicking Save button in file upload");
		
		return this;
	}
	
	private MenuMakerApp customizeTheGivenFoodItemIfRequired(String foodId, JSONObject itemDetails) {
		
		//"is_custom_item":false,
        //"customize_food_item"
		boolean customizeItemStatus = (Boolean)itemDetails.get("is_custom_item");
		if(! customizeItemStatus) {
			log("The current fooditem is not a customized item");
			return this;
		}
		JSONArray customItems = (JSONArray)itemDetails.get("customize_food_item");
		if(customItems.size() <= 0) {
			log("The custom items are not defined / given. Ignoring the customization of food item");
			return this;
		}
		for(Object i : customItems) {
			JSONObject customItem = (JSONObject)i;
			Assert.assertNotNull(customizeTheFoodItem(foodId, customItem, itemDetails), "Failed to customize the given item");
		}
		return this;
	}
	
	private MenuMakerApp customizeTheFoodItem(String foodId, JSONObject customItemDetails, JSONObject parentObject) {
		
		JSONArray components= (JSONArray) parentObject.get("components");
		
		int scrollMultiple = components.size();
		log(Integer.toString(scrollMultiple));
		
		String strFileSaveButton = getUILocator("add_new_item_save_existing").replaceAll("<REPLACE_FOOD_STATION_ID>", foodId);
		WebElement saveBtn = waitForElement(strFileSaveButton);
		Point p = saveBtn.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - (600*scrollMultiple)) + ");");
		log("Brought customize food item link into the view " + Integer.toString(600*scrollMultiple));
		
		String StrItem = getUILocator("customize_food_item_link_old");
		StrItem= StrItem.replaceAll("<REPLACE_FOOD_STATION_ID>", foodId);
		Assert.assertTrue(clickElement(StrItem), "Failed to click on the customisation option link");
		AppUtilities.delay(2000);
		
		Assert.assertNotNull(waitForElement("customize_food_item_add_category"), "Failed to find the Add Category link while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_save_btn"), "Failed to find the save button while customizing the component");
		
		createCategory(customItemDetails);
		//save the customized changes now
		Assert.assertTrue(clickElement("customize_food_item_save_btn"), "Failed to click the save button while customizing the component");
		log("Save button inthe customization screen has been clicked.");
		AppUtilities.delay(10000);
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"), "Failed as the save status is found after max threshold seconds");
		
		//Flow needs to be checked
		Assert.assertTrue(clickElement("customize_food_item_cancel_btn"), "Failed to click the Cancel button while customizing the component");
		log("Cancel button inthe customization screen has been clicked.");
		
		WebElement AddCategoryBtn = waitForElement("customize_food_item_add_category");
		p = AddCategoryBtn.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() + (600*scrollMultiple)) + ");");
		log("Brought customize food item link into the view" + Integer.toString(600*scrollMultiple));
		
		return this;
	}
	
	public MenuMakerApp createCategory(JSONObject customItemDetails){
		log(customItemDetails.toJSONString());
		Assert.assertTrue(clickElement("customize_food_item_add_category"), "Failed to click the Add Category link while customizing the food item in new window");
		
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_heading_dialog"), "Failed to find the heading while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_name_dialog"), "Failed to find the Add Category Name while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_additional_description"), "Failed to find the Additional description while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_display_order"), "Failed to find the display order while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_price_increase_dialog"), "Failed to find the Add Category price increase while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_included_quantity_dialog"), "Failed to find the Add Category included quantity while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_max_quantity_dialog"), "Failed to find the Add Category max quantity while customizing the food item in new window");
		String customizeCategoryType = (String)customItemDetails.get("customize_food_item_category_type");
		
		String componentName = (String)customItemDetails.get("customize_food_item_category");
		
		String componentDescription = "Testing customisation options"; 
		String componentMaxQuantity = (String)customItemDetails.get("customize_food_item_max_quantity");
		String componentIncludedQuantity = (String)customItemDetails.get("customize_food_item_included_quantity");
		
		String componentPriceInc = (String)customItemDetails.get("customize_food_item_increase_price");

		log("Component name:" + componentName);
		log("Component Increase Price:" + componentPriceInc);
		log("Component Max Quantity:" + componentMaxQuantity);
		log("Component Included Quantity:" + componentIncludedQuantity);
		
		Assert.assertTrue(typeText("customize_food_item_add_category_name_dialog", componentName), "Failed to type the Category name while customizing the food item in new window");
		log("TYped component name:" + componentName + " in textbox");
		AppUtilities.delay(2000);
		
		Assert.assertTrue(typeText("customize_food_item_add_category_additional_description", componentDescription),"Failed to enter the componentDescription");
		
		WebElement dispOrder = waitForElement("customize_food_item_add_category_display_order");
		String defaultDisplayOrder = dispOrder.getText();
		log(defaultDisplayOrder);
		WebElement e;
		if(componentPriceInc != null){
		e = waitForElement("customize_food_item_add_category_price_increase_dialog");
		enterNumericValuesOnTextBoxRobot(e,componentPriceInc);
		log("Typed component increase price:" + componentPriceInc + " in textbox");
		AppUtilities.delay(2000);
		}
		if (componentIncludedQuantity!=null){
		e = waitForElement("customize_food_item_add_category_included_quantity_dialog");
		Assert.assertNotNull(e, "Failed to wait for the Category included quantity while customizing the food item in new window");
		enterNumericValuesOnTextBoxRobot(e,componentIncludedQuantity);
		log("Typed component min quantity:" + componentIncludedQuantity + " in textbox");
		AppUtilities.delay(2000);
		}
		if (componentMaxQuantity !=null){
		e = waitForElement("customize_food_item_add_category_max_quantity_dialog");
		AppUtilities.delay(2000);
		
		Assert.assertNotNull(e, "Failed to wait for the Category max quantity while customizing the food item in new window");
		enterNumericValuesOnTextBoxRobot(e,componentMaxQuantity);
		log("Typed component max quantity:" + componentMaxQuantity + " in textbox");
		AppUtilities.delay(2000);
		}
		Assert.assertTrue(clickElement("customize_food_item_add_category_create_btn_dialog"), "Failed to click the Add Category Create button while customizing the food item in new window");
		log("Clicked Create btn");
		AppUtilities.delay(5000);
		
		String componentNameLocator = getUILocator("customize_food_item_category_list").replaceAll("<REPLACE_CUSTOMIZE_CATEGORY_NAME>", componentName);
		Assert.assertNotNull(waitForElement(componentNameLocator), "Failed to find the Component Name after adding it while customizing the food item");
		
		// Need to be validated after fix
		/*String compMaxQuantity = getUILocator("customize_food_item_category_max_qty").replaceAll("<REPLACE_CUSTOMIZE_CATEGORY_NAME>", componentName);
		compMaxQuantity= compMaxQuantity.replaceAll("<REPLACE_MAX_QTY>", componentMaxQuantity);
		Assert.assertNotNull(waitForElementWithText(compMaxQuantity, componentMaxQuantity), "Failed to find the Component Quantity after adding it while customizing the food item");

		String componentPriceIncLocator = getUILocator("customize_food_item_category_price_inc").replaceAll("<REPLACE_CUSTOMIZE_CATEGORY_NAME>", componentName);
		componentPriceIncLocator = componentPriceIncLocator.replaceAll("<REPLACE_INCREASE_PRICE>", componentPriceInc);
		

		Assert.assertNotNull(waitForElementWithText(componentPriceIncLocator, componentPriceInc), "Failed to find the Component Price Inc after adding it while customizing the food item");
		*/
		JSONArray componentItems = (JSONArray)customItemDetails.get("customize_food_items");
		 index = 1;
		for(Object o : componentItems) {
			JSONObject customItem = (JSONObject)o;
			Assert.assertNotNull(addCustomItem(index, componentName, customItem,componentPriceInc,customizeCategoryType), "Failed to add the custom item");
			index++;
		}
		//Assert.assertNotNull(clickElement("customize_food_item_cancel_btn"), "Failed to find the Component Name after adding it while customizing the food item");
		
		
		
		/*else {
			log("Minimum Qty is greater than maxium quantity");
				
				e = waitForElement("customize_food_item_add_category_min_quantity_dialog");
				Assert.assertNotNull(e, "Failed to wait for the Category min quantity while customizing the food item in new window");
				enterNumericValuesOnTextBoxRobot(e,componentMinQuantity);
				
				e = waitForElement("customize_food_item_add_category_max_quantity_dialog");
				Assert.assertNotNull(e, "Failed to wait for the Category max quantity while customizing the food item in new window");
				enterNumericValuesOnTextBoxRobot(e,componentMaxQuantity);
				log("Typed component max quantity:" + componentMaxQuantity + " in textbox");
				
				try{
				e= waitForElement("customize_food_item_add_category_create_btn_dialog");
				e.click();
				} catch (Exception r){
					
					String exceptionContent = "Exception"+e;
					log(exceptionContent);
					//Assert.assertTrue(exceptionContent.contains("Min Quantity should be less than or equal to Max Quantity"),"Failed to contain text");
					//Assert.assertTrue(r.getMessage().contains("Min Quantity should be less than or equal to Max Quantity"), "Failed to display error message pop up");
				}
				
			}*/
		return this;
	}
	
	public MenuMakerApp createCategory(JSONObject customItemDetails, JSONArray customizeType, int number_of_list_ingredient, String priceIncrease){
		log(customItemDetails.toJSONString());
	//	JSONArray typeOfFoodGroup = (JSONArray) customItemDetails.get("customize_food_item_type");
		
		Assert.assertTrue(clickElement("customize_food_item_add_category"), "Failed to click the Add Category link while customizing the food item in new window");
		
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_heading_dialog"), "Failed to find the heading while customizing the food item in new window");
		//Assert.assertNotNull(waitForElement("customize_food_item_add_category_required_yes_dialog"), "Failed to find the Required Yes option while customizing the food item in new window");
		//Assert.assertNotNull(waitForElement("customize_food_item_add_category_required_no_dialog"), "Failed to find the Required No option while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_name_dialog"), "Failed to find the Add Category Name while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_additional_description"), "Failed to find the Additional description while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_display_order"), "Failed to find the display order while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_price_increase_dialog"), "Failed to find the Add Category price increase while customizing the food item in new window");
		//Assert.assertNotNull(waitForElement("customize_food_item_add_category_min_quantity_dialog"), "Failed to find the Add Category min quantity while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_max_quantity_dialog"), "Failed to find the Add Category max quantity while customizing the food item in new window");
		
		String componentName = (String)customItemDetails.get("customize_food_item_category");
		String componentDescription = "This is new component"; 
		log("I am here");
		String componentMaxQuantity = (String)customItemDetails.get("customize_food_item_max_quantity");
		log("Again Here");
		
		String componentPriceInc = (String)customItemDetails.get("customize_food_item_increase_price");
		
		log("Component name:" + componentName);
		log("Component Increase Price:" + componentPriceInc);
		log("Component Max Quantity:" + componentMaxQuantity);
		
		Assert.assertTrue(typeText("customize_food_item_add_category_name_dialog", componentName), "Failed to type the Category name while customizing the food item in new window");
		log("TYped component name:" + componentName + " in textbox");
		AppUtilities.delay(2000);
		
		Assert.assertTrue(typeText("customize_food_item_add_category_additional_description", componentDescription),"Failed to enter the componentDescription");
		
		WebElement dispOrder = waitForElement("customize_food_item_add_category_display_order");
		String defaultDisplayOrder = dispOrder.getText();
		log(defaultDisplayOrder);
		Assert.assertTrue(typeText("customize_food_item_add_category_price_increase_dialog", priceIncrease), "Failed to type value in price increase field");
		
		for(Object type: customizeType) {
			String foodGroupType = (String) type;
			log("The customizetype available is: "+foodGroupType);
			if (foodGroupType.equals("Quantity")) {
				AppUtilities.delay(5000);
				WebElement e = waitForElement("customize_food_item_add_category_max_quantity_dialog");
				Assert.assertNotNull(e, "Failed to wait for the Category max quantity while customizing the food item in new window");
				enterNumericValuesOnTextBoxRobot(e,componentMaxQuantity);
				log("Typed component max quantity:" + componentMaxQuantity + " in textbox");
			}
		}
		
		
		Assert.assertTrue(clickElement("customize_food_item_add_category_create_btn_dialog"), "Failed to click the Add Category Create button while customizing the food item in new window");
		AppUtilities.delay(5000);
		
		String foodGroupType = null;
		//verifying the type of food group ingredients
		for(Object type : customizeType) {
			foodGroupType = (String)type;			

		log("The food group type is: "+foodGroupType);
		
		if (foodGroupType.equals("List")) {
			createListTypeCategory(number_of_list_ingredient, priceIncrease);
		}
		else if (foodGroupType.equals("Option")) {
			createOptionTypeCategory(priceIncrease);
		}
		else if (foodGroupType.equals("Quantity")) {
			createQuantityTypeCategory(componentMaxQuantity);
		}
		else {
			log("The customize type is not available");
		}
	}
		return this;
	}
	
	public MenuMakerApp cancelModifyCategory(JSONObject customItemDetails){
		
		String categoryName = (String) customItemDetails.get("customize_food_item_category");
		log(categoryName);
		String categoryEditItem = getUILocator("customize_food_item_category_edit_item");
		categoryEditItem = categoryEditItem.replaceAll("<REPLACE_CUSTOMIZE_CATEGORY_NAME>", categoryName);
		
		
		Assert.assertTrue(clickElement(categoryEditItem), "Failed to click the Edit Category link while customizing the food item in new window");
		//Assert.assertNotNull(waitForElement("customize_food_item_add_category_heading_dialog"), "Failed to find the heading while customizing the food item in new window");

		Assert.assertNotNull(waitForElement("customize_food_item_add_category_cancel_btn_dialog"), "Failed to find the Add Category price increase while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_edit_category_remove_btn_dialog"), "Failed to find the Add Category min quantity while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_edit_category_save_btn_dialog"), "Failed to find the Add Category max quantity while customizing the food item in new window");

		Assert.assertNotNull(clickElement("customize_food_item_add_category_cancel_btn_dialog"), "Failed to click cancel in the Add Category while customizing the food item in new window");
		return this;
		
	}
	
	public MenuMakerApp removeModifyCategory(JSONObject customItemDetails){
		
		String categoryName = (String) customItemDetails.get("customize_food_item_category");
		log(categoryName);
		String categoryEditItem = getUILocator("customize_food_item_category_edit_item");
		categoryEditItem = categoryEditItem.replaceAll("<REPLACE_CUSTOMIZE_CATEGORY_NAME>", categoryName);
		
		
		Assert.assertTrue(clickElement(categoryEditItem), "Failed to click the Edit Category link while customizing the food item in new window");
		//Assert.assertNotNull(waitForElement("customize_food_item_add_category_heading_dialog"), "Failed to find the heading while customizing the food item in new window");

		Assert.assertNotNull(waitForElement("customize_food_item_add_category_cancel_btn_dialog"), "Failed to find the Add Category price increase while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_edit_category_remove_btn_dialog"), "Failed to find the Add Category min quantity while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_edit_category_save_btn_dialog"), "Failed to find the Add Category max quantity while customizing the food item in new window");

		//Assert.assertNotNull(clickElement("customize_food_item_edit_category_remove_btn_dialog"), "Failed to click cancel in the Add Category while customizing the food item in new window");
		
		try{
		WebElement e = waitForElement("customize_food_item_edit_category_remove_btn_dialog");
		e.click();
		} catch (Exception e){
			log("Exception occured" + e);
		}
		//Assert.assertNull(waitForElement(categoryEditItem), "Faieled to remove the category");
		
		return this;
		
	}
	public MenuMakerApp cancelCategory(JSONObject customItemDetails){
		Assert.assertTrue(clickElement("customize_food_item_add_category"), "Failed to click the Add Category link while customizing the food item in new window");
		
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_heading_dialog"), "Failed to find the heading while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_required_yes_dialog"), "Failed to find the Required Yes option while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_required_no_dialog"), "Failed to find the Required No option while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_name_dialog"), "Failed to find the Add Category Name while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_additional_description"), "Failed to find the Additional description while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_display_order"), "Failed to find the display order while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_price_increase_dialog"), "Failed to find the Add Category price increase while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_min_quantity_dialog"), "Failed to find the Add Category min quantity while customizing the food item in new window");
		Assert.assertNotNull(waitForElement("customize_food_item_add_category_cancel_btn_dialog"), "Failed to find the Add Category max quantity while customizing the food item in new window");
		Assert.assertNotNull(clickElement("customize_food_item_add_category_cancel_btn_dialog"), "Failed to click cancel in the Add Category while customizing the food item in new window");
		
	return this;
	}
	
	public MenuMakerApp cancelCustomItemCreation(){
		Assert.assertNotNull(clickElement("customize_food_item_cancel_btn"), "Failed to click cancel in the Add Category while customizing the food item in new window");
		
	return this;
	}
	
	public MenuMakerApp saveCustomItemCreation(){
		Assert.assertNotNull(clickElement("customize_food_item_save_btn"), "Failed to click cancel in the Add Category while customizing the food item in new window");
		
	return this;
	}
	
	public MenuMakerApp removeCustomItemCreation(){
		String remove = getUILocator("customize_food_item_category_component_remove_food").replaceAll("<REPLACE_CUSTOMIZE_CATEGORY_NAME>", temp);
		remove = remove.replaceAll("<REPLACE_CUSTOM_COMPONENT_INDEX>", (index + ""));		
		Assert.assertNotNull(clickElement(remove), "Failed to click cancel in the Add Category while customizing the food item in new window");
		
	return this;
	}
	private void enterNumericValuesOnTextBox(WebElement e, String number) {
		try {
			
			//String windowName = driver.getWindowHandle();
			
			//log(windowName);
			//driver.switchTo().window(windowName);
			//Robot ra = new Robot();
			/*r.keyPress(KeyEvent.VK_META);
			r.keyPress(KeyEvent.VK_H);
			r.keyRelease(KeyEvent.VK_H );
			r.keyRelease(KeyEvent.VK_META );*/
			
			AppUtilities.delay(2000);
			
			//r.keyPress();
			//r.keyPress(KeyEvent.VK_2);
			//Actions action = new Actions(driver);
			//action.moveToElement(e).click().perform();
			//action.click(e).build().perform();
			
			e.clear();
			e.click();
			/*int digits = number.length();

			for(int i=0; i< digits; i++){
				char digit= (char)number.charAt(i);
				int value = (int)digit;
				value = value +48;
				System.out.println(value);
				ra.keyPress(value);
				ra.keyRelease(value);
				log("Typed the text in the input field value as:" + digit);
			}*/
			//r.keyPress(KeyEvent.VK_2);
			//AppUtilities.delay(500);
			//r.keyRelease(KeyEvent.VK_2);
			
			//e.clear();
			//e.click();
			//e.clear();
			//e.sendKeys(number);
			
			JavascriptExecutor javaExecutor = (JavascriptExecutor)driver;
			String retValue = (String)javaExecutor.executeScript("arguments[0].setAttribute('value', '" + number +"');return arguments[0].getAttribute('value');", e);
			log("Typed the text in the input field return value is:" + retValue);
			
		} catch(Exception ex) {
			log("Exception occurred while entering the numeric values. Error:" + ex);
		}
	}
	private void enterNumericValuesOnTextBoxRobot(WebElement e, String number) {
		try {
			if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")){
			//String windowName = driver.getWindowHandle();
			
			//log(windowName);
			//driver.switchTo().window(windowName);
			Robot ra = new Robot();
			/*r.keyPress(KeyEvent.VK_META);
			r.keyPress(KeyEvent.VK_H);
			r.keyRelease(KeyEvent.VK_H );
			r.keyRelease(KeyEvent.VK_META );*/
			AppUtilities.delay(2000);
			e.clear();
			e.click();
			int digits = number.length();

			for(int i=0; i< digits; i++){
				char digit= (char)number.charAt(i);
				int value = (int)digit;
				value = value +48;
				System.out.println(value);
				ra.keyPress(value);
				ra.keyRelease(value);
				log("Typed the text in the input field value as:" + digit);
			}
			}else {
				enterNumericValuesOnTextBox(e,number);
			}
			
		} catch(Exception ex) {
			log("Exception occurred while entering the numeric values. Error:" + ex);
		}
	}
	
	private MenuMakerApp addCustomItem(int index, String componentName, JSONObject customItem, String componentPriceInc, String customizeCategoryType) {
		String name = (String)customItem.get("customize_food_item_name");
		String itemNutrition = (String)customItem.get("customize_food_item_nutrition");
		Assert.assertTrue(clickElement("customize_food_item_category_add_item"), "Failed to click item to add");
		
		if (customizeCategoryType.equalsIgnoreCase("Quantity")){
		Assert.assertTrue(typeText("customize_quantity_type_category_item",name), "Failed to type the text");
	/*	String nutritionLocator = getUILocator("customize_quantity_type_category_item_nutrition");
		nutritionLocator= nutritionLocator.replaceAll("<REPLACE_INDEX>", index+"");
		enterNumericValuesOnTextBoxRobot(waitForElement(nutritionLocator),itemNutrition);*/
		} else if (customizeCategoryType.equalsIgnoreCase("List")){
			Assert.assertTrue(clickElement("customize_list_type_category_item"), "Failed to click item to add");
			String listname = (String)customItem.get("customize_list_food_group_name");
			Assert.assertTrue(typeText("customize_list_food_group_name",listname), "Failed to type the text");
			Assert.assertTrue(typeText("customize_list_food_group_ingredient",name), "Failed to type the text");
		} else if (customizeCategoryType.equalsIgnoreCase("Option")){
			Assert.assertTrue(typeText("customize_quantity_type_category_item",name), "Failed to type the text");
			String enableDefaultLocator = getUILocator("customize_option_type_enable_default");
			enableDefaultLocator= enableDefaultLocator.replaceAll("<REPLACE_INDEX>", index-1+"");
			Assert.assertTrue(clickElement(enableDefaultLocator), "Failed to click item to add");
			/*String nutritionLocator = getUILocator("customize_quantity_type_category_item_nutrition");
			nutritionLocator= nutritionLocator.replaceAll("<REPLACE_INDEX>", index-1+"");
			enterNumericValuesOnTextBoxRobot(waitForElement(nutritionLocator),itemNutrition);*/
		}
		return this;
	}
	
	private MenuMakerApp uploadCustomItemImage(int index,  String componentName, JSONObject customItem){

		
		String strImageFilePath = (String) customItem.get("customize_food_item_image_path");
		if(StringUtils.isBlank(strImageFilePath)) {
			log("Image file path is not configured for this food item. Ignoring the file upload");
			return this;
		}	else{	
			log("Checking availability of the given file:" + strImageFilePath);
			
			strImageFilePath = strBaseDir + strImageFilePath; 
			
			log(strImageFilePath);
			
			File f = new File(strImageFilePath);
			
			if(! (f.exists() && f.isFile())) {
				strImageFilePath = strBaseDir + File.separator + strImageFilePath;
				log("File doesnt exist. Checking with the framework base dir:" + strImageFilePath);
				f = new File(strImageFilePath);
			}
			Assert.assertTrue(f.exists() && f.isFile(), "Failed to check the given image file");
			AppUtilities.delay(2000);
			
			StringSelection selection = new StringSelection(strImageFilePath);
		    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		    clipboard.setContents(selection, selection);
			log("data has been copied to clipboard");
		
			//keyboard.type(Key.CMD + Key.SHIFT + "g");
			
			
			r.keyPress(KeyEvent.VK_META);
			r.keyPress(KeyEvent.VK_SHIFT);
			r.keyPress(KeyEvent.VK_G);
			AppUtilities.delay(500);
			r.keyRelease(KeyEvent.VK_G);
			r.keyRelease(KeyEvent.VK_SHIFT);
			r.keyRelease(KeyEvent.VK_META);
			
			
			log("CMD + SHIFT key has been clicked");
			AppUtilities.delay(5000);
			
			keyboard.paste(strImageFilePath);
			
			log("Paste action has been simulated");

			
			keyboard.type(Key.ENTER);
			log("Simulated Enter #1");
			
			AppUtilities.delay(2000);
			

			keyboard.type(Key.ENTER);
			log("Simualted Enter #2");
			AppUtilities.delay(10000);
			
		}
		
		return this;
	}
	
	private MenuMakerApp enterFoodItemNameDetails(JSONObject itemDetails) {
		String food_item_name = (String)itemDetails.get("food_item_name");
		String food_item_desc = (String)itemDetails.get("food_item_desc");
		JSONArray labels = (JSONArray)itemDetails.get("labels");
		String food_item_price = (String)itemDetails.get("food_item_price");
		AppUtilities.delay(5000);
		
		Assert.assertTrue(typeText("add_new_menu_item_name", food_item_name), "Failed to enter the new item dish name");
		AppUtilities.delay(2000);
		//WebElement itemName = waitForElement("add_new_menu_item_name");
		Robot item;
		try {
			item = new Robot();
			item.keyPress(KeyEvent.VK_ESCAPE);
			item.keyRelease(KeyEvent.VK_ESCAPE);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		checkPageIsReady();
		//To handle the predications for menu item name
		Assert.assertTrue(clickElement("add_new_menu_item_price"), "Failed to enter the new item dish price");
		if(labels == null){
		Assert.assertTrue(typeText("add_new_menu_item_price", food_item_price), "Failed to enter the new item dish price");
		} else {
			String addLabelButton= getUILocator("add_new_menu_item_label_add");
			String addLabelPrice= getUILocator("add_new_menu_item_label_price");
			String addLabelName= getUILocator("add_new_menu_item_label_name");
			int i=0;
			for (Object label : labels){
				JSONObject labelDetails = (JSONObject) label;
				if(i<labels.size()-1){
				String addLabelButtonLoc = addLabelButton.replace("<INDEX>", i+"");
				Assert.assertTrue(clickElement(addLabelButtonLoc), "failed to click the add button");
				}
				String addLabelPriceLoc = addLabelPrice.replace("<INDEX>", i+"");
				Assert.assertTrue(typeText(addLabelPriceLoc, (String)labelDetails.get("label_price")), "Failed to enter the new item dish price");
				String addLabelNameLoc = addLabelName.replace("<INDEX>", i+"");
				Assert.assertTrue(typeText(addLabelNameLoc, (String)labelDetails.get("label_name")), "Failed to enter the new item dish price");
				i++;
			}
		}
		AppUtilities.delay(2000);
		Assert.assertTrue(typeText("add_new_menu_item_desc", food_item_desc), "Failed to enter the new item dish desc");
		AppUtilities.delay(2000);
		checkPageIsReady();
		//escapeBtn();
		//Assert.assertTrue(clickElement("add_new_menu_item_price"), "Failed to enter the new item dish price");
		/*
		WebElement e = waitForElement("add_new_menu_item_desc");
		log(e.getText());
		Point p = e.getLocation();
		e.sendKeys(food_item_desc);
		//Assert.assertNotNull(e, "Failed to find the image section for the new food item");
		//Assert.assertTrue(typeText("add_new_menu_item_desc", food_item_desc), "Failed to enter the new item dish desc");
		AppUtilities.delay(2000);
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 250) + ");");
		log("Brought the image into view");
		AppUtilities.delay(3000);*/
		return this;
	}
	
	private MenuMakerApp enterFoodItemNutritionDetails(JSONObject itemDetails) {
		JSONArray nutritions = (JSONArray)itemDetails.get("food_item_nutrition");
		String manageNutrition = getUILocator("add_new_menu_item_nutrition_button");
		manageNutrition = manageNutrition.replace("<REPLACE_FOOD_STATION_ID>", foodStationRuntimeId);
		Assert.assertTrue(clickElement(manageNutrition), "Failed to click on the expand the food item");
		AppUtilities.delay(2000);
		int i =1;
		for (Object nutri : nutritions){
			JSONObject nutrition = (JSONObject) nutri;
		
		String calNutrition = getUILocator("add_new_item_nutrition_calorie");
		calNutrition = calNutrition.replaceAll("<REPLACE_INDEX>", i+"");
		enterNumericValuesOnTextBoxRobot(waitForElement(calNutrition), (String)nutrition.get("calorie"));
		AppUtilities.delay(2000);
		
		String fatNutrition = getUILocator("add_new_item_nutrition_fat");
		fatNutrition = fatNutrition.replaceAll("<REPLACE_INDEX>", i+"");
		enterNumericValuesOnTextBoxRobot(waitForElement(fatNutrition), (String)nutrition.get("fat"));
		AppUtilities.delay(2000);
		
		String carbsNutrition = getUILocator("add_new_item_nutrition_carbs");
		carbsNutrition = carbsNutrition.replaceAll("<REPLACE_INDEX>", i+"");
		enterNumericValuesOnTextBoxRobot(waitForElement(carbsNutrition), (String)nutrition.get("carbs"));
		AppUtilities.delay(2000);
		
		String sugarNutrition = getUILocator("add_new_item_nutrition_sugar");
		sugarNutrition = sugarNutrition.replaceAll("<REPLACE_INDEX>", i+"");
		enterNumericValuesOnTextBoxRobot(waitForElement(sugarNutrition), (String)nutrition.get("sugar"));
		AppUtilities.delay(2000);
		
		String proNutrition = getUILocator("add_new_item_nutrition_protein");
		proNutrition = proNutrition.replaceAll("<REPLACE_INDEX>", i+"");
		enterNumericValuesOnTextBoxRobot(waitForElement(proNutrition), (String)nutrition.get("protein"));
		AppUtilities.delay(2000);
		
		String fiberNutrition = getUILocator("add_new_item_nutrition_fiber");
		fiberNutrition = fiberNutrition.replaceAll("<REPLACE_INDEX>", i+"");
		enterNumericValuesOnTextBoxRobot(waitForElement(fiberNutrition), (String)nutrition.get("fiber"));
		AppUtilities.delay(2000);
		i++;
		}
		Assert.assertNotNull(clickElement("add_new_item_nutrition_save_button"), "Failed to find Display order field");
		AppUtilities.delay(5000);
		Assert.assertNotNull(clickElement("add_new_item_nutrition_cancel_button"), "Failed to find Display order field");
		
		return this;
	}
	
	private Boolean enterAItemDetail(String elementIdentifier, String itemValue ){
		WebElement elementName = waitForElement(elementIdentifier);
		JavascriptExecutor myExecutor = ((JavascriptExecutor) driver);
		myExecutor.executeScript("arguments[0].value='"+ itemValue+"'", elementName);
		return true;
	}
	
	private MenuMakerApp enterServingDetails(JSONObject itemDetails) {
		
		//JSONObject nutrition = (JSONObject)itemDetails.get("food_item_nutrition");
		String serving = (String)itemDetails.get("serving");		
		String maxno = (String)itemDetails.get("maxno");
		String maxPerPerson = (String)itemDetails.get("max_per_person");
		String futureStartDate = (String)itemDetails.get("future_start_date");
		String futureEndDate = (String)itemDetails.get("future_end_date");
		String autoComplete = (String)itemDetails.get("autocomplete");		
		
		String start_date = null;
		String  end_date = null;
		if (futureStartDate!=null && futureEndDate != null)
		{
			start_date = futureStartDate;
			end_date = futureEndDate;
		}
		else
		{
		Date todayDate = new java.util.Date();
		 start_date = new SimpleDateFormat("MM/dd/yyyy").format(new Date(todayDate.getTime()));
		 end_date= new SimpleDateFormat("MM/dd/yyyy").format(new Date(todayDate.getTime()+(900*24*60*60*1000)));
		 log("end date"+end_date);
		}
		
		WebElement e = waitForElement("label_new_menu_description_title");
		Point p = e.getLocation();
		Assert.assertNotNull(e, "Failed to find the image section for the new food item");
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 250) + ");");
		log("Brought the image into view");
		AppUtilities.delay(5000);
		
		Assert.assertTrue(clickElement("add_new_item_forheretogoselection"), "Failed to click the serving options");
		
		String strServing = getUILocator("add_new_item_forheretogooptionSelection");
		if(StringUtils.equalsIgnoreCase(serving, "For here/To go")) {
			strServing = strServing.replaceAll("<REPLACE_TEXT>","For here/to go");
		} else if(StringUtils.equalsIgnoreCase(serving, "For here")) {
			strServing = strServing.replaceAll("<REPLACE_TEXT>","For here");
		} else if(StringUtils.equalsIgnoreCase(serving, "To go")) {
			strServing = strServing.replaceAll("<REPLACE_TEXT>","To go");
		}
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement(strServing), "Failed to click the serving options");
		
		//AutoComplete 
		Assert.assertTrue(clickElement("add_new_item_autocompleteselection"), "Failed to click the serving options");
		String strAutoComplete = getUILocator("add_new_item_autocompleteoptionselection");
		if(StringUtils.equalsIgnoreCase(autoComplete, "Yes")) {
			strAutoComplete = strAutoComplete.replaceAll("<REPLACE_TEXT>","Yes");
		} else {
			strAutoComplete = strAutoComplete.replaceAll("<REPLACE_TEXT>","No");
		} 
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement(strAutoComplete), "Failed to click the serving options");
		
		//Display order
		
		//DisplayOrderMenu(itemDetails,1);
		
		//enter the max no
		Assert.assertTrue(enterAItemDetail(getUILocator("add_new_item_max_order"), maxno), "Failed to enter the maximum item max order");
		int MaxOrders= 999, MaxPerPerson= 99;
		MaxOrders= Integer.parseInt(maxno);
		if(maxPerPerson!= null){
			Assert.assertTrue(enterAItemDetail(getUILocator("add_new_item_max_per_person"), maxPerPerson), "Failed to enter the maximum order per person");
			MaxPerPerson= Integer.parseInt(maxPerPerson);
		}
		if (MaxOrders< MaxPerPerson)
		{
			Assert.assertNotNull(waitForElement("add_new_item_max_per_person_error"));
		}
		Assert.assertTrue(typeText("add_new_item_schedule_start_date", start_date), "Failed to enter the maximum order per person");
		Assert.assertTrue(typeText("add_new_item_schedule_end_date", end_date), "Failed to enter the maximum order per person");
		
		log("Entered the Serving details");
		AppUtilities.delay(2000);
		return this;
	}
	
	private MenuMakerApp DisplayOrderMenu(JSONObject ItemDetail, int noOfItems)
	{	
		String displayOrderLocator = getUILocator("add_new_item_display_order");
		WebElement displayOrder = waitForElement(displayOrderLocator);
		String displayOrderValue = displayOrder.getAttribute("value");
		
		Assert.assertNotNull(waitForElement("add_new_item_display_order"), "Failed to find Display order field");
		log("The display order value is: "+displayOrderValue);
		//log("The wait for element result is: "+result);
		Assert.assertEquals(waitForElement("add_new_item_display_order"), 1);
		return this;
	}
	
	private MenuMakerApp changeDisplayOrderMenu(JSONObject ItemDetail, int noOfItems)
	{
		Assert.assertTrue(typeText("add_new_item_display_order", Integer.toString(noOfItems)));
		return this;
	}
	
	public MenuMakerApp verifyDisplayOrderMenu(JSONArray foodItemsList)
	{
		for(Object o : foodItemsList) {
			JSONObject item = (JSONObject)o;
			Assert.assertNotNull(validateDisplayOrderMenu(item), "Failed to remove the food item");
		}
		return this;
	}
	
	public MenuMakerApp validateDisplayOrderMenu(JSONObject foodItem)
	{
		getDisplayOrderMenu(foodItem);
		String station = (String)foodItem.get("select_station");
		//validate display order
		for(int i=1;i<=foodItemCollection.size();i++)
		{
		String foodItemNamefromList = foodItemCollection.get(Integer.toString(i));
		log(foodItemNamefromList);
		Assert.assertEquals(foodItemNamefromList,station +Integer.toString(i-1) );
		}
		return this;
	}
	
	public MenuMakerApp getDisplayOrderMenu(JSONObject foodItem)
	{
		selectMealTimeCaffeLocationStation(foodItem);
		
		String station = (String)foodItem.get("select_station");
		//String foodItemName = (String) foodItem.get("food_item_name");
		String foodItemList = getUILocator("list_food_items_for_station").replaceAll("<REPLACE_STATION_NAME>", station);
		List<WebElement> list = waitForElements(foodItemList, 20);
		
		if(list == null || list.size() <= 0) {
			log("No dish items found in the list.");
			return this;
		}
		log("No. of food elements:" + list.size());

		int count = list.size();
		log("Total number of dishes in the station found as:" + count);

		for(WebElement e : list) {
					String strFoodId = e.getAttribute("id");
					log("Found the food item id to expand:" + strFoodId);
					String ItemName = getUILocator("list_food_item_name_for_station_ngBind");
					ItemName = ItemName.replaceAll("<REPLACE_FOOD_ID>", strFoodId);
					WebElement i = waitForElement(ItemName);
					String foodItemName = i.getText();
					
					String Expand = getUILocator("list_food_item_expand_button");
					Expand = Expand.replaceAll("<REPLACE_FOOD_ID>", strFoodId);
					Assert.assertTrue(clickElement(Expand), "Failed to click on the expand the food item");

					String dispOrder = getUILocator("list_display_order_menu_item");
					dispOrder = dispOrder.replaceAll("<REPLACE_FOOD_ID>", strFoodId);
					WebElement f = waitForElement(dispOrder);
					String displayOder = f.getAttribute("value");
					foodItemCollection.put(displayOder,strFoodId);
					foodItemNameDisplayOrderCollection.put(Integer.parseInt(displayOder),foodItemName);
					String collapse = getUILocator("list_food_item_collapse_button");
					collapse = collapse.replaceAll("<REPLACE_FOOD_ID>", strFoodId);
					Assert.assertTrue(clickElement(collapse), "Failed to click on the collapse the food item");			
		}
		
		log(foodItemCollection.toString());
		log(foodItemNameDisplayOrderCollection.toString());
		return this;
	}
	
	private void escapeBtn(){
		
		Robot r;
		try {
			r = new Robot();
			r.keyPress(KeyEvent.VK_ESCAPE);
			r.keyRelease(KeyEvent.VK_ESCAPE);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void checkPageIsReady() {
		  
		  JavascriptExecutor js = (JavascriptExecutor)driver;
		  Boolean state = true;
		  int i=0;
		  while(state){ 
			log("waiting for the page to load");
			try {
		    Thread.sleep(1000);
		    i++;
		    }catch (InterruptedException e) {} 
		   if (js.executeScript("return document.readyState").toString().equals("complete")){ 
			   log("Page sucessfully loaded");
			   state = false; 
		   }   
		   if (i==150){
			   log("Page not sucessfully loaded for 150s");
			   state = false; 
		   }
		   log(Integer.toString(i));
		  }
		 }
	
	private MenuMakerApp enterFoodItemComponentDetails(WebElement menuContainer,String station, int componentIndex, JSONObject componentDetails) {
		
		String componentName = (String) componentDetails.get("component_name");
		JSONArray ingredients = (JSONArray) componentDetails.get("ingredients");
		JSONObject componentNutrition = (JSONObject)componentDetails.get("component_item_nutrition");
		AppUtilities.delay(15000);
		if(componentIndex != 0) {
			
			WebElement e = waitForElement("add_new_item_save");
			Point p = e.getLocation();
			Assert.assertNotNull(e, "Failed to find the image section for the new food item");
			log("Element original position:" + p.getX() + "," + p.getY());
			((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 500*componentIndex) + ");");
			log("Element original position:" + p.getX() + "," + (p.getY() - 500*componentIndex));
			AppUtilities.delay(5000);
			Assert.assertTrue(clickElement("add_new_component"), "Failed to click the Add Component link");
			log("Add new component has been clicked. waiting for 5 seconds");
			AppUtilities.delay(5000);
		}
		
		//Dont click Add Component as by default first component is shown with fields
		checkPageIsReady();
		String stationindex ="";
		try{
			stationindex = Integer.toString(ind);
		}catch(Exception e){
			log(e.getMessage());
		}
		String strComponentNameLocator = getUILocator("add_new_component_name").replaceAll("<REPLACE_COMPONENT_INDEX>", (componentIndex + 1) + "");
		strComponentNameLocator = strComponentNameLocator.replaceAll("<REPLACE_FOOD_STATION_ID>", station+stationindex);
		String strComponentIngredientsLocator = getUILocator("add_new_component_ingredients").replaceAll("<REPLACE_COMPONENT_INDEX>", (componentIndex + 1) + "");
		
		String strComponentNutCalLocator = getUILocator("add_new_component_nutrition_calorie").replaceAll("<REPLACE_COMPONENT_INDEX>", (componentIndex + 1) + "");
		String strComponentNutFatLocator = getUILocator("add_new_component_nutrition_fat").replaceAll("<REPLACE_COMPONENT_INDEX>", (componentIndex + 1) + "");
		String strComponentNutCarbsLocator = getUILocator("add_new_component_nutrition_carbs").replaceAll("<REPLACE_COMPONENT_INDEX>", (componentIndex + 1) + "");
		String strComponentNutSugarLocator = getUILocator("add_new_component_nutrition_sugar").replaceAll("<REPLACE_COMPONENT_INDEX>", (componentIndex + 1) + "");
		String strComponentNutProteinLocator = getUILocator("add_new_component_nutrition_protein").replaceAll("<REPLACE_COMPONENT_INDEX>", (componentIndex + 1) + "");
		String strComponentNutFibreLocator = getUILocator("add_new_component_nutrition_fibre").replaceAll("<REPLACE_COMPONENT_INDEX>", (componentIndex + 1) + "");
		
		componentName = componentName + Integer.toString((int)Math.floor((Math.random() * 100) + 1));
		Assert.assertTrue(typeText(strComponentNameLocator, componentName), "Failed to enter the component name:" + componentName);
		escapeBtn();
		for(Object ing : ingredients) {
			String ingredient = (String)ing;
			Assert.assertTrue(typeText(strComponentIngredientsLocator, ingredient), "Failed to enter the ingredient name:" + ingredient);
			clickElement(strComponentNutCalLocator);
			AppUtilities.delay(2000);
		}
		
		enterNumericValuesOnTextBoxRobot(waitForElement(strComponentNutCalLocator), (String)componentNutrition.get("calorie"));
		AppUtilities.delay(2000);
		enterNumericValuesOnTextBoxRobot(waitForElement(strComponentNutFatLocator), (String)componentNutrition.get("fat"));
		AppUtilities.delay(2000);
		enterNumericValuesOnTextBoxRobot(waitForElement(strComponentNutCarbsLocator), (String)componentNutrition.get("carbs"));
		AppUtilities.delay(2000);
		enterNumericValuesOnTextBoxRobot(waitForElement(strComponentNutSugarLocator), (String)componentNutrition.get("sugar"));
		AppUtilities.delay(2000);
		enterNumericValuesOnTextBoxRobot(waitForElement(strComponentNutProteinLocator), (String)componentNutrition.get("protein"));
		AppUtilities.delay(2000);
		enterNumericValuesOnTextBoxRobot(waitForElement(strComponentNutFibreLocator), (String)componentNutrition.get("fiber"));
		
		/*
		Assert.assertTrue(enterAItemDetail(strComponentNutCalLocator, (String)componentNutrition.get("calorie")), "Failed to enter the component nutrition calorie for:" + componentName);
		AppUtilities.delay(2000);
		Assert.assertTrue(enterAItemDetail(strComponentNutFatLocator, (String)componentNutrition.get("fat")), "Failed to enter the component nutrition fat for:" + componentName);
		AppUtilities.delay(2000);
		Assert.assertTrue(enterAItemDetail(strComponentNutCarbsLocator, (String)componentNutrition.get("carbs")), "Failed to enter the component nutrition carbs for:" + componentName);
		AppUtilities.delay(2000);
		Assert.assertTrue(enterAItemDetail(strComponentNutSugarLocator, (String)componentNutrition.get("sugar")), "Failed to enter the component nutrition sugar for:" + componentName);
		AppUtilities.delay(2000);
		Assert.assertTrue(enterAItemDetail(strComponentNutProteinLocator, (String)componentNutrition.get("protein")), "Failed to enter the component nutrition protein for::" + componentName);
		AppUtilities.delay(2000);
		Assert.assertTrue(enterAItemDetail(strComponentNutFibreLocator, (String)componentNutrition.get("fiber")), "Failed to enter the component nutrition fibre for:" + componentName);
		log("The component nutrition values have been entered");*/
		AppUtilities.delay(2000);
		
		
		return this;
	}
	
	public MenuMakerApp removeFoodItems(JSONArray foodItemsList) {
		
		Assert.assertNotNull(foodItemsList, "Failed to remove the food items as the input list found to be null");
		Assert.assertTrue(foodItemsList.size() > 0, "Failed to remove the food items as the input list is empty");
		
		
		for(Object o : foodItemsList) {
			JSONObject item = (JSONObject)o;
			Assert.assertNotNull(removeGivenFoodItem(item), "Failed to remove the food item");
		}
		
		return this;
	}
	
	public MenuMakerApp removeGivenFoodItem(JSONObject itemDetails) {
		
		Assert.assertNotNull(itemDetails, "Failed to remove the given food item found to be null");
		
		Assert.assertNotNull(selectMealTimeCaffeLocationStation(itemDetails), "Failed to select the meal-time, Caffe Location and Station");
		
		String select_station = (String)itemDetails.get("select_station");
		String strAddDishLink = getUILocator("add_dish_link");
		strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);

		String itemName = (String)itemDetails.get("food_item_name");
		String station = (String)itemDetails.get("select_station");
		removeFoodItem(itemName, station);
		return this;
	}
	public MenuMakerApp removeGivenSharedFoodItems(JSONObject itemDetails) {
		Assert.assertNotNull(itemDetails, "Failed to remove the given food item found to be null");
		Assert.assertNotNull(selectCaffeRegion(itemDetails), "Failed to select the meal-time, Caffe Location and Station");
		String itemName = (String)itemDetails.get("food_item_name");
		String station = (String)itemDetails.get("select_caffe_region");
		removeFoodItem(itemName, station);
		return this;
	}
	public MenuMakerApp removeFoodItem(String itemName, String FoodStationName){
		String foodItemList = getUILocator("list_food_items_for_station").replaceAll("<REPLACE_STATION_NAME>", FoodStationName);
		List<WebElement> list = waitForElements(foodItemList, 20);
		ind = 0;
		if(list == null || list.size() <= 0) {
			log("No dish items found in the list.");
			return this;
		}
		log("No. of food elements:" + list.size());

		int count = list.size();
		int itemsIndex = 0;
		log("Total number of dishes with the same found as:" + count);
		/* To be Fixed
		for(WebElement e : list) {
					log("Food item to be deleted found");
					String strFoodId = e.getAttribute("id");
					log("Deleting the food item id:" + strFoodId);
					String strFoodItem = getUILocator("list_food_item_name_for_station_ngBind");
					strFoodItem = strFoodItem.replaceAll("<REPLACE_FOOD_ID>", strFoodId);
					String r = null;
					r = waitForElement(strFoodItem).getText();
					log(r);
					String strFoodItemStatus = getUILocator("list_food_item_status_for_station_ngBind");
					strFoodItemStatus = strFoodItemStatus.replaceAll("<REPLACE_FOOD_ID>", strFoodId);
					String s = null;
					s = waitForElement(strFoodItemStatus).getText();
					log(s);
					//ind = itemsIndex+1;
					//log(Integer.toString(ind));
					if(r != null || s!=null){
						if(r.contains(itemName)|| s.contains("DRAFT")){
					Assert.assertTrue(removeFoodMenuById(strFoodId), "Failed to remove the food menu by station id:" + strFoodId);
					count = --count;
					if (count > 0)
					{
						ind= --count;
					}
					//ind = itemsIndex;
					log(Integer.toString(ind));
					//remove break to delete all the items under same name
						}else {
							existingIds.put(Integer.toString(itemsIndex),strFoodId );
							//existId = true;
							itemsIndex++;
						}
					}
			}*/
		for (int i= count-1; i>=0; i--) {
			String strFoodId = FoodStationName+i;
			String strFoodItem = getUILocator("list_food_item_name_for_station_ngBind");
			strFoodItem = strFoodItem.replaceAll("<REPLACE_FOOD_ID>", strFoodId);
			String r = null;
			r = waitForElement(strFoodItem).getText();
			log(r);
			if(r != null ) {
			Assert.assertTrue(removeFoodMenuById(strFoodId), "Failed to remove the food menu by station id:" + strFoodId);
			}
		}

		
		/*
		String foodItemList = getUILocator("list_food_item_names_for_station").replaceAll("<REPLACE_STATION_NAME>", station);
		List<WebElement> list = waitForElements(foodItemList, 20);
		
		if(list == null || list.size() <= 0) {
			log("No dish items found in the list.");
			return this;
		}
		log("No. of food elements:" + list.size());
		//for(WebElement e : list) {
		int count = 0;
		for(WebElement e : list) {
			log("Existing element value:" + e.getText() + " checking with " + itemName);
			String strDishName = e.getText();
			log(strDishName);
			if(StringUtils.equalsIgnoreCase(strDishName, itemName)) {
				count++;
			}
		}
		log("Total number of dishes with the same found as:" + count);
		while(count > 0) {
			list = waitForElements(foodItemList);
			log("No. of food elements:" + list.size());
			for(WebElement e : list) {
				String strDishName = e.getText();
				if(StringUtils.equalsIgnoreCase(strDishName, itemName)) {
					log("Food item to be deleted found");
					String strFoodStationId = e.getAttribute("id");
					strFoodStationId = strFoodStationId.replaceAll("titlename_", "");
					log("Deleting the food item id:" + strFoodStationId);
					Assert.assertTrue(removeFoodMenuByStationId(strFoodStationId), "Failed to remove the food menu by station id:" + strFoodStationId);
					break;
				}
			}
			count--;
		}*/
		return this;
	}
	
public MenuMakerApp removeGivenSharedFoodItem(JSONObject itemDetails) {
		
		Assert.assertNotNull(itemDetails, "Failed to remove the given food item found to be null");
		
		Assert.assertNotNull(selectMealTimeCaffeLocationStation(itemDetails), "Failed to select the meal-time, Caffe Location and Station");
		
		String select_station = (String)itemDetails.get("select_station");
		String strAddDishLink = getUILocator("add_dish_link");
		strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);

		String itemName = (String)itemDetails.get("food_item_name");
		String station = (String)itemDetails.get("select_station");
		
		String foodItemList = getUILocator("list_food_items_for_station").replaceAll("<REPLACE_STATION_NAME>", station);
		List<WebElement> list = waitForElements(foodItemList, 20);
		ind = 0;
		if(list == null || list.size() <= 0) {
			log("No dish items found in the list.");
			
			return this;
		}
		log("No. of food elements:" + list.size());

		int count = list.size();
		int itemsIndex = 0;
		log("Total number of dishes with the same found as:" + count);
		for(WebElement e : list) {
					log("Food item to be deleted found");
					String strFoodId = e.getAttribute("id");
					log("Deleting the food item id:" + strFoodId);
					
					String strFoodItem = getUILocator("list_food_item_name_for_station_ngBind");
					strFoodItem = strFoodItem.replaceAll("<REPLACE_FOOD_ID>", strFoodId);
					String r = null;
					r = waitForElement(strFoodItem).getText();
					log(r);
					String strFoodItemStatus = getUILocator("list_food_item_status_for_station_ngBind");
					strFoodItemStatus = strFoodItemStatus.replaceAll("<REPLACE_FOOD_ID>", strFoodId);
					String s = null;
					s = waitForElement(strFoodItemStatus).getText();
					log(s);
					//ind = itemsIndex+1;
					//log(Integer.toString(ind));
					if(r != null || s!=null){
						if(r.contains(itemName)|| s.contains("DRAFT")){
					Assert.assertTrue(removeFoodMenuById(strFoodId), "Failed to remove the food menu by station id:" + strFoodId);
					count = --count;
					if (count > 0)
					{
						ind= --count;
					}
					//ind = itemsIndex;
					log(Integer.toString(ind));
					//remove break to delete all the items under same name
						}else {
							existingIds.put(Integer.toString(itemsIndex),strFoodId );
							//existId = true;
							itemsIndex++;
						}
					}
			}
		return this;
	}
	
	public MenuMakerApp expandCollapseMenuItems(JSONArray foodItems)
	{
		Assert.assertNotNull(foodItems, "Failed to expand menu item as the food Item is null");
		Assert.assertTrue(foodItems.size() > 0, "Failed to expand the menu Item as Food Menu list is empty");
		for(Object item: foodItems)
		{
			JSONObject foodItem = (JSONObject) item;
			expandCollapseMenuItem(foodItem);
		}
		return this;
	}
	
	private MenuMakerApp expandCollapseMenuItem(JSONObject foodItem){
		
		selectMealTimeCaffeLocationStation(foodItem);
		String station = (String)foodItem.get("select_station");
		String foodItemName = (String) foodItem.get("food_item_name");
		String foodItemList = getUILocator("list_food_items_for_station").replaceAll("<REPLACE_STATION_NAME>", station);
		List<WebElement> list = waitForElements(foodItemList, 20);
		
		if(list == null || list.size() <= 0) {
			log("No dish items found in the list.");
			return this;
		}
		log("No. of food elements:" + list.size());

		int count = list.size();
		log("Total number of dishes in the station found as:" + count);
		
		HashMap <String,String> foodItemCollection = new HashMap<String,String>();
		
		for(WebElement e : list) {
					String strFoodId = e.getAttribute("id");
					log("Found the food item id to expand:" + strFoodId);
					String ItemName = getUILocator("list_food_item_name_for_station_ngBind");
					ItemName = ItemName.replaceAll("<REPLACE_FOOD_ID>", strFoodId);
					WebElement Name = waitForElement(ItemName);
					String foodItemNameFound = Name.getText();
					log(foodItemNameFound+ ":" +strFoodId);
					foodItemCollection.put(foodItemNameFound,strFoodId);
		}
		
		String foodId = foodItemCollection.get(foodItemName);

		String Expand = getUILocator("list_food_item_expand_button");
		Expand = Expand.replaceAll("<REPLACE_FOOD_ID>", foodId);
		Assert.assertTrue(clickElement(Expand), "Failed to click on the expand the food item");
		
		String collapse = getUILocator("list_food_item_collapse_button");
		collapse = collapse.replaceAll("<REPLACE_FOOD_ID>", foodId);
		Assert.assertTrue(clickElement(collapse), "Failed to click on the collapse the food item");
		return this;
	}
	
	private boolean removeFoodMenuByStationId(String aFoodStationId) {
		
		String strRemoveDishLink = getUILocator("remove_dish_link").replaceAll("<REPLACE_FOOD_STATION_ID>", aFoodStationId);
		WebElement link = waitForElement(strRemoveDishLink);
		Point p = link.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 150) + ");");
		log("Brought the removelink into view");

		Assert.assertTrue(clickElement(strRemoveDishLink), "Failed to click on the remove dish link");
		AppUtilities.delay(3000);
		Assert.assertNotNull(waitForElement("remove_food_item_confirmation_text"), "Failed to find the delete confirmation text on deleting the food item");
		Assert.assertTrue(clickElement("remove_food_item_ok_button"), "Failed to click OK button");
		AppUtilities.delay(2000);
		return true;
	}
	
	private boolean removeFoodMenuById(String aFoodId) {
		
		String strRemoveDishLink = getUILocator("remove_dish_link_new").replaceAll("<REPLACE_FOOD_ID>", aFoodId);
		WebElement link = waitForElement(strRemoveDishLink);
		Point p = link.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 150) + ");");
		log("Brought the removelink into view");

		Assert.assertTrue(clickElement(strRemoveDishLink), "Failed to click on the remove dish link");
		AppUtilities.delay(3000);
		Assert.assertNotNull(waitForElement("remove_food_item_confirmation_text"), "Failed to find the delete confirmation text on deleting the food item");
		Assert.assertTrue(clickElement("remove_food_item_ok_button"), "Failed to click OK button");
		AppUtilities.delay(2000);
		return true;
	}
	
	public MenuMakerApp navigateToCaffePage (JSONArray caffeDetails) {
		Assert.assertTrue(clickElement("caffe_page"), "Failed to click Caffe option");
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("caffe_info_page"), "Failed to click Caffe Info option");
		AppUtilities.delay(4000);
		//driver.navigate().refresh();
		AppUtilities.delay(4000);
		Assert.assertTrue(clickElement("caffe_select_region_dropdown"), "Failed to click Caffe Region Dropdown");
		log ("The caffe details are navigateToCaffePage: "+caffeDetails);
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeRegion = (String)caffeDetail.get("select_caffe_region");
			String caffeName = (String)caffeDetail.get("select_caffe_location");
			AppUtilities.delay(2000);
			String strCaffeRegionLocator = getUILocator("caffe_select_region").replaceAll("<REPLACE_CAFFE_REGION_NAME>", caffeRegion);
			Assert.assertTrue(clickElement(strCaffeRegionLocator), "Failed to click caffe region dropdown");
			AppUtilities.delay(2000);
			log("Selected Region locator");
			String strCaffeLocator = getUILocator("caffe_select_caffe").replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", caffeName);
			Assert.assertTrue(clickElement(strCaffeLocator), "Failed to click Caffe Name while selecting in Caffe page");
			AppUtilities.delay(4000);
		}
		return this;
	}
	
	public MenuMakerApp addStations (JSONArray caffeDetails) {
		
		Assert.assertNotNull(caffeDetails, "Failed as the food items to be created found to be null");
		Assert.assertTrue(caffeDetails.size() > 0, "Failed as the food items to be created found to be empty");
		
		for(Object i : caffeDetails) {
			JSONObject foodItem = (JSONObject)i;
			Assert.assertNotNull(addStation(foodItem), "Failed to create the food item with details:" + foodItem.toJSONString());
		}
		return this;
	}
	
	private MenuMakerApp addStation(JSONObject caffeDetail){
		navigateToStation(caffeDetail);
		
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		String select_station = (String)caffeDetail.get("select_station");
		
		String strStation = getUILocator("station_select_station_in_station_page");
		strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		Assert.assertTrue(clickElement(strStation), "Failed to click the Station:" + select_station);
		log("The station:" + select_station + " has been selected");
		AppUtilities.delay(2000);
		
		String activate = getUILocator("station_active_inactive_cb_station_page");
		activate = activate.replaceAll("<REPLACE_STATION_ID>", stationId);
		WebElement actCheckBox = waitForElement(activate);
		String checkBoxSelection= actCheckBox.getAttribute("checked");
		//log(checkBoxSelection);
		if (checkBoxSelection != null)
		{
		Assert.assertTrue(clickElement(activate), "Failed to click active button for the Station");
		log("The station:" + select_station + " has been activated");
		}
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to save the station page");
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
		Assert.assertTrue(clickElement("menu_page"));
		return this;
	}
	
	public MenuMakerApp activateStations (JSONArray caffeDetails) {
		
		Assert.assertNotNull(caffeDetails, "Failed as the food items to be created found to be null");
		Assert.assertTrue(caffeDetails.size() > 0, "Failed as the food items to be created found to be empty");
		navigateToStationPage(caffeDetails);
		for(Object i : caffeDetails) {
			JSONObject foodItem = (JSONObject)i;
			Assert.assertNotNull(activateStation(foodItem), "Failed to create the food item with details:" + foodItem.toJSONString());
		}
		return this;
	}
	public MenuMakerApp deActivateStations (JSONArray caffeDetails) {
		
		Assert.assertNotNull(caffeDetails, "Failed as the food items to be created found to be null");
		Assert.assertTrue(caffeDetails.size() > 0, "Failed as the food items to be created found to be empty");
		navigateToStationPage(caffeDetails);
		
		log("I am here");
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			Assert.assertNotNull(deActivateStation(caffeDetail), "Failed to create the food item with details:" + caffeDetail.toJSONString());
			Assert.assertNotNull(verifyMenuForDeActivatedStation(caffeDetail), "Failed to select the meal-time, Caffe Location and Station");
		}
		return this;
	}
	
	private MenuMakerApp verifyMenuForDeActivatedStation(JSONObject caffeDetail )
	{
		selectMealTimeCaffeLocationStationMenuPage(caffeDetail);
		String select_station = (String)caffeDetail.get("select_station");
		String strLeftStation = getUILocator("select_station_left_side");
		strLeftStation = strLeftStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		//Assert.assertNull(waitForElement(strLeftStation,20), "Failed to deactivate the Station:" + select_station);
		//log("The station:" + select_station + " has been de activated sucessfully");
		AppUtilities.delay(2000);
		return this;
	}
	private MenuMakerApp deActivateStation(JSONObject caffeDetail){
		navigateToStation(caffeDetail);
		String select_station = (String)caffeDetail.get("select_station");
		
		String strStation = getUILocator("station_select_station_in_station_page");
		strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		Assert.assertTrue(clickElement(strStation), "Failed to click the Station:" + select_station);
		log("The station:" + select_station + " has been selected");
		AppUtilities.delay(2000);
		
		String activate = getUILocator("station_active_inactive_cb_station_page");
		activate = activate.replaceAll("<REPLACE_STATION_ID>", stationId);
		WebElement actCheckBox = waitForElement(activate);
		String checkBoxSelection= actCheckBox.getAttribute("checked");
		if (checkBoxSelection != null) {
			Assert.assertTrue(clickElement(activate), "Failed to click active button for the Station");
			log("The station:" + select_station + " has been deactivated");
		}
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to save the station page");
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
		Assert.assertTrue(clickElement("menu_page"));
		return this;
	}
	
	private MenuMakerApp navigateToStation (JSONObject caffeDetail)
	{
		Assert.assertTrue(clickElement("caffe_page"), "Failed to click Caffe option");
		Assert.assertTrue(clickElement("caffe_info_page"), "Failed to click Caffe Info option");
		Assert.assertTrue(clickElement("caffe_station_page"), "Failed to click Caffe station option");
		String aCaffeLocation = (String) caffeDetail.get("select_caffe_location");
		Assert.assertTrue(clickElement("current_station_in_station_page"), "Failed to click the Caffe Location menu");
		String cafeLocation = getUILocator("select_cafe_by_name");
		cafeLocation = cafeLocation.replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", aCaffeLocation);
		Assert.assertTrue(clickElement(cafeLocation), "Failed to click the Caffe Location:" + aCaffeLocation);		
		Assert.assertTrue(waitForElementWithText("current_station_in_station_page", aCaffeLocation), "Failed to find the current caffe location as:" + aCaffeLocation);
		return this;
	}
	
	public MenuMakerApp verifyStationTypeForHere(JSONArray caffeDetails) {
		JSONObject caffeDetail = null;
		for (Object caffeInfo : caffeDetails ) {
			caffeDetail = (JSONObject) caffeInfo;
		}
		String select_station = (String)caffeDetail.get("select_station");
		String strStation = getUILocator("station_select_station_in_station_page");
		strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		String strStationTypeLocator = getUILocator("station_type_in_station_page").replaceAll("<REPLACE_STATION_ID>", stationId); 
		Assert.assertTrue(clickElement(strStationTypeLocator), "Failed to click the station type locator");
		String strStationTypeDropdownLocator = getUILocator("station_type_dropdown_for_here_in_station_page").replaceAll("<REPLACE_STATION_ID>", stationId); 
		Assert.assertTrue(clickElement(strStationTypeDropdownLocator), "Failed to click the station type dropdown");
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the Save button");
		AppUtilities.delay(5000);
		return this;
	}
	
	public MenuMakerApp verifyStationTypeToGo(JSONArray caffeDetails) {
		JSONObject caffeDetail = null;
		for (Object caffeInfo : caffeDetails ) {
			caffeDetail = (JSONObject) caffeInfo;
		}
		String select_station = (String)caffeDetail.get("select_station");
		String strStation = getUILocator("station_select_station_in_station_page");
		strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		String strStationTypeLocator = getUILocator("station_type_in_station_page").replaceAll("<REPLACE_STATION_ID>", stationId); 
		Assert.assertTrue(clickElement(strStationTypeLocator), "Failed to click the station type locator");
		String strStationTypeDropdownLocator = getUILocator("station_type_dropdown_for_here_in_station_page").replaceAll("<REPLACE_STATION_ID>", stationId); 
		Assert.assertTrue(clickElement(strStationTypeDropdownLocator), "Failed to click the station type dropdown");
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the Save button");
		AppUtilities.delay(5000);
		return this;
	}
	public MenuMakerApp verifyStationType(JSONArray caffeDetails) {
		JSONObject caffeDetail = null;
		for (Object caffeInfo : caffeDetails ) {
			caffeDetail = (JSONObject) caffeInfo;
		}
		String select_station = (String)caffeDetail.get("select_station");
		String strStation = getUILocator("station_select_station_in_station_page");
		strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		String strStationTypeLocator = getUILocator("station_type_in_station_page").replaceAll("<REPLACE_STATION_ID>", stationId); 
		Assert.assertTrue(clickElement(strStationTypeLocator), "Failed to click the station type locator");
		String strStationTypeDropdownLocator = getUILocator("station_type_dropdown_in_station_page").replaceAll("<REPLACE_STATION_ID>", stationId); 
		Assert.assertTrue(clickElement(strStationTypeDropdownLocator), "Failed to click the station type dropdown");
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the Save button");
		AppUtilities.delay(5000);
		return this;
	}

	
	
	private MenuMakerApp activateStation(JSONObject caffeDetail){
		String select_station = (String)caffeDetail.get("select_station");
		String scheduleforTime = (String)caffeDetail.get("food_for");
		if (scheduleforTime.equals("lunch")){
			scheduleforTime = "Lunch";
			
		}
		String aCaffeLocation = (String)caffeDetail.get("select_caffe_location");
		String cafeLocation = getUILocator("select_cafe_by_name");
		Assert.assertTrue(clickElement("current_caffe_location_station_page"), "Failed to find the default caffe location");
		cafeLocation = cafeLocation.replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", aCaffeLocation);
		Assert.assertTrue(clickElement(cafeLocation), "Failed to choose the caffe location");
		AppUtilities.delay(2000);
		String strStationNameLeftPaneLocator = getUILocator("select_station_left_side").replaceAll("<REPLACE_STATION_NAME>", select_station);
		Assert.assertNotNull(waitForElement(strStationNameLeftPaneLocator), "Failed to find the element");
		AppUtilities.delay(5000);
		
		String strStation = getUILocator("station_select_station_in_station_page");
		strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		Assert.assertTrue(clickElement(strStation), "Failed to click the Station:" + select_station);
		log("The station:" + select_station + " has been selected");
		AppUtilities.delay(2000);
		
		Assert.assertNotNull(activateScheduleSave(select_station,stationId, scheduleforTime),"Failed to activate Schedule");
		Assert.assertTrue(clickElement("menu_page"));
		
		return this;
	}
	
	private MenuMakerApp activateScheduleSave(String select_station,String stationId, String scheduleforTime ){
		
		String activate = getUILocator("station_active_inactive_cb_station_page");
		activate = activate.replaceAll("<REPLACE_STATION_ID>", stationId);
		WebElement actCheckBox = waitForElement(activate);
		String checkBoxSelection= actCheckBox.getAttribute("checked");
		log(checkBoxSelection);
		if (checkBoxSelection == null)
		{
		Assert.assertTrue(clickElement(activate), "Failed to click active button for the Station");
		log("The station:" + select_station + " has been activated");
		}
		
		String schedule = getUILocator("schedule_section_station_page");
		schedule = schedule.replaceAll("<REPLACE_STATION_ID>", stationId);
		String mealIdCheckBox = getUILocator("schedule_stations_page").replaceAll("<REPLACE_STATION_ID>", stationId);
		String mealIdLabel= getUILocator("schedule_labels_station_page").replaceAll("<REPLACE_STATION_ID>", stationId);
		
		List<WebElement> list = waitForElements(schedule, 20);
		
		if(list == null || list.size() <= 0) {
			log("No schedule found in the list.");
			return this;
		}
		log("No. of schedules:" + list.size());

		int count = list.size();
		log("Total number of schedule in the station found as:" + count);
		
		HashMap <String,String> scheduleTime = new HashMap<String,String>();
		
		for(WebElement s : list) {
				
				WebElement MealId= s.findElement(By.xpath(mealIdCheckBox));
				WebElement MealName= s.findElement(By.xpath(mealIdLabel));
				String scheduleMealId = MealId.getAttribute("id");
				String scheduleMealName = MealName.getText();
				log("Found the schedule id:"+ scheduleMealId+ " of the Meal Name:" +scheduleMealName);
				scheduleTime.put(scheduleMealName, scheduleMealId);
		}
		
		int noOfSchedules = scheduleTime.size();
		log(Integer.toString(noOfSchedules));
		
		log (scheduleTime.toString());
		
		String scheduleForId = scheduleTime.get(scheduleforTime);
		log("The schedule id is: "+scheduleForId);
		String scheduleId1 = getUILocator("schedule_id_station_page").replaceAll("<REPLACE_STATION_ID>", stationId);
		//scheduleId = scheduleId.replaceAll("<REPLACE_STATION_ID>", stationId);
		String scheduleId = scheduleId1.replaceAll("<REPLACE_SCHEDULE_ID>",scheduleForId);
		WebElement scheduleCheckBox = waitForElement(scheduleId);
		checkBoxSelection= scheduleCheckBox.getAttribute("checked");
		log(checkBoxSelection);
		if (checkBoxSelection == null)
		{
			Assert.assertTrue(clickElement(scheduleId), "Failed to save the station page");
		}
		
		
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to save the station page");
		
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
		
		return this;
	}
	
	public MenuMakerApp verifyStationInMenuTab(JSONArray caffeDetails){
		
		JSONObject caffeDetail = null;
		String aCaffeLocation = null;
		String select_station = null;

		for(Object i: caffeDetails) {
			caffeDetail = (JSONObject) i;
			aCaffeLocation = (String)caffeDetail.get("select_caffe_location");
			log(newStationName);
			
			if (newStationName ==null){
			select_station = (String)caffeDetail.get("select_station");
			} 
			else {
			select_station = newStationName;
			}
		}
		

		
		String scheduleforTime = (String)caffeDetail.get("food_for");
		if(scheduleforTime.equals("lunch")){
			scheduleforTime = "Lunch";
			
		}
	
		String strStation = getUILocator("station_select_station_in_station_page");
		strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		Assert.assertTrue(clickElement(strStation), "Failed to click the Station:" + select_station);
		log("The station:" + select_station + " has been selected");
		AppUtilities.delay(2000);
		
		String strStation1 = getUILocator("station_name_field_in_station_page").replaceAll("<REPLACE_STATION_ID>", stationId);
		WebElement stationNameElement = waitForElement(strStation1);
		String stationName = stationNameElement.getAttribute("value");
		log("The station name is: "+stationName);
		
		String strStationPriceLocator = getUILocator("station_default_price_in_station_page1").replaceAll("<REPLACE_STATION_ID>", stationId);
		WebElement stationPriceElement = waitForElement(strStationPriceLocator);
		String stationPrice = stationPriceElement.getAttribute("value");
		log("The station price is: "+stationPrice);
		
		String strDisplayOrderLocator = getUILocator("station_display_order_in_station_page1").replaceAll("<REPLACE_STATION_ID>", stationId);
		WebElement stationDisplayOrderElement = waitForElement(strDisplayOrderLocator);
		String stationDisplayOrder = stationDisplayOrderElement.getAttribute("value");
		log("The station display order is: "+stationDisplayOrder);
		
		String activate = getUILocator("station_active_inactive_cb_station_page");
		activate = activate.replaceAll("<REPLACE_STATION_ID>", stationId);
		WebElement actCheckBox = waitForElement(activate);
		String checkBoxSelection= actCheckBox.getAttribute("checked");
		log(checkBoxSelection);
		if (checkBoxSelection == null)
		{
		Assert.assertTrue(clickElement(activate), "Failed to click active button for the Station");
		log("The station:" + select_station + " has been activated");
		}
		
		String schedule = getUILocator("schedule_section_station_page");
		schedule = schedule.replaceAll("<REPLACE_STATION_ID>", stationId);
		String mealIdCheckBox = getUILocator("schedule_stations_page");
		String mealIdLabel= getUILocator("schedule_labels_station_page");
		
		List<WebElement> list = waitForElements(schedule, 20);
		
		if(list == null || list.size() <= 0) {
			log("No schedule found in the list.");
			return this;
		}
		log("No. of schedules:" + list.size());

		int count = list.size();
		log("Total number of schedule in the station found as:" + count);
		
		HashMap <String,String> scheduleTime = new HashMap<String,String>();
		
		for(WebElement s : list) {
				
				WebElement MealId= s.findElement(By.xpath(mealIdCheckBox));
				WebElement MealName= s.findElement(By.xpath(mealIdLabel));
				String scheduleMealId = MealId.getAttribute("id");
				String scheduleMealName = MealName.getText();
				log("Found the schedule id:"+ scheduleMealId+ " of the Meal Name:" +scheduleMealName);
				scheduleTime.put(scheduleMealName, scheduleMealId);
		}
		
		int noOfSchedules = scheduleTime.size();
		log(Integer.toString(noOfSchedules));
		
		log (scheduleTime.toString());
		
		String scheduleForId = scheduleTime.get(scheduleforTime);
		
		String scheduleId = getUILocator("schedule_id_station_page");	
		scheduleId = scheduleId.replaceAll("<REPLACE_STATION_ID>", stationId);
		scheduleId = scheduleId.replaceAll("<REPLACE_SCHEDULE_ID>",scheduleForId);
		
		WebElement scheduleCheckBox = waitForElement(scheduleId);
		checkBoxSelection= scheduleCheckBox.getAttribute("checked");
		log(checkBoxSelection);
		if (checkBoxSelection == null)
		{
			Assert.assertTrue(clickElement(scheduleId), "Failed to save the station page");
		}
		
		
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to save the station page");
		
		//Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
		Assert.assertTrue(clickElement("menu_page"), "Failed to click MenuTab");
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("lunch_meal_time"), "Failed to click Lunch menu");
		AppUtilities.delay(5000);
		
		Assert.assertTrue(clickElement("current_caffe_location"), "Failed to click the Caffe Location menu");
		String cafeLocation = getUILocator("select_cafe_by_name");
		cafeLocation = cafeLocation.replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", aCaffeLocation);
		Assert.assertTrue(clickElement(cafeLocation), "Failed to choose the caffe location");
		AppUtilities.delay(2000);
		String strStationNameLeftPaneLocator = getUILocator("select_station_left_side").replaceAll("<REPLACE_STATION_NAME>", select_station);
		Assert.assertNotNull(waitForElement(strStationNameLeftPaneLocator), "Failed to find the element");
		AppUtilities.delay(5000);
		
		//String select_station = (String)itemDetails.get("select_station");
		String strAddDishLink = getUILocator("add_dish_link");
		strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		Assert.assertTrue(clickElement(strAddDishLink), "Failed to click Add Dish on the selected Station:" + select_station);
		log("Clicked on Add Dish link");
		AppUtilities.delay(2000);
		
		String strMenuPriceLocator = getUILocator("add_new_menu_item_price");
		WebElement MenuPriceElement = waitForElement(strMenuPriceLocator);
		String MenuPriceValue = MenuPriceElement.getAttribute("value");
		log("The menu price is: "+MenuPriceValue);
		
		//if(stationPrice.contains(".")){
			stationPrice = stationPrice+".00";
			log(stationPrice);
		//}
		Assert.assertTrue(MenuPriceValue.equals(stationPrice), "Station Page value is not displayed in Menu Page");
		return this;
	}
	
	public MenuMakerApp navigateToStationPage (JSONArray caffeDetails) {
		
		navigateToCaffePage(caffeDetails);
		log("Successfully clicked caffe");
		AppUtilities.delay(4000);
		Assert.assertTrue(clickElement("caffe_station_page"), "Failed to click Caffe station field");
		/*
		WebElement element = waitForElement("caffe_station_page");
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
	
		//Need to fix the below scipt once <rdar://problem/26653894> : Only one caffe is shown in Caffe page is fixed and deployed, Work around
		String url = driver.getCurrentUrl();
		log(url);
		driver.navigate().refresh();
		navigateToCaffePage(caffeDetails);
		
		AppUtilities.delay(10000);
		//Actions selectAction = new Actions(driver);
		WebElement caffeStation = waitForElement("caffe_station_page");
		//selectAction.click(caffeStation).build().perform();
		caffeStation.click();
		AppUtilities.delay(2000);*/
		log("Successfully navigated to station page");
		return this;
	}
	
	public MenuMakerApp checkCaffeNameInCaffeInfoPage(JSONArray caffeDetails) {

		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeName = (String)caffeDetail.get("select_caffe_location");
			String strCaffeNameLocator = getUILocator("caffe_name_in_caffe_page").replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", caffeName);
			
			scrollToElement(waitForElement(strCaffeNameLocator));
			
			Assert.assertNotNull(waitForElement(strCaffeNameLocator), "Failed to find the caffe name");
			//Assert.assertTrue(typeText(strCaffeNameLocator, "Caffe Test"), "Failed to type text in Caffe name field");
			AppUtilities.delay(2000);
			log("Successfully validated Caffe name in Caffe info page");
		}
		return this;
	}
	
	public MenuMakerApp checkCaffeAddressInCaffeInfoPage(JSONArray caffeDetails) {
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeAddress = (String)caffeDetail.get("address");
			String strCaffeAddressLocator = getUILocator("caffe_address_in_caffe_page").replaceAll("<REPLACE_CAFFE_LOCATION_ADDRESS>", caffeAddress);
			Assert.assertNotNull(waitForElement(strCaffeAddressLocator), "Failed to find the caffe Address");
			log("Successfully validated Caffe Address in Caffe info page");
		}
		
		return this;
	}
	
	public MenuMakerApp checkCaffeStreetAddressUpdateInCaffeInfoPage(JSONArray caffeDetails) {
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeAddress = (String)caffeDetail.get("street_address");
			String strCaffeAddressLocator = getUILocator("caffe_street_address_in_caffe_page");
			Assert.assertNotNull(waitForElement(strCaffeAddressLocator), "Failed to find the caffe Address");
			Assert.assertTrue(typeText(strCaffeAddressLocator, caffeAddress));
			Assert.assertNotNull(saveButtonClickInCaffePage(), "Failed to save caffe address changes");
			log("Successfully validated Caffe Address Updation in Caffe info page");
		}
		
		return this;
	}
	
	public MenuMakerApp checkCaffeNameUpdateInCaffeInfoPage(JSONArray caffeDetails) {
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeName = (String)caffeDetail.get("select_caffe_location");
			String strCaffeNameLocator = getUILocator("caffe_name_field_in_caffe_page");
			Assert.assertNotNull(waitForElement(strCaffeNameLocator), "Failed to find the caffe name");
			Assert.assertTrue(typeText(strCaffeNameLocator, caffeName));
			Assert.assertNotNull(saveButtonClickInCaffePage(), "Failed to save caffe name changes");
			log("Successfully validated Caffe Name Updation in Caffe info page");
		}
		
		return this;
	}
	
	public MenuMakerApp addCaffeLayoutAttachment(JSONArray caffeDetails) {
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			Assert.assertNotNull(uploadImageFile(caffeDetail, getUILocator("upload_caffe_info_page")), "Failed to upload the file for the Caffe Layout");
			Assert.assertNotNull(saveButtonClickInCaffePage(), "Failed to save caffe address changes");
			AppUtilities.delay(4000);
			
			String[] filePath = caffeDetail.get("image_path").toString().split("/");
			String fileName = filePath[filePath.length-1];
			log("fileName: "+fileName);
			String fileNameLocator = getUILocator("caffe_layout_attachment_caffe_info_page").replaceAll("<REPLACE_TEXT>", fileName);
			Assert.assertNotNull(waitForElement(fileNameLocator), "Failed to find the Uploaded file in Caffe Info screen");
			log("Successfully Uploaded Attachment in Caffe info page");
		}
		
		return this;
	}
	
	public MenuMakerApp stationDataValidationAndUpdation(JSONArray caffeDetails) {
		
		//Stations tab click
		Assert.assertTrue(clickElement("caffe_stations_page"), "Failed to click Caffe Station link");
		AppUtilities.delay(3000);
		
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;		
			Assert.assertNotNull(orderTypeAndOrderMsgUpdation(caffeDetail), "Failed while validating order Type and order message drop down selection Caffe Station screen");		
		}
		
		return this;
	}
	
	private MenuMakerApp orderTypeAndOrderMsgUpdation(JSONObject caffeDetail) {
		
		Assert.assertNotNull(waitForElement("station_name_header_station_page"), "Failed to find the Caffe Station header in Caffe Station screen");
		//Expanding the down arrow for the station to view details
		
		String expandStation = getUILocator("expand_station_arrow_station_page").replaceAll("<station_name>", caffeDetail.get("select_station").toString());
		Assert.assertTrue(clickElement(expandStation), "Failed to click > arrow for the first visible station");
		AppUtilities.delay(2000);		
		//Order Type Drop down selection
		String orderTypeDataOption = (String) caffeDetail.get("order_type_select");
		Select select = new Select(waitForElement("order_type_drop_down_station_page"));
		log("Order Type drop down option: "+ select.getFirstSelectedOption().getText());
		select.selectByVisibleText(orderTypeDataOption);
		AppUtilities.delay(3000);
		log("Order Type drop down option"+ select.getFirstSelectedOption().getText()+ " is selected successfully");
		
		//Order Confirmation Message selection
		String orderConfirmationMsg =(String) caffeDetail.get("order_type_msg_select");
		select = new Select(waitForElement("order_msg_drop_down_station_page"));
		log("Order Confirmation Message drop down option: "+ select.getFirstSelectedOption().getText());
		select.selectByVisibleText(orderConfirmationMsg);
		AppUtilities.delay(3000);
		log("OrderConfirmation Message drop down option"+ select.getFirstSelectedOption().getText()+ " is selected successfully");
		
		return this;
	}
	
	public MenuMakerApp servingTypeDataUpdation(JSONArray caffeDetails) {
		
		//Stations tab click
		Assert.assertTrue(clickElement("caffe_stations_page"), "Failed to click Caffe Station link");
		AppUtilities.delay(3000);
		
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			
			Assert.assertNotNull(waitForElement("station_name_header_station_page"), "Failed to find the Caffe Station header in Caffe Station screen");
			//Expanding the down arrow for the station to view details
			
			String expandStation = getUILocator("expand_station_arrow_station_page").replaceAll("<station_name>", caffeDetail.get("select_station").toString());
			Assert.assertTrue(clickElement(expandStation), "Failed to click > arrow for the first visible station");
			AppUtilities.delay(2000);		
					
			Select select = new Select(waitForElement("serving_type_drop_down_station_page"));
			String defaultServingTypeOptionSelected = select.getFirstSelectedOption().getText();
			String servingTypeOptionData = caffeDetail.get("serving_type_station_option").toString();
			log("Serving Type drop down option: "+ defaultServingTypeOptionSelected);
			
			String servingTypeSelectedCaffeInfoTab = readDataFromRunStore("servingTypeSelectedCaffeInfoTab");
			log("Serving Type data selected in Caffe Info Tab: "+ servingTypeSelectedCaffeInfoTab);
			
			if(servingTypeOptionData.equalsIgnoreCase(servingTypeSelectedCaffeInfoTab) && 
					(defaultServingTypeOptionSelected.equalsIgnoreCase(servingTypeOptionData))) {
				log("Serving Type in Stations tab is similar to Serving Type in Caffe Info tab as per given test data");
			}
			else {			
				//Select option as per test data for serving type
				select.selectByVisibleText(servingTypeOptionData);
				AppUtilities.delay(2000);
				log("Serving Type drop down option"+ select.getFirstSelectedOption().getText()+ " is selected successfully");
			
				// Save button click
				Assert.assertNotNull(saveStationDetailsStationsTab(), "Failed while save Station tab in Caffe Page");
				log("Successfully saved changes in Caffe page Stations tab");
			
				scrollToElement(waitForElement("station_name_header_station_page"));
				
				//Updating back to default option
				select.selectByVisibleText(defaultServingTypeOptionSelected);
								
				Assert.assertNotNull(saveStationDetailsStationsTab(), "Failed while save Station tab in Caffe Page");
			}
		}
		
		return this;
	}
	
	public MenuMakerApp updateStationTypeInStationsTab(JSONArray caffeDetails) {		
		Assert.assertTrue(clickElement("caffe_stations_page"), "Failed to click Caffe Station link");
		AppUtilities.delay(3000);
		
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			
			Assert.assertNotNull(waitForElement("station_name_header_station_page"), "Failed to find the Caffe Station header in Caffe Station screen");
			//Expanding the down arrow for the station to view details
			
			String expandStation = getUILocator("expand_station_arrow_station_page").replaceAll("<station_name>", caffeDetail.get("select_station").toString());
			Assert.assertTrue(clickElement(expandStation), "Failed to click > arrow for the first visible station");
			AppUtilities.delay(2000);		
			
			
			JSONArray stationTypeDetails = (JSONArray) caffeDetail.get("station_type");
			for (int j = 0; j < stationTypeDetails.size(); j++) {
				String stationTypeData = stationTypeDetails.get(j).toString();
				log("Validation for Caffe Serving Type:" + stationTypeData);
				String caffe_Serving_Locator = getUILocator("station_type_check_box");
				caffe_Serving_Locator = caffe_Serving_Locator.replaceAll("<REPLACE_TEXT>", stationTypeData);
				
				if(!waitForElement(caffe_Serving_Locator).isSelected())
					Assert.assertTrue(clickElement(caffe_Serving_Locator),
						"Failed to click the Caffe Serving check box in Caffe Station screen");
				
				AppUtilities.delay(2000);	
			}
		}
		
		return this;
	}
	
	public MenuMakerApp addNewStationInStationTab(JSONArray caffeDetails) {
		
		//Stations tab click
		Assert.assertTrue(clickElement("caffe_stations_page"), "Failed to click Caffe Station link");
		AppUtilities.delay(3000);
		
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
						
			//Click on Add Station link
			Assert.assertTrue(clickElement("add_station_link_station_page"), "Failed to click Add Station link");
			AppUtilities.delay(3000);
			List<WebElement> listOfStations = waitForElements("expand_station_station_page");
			
			int newStationIndex = listOfStations.size()-1;
			log("newStationIndex: " + newStationIndex);
			
			//Type Caffe Station Name 
			String stationName = (String)caffeDetail.get("new_station_name");
			//RandomName Creation for ingredient name to avoid duplicates		
			int randNum = (int) (Math.random() * 1000);
			stationName=stationName+randNum;
			log(stationName);
			
			String strStationNameLocator = getUILocator("station_name_field_station_page").replaceAll("<REPLACE_INDEX>", Integer.toString(newStationIndex));
			Assert.assertNotNull(waitForElement(strStationNameLocator), "Failed to find the Station name field");
			Assert.assertTrue(typeText(strStationNameLocator, stationName));
			
			//Select Station Type
			JSONArray stationTypeDetails = (JSONArray) caffeDetail.get("station_type");
			for (int j = 0; j < stationTypeDetails.size(); j++) {
				String stationTypeData = stationTypeDetails.get(j).toString();
				log("Validation for Caffe Serving Type:" + stationTypeData);
				String caffe_Serving_Locator = getUILocator("station_type_check_box");//.replaceAll("<REPLACE_INDEX>", Integer.toString(newStationIndex));
				caffe_Serving_Locator = caffe_Serving_Locator.replaceAll("<REPLACE_TEXT>", stationTypeData);
				Assert.assertTrue(clickElement(caffe_Serving_Locator),
						"Failed to click the Caffe Serving check box in Caffe Station screen");
			}
			
			//Select Schedule Check box
			JSONArray scheduleDetails = (JSONArray) caffeDetail.get("schedule_data");
			for (int j = 0; j < scheduleDetails.size(); j++) {
				String scheduleData = scheduleDetails.get(j).toString();
				log("Validation for Caffe Schedule:" + scheduleData);
				String caffe_Schedule_Locator = getUILocator("schedule_check_box").replaceAll("<REPLACE_INDEX>", Integer.toString(newStationIndex));
				caffe_Schedule_Locator = caffe_Schedule_Locator.replaceAll("<REPLACE_TEXT>", scheduleData);
				
				if(!waitForElement(caffe_Schedule_Locator).isSelected()) {
					Assert.assertTrue(clickElement(caffe_Schedule_Locator),
						"Failed to click the Caffe Schedule check box in Caffe Station screen");
				}
			}
			
			//Serving Type Drop down select
			Select select = new Select(waitForElement("serving_type_drop_down_station_page"));
			select.selectByVisibleText(caffeDetail.get("serving_type_station_option").toString());
			
			//Type data for Default Price Field
			String price = (String)caffeDetail.get("default_price");
			String priceLocator = getUILocator("default_price_field").replaceAll("<REPLACE_INDEX>", Integer.toString(newStationIndex));
			Assert.assertNotNull(waitForElement(priceLocator), "Failed to find the Station name field");
			Assert.assertTrue(typeText(priceLocator, price));
			
			//Order Type Drop down selection
			String orderTypeDataOption = (String) caffeDetail.get("order_type_select");
			List<WebElement> orderTypeList = waitForElements("order_type_drop_down_station_page");	
			select = new Select(orderTypeList.get(orderTypeList.size()-1));
			log("Order Type drop down option: "+ select.getFirstSelectedOption().getText());
			select.selectByVisibleText(orderTypeDataOption);
			AppUtilities.delay(3000);
			log("Order Type drop down option"+ select.getFirstSelectedOption().getText()+ " is selected successfully");
			
			//Order Confirmation Message selection
			String orderConfirmationMsg =(String) caffeDetail.get("order_type_msg_select");
			
			List<WebElement> orderMsgList = waitForElements("order_msg_drop_down_station_page");		
			select = new Select(orderMsgList.get(orderMsgList.size()-1));
			log("Order Confirmation Message drop down option: "+ select.getFirstSelectedOption().getText());
			select.selectByVisibleText(orderConfirmationMsg);
			AppUtilities.delay(3000);
			log("OrderConfirmation Message drop down option"+ select.getFirstSelectedOption().getText()+ " is selected successfully");
			
			
		}
		
		return this;
	}
	
	public MenuMakerApp saveStationDetailsStationsTab() {
		AppUtilities.delay(5000);
		//Save button click
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("save_station_page"), "Failed to click the Save button");
		AppUtilities.delay(4000);
		Assert.assertNotNull(waitForElement("save_status"), "Failed to find save status");
		return this;
	}
	
	public MenuMakerApp updateActiveStatusOfAStation(JSONArray caffeDetails) {

		// Stations tab click
		Assert.assertTrue(clickElement("caffe_stations_page"), "Failed to click Caffe Station link");
		AppUtilities.delay(3000);

		for (Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject) i;

			// Click on Add Station link
			Assert.assertTrue(clickElement("add_station_link_station_page"), "Failed to click Add Station link");
			AppUtilities.delay(3000);
			List<WebElement> listOfStations = waitForElements("station_name_list_station_page");
			int indexForUpdate = 0;
			String stationNameFromUI = null;
			String stationNameToUpdate =(String) caffeDetail.get("select_station");
			
			for(int j=0;j<listOfStations.size();j++) {
				stationNameFromUI = listOfStations.get(j).getText();
				if(stationNameToUpdate.equalsIgnoreCase(stationNameFromUI)) {
					indexForUpdate = j;
				}
			}
			
			String activeCheckBoxLocator = getUILocator("station_active_checkbox_station_page").replaceAll("<REPLACE_INDEX>", Integer.toString(indexForUpdate));
			Assert.assertTrue(clickElement(activeCheckBoxLocator), "Failed to click the active check box for the station"+stationNameToUpdate);
						
		}

		return this;
	}

	public MenuMakerApp saveButtonClickInCaffePage() {
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the Save button");
		AppUtilities.delay(4000);		
		log("Successfully validated save button click in Caffe page");
		return this;
	}
	
	public MenuMakerApp checkCaffeEmailInCaffeInfoPage(JSONArray caffeDetails) {
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeEmailID = (String)caffeDetail.get("Email_ID");
			String strCaffeEmailLocator = getUILocator("caffe_email_id_in_caffe_page").replaceAll("<REPLACE_CAFFE_EMAIL>", caffeEmailID);
			Assert.assertNotNull(waitForElement(strCaffeEmailLocator), "Failed to find the caffe Email ID");
			log("Successfully validated Caffe Email Id in Caffe info page");
		}
		return this;
	}
	
	public MenuMakerApp checkCaffeTeamInCaffeInfoPage(JSONArray caffeDetails) {
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeTeam = (String)caffeDetail.get("Team");
			String strCaffeTeamLocator = getUILocator("caffe_team_field_in_caffe_page").replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", caffeTeam);
			WebElement link = waitForElement(strCaffeTeamLocator);
			Point p = link.getLocation();
			((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 150) + ");");
			log("Brought the Team field into view");
			Assert.assertNotNull(waitForElement(strCaffeTeamLocator), "Failed to find the caffe Team");
			log("Successfully validated Caffe Team in Caffe info page");
		}
		return this;
	}
	
	public MenuMakerApp verifyAddStationButton() {
		int stationsBeforeAdd = stationsAvailable();
		log("Array size: "+stationsBeforeAdd);
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		int stationsAfterAdd = stationsAvailable();
		log("Array size after new station: "+stationsAfterAdd);
		Assert.assertEquals(stationsAfterAdd, stationsBeforeAdd+1 , "Failed to add station tab");
		log("Successfully validated add station button");
		return this;	
	}

	public MenuMakerApp validateNameFieldNewStation() {
		int stationsCount = stationsAvailable();
		int stationCount = stationsCount-1;
		String stationName = Integer.toString(stationCount);
		String strStationNameFieldLocator = getUILocator("station_name_field_in_station_page1").replaceAll("<REPLACE_STATION_ID>", stationName); 
		Assert.assertTrue(typeText(strStationNameFieldLocator, "New Station Name-"+stationCount), "Failed to type the newly added station's name");
		newStationName = "New Station Name-"+stationCount;
		log("Successfully validated Name field for New station");
		return this;
	}
	
	public MenuMakerApp validateActiveFieldNewStation(JSONArray caffeDetails) {
		int stationsCount = stationsAvailable();
		int stationCount = stationsCount-1;
		String strStationActiveFieldLocator = getUILocator("station_active_inactive_in_station_page").replaceAll("<REPLACE_ACTIVE_ID>", Integer.toString(stationCount)); 
		WebElement stationActiveFieldLocator = waitForElement(strStationActiveFieldLocator);
		boolean stationActiveFieldValue = stationActiveFieldLocator.isSelected();
		Assert.assertFalse(stationActiveFieldValue);
		log("Successfully validated Active field for New station");
		return this;
	}
	
	public MenuMakerApp getDisplayOrderStation(JSONArray caffeDetails){
		navigateToStationPage(caffeDetails);
		int stations = stationsAvailable();
		for (int i = 0; i<stations; i++){
		String stationNumber = Integer.toString(i);
		String strStationNameFieldLocator = getUILocator("station_name_field_in_station_page1").replaceAll("<REPLACE_STATION_ID>", stationNumber); 
		WebElement Name = waitForElement(strStationNameFieldLocator);
		String stationName = Name.getAttribute("value");
		log(stationName);
		AppUtilities.delay(2000);
		String strDisplayOrderFieldLocator = getUILocator("station_display_order_in_station_page").replaceAll("<REPLACE_DISPLAYORDER_ID>", stationNumber);
		WebElement disp = waitForElement(strDisplayOrderFieldLocator);
		String displayOrder = disp.getAttribute("value");
		log(displayOrder);
		AppUtilities.delay(2000);
		String strStationActiveFieldLocator = getUILocator("station_active_inactive_in_station_page").replaceAll("<REPLACE_ACTIVE_ID>", stationNumber); 
		WebElement stationActiveFieldLocator = waitForElement(strStationActiveFieldLocator);
		boolean stationActiveFieldValue = stationActiveFieldLocator.isSelected();
		log(Boolean.toString(stationActiveFieldValue));
		AppUtilities.delay(2000);
		
		/*To get exact number of values to be displayed in GuestApp for a schedule
		 * String scheduleId = getUILocator("schedule_id_station_page");	
		scheduleId = scheduleId.replaceAll("<REPLACE_STATION_ID>", stationId);
		scheduleId = scheduleId.replaceAll("<REPLACE_SCHEDULE_ID>",scheduleForId);
		Assert.assertTrue(clickElement(scheduleId), "Failed to save the station page");*/
		
		stationOrder.put(stationName,Integer.parseInt(displayOrder));
		
		/*if(stationActiveFieldValue){
			log("Inserting value in hashmap");
			stationOrder.put(stationName,Integer.parseInt(displayOrder));
		}*/
		
		Point p = disp.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 750) + ");");
		AppUtilities.delay(2000);
		
		}
		
		log(stationOrder.toString());
		log("Successfully validated Display order for New station");
		return this;
		
	}
	
	
	public MenuMakerApp checkItemsAvailablityForStations(JSONArray caffeDetails)
	{
		JSONObject caffeDetail = (JSONObject)caffeDetails.get(0);
		String aCaffeLocation =  (String) caffeDetail.get("select_caffe_location");
		Assert.assertTrue(clickElement("menu_page"), "Failed to click Menu tab");
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("lunch_meal_time"), "Failed to click the lunch meal time link");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("current_caffe_location"), "Failed to click the Caffe Location menu");
		String cafeLocation = getUILocator("select_cafe_by_name");
		cafeLocation = cafeLocation.replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", aCaffeLocation);
		Assert.assertTrue(clickElement(cafeLocation), "Failed to choose the caffe location");
		AppUtilities.delay(2000);
		
		String foodType =  (String) caffeDetail.get("food_type");
		if(foodType.equals("Standard")){
		Assert.assertTrue(clickElement("select_standard_menu"), "Failed to click standard button ");
		} else if (foodType.equals("Specials")){
		Assert.assertTrue(clickElement("select_special_menu"), "Failed to click specials");
				
		}
		
		List<WebElement> stationsWithMenuItem  = waitForElements("stations_with_menu_item");
		for (WebElement e : stationsWithMenuItem)
		{
			String stationName = e.getText();
			stationOrder.remove(stationName);
		}
		
		log(stationOrder.toString());
				
		return this;
	}
	public MenuMakerApp validateDisplayOrderFieldNewStation() {
		//Display order of the last station before adding a new station
		int stationsBeforeAdd = stationsAvailable();
		int stationCountBeforeAdd = stationsBeforeAdd-1;
		String stationNameBeforeAdd = Integer.toString(stationCountBeforeAdd);
		String strStationNameFieldLocatorBeforeAdd = getUILocator("station_display_order_in_station_page").replaceAll("<REPLACE_DISPLAYORDER_ID>", stationNameBeforeAdd);
		WebElement strStationDisplayOrderBeforeAdd = waitForElement(strStationNameFieldLocatorBeforeAdd);
		String stationDisplayOrderBeforeAdd = strStationDisplayOrderBeforeAdd.getAttribute("value");
		log("The display order shown is: "+stationDisplayOrderBeforeAdd);
		
		//Display order after adding a station
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		int stationsAfterAdd = stationsAvailable();
		int stationCountAfterAdd = stationsAfterAdd-1;
		String stationNameAfterAdd = Integer.toString(stationCountAfterAdd);
		String strStationNameFieldLocatorAfterAdd = getUILocator("station_display_order_in_station_page").replaceAll("<REPLACE_DISPLAYORDER_ID>", stationNameAfterAdd);
		WebElement strStationDisplayOrderAfterAdd = waitForElement(strStationNameFieldLocatorAfterAdd);
		String stationDisplayOrderAfterAdd = strStationDisplayOrderAfterAdd.getAttribute("value");
		log("The display order shown is: "+stationDisplayOrderAfterAdd);
		if (stationDisplayOrderAfterAdd == stationDisplayOrderBeforeAdd+1) {
			Assert.assertTrue(true);
		}
		log("The display order is generated correctly for new station");
		return this;
	}
	
	public MenuMakerApp checkStationNameFieldMandatory() {
		AppUtilities.delay(4000);
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		//Number of stations
		int stationsAfterAdd = stationsAvailable();
		int stationCount = stationsAfterAdd-1;
		String stationName = Integer.toString(stationCount);
		String strStationNameFieldLocator = getUILocator("station_display_order_in_station_page").replaceAll("<REPLACE_DISPLAYORDER_ID>", stationName); 
		Assert.assertTrue(clickElement(strStationNameFieldLocator), "Failed to click Add station Button");
		
		//Validating the mandatory message
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement("station_name_mandatory_validation_in_station_page"), "Failed to find the mandatory message for stations");
		log("Successfully validated Station name field mandatory");
		return this;
	}
	
	public MenuMakerApp checkStationNameDuplicate() {
		String expectedAlertText = "Duplicate station name.";
		//Display order of the last station before adding a new station
		int stationsPresentBeforeAdd = stationsAvailable();
		int stationCountBeforeAdd = stationsPresentBeforeAdd-1;
		String stationIdBeforeAdd = Integer.toString(stationCountBeforeAdd);
		String strStationNameFieldLocatorBeforeAdd = getUILocator("station_name_field_in_station_page1").replaceAll("<REPLACE_STATION_ID>", stationIdBeforeAdd);
		WebElement strStationNameBeforeAdd = waitForElement(strStationNameFieldLocatorBeforeAdd);
		String stationNameBeforeAdd = strStationNameBeforeAdd.getAttribute("value");
		log("The display order shown is: "+stationNameBeforeAdd);
		AppUtilities.delay(4000);
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		//Number of stations
		int stationsPresentAfterAdd = stationsAvailable();
		int stationCount = stationsPresentAfterAdd-1;
		String stationIdBAfterAdd = Integer.toString(stationCount);
		String strStationNameFieldLocator = getUILocator("station_name_field_in_station_page1").replaceAll("<REPLACE_STATION_ID>", stationIdBAfterAdd); 
		
		if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")) {
			try{
				//Assert.assertTrue(typeText(strStationNameFieldLocator, stationNameBeforeAdd), "Failed to keyin the station name");
				//Validating the error message
			
			WebElement stationName = waitForElement(strStationNameFieldLocator);
			stationName.sendKeys(stationNameBeforeAdd);
			
			} catch (Exception e){
				
				String exceptionContent = "Exception"+e;
				log(exceptionContent);
				Assert.assertTrue(exceptionContent.contains(expectedAlertText),"Failed to contain text");
			}
			} else if (StringUtils.containsIgnoreCase(getBrowserName(), "firefox")){
				Assert.assertTrue(typeText(strStationNameFieldLocator, stationNameBeforeAdd), "Failed to keyin the station name");
				
			//Safari unhandled alert exception is thrown. Working fine for fireFox
			AppUtilities.delay(2000);
			//Validating the error message
			driver.switchTo().alert();
			String actualAlertText = driver.switchTo().alert().getText();
			boolean compareResult  = actualAlertText.equalsIgnoreCase(expectedAlertText);
			Assert.assertTrue(compareResult, "The duplicate display order alert is not displayed");
	        driver.switchTo().alert().accept();
	        }

		AppUtilities.delay(2000);
		log("Successfully validated Station name duplicate");
	return this;
	}
	
	public MenuMakerApp checkDisplayOrderDuplicate() {
		String expectedAlertText = "Duplicate Display Order";
		//Display order of the last station before adding a new station
		int stationsPresentBeforeAdd = stationsAvailable();
		int stationCountBeforeAdd = stationsPresentBeforeAdd-1;
		String stationIdBeforeAdd = Integer.toString(stationCountBeforeAdd);
		String strStationDisplayOrderFieldLocatorBeforeAdd = getUILocator("station_display_order_in_station_page").replaceAll("<REPLACE_DISPLAYORDER_ID>", stationIdBeforeAdd);
		WebElement strStationDisplayOrderBeforeAdd = waitForElement(strStationDisplayOrderFieldLocatorBeforeAdd);
		String stationDisplayOrderBeforeAdd = strStationDisplayOrderBeforeAdd.getAttribute("value");
		log("The display order shown is: "+stationDisplayOrderBeforeAdd);
		AppUtilities.delay(4000);
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		//Number of stations
		int stationsPresentAfterAdd = stationsAvailable();
		int stationCount = stationsPresentAfterAdd-1;
		String stationIdBAfterAdd = Integer.toString(stationCount);
		
		String strStationNameFieldLocator = getUILocator("station_name_field_in_station_page1").replaceAll("<REPLACE_STATION_ID>", stationIdBAfterAdd); 
		Assert.assertTrue(typeText(strStationNameFieldLocator, stationDisplayOrderBeforeAdd), "Failed to keyin the station name");
		AppUtilities.delay(2000);
		
		String strPriceFieldLocator = getUILocator("station_default_price_in_station_page").replaceAll("<REPLACE_DEFAULTPRICE_ID>", stationIdBAfterAdd); 
		Assert.assertTrue(typeText(strPriceFieldLocator, stationDisplayOrderBeforeAdd), "Failed to keyin the station price");
		AppUtilities.delay(2000);
		
		String strStationDisplayOrderFieldLocator = getUILocator("station_display_order_in_station_page").replaceAll("<REPLACE_DISPLAYORDER_ID>", stationIdBAfterAdd); 
		Assert.assertTrue(typeText(strStationDisplayOrderFieldLocator, stationDisplayOrderBeforeAdd), "Failed to keyin the station order");
		AppUtilities.delay(2000);
		
		WebElement e = waitForElement(strStationDisplayOrderFieldLocator);
		String className = e.getAttribute("class");
		
		
		Assert.assertTrue(className.contains("address-red"),"Failed to display order duplicate");
		log("Successfully validated display order duplicate");
        return this;
	}
	
	public MenuMakerApp validateAlertWhenNavigatedToOtherTabsFromStation() {
		String expectedAlertText = "Save your changes or cancel your changes.";
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		int stationsPresent = stationsAvailable();
		int stationCount = stationsPresent-1;
		String stationIdBAfterAdd = Integer.toString(stationCount);
		String strStationDisplayOrderFieldLocator = getUILocator("station_name_field_in_station_page1").replaceAll("<REPLACE_STATION_ID>", stationIdBAfterAdd); 
		Assert.assertTrue(typeText(strStationDisplayOrderFieldLocator, "Welcome"), "Failed to keyin the station name");
		AppUtilities.delay(2000);
		
		if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")) {
		try{
		WebElement infoPage = waitForElement("caffe_info_page_nondefaultselect");
		log("Gonna click");
		infoPage.click();
		} catch (Exception e){
			
			String exceptionContent = "Exception"+e;
			log(exceptionContent);
			Assert.assertTrue(exceptionContent.contains(expectedAlertText),"Failed to contain text");
		}
		} else if (StringUtils.containsIgnoreCase(getBrowserName(), "firefox")){
		Assert.assertTrue(clickElement("caffe_info_page_nondefaultselect"), "Failed to click Caffe Info option");
		
		//Safari unhandled alert exception is thrown. Working fine for fireFox
		AppUtilities.delay(2000);
		//Validating the error message
		driver.switchTo().alert();
		String actualAlertText = driver.switchTo().alert().getText();
		boolean compareResult  = actualAlertText.equalsIgnoreCase(expectedAlertText);
		Assert.assertTrue(compareResult, "The duplicate display order alert is not displayed");
        driver.switchTo().alert().accept();}
		log("Successfully validated the alert message when navigated to other tab");
		return this;
	}
	
	public MenuMakerApp verifyCancelButton() {
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		int stationCountAfterAdd = stationsAvailable();
		log("The stations count after add is: "+stationCountAfterAdd);
		Assert.assertTrue(clickElement("station_cancel_button_in_station_page"), "Failed to click the cancel button in station page");
		//AppUtilities.delay(4000);
		log("Successfully validated Cancel button in Station page");
		return this;
	}
	
	
	public MenuMakerApp verifyStationNameInLeftPane() {
		String stationName = "Station created for Automation";
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		int stationsPresent = stationsAvailable();
		int stationCountAfterAdd = stationsPresent-1;
		String stationIdBAfterAdd = Integer.toString(stationCountAfterAdd);
		log("The stationIdBAfterAdd from function is: "+stationIdBAfterAdd);
		String strStationDisplayOrderFieldLocator = getUILocator("station_name_field_in_station_page1").replaceAll("<REPLACE_STATION_ID>", stationIdBAfterAdd); 
		Assert.assertTrue(typeText(strStationDisplayOrderFieldLocator, stationName), "Failed to keyin the station name");
		AppUtilities.delay(5000);
		List<WebElement> myList_afterNewStation=driver.findElements(By.className("stationName"));
		List<String> allStations_afterNewStation=new ArrayList<String>();
		log("he size of stations presetn in left pane is: "+myList_afterNewStation.size());
		for(int k=0; k<myList_afterNewStation.size(); k++){
			allStations_afterNewStation.add(myList_afterNewStation.get(k).getText());
			log(allStations_afterNewStation.get(k));
			if (allStations_afterNewStation.get(k).equals(stationName)) {
				Assert.assertTrue(true);
			}
		}
		log("Successfully verified save button on left pane");
		return this;
	}
	
	public int stationsAvailable() {
		AppUtilities.delay(3000);
		List<WebElement> myList_afterNewStation=driver.findElements(By.className("station-food-item-list-link"));
		List<String> allStations_afterNewStation=new ArrayList<String>();
		log("The list size after new station: "+myList_afterNewStation.size());
		for(int k=0; k<myList_afterNewStation.size(); k++){
			allStations_afterNewStation.add(myList_afterNewStation.get(k).getText());
		}
		int stationsPresent= allStations_afterNewStation.size();
		return stationsPresent;
	}
	
	public MenuMakerApp validateAlertWhenNavigatedToOtherTabsFromCaffe() {
		String expectedAlertText = "Save your changes or cancel your changes.";
		AppUtilities.delay(2000);
		
		if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")) {
		try{
		WebElement stationLink = waitForElement("caffe_station_page");
		stationLink.click();
		} catch (Exception e){
			
			String exceptionContent = "Exception"+e;
			log(exceptionContent);
			Assert.assertTrue(exceptionContent.contains(expectedAlertText),"Failed to contain text");
		}
		} else if (StringUtils.containsIgnoreCase(getBrowserName(), "firefox")){
		Assert.assertTrue(clickElement("caffe_station_page"), "Failed to click station option");

		AppUtilities.delay(2000);
		//Validating the error message
		driver.switchTo().alert();
		String actualAlertText = driver.switchTo().alert().getText();
		boolean compareResult  = actualAlertText.equalsIgnoreCase(expectedAlertText);
		Assert.assertTrue(compareResult, "The duplicate display order alert is not displayed");
        driver.switchTo().alert().accept();
		}
		log("Successfully validated the alert message when navigated to other page from Caffe page");
		return this;
		
	}
	
	public MenuMakerApp verifyChosenCaffeInStationsPage(JSONArray caffeDetails) {
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeName = (String)caffeDetail.get("select_caffe_location");
			
			String strCaffeNameInStationPage = getUILocator("caffe_name_in_station_page").replaceAll("<REPLACE_CAFFE_NAME>", caffeName);
			Assert.assertNotNull(waitForElement(strCaffeNameInStationPage), "Failed to find the caffe name in station screen");
		}
		return this;
	}
	
	public MenuMakerApp verifyCancelButtonInCaffePage(JSONArray caffeDetails) {
		Assert.assertTrue(clickElement("station_cancel_button_in_station_page"), "Failed to click the cancel button in station page");
		AppUtilities.delay(4000);
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeName = (String)caffeDetail.get("select_caffe_location");
			String strCaffeNameInStationPage = getUILocator("caffe_name_in_caffe_page").replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", caffeName);
			Assert.assertNotNull(waitForElement(strCaffeNameInStationPage), "Failed to find the caffe name in station screen");
		}
		log("Successfully validated the cancel button in caffe page");
		return this;
	}
	
	//Added by Chithra
	public MenuMakerApp verifyCaffeOfferingsInCaffePage(JSONArray caffeDetails) {
		AppUtilities.delay(4000);
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeName = (String)caffeDetail.get("select_caffe_location");
			String strCaffeNameInCaffeInfoPage = getUILocator("caffe_name_in_caffe_page").replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", caffeName);
			
			scrollToElement(waitForElement(strCaffeNameInCaffeInfoPage));
			
			log("Scrolled to Station Name");
			
			Assert.assertNotNull(waitForElement(strCaffeNameInCaffeInfoPage), "Failed to find the caffe name in Caffe Info screen");
						
			//Validation of Caffe Offerings in Caffe Info tab
			JSONArray offeringDetails = (JSONArray)caffeDetail.get("cafe_offerings");
			
			
			for(int j=0;j<offeringDetails.size();j++) {
				log("Validation for Caffe Offering option:" + offeringDetails.get(j));
				String caffe_Offering_Locator = getUILocator("caffe_offerings_label");
				caffe_Offering_Locator=caffe_Offering_Locator.replaceAll("<REPLACE_INDEX>", Integer.toString(j));
				Assert.assertNotNull(waitForElement(caffe_Offering_Locator), "Failed to find the Caffe Offering in Caffe Info screen");	
				
				log("Caffe Offering Label :"+  waitForElement(caffe_Offering_Locator).getText());
				String caffeOfferingLabelFromUI = waitForElement(caffe_Offering_Locator).getText();
				if( offeringDetails.get(j).toString().equalsIgnoreCase(caffeOfferingLabelFromUI)) {
					log("Caffe Offering Label validation completed for "+  offeringDetails.get(j));
				}
				String caffe_Offering_Checkbox_Locator = getUILocator("caffe_offerings_checkbox");
				caffe_Offering_Checkbox_Locator=caffe_Offering_Checkbox_Locator.replaceAll("<REPLACE_INDEX>", Integer.toString(j));
				Assert.assertNotNull(waitForElement(caffe_Offering_Checkbox_Locator), "Failed to find the Caffe Offering Checkbox in Caffe Info screen");
				
				if(waitForElement(caffe_Offering_Checkbox_Locator).isSelected()) {
					//Checked data for verification
					log("Checked attribute for Caffe Offering: " +   offeringDetails.get(j).toString() + " is "+ waitForElement(caffe_Offering_Checkbox_Locator).getAttribute("checked"));
					
					/*//Validation in Stations Tab - Feature Not available hence commented below validation
					Assert.assertTrue(clickElement("caffe_stations_page"), "Failed to click Caffe Station link");
					AppUtilities.delay(3000);
					Assert.assertNotNull(waitForElement("station_name_header_station_page"), "Failed to find the Caffe Station header in Caffe Station screen");
					
					Assert.assertTrue(clickElement("expand_station_station_page"), "Failed to click > arrow for the first visible station");
					
					String stationTypeLocator = getUILocator("station_type_label").replaceAll("<REPLACE_TEXT>", caffeOfferingLabelFromUI);
					Assert.assertNotNull(waitForElement(stationTypeLocator), "Failed to find the Caffe Type data in Caffe Station screen");
										
					//Navigate back to Caffe Info Tab
					Assert.assertTrue(clickElement("caffe_info_page"), "Failed to click Caffe Info option");
					AppUtilities.delay(4000);*/
				}
			}	
						
		}
				
		return this;
	}
	
	public MenuMakerApp verifyCaffeOfferingsUpdationInCaffePage(JSONArray caffeDetails) {
		AppUtilities.delay(4000);
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeName = (String)caffeDetail.get("select_caffe_location");
			String strCaffeNameInCaffeInfoPage = getUILocator("caffe_name_in_caffe_page").replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", caffeName);
			
			scrollToElement(waitForElement(strCaffeNameInCaffeInfoPage));
			
			log("Scrolled to Station Name");
			
			Assert.assertNotNull(waitForElement(strCaffeNameInCaffeInfoPage), "Failed to find the caffe name in Caffe Info screen");
						
			//Validation of Caffe Offerings in Caffe Info tab
			JSONArray offeringDetails = (JSONArray)caffeDetail.get("cafe_offerings");
			
			
			for(int j=0;j<offeringDetails.size();j++) {
				log("Validation for Caffe Offering option:" + offeringDetails.get(j));
				String caffe_Offering_Locator = getUILocator("caffe_offerings_label");
				caffe_Offering_Locator=caffe_Offering_Locator.replaceAll("<REPLACE_INDEX>", Integer.toString(j));
				Assert.assertNotNull(waitForElement(caffe_Offering_Locator), "Failed to find the Caffe Offering in Caffe Info screen");	
				
				log("Caffe Offering Label :"+  waitForElement(caffe_Offering_Locator).getText());
				String caffeOfferingLabelFromUI = waitForElement(caffe_Offering_Locator).getText();
				if( offeringDetails.get(j).toString().equalsIgnoreCase(caffeOfferingLabelFromUI)) {
					log("Caffe Offering Label validation completed for "+  offeringDetails.get(j));
				}
				String caffe_Offering_Checkbox_Locator = getUILocator("caffe_offerings_checkbox");
				caffe_Offering_Checkbox_Locator=caffe_Offering_Checkbox_Locator.replaceAll("<REPLACE_INDEX>", Integer.toString(j));
				Assert.assertNotNull(waitForElement(caffe_Offering_Checkbox_Locator), "Failed to find the Caffe Offering Checkbox in Caffe Info screen");
				
				if(!waitForElement(caffe_Offering_Checkbox_Locator).isSelected()) {
					//Checked data for verification
					Assert.assertTrue(clickElement(caffe_Offering_Checkbox_Locator), "Failed to click the Caffe Offering Checkbox in Caffe Info screen");
				}
				
				Assert.assertNotNull(saveButtonClickInCaffePage(), "Failed to save caffe info changes");
			}	
						
		}
				
		return this;
	}
	
	public MenuMakerApp validateCaffeInfoUpdation(JSONArray caffeDetails) {
		AppUtilities.delay(4000);
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeName = (String)caffeDetail.get("select_caffe_location");
			String strCaffeNameInCaffeInfoPage = getUILocator("caffe_name_in_caffe_page").replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", caffeName);
			
			scrollToElement(waitForElement(strCaffeNameInCaffeInfoPage));
			
			log("Scrolled to Station Name");
			
			Assert.assertNotNull(waitForElement(strCaffeNameInCaffeInfoPage), "Failed to find the caffe name in Caffe Info screen");
			
			//Address Data updation
			Assert.assertNotNull(addressDataUpdationCaffeInfoTab(caffeDetail), "Failed to update the caffe address data in Caffe Info screen");
									
			//Updation of Caffe Offerings in Caffe Info tab
			JSONArray offeringDetails = (JSONArray)caffeDetail.get("cafe_offerings");			
			
			for(int j=0;j<offeringDetails.size();j++) {
				log("Validation for Caffe Offering option:" + offeringDetails.get(j).toString());
				String caffe_Offering_Locator = getUILocator("caffe_offerings_checkbox_caffe_info_page");
				caffe_Offering_Locator=caffe_Offering_Locator.replaceAll("<REPLACE_TEXT>", offeringDetails.get(j).toString());
				Assert.assertNotNull(waitForElement(caffe_Offering_Locator), "Failed to find the Caffe Offering in Caffe Info screen");	
				if(!waitForElement(caffe_Offering_Locator).isSelected()) {
					//Offering Check Box Click
					Assert.assertTrue(clickElement(caffe_Offering_Locator), "Failed to click the Caffe Offering Checkbox for "+offeringDetails.get(j).toString()+" in Caffe Info screen");						
				}								
			}	
			
			//Serving Radio button selection
			String caffe_Serving_Radio_Button = getUILocator("serving_button_using_Label_caffe_info_page");			
			caffe_Serving_Radio_Button=caffe_Serving_Radio_Button.replaceAll("<REPLACE_TEXT>", caffeDetail.get("serving_caffe_info_select").toString());
			Assert.assertTrue(clickElement(caffe_Serving_Radio_Button), "Failed to click the Caffe Serving Radio button in Caffe Info screen");
			
			
		}
				
		return this;
	}
	
	public MenuMakerApp validateCaffeAddressUpdation(JSONArray caffeDetails) {
		AppUtilities.delay(4000);
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			String caffeName = (String)caffeDetail.get("select_caffe_location");
			String strCaffeNameInCaffeInfoPage = getUILocator("caffe_name_in_caffe_page").replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", caffeName);
			
			scrollToElement(waitForElement(strCaffeNameInCaffeInfoPage));
			
			log("Scrolled to Station Name");
			
			Assert.assertNotNull(waitForElement(strCaffeNameInCaffeInfoPage), "Failed to find the caffe name in Caffe Info screen");
			
			//Address Data updation
			Assert.assertNotNull(addressDataUpdationCaffeInfoTab(caffeDetail), "Failed to update the caffe address data in Caffe Info screen");			
		}
				
		return this;
	}
	
	private MenuMakerApp addressDataUpdationCaffeInfoTab(JSONObject caffeDetail) {

		String caffeStreetAddress = (String) caffeDetail.get("street_address");
		log("caffeStreetAddress"+ caffeStreetAddress);
		if (caffeStreetAddress != "") {
			String strCaffeStreetAddressLocator = getUILocator("caffe_street_address_in_caffe_page");
			Assert.assertNotNull(waitForElement(strCaffeStreetAddressLocator),
					"Failed to find the caffe street Address");
			Assert.assertTrue(typeText(strCaffeStreetAddressLocator, caffeStreetAddress));
		}

		String caffeCityAddress = (String) caffeDetail.get("city");
		log("caffeCityAddress"+ caffeCityAddress);
		if (caffeCityAddress != "") {
			String strCaffeCityLocator = getUILocator("caffe_city_field_caffe_info_page");
			Assert.assertNotNull(waitForElement(strCaffeCityLocator), "Failed to find the caffe City Address");
			Assert.assertTrue(typeText(strCaffeCityLocator, caffeCityAddress));
		}

		String caffeStateAddress = (String) caffeDetail.get("state");
		log("caffeStateAddress"+ caffeStateAddress);
		if (caffeStateAddress!=null || caffeStateAddress != "") {
			String strCaffeStateLocator = getUILocator("caffe_state_field_caffe_info_page");
			Assert.assertNotNull(waitForElement(strCaffeStateLocator), "Failed to find the caffe State Address");
			Assert.assertTrue(typeText(strCaffeStateLocator, caffeStateAddress));
		}

		String caffeZipCodeAddress = (String) caffeDetail.get("zip_code");
		log("caffeZipCodeAddress"+ caffeZipCodeAddress);
		if (caffeZipCodeAddress != "") {
			String strCaffeZipCodeLocator = getUILocator("caffe_zip_code_field_caffe_info_page");
			Assert.assertNotNull(waitForElement(strCaffeZipCodeLocator), "Failed to find the caffe ZipCode Address");
			Assert.assertTrue(typeText(strCaffeZipCodeLocator, caffeZipCodeAddress));
		}

		String caffeCountryAddress = (String) caffeDetail.get("country");
		log("caffeCountryAddress"+ caffeCountryAddress);
		if (caffeCountryAddress != "") {
			String strCaffeCountryLocator = getUILocator("caffe_country_field_caffe_info_page");
			Assert.assertNotNull(waitForElement(strCaffeCountryLocator), "Failed to find the caffe Country Address");
			Assert.assertTrue(typeText(strCaffeCountryLocator, caffeCountryAddress));
		}

		return this;
	}
	
	
	// Added by Chithra
	public MenuMakerApp verifyCaffeServingInCaffePage(JSONArray caffeDetails) {
		AppUtilities.delay(4000);
		for (Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject) i;
			String caffeName = (String) caffeDetail.get("select_caffe_location");
			String strCaffeNameInCaffeInfoPage = getUILocator("caffe_name_in_caffe_page")
					.replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", caffeName);

			scrollToElement(waitForElement(strCaffeNameInCaffeInfoPage));

			log("Scrolled to Station Name");

			Assert.assertNotNull(waitForElement(strCaffeNameInCaffeInfoPage),
					"Failed to find the caffe name in Caffe Info screen");

			// Validation of Caffe Serving Type in Caffe Info tab
			JSONArray servingDetails = (JSONArray) caffeDetail.get("serving_type");

			for (int j = 0; j < servingDetails.size(); j++) {
				String servingTypeData = servingDetails.get(j).toString();
				log("Validation for Caffe Serving Type option:" + servingTypeData);
				String caffe_Serving_Locator = getUILocator("serving_label_caffe_info_page");
				caffe_Serving_Locator = caffe_Serving_Locator.replaceAll("<REPLACE_TEXT>", servingTypeData);
				Assert.assertNotNull(waitForElement(caffe_Serving_Locator),
						"Failed to find the Caffe Serving in Caffe Info screen");
			}
			//Validation of Radio button Checked
			String caffe_Serving_Radio_Button = getUILocator("serving_radio_button_caffe_info_page");			
			List<WebElement> radioButtons = waitForElements(caffe_Serving_Radio_Button);
			
			for(int k=0;k<radioButtons.size();k++) {
				if(radioButtons.get(k).isSelected()) {
					log("Radio button is selected for "+servingDetails.get(k).toString());
					writeDataInRunStore("servingTypeSelectedCaffeInfoTab", servingDetails.get(k).toString());
				}
			}
		}

		return this;
	}

	public MenuMakerApp verifySaveButtonInCaffePage(JSONArray caffeDetails) {
		String teamData = "Created Test Caffe For Automation";
		for (Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject) i;
			String caffeTeam = (String) caffeDetail.get("Team");
			String strCaffeTeamLocator = getUILocator("caffe_team_field_in_caffe_page")
					.replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", caffeTeam);
			WebElement link = waitForElement(strCaffeTeamLocator);
			Point p = link.getLocation();
			((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 150) + ");");
			log("Brought the Team field into view");
			Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the Save button");
			AppUtilities.delay(4000);
			Assert.assertNotNull(waitForElement(strCaffeTeamLocator), "Failed to find the caffe Team");
			Assert.assertTrue(typeText(strCaffeTeamLocator, teamData), "Failed to type the text in team field");
			String strCaffeTeamLocator1 = getUILocator("caffe_team_field_in_caffe_page").replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", teamData);
			Assert.assertNotNull(waitForElement(strCaffeTeamLocator1),"Failed to find the team element");
		}
		log("Successfully validated save button Caffe page");
		return this;
	}
	
	public MenuMakerApp verifyDateAndTime() {
		 Calendar cal = Calendar.getInstance();
		 String timeNow = new SimpleDateFormat("MMMMM dd, hh:mm a").format(cal.getTime());
		 log("The date is: "+timeNow);
		 //String strDateTimeCaffeLocator = getUILocator("caffe_date_time_in_caffe_page");
		 WebElement strDateTimeCaffeLocator = waitForElement("caffe_date_time_in_caffe_page");
		 String dateTimeCaffeLocator = strDateTimeCaffeLocator.getText();
		 log("The time stamp is: "+dateTimeCaffeLocator);
		 boolean compareResult = dateTimeCaffeLocator.equalsIgnoreCase(timeNow);
		 Assert.assertTrue(compareResult);
		 log("Successfully validated Date and time in Caffe page");
		 return this;
	}
	
	public MenuMakerApp verifyAddSchedule() {
		//Updated to be more specific on Add Schedule
		//List<WebElement> myList_beforeNewSchedule=driver.findElements(By.className("selectpicker"));
		List<WebElement> myList_beforeNewSchedule=waitForElements("select_schedule_caffe_info_page");
		
		log("The list size for new station: "+myList_beforeNewSchedule.size());
		int schedulePresent = myList_beforeNewSchedule.size();
		int scheduleCountAfterAdd = schedulePresent-1;
		AppUtilities.delay(4000);
		String strScheduleAddButton = getUILocator("add_schedule_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		scrollToElement(waitForElement(strScheduleAddButton));
		Assert.assertTrue(clickElement(strScheduleAddButton), "Failed to click the Add schedule button");
		AppUtilities.delay(4000);
		List<WebElement> myList_afterNewSchedule=waitForElements("select_schedule_caffe_info_page");
		log("The list size after new station: "+myList_afterNewSchedule.size());
		Assert.assertTrue(myList_beforeNewSchedule.size()+1 == myList_afterNewSchedule.size(), "Failed to add new Schedule");
		AppUtilities.delay(2000);
		log("Successfully validated Add Schedule feature");
		return this;
	}
	
	public MenuMakerApp verifyScheduleNameMandatory() {
		Assert.assertNotNull(waitForElement("schedule_name_required_in_caffe_page"), "Failed to find the schedule name mandatory text");
		log("Successfully validated Schedule Name Mandatory message");
		return this;
	}
	
	public MenuMakerApp verifySaveSchedule() {
		List<WebElement> myList_afterNewStation=driver.findElements(By.xpath("//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'selectedCafeeServesMealTime')]"));
		//List<String> allStations_afterNewStation=new ArrayList<>();
		log("The list size after new station: "+myList_afterNewStation.size());
		int schedulePresent = myList_afterNewStation.size();
		int scheduleCountAfterAdd = schedulePresent-1;
		String scheduleName = "Automation"+(schedulePresent);
		String strScheduleNameFieldLocator = getUILocator("schedule_name_field_dropdown_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(clickElement(strScheduleNameFieldLocator), "Failed to click the Schedule name field");
		AppUtilities.delay(5000);
		String strScheduleNameOptionLocator = getUILocator("schedule_name_dropdown_othersoption_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(clickElement(strScheduleNameOptionLocator),"Failed to click Others option");
		Assert.assertTrue(clickElement(strScheduleNameOptionLocator),"Failed to click Others option");
		AppUtilities.delay(3000);
		String strScheduleOtherFieldLocator = getUILocator("schedule_name_other_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(typeText(strScheduleOtherFieldLocator, scheduleName), "Unable to enter text in Schedule others field");
		//String strScheduleWeekDaysLocator = getUILocator("schedule_weekdays_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		//WebElement strScheduleWeekDays = waitForElement(strScheduleWeekDaysLocator);
		String strScheduleStartTimeLocator = getUILocator("schedule_start_time_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(typeText(strScheduleStartTimeLocator, "10:00 am"),"Failed to type the start time in schedule");
		String strScheduleEndTimeLocator = getUILocator("schedule_end_time_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(typeText(strScheduleEndTimeLocator, "05:00 pm"),"Failed to type the end time in schedule");
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the save button");
		AppUtilities.delay(10000);
		String strScheduleNameFieldLocatorAftersave = getUILocator("schedule_name_field_aftersave_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_NAME>", scheduleName);
		Assert.assertNotNull(waitForElement(strScheduleNameFieldLocatorAftersave), "Failed to save Schedule");
		log("The schedule is found");
		AppUtilities.delay(7000);
		log("Successfully validated save schedule");
		return this;
	}
	
	public MenuMakerApp verifySaveScheduleCaffeinfo(JSONArray caffeDetails) {
		for(Object i : caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			
			String startTime = (String) caffeDetail.get("schedule_start_time");
			String endTime = (String) caffeDetail.get("schedule_end_time");
			
			//List<WebElement> myList_afterNewStation=driver.findElements(By.xpath("//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'selectedCafeeServesMealTime')]"));
			List<WebElement> myList_afterNewStation=waitForElements("select_schedule_caffe_info_page");
			
			//List<String> allStations_afterNewStation=new ArrayList<>();
			log("The list size after new station: "+myList_afterNewStation.size());
			int schedulePresent = myList_afterNewStation.size();
			int scheduleCountAfterAdd = schedulePresent-1;
			String scheduleName = "Automation"+(schedulePresent);
			String strScheduleNameFieldLocator = getUILocator("schedule_name_field_dropdown_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
			Assert.assertTrue(clickElement(strScheduleNameFieldLocator), "Failed to click the Schedule name field");
			AppUtilities.delay(5000);
			String strScheduleNameOptionLocator = getUILocator("schedule_name_dropdown_othersoption_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
			Assert.assertTrue(clickElement(strScheduleNameOptionLocator),"Failed to click Others option");
			Assert.assertTrue(clickElement(strScheduleNameOptionLocator),"Failed to click Others option");
			AppUtilities.delay(3000);
			String strScheduleOtherFieldLocator = getUILocator("schedule_name_other_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
			Assert.assertTrue(typeText(strScheduleOtherFieldLocator, scheduleName), "Unable to enter text in Schedule others field");
			//Selecting week days in a week
			String strScheduleWeekDaysLocator = getUILocator("schedule_weekdays_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
			Assert.assertTrue(clickElement(strScheduleWeekDaysLocator), "Failed to click Monday field in Schedule");
			String strScheduleWeekDays2Locator = getUILocator("schedule_weekdays2_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
			Assert.assertTrue(clickElement(strScheduleWeekDays2Locator), "Failed to find Tuesday field in Schedule");
			String strScheduleWeekDays3Locator = getUILocator("schedule_weekdays3_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
			Assert.assertTrue(clickElement(strScheduleWeekDays3Locator), "Failed to find Wednesday field in Schedule");
			String strScheduleWeekDays4Locator = getUILocator("schedule_weekdays4_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
			Assert.assertTrue(clickElement(strScheduleWeekDays4Locator), "Failed to find Thursday field in Schedule");
			String strScheduleWeekDays5Locator = getUILocator("schedule_weekdays5_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
			Assert.assertTrue(clickElement(strScheduleWeekDays5Locator), "Failed to find Friday field in Schedule");
			
			
			String strScheduleStartTimeLocator = getUILocator("schedule_start_time_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
			Assert.assertTrue(typeText(strScheduleStartTimeLocator, startTime),"Failed to type the start time in schedule");
			String strScheduleEndTimeLocator = getUILocator("schedule_end_time_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
			Assert.assertTrue(typeText(strScheduleEndTimeLocator, endTime),"Failed to type the end time in schedule");
			Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the save button");
			AppUtilities.delay(10000);
			String strScheduleNameFieldLocatorAftersave = getUILocator("schedule_name_field_aftersave_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_NAME>", scheduleName);
			Assert.assertNotNull(waitForElement(strScheduleNameFieldLocatorAftersave), "Failed to save Schedule");
			log("The schedule is found");
			AppUtilities.delay(7000);
			log("Successfully validated save schedule");
			
		}
		
		return this;
	}
	
	public MenuMakerApp verifyDaysFieldSchedule() {
		List<WebElement> myList_afterNewStation=driver.findElements(By.xpath("//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'selectedCafeeServesMealTime')]"));
		//List<String> allStations_afterNewStation=new ArrayList<>();
		log("The list size after new station: "+myList_afterNewStation.size());
		int schedulePresent = myList_afterNewStation.size();
		int scheduleCountAfterAdd = schedulePresent-1;
		String strScheduleWeekDaysLocator = getUILocator("schedule_weekdays_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(clickElement(strScheduleWeekDaysLocator), "Failed to find Weekdays field in Schedule");
		log("Sucessfully validated days field in schedule");
		return this;
	}
	
	public MenuMakerApp verifyTimeFieldSchedule() {
		List<WebElement> myList_afterNewStation=driver.findElements(By.xpath("//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'selectedCafeeServesMealTime')]"));
		//List<String> allStations_afterNewStation=new ArrayList<>();
		log("The list size after new station: "+myList_afterNewStation.size());
		int schedulePresent = myList_afterNewStation.size();
		int scheduleCountAfterAdd = schedulePresent-1;
		String strScheduleWeekDaysLocator = getUILocator("schedule_weekdays_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(clickElement(strScheduleWeekDaysLocator), "Failed to find Weekdays field in Schedule");
		String strScheduleStartTimeLocator = getUILocator("schedule_start_time_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		//Commented by Chithra
		/*Assert.assertTrue(typeText(strScheduleStartTimeLocator, "10:00 a"),"Failed to type the start time in schedule");
		//Validating the error message when not provided proper time
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the save button");
		AppUtilities.delay(3000);
		Assert.assertNotNull(waitForElement("schedule_proper_time_mess_in_caffe_page"), "Failed to find the error message");
		*/
		Assert.assertTrue(typeText(strScheduleStartTimeLocator, "10:00 am"),"Failed to type the start time in schedule");
		String strScheduleEndTimeLocator = getUILocator("schedule_end_time_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(typeText(strScheduleEndTimeLocator, "05:00 pm"),"Failed to type the end time in schedule");
		log("Sucessfully validated time field in schedule");
		return this;
	}
	
	public MenuMakerApp verifyStartEndSchedule() {
		List<WebElement> myList_afterNewStation=driver.findElements(By.xpath("//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'selectedCafeeServesMealTime')]"));
		//List<String> allStations_afterNewStation=new ArrayList<>();
		log("The list size after new station: "+myList_afterNewStation.size());
		int schedulePresent = myList_afterNewStation.size();
		int scheduleCountAfterAdd = schedulePresent-1;
		String strScheduleWeekDaysLocator = getUILocator("schedule_weekdays_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(clickElement(strScheduleWeekDaysLocator), "Failed to find Weekdays field in Schedule");
		String strScheduleStartTimeLocator = getUILocator("schedule_start_time_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(typeText(strScheduleStartTimeLocator, "10:00 pm"),"Failed to type the start time in schedule");
		String strScheduleEndTimeLocator = getUILocator("schedule_end_time_field_in_caffe_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(scheduleCountAfterAdd));
		Assert.assertTrue(typeText(strScheduleEndTimeLocator, "5:00 pm"),"Failed to type the end time in schedule");
		//Validating the error message when not provided proper time
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the save button");
		AppUtilities.delay(3000);
		Assert.assertNotNull(waitForElement("schedule_proper_time_mess_in_caffe_page"), "Failed to find the error message");
		log("Sucessfully validated the start and end time in schedule");
		return this;
	}
	
	public MenuMakerApp validateDefaultPriceFieldNewStation() {
		//Display order after adding a station
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		int stationsAfterAdd = stationsAvailable();
		int stationCountAfterAdd = stationsAfterAdd-1;
		String strStationPriceFieldLocatorAfterAdd = getUILocator("station_default_price_in_station_page").replaceAll("<REPLACE_DEFAULTPRICE_ID>", Integer.toString(stationCountAfterAdd));
		//WebElement StationPriceFieldLocatorAfterAdd = waitForElement(strStationPriceFieldLocatorAfterAdd);
		Assert.assertTrue(typeText(strStationPriceFieldLocatorAfterAdd, "3.00"), "Failed to type default price");
		log("The default price is generated correctly for new station");
		return this;
	}
	
	public MenuMakerApp checkStationPriceFieldMandatory() {
		AppUtilities.delay(4000);
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		//Number of stations
		int stationsAfterAdd = stationsAvailable();
		int stationCount = stationsAfterAdd-1;
		String strStationNameFieldLocator = getUILocator("station_default_price_in_station_page").replaceAll("<REPLACE_DEFAULTPRICE_ID>", Integer.toString(stationCount)); 
		Assert.assertTrue(clickElement(strStationNameFieldLocator), "Failed to click Price field ");
		
		//Validating the mandatory message
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement("station_price_mandatory_validation_in_station_page"), "Failed to find the mandatory message for price");
		log("Successfully validated Station price field mandatory");
		return this;
	}

	public MenuMakerApp verifySaveButton() {
		int stationsBeforeAdd = stationsAvailable();
		log("Entering station name: ");
		validateNameFieldNewStation();
		int stationsAfterAdd = stationsAvailable();
		int stationCount = stationsAfterAdd-1;
		String strStationPriceFieldLocatorAfterAdd = getUILocator("station_default_price_in_station_page").replaceAll("<REPLACE_DEFAULTPRICE_ID>", Integer.toString(stationCount));
		//WebElement StationPriceFieldLocatorAfterAdd = waitForElement(strStationPriceFieldLocatorAfterAdd);
		Assert.assertTrue(typeText(strStationPriceFieldLocatorAfterAdd, "3.00"), "Failed to type default price");
		log("The default price is generated correctly for new station");
		
		String activate = getUILocator("station_active_inactive_cb_station_page1");
		activate = activate.replaceAll("<REPLACE_ACTIVE_ID>", Integer.toString(stationCount));
		WebElement actCheckBox = waitForElement(activate);
		String checkBoxSelection= null;
		checkBoxSelection= actCheckBox.getAttribute("checked");
		//log(checkBoxSelection);
		if (checkBoxSelection == null)
		{
		Assert.assertTrue(clickElement(activate), "Failed to click active button for the Station");
		//log("The station:" + select_station + " has been activated");
		}
		
		String scheduleTime  = "xpath=//input[contains(@id, 'mealtype-"+Integer.toString(stationCount)+"')]";
		List <WebElement> schedule = waitForElements(scheduleTime);
		
		for (WebElement e: schedule){
			e.click();
		}
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the Save button in station page");
		AppUtilities.delay(4000);
		if (stationsAfterAdd == stationsBeforeAdd+1) {
			Assert.assertTrue(true);
		}
		log("Successfully validated save button");
		return this;
	}
	
	public MenuMakerApp checkActiveStationAndSave(JSONArray caffeDetails) {
		
		JSONObject caffeDetail = (JSONObject) caffeDetails.get(0);
		String select_station = (String)caffeDetail.get("select_station");
		
		String strStation = getUILocator("station_select_station_in_station_page");
		strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		Assert.assertTrue(clickElement(strStation), "Failed to click the Station:" + select_station);
		log("The station:" + select_station + " has been selected");
		AppUtilities.delay(2000);
		
		String activate = getUILocator("station_active_inactive_cb_station_page");
		activate = activate.replaceAll("<REPLACE_STATION_ID>", stationId);
		WebElement actCheckBox = waitForElement(activate);
		String checkBoxSelection= null;
		checkBoxSelection= actCheckBox.getAttribute("checked");
		//log(checkBoxSelection);
		if (checkBoxSelection == null)
		{
		Assert.assertTrue(clickElement(activate), "Failed to click active button for the Station");
		log("The station:" + select_station + " has been activated");
		}
		
		
		
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to save the station page");
	//	Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
		AppUtilities.delay(3000);
		/*Assert.assertTrue(clickElement("menu_page"));
		
		Existing:
		verifySaveButton();
		int stationsAfterAdd = stationsAvailable();
		int stationsCount = stationsAfterAdd-1;
		String strStationActiveFieldLocator = getUILocator("station_active_inactive_in_station_page").replaceAll("<REPLACE_ACTIVE_ID>", Integer.toString(stationsCount)); 
		Assert.assertTrue(clickElement(strStationActiveFieldLocator), "Failed to click the Active checkbox");
		WebElement stationActiveFieldLocator = waitForElement(strStationActiveFieldLocator);
		boolean stationActiveFieldValue = stationActiveFieldLocator.isSelected();
		Assert.assertTrue(stationActiveFieldValue);*/
		log("Successfully activated station and save");
		return this;
	}
	
	public MenuMakerApp checkInactiveStationAndSave(String select_station) {
		
		//String select_station = (String)caffeDetail.get("select_station");
		
		String strStation = getUILocator("station_select_station_in_station_page");
		strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		log("In Function");
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		Assert.assertTrue(clickElement(strStation), "Failed to click the Station:" + select_station);
		log("The station:" + select_station + " has been selected");
		AppUtilities.delay(2000);
		
		String activate = getUILocator("station_active_inactive_cb_station_page");
		activate = activate.replaceAll("<REPLACE_STATION_ID>", stationId);
		WebElement actCheckBox = waitForElement(activate);
		String checkBoxSelection= null;
		checkBoxSelection= actCheckBox.getAttribute("checked");
		//log(checkBoxSelection);
		if (checkBoxSelection != null)
		{
		Assert.assertTrue(clickElement(activate), "Failed to click active button for the Station");
		log("The station:" + select_station + " has been activated");
		}
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to save the station page");
		//Assert.assertNotNull(waitForElement("customize_food_item_save_status"));
		
		/*Existing: 
		verifySaveButton();
		int stationsAfterAdd = stationsAvailable();
		int stationsCount = stationsAfterAdd-1;
		String strStationActiveFieldLocator = getUILocator("station_active_inactive_in_station_page").replaceAll("<REPLACE_ACTIVE_ID>", Integer.toString(stationsCount)); 
		Assert.assertTrue(clickElement(strStationActiveFieldLocator), "Failed to click the Active checkbox");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement(strStationActiveFieldLocator), "Failed to click the Active checkbox");
		WebElement stationActiveFieldLocator = waitForElement(strStationActiveFieldLocator);
		boolean stationActiveFieldValue = stationActiveFieldLocator.isSelected();
		Assert.assertFalse(stationActiveFieldValue);*/
		log("Successfully inactivated station and save");
		return this;
	}
	
	public MenuMakerApp checkUploadingImageStation(JSONArray caffeDetails) {
		AppUtilities.delay(4000);
		//highlightSafari();
		Assert.assertTrue(clickElement("station_add_button_in_station_page"), "Failed to click Add station Button");
		AppUtilities.delay(4000);
		//Number of stations
		int stationsAfterAdd = stationsAvailable();
		int stationCount = stationsAfterAdd-1;
		String strStationImageBtnLocator = getUILocator("station_upload_image_in_station_page").replaceAll("<REPLACE_IMAGE_BTN_ID>", Integer.toString(stationCount)); 
		Assert.assertTrue(clickElement(strStationImageBtnLocator), "Failed to click Price field ");
		AppUtilities.delay(4000);
		for (Object i : caffeDetails) {
			JSONObject foodItem = (JSONObject)i;
			String strImageFilePath = (String)foodItem.get("food_item_image_path");
			log("The image path is: "+strImageFilePath);
			if(StringUtils.isBlank(strImageFilePath)) {
				log("Image file path is not configured for this food item. Ignoring the file upload");
				return this;
			}
			log("Checking availability of the given file:" + strImageFilePath);
			
			strImageFilePath = strBaseDir + strImageFilePath; 
			
			log(strImageFilePath);
			
			File f = new File(strImageFilePath);
			
			if(! (f.exists() && f.isFile())) {
				strImageFilePath = strBaseDir + File.separator + strImageFilePath;
				log("File doesnt exist. Checking with the framework base dir:" + strImageFilePath);
				f = new File(strImageFilePath);
			}
			Assert.assertTrue(f.exists() && f.isFile(), "Failed to check the given image file");
			AppUtilities.delay(2000);
			
			StringSelection selection = new StringSelection(strImageFilePath);
		    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
		    clipboard.setContents(selection, selection);
			log("data has been copied to clipboard");
		
			//keyboard.type(Key.CMD + Key.SHIFT + "g");
			
			
			r.keyPress(KeyEvent.VK_META);
			r.keyPress(KeyEvent.VK_SHIFT);
			r.keyPress(KeyEvent.VK_G);
			AppUtilities.delay(500);
			r.keyRelease(KeyEvent.VK_G);
			r.keyRelease(KeyEvent.VK_SHIFT);
			r.keyRelease(KeyEvent.VK_META);
			
			
			log("CMD + SHIFT key has been clicked");
			AppUtilities.delay(5000);
			
			keyboard.paste(strImageFilePath);
			
			log("Paste action has been simulated");

			
			keyboard.type(Key.ENTER);
			log("Simulated Enter #1");
			
			AppUtilities.delay(2000);
			

			keyboard.type(Key.ENTER);
			log("Simualted Enter #2");
			AppUtilities.delay(10000);
			
		}
		log("Successfully uploaded image to Station");
		return this;
	}
	
	public MenuMakerApp verifyCaffeAccessLeadChef() {
		Assert.assertTrue(clickElement("caffe_page"), "Failed to click Caffe option");
		AppUtilities.delay(10000);
		Assert.assertNotNull(waitForElement("lead_chef_noaccess_mess_in_caffe_page"), "Lead chef have access to caffe page");
		return this;
	}
	
	public MenuMakerApp verifyCaffeAccessSuperAdmin() {
		//Assert.assertTrue(clickElement("caffe_page"), "Failed to click Caffe option");
		//AppUtilities.delay(10000);
		//Assert.assertTrue(clickElement("caffe_info_page"), "Failed to click Info option");
		AppUtilities.delay(2000);
		JDBCUtil myConn = new JDBCUtil();
		myConn.CreateConn();
		List<String> caffeName=myConn.getAllCaffe();
		myConn.CloseConn();
		log("The caffe list is: "+caffeName);
		/*
		while(rs.next()){
			 CaffeName.add(rs.getString(1));
		     } 
		} catch (SQLException e) {
		
		e.printStackTrace();
		}
	 
	 	Iterator<String> itr = CaffeName.iterator();
       	while(itr.hasNext()){
           System.out.println(itr.next());
       	}
		 */
		List<WebElement> myList_afterNewStation=driver.findElements(By.xpath("//ul[contains(@class, 'caffes-drop-down-list')]//li[contains(@ng-repeat, 'Caffes')]//a[contains(@class, 'ng-binding')]"));
		List<String> allStations_afterNewStation=new ArrayList<String>();
		log("The list size after new station: "+myList_afterNewStation.size());
		for(int k=0; k<myList_afterNewStation.size(); k++){
			allStations_afterNewStation.add(myList_afterNewStation.get(k).getText());
			System.out.println(myList_afterNewStation.get(k).getText());
			}
		
		log("The caffe list from caffe page is:"+allStations_afterNewStation);
		return this;
	}
	
	public MenuMakerApp verifyScheduleInStationsPage(JSONArray caffeDetails) {
		
		List<WebElement> myList_afterNewStation=driver.findElements(By.xpath("//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'selectedCafeeServesMealTime')]"));
		int schedulePresent = myList_afterNewStation.size();
		//int scheduleCountAfterAdd = schedulePresent-1;
		log("The size of the schedule is: "+schedulePresent);
		JSONObject caffeDetail = (JSONObject) caffeDetails.get(0);
		log(caffeDetail.toJSONString());
		navigateToStationPage(caffeDetails);
		String stationNameValue = (String) caffeDetail.get("select_station");
		String strStation = getUILocator("station_name_left_pane_in_station_page").replaceAll("<REPLACE_STATION_NAME>", stationNameValue);
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		log("The station id is: "+stationId);
		navigateToStationPage(caffeDetails);
		String strScheduleStationLocator = getUILocator("schedule_in_station_page").replaceAll("<REPLACE_STATION_ID>", stationId);
		String strScheduleStation = strScheduleStationLocator.replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(schedulePresent));
		Assert.assertNotNull(waitForElement(strScheduleStation), "Failed to find the Schedule in Station page");
		log("Sucessfully validated schedule in stations page");
		return this;
	}
	
	private void changeCaffeDetail(String configureStationName, String orignalStationName, String caffeName){
		
		AppUtilities.delay(5000);

		JDBCUtil changeCaffeName = new JDBCUtil();

		try {

			changeCaffeName.getPropValues();

			changeCaffeName.CreateConn();

			changeCaffeName.changeCaffeName(configureStationName, orignalStationName, caffeName);
			
			log("Modified station name"+ configureStationName);

		} catch (IOException e) {

		log("Exception occured while updating JDBC Call"+e);

		}

	}
	
	public MenuMakerApp modifyStationName(JSONArray caffeDetails, String changeName) {
				
				JSONObject caffeDetail = (JSONObject)caffeDetails.get(0);
				//navigateToStation(caffeDetail);
				String caffe = (String)caffeDetail.get("select_caffe_location");
				String station = (String) caffeDetail.get("station");
				String select_station = (String)caffeDetail.get("modify_station");
				String scheduleforTime = (String)caffeDetail.get("food_for");
				if (scheduleforTime.equals("lunch")){
					scheduleforTime= "Lunch";
				}
				
				String strStation = getUILocator("station_select_station_in_station_page");
				
				changeCaffeDetail(select_station, station, caffe);
				AppUtilities.delay(5000);
				
				Assert.assertNotNull(navigateToStationPage(caffeDetails), "Failed to navigate to station page");
				strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
				
				WebElement e = waitForElement(strStation);
				
				String stationId = e.getAttribute("target-elm-id");

				Assert.assertTrue(clickElement(strStation), "Failed to click the Station:" + select_station);
				log("The station:" + select_station + " has been selected");
				AppUtilities.delay(2000);
				
				String stationName = getUILocator("station_name_field_in_station_page");
				stationName = stationName.replaceAll("<REPLACE_STATION_ID>", stationId);
				Assert.assertTrue(typeText(stationName,changeName ), "Failed to Enter the New Station Name");
				Assert.assertNotNull(activateScheduleSave(select_station,stationId, scheduleforTime), "Failed to activate station");

				return this;
	
	}
	
 	public MenuMakerApp verifyRemoveSchedule() {
 		//navigateToCaffePage(caffeDetails);
 		
 		//Discard changes
 		Assert.assertTrue(clickElement("station_cancel_button_in_station_page"), "Failed to click cancel button");
 		Assert.assertTrue(clickElement("caffe_page"), "Failed to navigate to Caffe Page");
 		Assert.assertTrue(clickElement("caffe_info_page"), "Failed to click Caffe Info option");
		AppUtilities.delay(5000);
		List<WebElement> myList_afterNewStation=driver.findElements(By.className("selectpicker"));
		log("The list size after new station: "+myList_afterNewStation.size());
		int 	index = myList_afterNewStation.size()-1;
		Select select = new Select(myList_afterNewStation.get(index));
		String schduleToDelete = select.getFirstSelectedOption().getText(); 			
		if(schduleToDelete.contains("Automation")) {	
			Assert.assertTrue(clickElement("schedule_label_in_caffe_page"), "Failed to find the schedule");
			String strRemoveSchedule = getUILocator("remove_schedule_in_caffe_page").replaceAll("<REPLACE_INDEX_ID>", Integer.toString(index));
			AppUtilities.delay(4000);
			Assert.assertTrue(clickElement(strRemoveSchedule), "Failed to click the remove button");
			AppUtilities.delay(4000);	
			Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the save button");
			AppUtilities.delay(4000);
			log("Sucessfully validated remove schedule");
		}
		
		
		//Commented by Chithra
		/*for(int k=0; k<myList_afterNewStation.size(); k++){
			
			allStations_afterNewStation.add(myList_afterNewStation.get(k).getText());
			System.out.println(myList_afterNewStation.get(k).getText());
			String text1 = myList_afterNewStation.get(k).getText();
			String text2 = "Automation"+(myList_afterNewStation.size())+'\n'+"Others";
			log("The Automation text is:"+"Automation"+(myList_afterNewStation.size()));
			if (text1.equalsIgnoreCase(text2)) {
				log("The index where Added schedule found is: "+k);
				index = k;
			}
			else {
				log("The index is not found");
			}
		}
			Assert.assertTrue(clickElement("schedule_label_in_caffe_page"), "Failed to find the schedule");
			String strRemoveSchedule = getUILocator("remove_schedule_in_caffe_page").replaceAll("<REPLACE_INDEX_ID>", Integer.toString(index));
			AppUtilities.delay(4000);
			Assert.assertTrue(clickElement(strRemoveSchedule), "Failed to click the remove button");
			AppUtilities.delay(4000);
			Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click the save button");
			AppUtilities.delay(4000);
			log("Sucessfully validated remove schedule");*/
		return this;
	}
	
	public MenuMakerApp verifyScheduleRemoveInStationsPage(JSONArray caffeDetails) {
		List<WebElement> myList_afterNewStation=driver.findElements(By.xpath("//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'selectedCafeeServesMealTime')]"));
		int schedulePresent = myList_afterNewStation.size();
		//int scheduleCountAfterAdd = schedulePresent;
		log("The size of the schedule is: "+schedulePresent);
		navigateToStationPage(caffeDetails);
		AppUtilities.delay(7000);
		String strScheduleStation = getUILocator("schedule_in_station_page").replaceAll("<REPLACE_SCHEDULE_ID>", Integer.toString(schedulePresent));
		log("The schedule object is: "+strScheduleStation);
		Assert.assertNull(waitForElement(strScheduleStation), "Schedule is not removed");
		log("Sucessfully validated schedule after remove in stations page");
		return this;
	}
	
	public MenuMakerApp verifyScheduleCheckStationsPage(JSONArray caffeDetails) {
		navigateToStationPage(caffeDetails);
		int scheduleCountAfterAdd = stationsAvailable()-1;
		String stationNameId = "station-"+(scheduleCountAfterAdd);
		String strStation1 = getUILocator("station_name_field_in_station_page").replaceAll("<REPLACE_STATION_ID>", stationNameId);
		WebElement stationName = waitForElement(strStation1);
		String stationNameValue = stationName.getAttribute("value");
		log("The station name is: "+stationNameValue);
		//strStation = strStation.replaceAll("<REPLACE_STATION_NAME>", select_station);
		String strStation = getUILocator("station_name_left_pane_in_station_page").replaceAll("<REPLACE_STATION_NAME>", stationNameValue);
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		log("The station id is: "+stationId);
		log("The path is //div[contains(@id," +stationId +")]//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'mealsList')]");
		List<WebElement> myList_afterNewSchedule1=driver.findElements(By.xpath("//div[contains(@id, '" +stationId +"')]//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'mealsList')]"));
		log("The list size after new station: "+myList_afterNewSchedule1.size());
	
		String scheduleforTime = "Automation"+Integer.toString(myList_afterNewSchedule1.size()-1);
		log("The schedule object is: "+scheduleforTime);
		String schedule = getUILocator("schedule_section_station_page");
		schedule = schedule.replaceAll("<REPLACE_STATION_ID>", stationId);
		String mealIdCheckBox = getUILocator("schedule_stations_page");
		String mealIdLabel= getUILocator("schedule_labels_station_page");
		log("I am here3");
		List<WebElement> list = waitForElements(schedule, 20);
		
		if(list == null || list.size() <= 0) {
			log("No schedule found in the list.");
			return this;
		}
		log("No. of schedules:" + list.size());
	
		int count = list.size();
		log("Total number of schedule in the station found as:" + count);
		
		HashMap <String,String> scheduleTime = new HashMap<String,String>();
		
		for(WebElement s : list) {
				
				WebElement MealId= s.findElement(By.xpath(mealIdCheckBox));
				WebElement MealName= s.findElement(By.xpath(mealIdLabel));
				String scheduleMealId = MealId.getAttribute("id");
				log("The meal id is: "+scheduleMealId);
				String scheduleMealName = MealName.getText();
				log("Found the schedule id:"+ scheduleMealId+ " of the Meal Name:" +scheduleMealName);
				scheduleTime.put(scheduleMealName, scheduleMealId);
		}
		
		int noOfSchedules = scheduleTime.size();
		log(Integer.toString(noOfSchedules));
		
		log (scheduleTime.toString());
		
		String scheduleForId = scheduleTime.get(scheduleforTime);
		log("The station id is: "+stationId);
		log("The schedule id is: "+scheduleForId);
		String scheduleId = getUILocator("schedule_id_station_page");	
		scheduleId = scheduleId.replaceAll("<REPLACE_STATION_ID>", stationId);
		scheduleId = scheduleId.replaceAll("<REPLACE_SCHEDULE_ID>",scheduleForId);
		Assert.assertTrue(clickElement(scheduleId), "Failed to save the station page");
		AppUtilities.delay(10000);
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click save button");
	
		return this;
	}
	
	
	public MenuMakerApp validateScheduleInCaffePage(JSONArray caffeDetails) {
		navigateToStationPage(caffeDetails);
		JSONObject caffeDetail = (JSONObject) caffeDetails.get(0);
		log(caffeDetail.toJSONString());
		String stationNameValue = (String) caffeDetail.get("select_station");
		String strStation = getUILocator("station_name_left_pane_in_station_page").replaceAll("<REPLACE_STATION_NAME>", stationNameValue);
		WebElement e = waitForElement(strStation);
		String stationId = e.getAttribute("target-elm-id");
		log("The station id is: "+stationId);
		log("The path is //div[contains(@id," +stationId +")]//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'mealsList')]");
		List<WebElement> myList_afterNewSchedule1=driver.findElements(By.xpath("//div[contains(@id, '" +stationId +"')]//div[contains(@class, 'ng-scope') and contains(@ng-repeat, 'mealsList')]"));
		log("The list size after new station: "+myList_afterNewSchedule1.size());
	
		String scheduleforTime = "Automation"+Integer.toString(myList_afterNewSchedule1.size());
		log("The schedule object is: "+scheduleforTime);
		String schedule = getUILocator("schedule_section_station_page");
		schedule = schedule.replaceAll("<REPLACE_STATION_ID>", stationId);
		String mealIdCheckBox = getUILocator("schedule_stations_page").replaceAll("<REPLACE_STATION_ID>", stationId);
		String mealIdLabel= getUILocator("schedule_labels_station_page").replaceAll("<REPLACE_STATION_ID>", stationId);
		log("I am here3");
		List<WebElement> list = waitForElements(schedule, 20);
		
		if(list == null || list.size() <= 0) {
			log("No schedule found in the list.");
			return this;
		}
		log("No. of schedules:" + list.size());
	
		int count = list.size();
		log("Total number of schedule in the station found as:" + count);
		
		HashMap <String,String> scheduleTime = new HashMap<String,String>();
		
		for(WebElement s : list) {
				
				WebElement MealId= s.findElement(By.xpath(mealIdCheckBox));
				WebElement MealName= s.findElement(By.xpath(mealIdLabel));
				String scheduleMealId = MealId.getAttribute("id");
				log("The meal id is: "+scheduleMealId);
				String scheduleMealName = MealName.getText();
				log("Found the schedule id:"+ scheduleMealId+ " of the Meal Name:" +scheduleMealName);
				scheduleTime.put(scheduleMealName, scheduleMealId);
		}
		
		int noOfSchedules = scheduleTime.size();
		log(Integer.toString(noOfSchedules));
		
		log (scheduleTime.toString());
		
		String scheduleForId = scheduleTime.get(scheduleforTime);
		log("The station id is: "+stationId);
		log("The schedule id is: "+scheduleForId);
		String scheduleId = getUILocator("schedule_id_station_page");	
		scheduleId = scheduleId.replaceAll("<REPLACE_STATION_ID>", stationId);
		scheduleId = scheduleId.replaceAll("<REPLACE_SCHEDULE_ID>",scheduleForId);
		Assert.assertTrue(clickElement(scheduleId), "Failed to save the station page");
		AppUtilities.delay(10000);
		Assert.assertTrue(clickElement("station_save_button_in_station_page"), "Failed to click save button");
		log("Sucessfully validated schedule in caffe page");
		return this;
	}
	public MenuMakerApp verifyStationInSchedule(JSONArray caffeDetails) {
		//getting the station name
		String aCaffeLocation = null;
		for (Object i: caffeDetails) {
			JSONObject caffeDetail = (JSONObject)i;
			aCaffeLocation = (String)caffeDetail.get("select_caffe_location");
		}
		int scheduleCountAfterAdd = stationsAvailable()-1;
		String stationNameId = "station-"+scheduleCountAfterAdd;
		String strStation1 = getUILocator("station_name_field_in_station_page").replaceAll("<REPLACE_STATION_ID>", stationNameId);
		WebElement stationName = waitForElement(strStation1);
		String stationNameValue = stationName.getAttribute("value");
		log("The station name is: "+stationNameValue);
		Assert.assertTrue(clickElement("menu_page"), "Failed to click Menu tab");
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("variable_meal_time"), "Failed to click the variable meal time link");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("current_caffe_location"), "Failed to click the Caffe Location menu");
		String cafeLocation = getUILocator("select_cafe_by_name");
		cafeLocation = cafeLocation.replaceAll("<REPLACE_CAFFE_LOCATION_NAME>", aCaffeLocation);
		Assert.assertTrue(clickElement(cafeLocation), "Failed to choose the caffe location");
		AppUtilities.delay(2000);
		String strStationNameLeftPaneLocator = getUILocator("select_station_left_side").replaceAll("<REPLACE_STATION_NAME>", stationNameValue);
		Assert.assertNotNull(waitForElement(strStationNameLeftPaneLocator), "Failed to find the element");
		AppUtilities.delay(10000);
		return this;
	}
	
	
	public MenuMakerApp verifyDefaultPriceMenuTab() {
		int stationsAfterAdd = stationsAvailable();
		int stationCountAfterAdd = stationsAfterAdd-1;
		String strStationPriceFieldLocatorAfterAdd = getUILocator("station_default_price_in_station_page").replaceAll("<REPLACE_DEFAULTPRICE_ID>", Integer.toString(stationCountAfterAdd));
		WebElement stationPriceFieldLocatorAfterAdd = waitForElement(strStationPriceFieldLocatorAfterAdd);
		String priceFromStationPage = stationPriceFieldLocatorAfterAdd.getAttribute("value"); 
		log("The default price is: "+priceFromStationPage);
		Assert.assertTrue(clickElement("lunch_meal_time"), "Failed to click lunch ");
		//String strAddDishLink = getUILocator("add_dish_link");
		//strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);
		
		//Assert.assertTrue(clickElement(strAddDishLink), "Failed to click Add Dish on the selected Station:" + select_station);
		log("Clicked on Add Dish link");
		AppUtilities.delay(2000);
		return this;
	}
	
	public MenuMakerApp createVouchers(JSONArray voucherDetails, String empName){
		
		Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		for (Object voucher: voucherDetails){
			JSONObject voucherDetail = (JSONObject) voucher;
			Assert.assertNotNull(createVoucher(voucherDetail,empName), "Failed to create voucher with details"+voucherDetails.toString());
		}
		Assert.assertNotNull(saveVoucher(),"Failed to save voucher");
		Assert.assertNotNull(submitVoucher(),"Failed to submit the voucher");
		
		Assert.assertTrue(clickElement("myrequest_tab_voucher_page"),"Failed to click on my Request page");
		log("Successfully created vouchers");
		return this;
	}

	private MenuMakerApp createVoucher(JSONObject voucherDetail, String empName) {
		
		Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
		String voucherType = (String) voucherDetail.get("voucher_type");
		
		if (voucherType.equals("meal voucher"))
		{
			voucherTypeToSelect = "0";
			voucherTypeInTest = "Meal Voucher";
			Assert.assertNotNull(createMealVouchers(voucherDetail,empName),"Failed to create Meal voucher with details" +voucherDetail.toString());
			Assert.assertTrue(waitForElementWithText("quantity_voucher_page", Integer.toString(totalVoucherQuantity)), "Failed to find the Total quantity");
			Assert.assertTrue(waitForElementWithText("totals_voucher_page", Integer.toString(totalVoucherAmount)), "Failed to find the Totals of the voucher");
		}else if(voucherType.equals("meal program")) {
			voucherTypeToSelect = "1";
			voucherTypeInTest = "Meal Program";
			Assert.assertNotNull(createMealProgram(voucherDetail,empName),"Failed to create Meal voucher with details" +voucherDetail.toString());
		}

		return this;
	}
	public int totalVoucherAmount;
	public int totalVoucherQuantity;
	

	
	public Boolean selectSafari(){
		
		Robot r;
		try {
			r = new Robot();
			r.keyPress(KeyEvent.VK_META);
			r.keyPress(KeyEvent.VK_S);
			r.keyPress(KeyEvent.VK_SHIFT);
			r.keyRelease(KeyEvent.VK_S );
			r.keyRelease(KeyEvent.VK_SHIFT);
			r.keyRelease(KeyEvent.VK_META );
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			log("Selected Safari");
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return true;

	}
	public MenuMakerApp addAMealVoucher(JSONObject voucherDetail, int numberOfVouchers){
		
		
		if(numberOfVouchers >= 1)
		{
		Assert.assertNotNull(clickElement("plus_button_voucher_page"), "Failed to find plus button");
		}
		String plannedUseType = (String) voucherDetail.get("planned_use");
		String voucherValue = (String) voucherDetail.get("value");
		String voucherQuantity = (String) voucherDetail.get("quantity");
		String totalVoucherValue = (String) voucherDetail.get("total_voucher_value");
		log(plannedUseType);
		totalVoucherAmount = totalVoucherAmount+Integer.parseInt(totalVoucherValue);
		totalVoucherQuantity = totalVoucherQuantity+Integer.parseInt(voucherQuantity);
		
		String WEPlannedUseType = getUILocator("planned_use_voucher_page");
		WEPlannedUseType = WEPlannedUseType.replaceAll("<REPLACE_INDEX>", Integer.toString(numberOfVouchers+1));
		WebElement plannedUseSelect = waitForElement(WEPlannedUseType);
		//log("Default option selected:"+ plannedUseSelect.getText());
		plannedUseSelect.click();
		
		String selectPlannedUserType = getUILocator("select_voucher_type_after_click_voucher_page");
		selectPlannedUserType = selectPlannedUserType.replaceAll("<REPLACE_TICKET_TYPE>", plannedUseType);
		selectPlannedUserType = selectPlannedUserType.replaceAll("<REPLACE_INDEX>", Integer.toString(numberOfVouchers+1));
		Assert.assertTrue(clickElement(selectPlannedUserType), "Failed to click planned user type");
		
		
		String WEVoucherValue = getUILocator("voucher_value_voucher_page1");
		WEVoucherValue = WEVoucherValue.replaceAll("<REPLACE_VOUCHER_INDEX>", Integer.toString(numberOfVouchers));
		Assert.assertNotNull(waitForElement(WEVoucherValue), "Failed to find the voucher Value field");
		
		WebElement voucherValueElement = waitForElement(WEVoucherValue);
		
		log(voucherValueElement.getText() +" "+voucherValue);
		/*
		String selectPlannedUserType = getUILocator("select_voucher_type_after_click_voucher_page");
		selectPlannedUserType = selectPlannedUserType.replaceAll("<REPLACE_TICKET_TYPE>", plannedUseType);
		WebElement parent = voucherValueElement.findElement(By.xpath("../.."));
		
		log(parent.getAttribute("xpath"));
		WebElement child = parent.findElement(By.xpath("/div["+Integer.toString(numberOfVouchers)+"]//button[contains(@class,'ticket-type-button')]"));
		log(child.getAttribute("xpath"));
		child.click();
		WebElement UserType= child.findElement(By.xpath(selectPlannedUserType));
		UserType.click();*/
		
		
		//String WEPlannedUseType= getUILocator("planned_use_voucher_page1");
	
		/*WEPlannedUseType =WEPlannedUseType.replaceAll("<REPLACE_VOUCHER_INDEX>", Integer.toString(numberOfVouchers));
		WebElement plannedUse = waitForElement(WEPlannedUseType);
		log("Default option selected:"+ plannedUse.getText());
		plannedUse.click();
		Select select =new Select(plannedUse);
		select.selectByVisibleText(plannedUseType);
		log("Option selected:"+ plannedUse.getText());*/
		//WebElement valueOfVoucherTypeSelected = waitForElement(WEVoucherValue);
		//String valueOfSelectedVoucher= valueOfVoucherTypeSelected.getAttribute("value");
		//Assert.assertEquals(valueOfSelectedVoucher, voucherValue);
		String voucherQty = getUILocator("voucher_quantity_voucher_page1");
		voucherQty =voucherQty.replaceAll("<REPLACE_VOUCHER_INDEX>", Integer.toString(numberOfVouchers));
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement(voucherQty), "Clicking Quantity field failed");
		AppUtilities.delay(5000);
		log("Sending keys");
		enterNumericValuesOnTextBoxRobot(waitForElement(voucherQty),voucherQuantity);
		AppUtilities.delay(5000);
		String voucherTotal= getUILocator("voucher_total_voucher_page1");
		voucherTotal= voucherTotal.replaceAll("<REPLACE_VOUCHER_INDEX>", Integer.toString(numberOfVouchers));
		WebElement total = waitForElement(voucherTotal);
		log (total.getText() + totalVoucherValue);
		Assert.assertTrue(total.getText().contains(totalVoucherValue));
		//Assert.assertTrue(waitForElementWithText(voucherTotal, " $"+totalVoucherValue+".00"),"Voucher values doesnt match");
		//Assert.assertNotNull(waitForElement("plus_button_voucher_page"), "Failed to find plus button");
		return this;
	}
	public MenuMakerApp createMealVouchers(JSONObject voucherDetail, String empName){
		
		String businessJustification = (String) voucherDetail.get("business_justification");
		String requestForUser = (String) voucherDetail.get("request_for");
		String additional_email_content = (String) voucherDetail.get("additional_email_content");
		String region=(String) voucherDetail.get("region");
		String city=(String) voucherDetail.get("city");
		String businessJustificationOption=(String) voucherDetail.get("business_justification_option");
		JSONArray mtVouchers = (JSONArray) voucherDetail.get("vouchers");		
		Assert.assertTrue(clickElement("request_vouchers_voucher_page"), "Failed to click voucher page");
		int numberOfVouchers =0;
		totalVoucherAmount= 0;
		totalVoucherQuantity= 0;

		WebElement RequestDropdown = waitForElement("request_for_voucher_page");
		log("Default option selected:"+ RequestDropdown.getText());
		if(requestForUser.equals("On Behalf"))
		{
			String RequestForEmailAdd = (String)voucherDetail.get("request_email");
			String RequestorName= (String)voucherDetail.get("requestor_name");
			WebElement RequestFor = waitForElement("request_for_voucher_page");
			RequestFor.click();
			Select select =new Select(RequestFor);
			select.selectByVisibleText(requestForUser);
			//Added by Chithra
			AppUtilities.delay(15000);
			
			String requestForEmailFieldLocator = getUILocator("search_field_on_behalf_voucher_modal_dialog");
			WebElement requestForEmailField = waitForElement(requestForEmailFieldLocator);
			requestForEmailField.sendKeys(RequestForEmailAdd);
			requestForEmailField.sendKeys(Keys.ENTER);
			String RequestForEmail = getUILocator("request_email_on_behalf_voucher_modal_dialog");
			RequestForEmail = RequestForEmail.replaceAll("<REPLACE_BEHALF_OF_EMAIL>", RequestForEmailAdd);
			log(RequestForEmail);
			Assert.assertNotNull(waitForElement("label_request_on_behalf_voucher_modal_dialog"), "Failed to open model window");
			Assert.assertNotNull(clickElement(RequestForEmail), "Failed to find email in model window");
			AppUtilities.delay(2000);
			Assert.assertNotNull(clickElement("select_on_behalf_voucher_modal_dialog"), "Failed to select email in model window");
			AppUtilities.delay(2000);

		/*
		//WebElement voucherSearch = waitForElement("search_field_on_behalf_voucher_modal_dialog");
	//	voucherSearch.sendKeys(RequestForEmailAdd);
		//voucherSearch.sendKeys(Keys.RETURN);
		AppUtilities.delay(5000);
		Assert.assertNotNull(clickElement("select_on_behalf_voucher_modal_dialog"), "Failed to select email in model window");
		AppUtilities.delay(2000);

			String ReqName= waitForElement("requestor_name_voucher_page").getText();
			String ReqEmail= waitForElement("requestor_email_voucher_page").getText();
			Assert.assertTrue(ReqName.contains(RequestorName),"Failed to find the Requestor Name: "+ RequestorName);
			Assert.assertTrue(ReqEmail.contains(RequestForEmailAdd),"Failed to find the Requestor Email: "+ RequestForEmailAdd);
			*/
			String requestOnBehalfNameFieldLocator = getUILocator("requestor_name_voucher_page");
			requestOnBehalfNameFieldLocator= requestOnBehalfNameFieldLocator.replaceAll("<REPLACE_NAME>", RequestorName);
			Assert.assertNotNull(waitForElement(requestOnBehalfNameFieldLocator), "Failed to find On Behalf of Name");
			
			String requestOnBehalfEmailFieldLocator = getUILocator("requestor_email_voucher_page");
			requestOnBehalfEmailFieldLocator= requestOnBehalfEmailFieldLocator.replaceAll("<REPLACE_EMAIL>", RequestForEmailAdd);
			Assert.assertNotNull(waitForElement(requestOnBehalfEmailFieldLocator), "Failed to find On Behalf of email");
		
		}
		Assert.assertTrue(clickElement("region_dropdown_voucher_page"), "Failed to click region dropdown");
		String selectRegion = getUILocator("region_dropdown_value_voucher_page");
		selectRegion = selectRegion.replaceAll("<REPLACE_TEXT>", region);
		log("selectRegion"+selectRegion);
		Assert.assertTrue(clickElement(selectRegion), "Failed to choose region dropdown value");
		
		//Assert.assertTrue(clickElement("region_dropdown_value_voucher_page"), "Failed to choose region dropdown value");
		Assert.assertTrue(clickElement("city_dropdown_voucher_page"), "Failed to click city dropdown");
		String selectCity = getUILocator("city_dropdown_value_voucher_page");
		selectCity = selectCity.replaceAll("<REPLACE_TEXT>", city);
		log("selectCity"+selectCity);
		Assert.assertTrue(clickElement(selectCity), "Failed to click city value");
		
		//Assert.assertTrue(clickElement("city_dropdown_value_voucher_page"), "Failed to choose city dropdown value");
		
		WebElement e = waitForElement("business_justification_dropdown_voucher_page");
		log(e.getText());
		Assert.assertTrue(clickElement("business_justification_dropdown_voucher_page"), "Failed to click business justification drop down");
		String selectBusinessJustificationPlannedUse = getUILocator("business_justification_dropdown_value_voucher_page");
		selectBusinessJustificationPlannedUse = selectBusinessJustificationPlannedUse.replaceAll("<REPLACE_TEXT>", businessJustificationOption);
		log("selectBusinessJustificationPlannedUse"+selectBusinessJustificationPlannedUse);
		Assert.assertTrue(clickElement(selectBusinessJustificationPlannedUse), "Failed to select business jusitification value in drop down");
		
		//Assert.assertTrue(clickElement("business_justification_dropdown_value_voucher_page"), "failed to click business jusitification value in drop down");
		
		Assert.assertNotNull(typeText("business_justification_voucher_page", businessJustification), "Failed to enter Business Justification");
		//Added by Chithra- Additional Email Content
		Assert.assertNotNull(typeText("distribution_email_content", additional_email_content), "Failed to enter Additional Eemail Content");		
		for (Object i: mtVouchers){
			JSONObject mtVoucher = (JSONObject) i;
			addAMealVoucher(mtVoucher,numberOfVouchers);
			numberOfVouchers++;
		}
		
		return this;
	}
	
	public MenuMakerApp validateRequestVoucherPage(JSONArray voucherDetails, String employeeName){
		
		JSONObject voucherDetail = (JSONObject)voucherDetails.get(0);
		Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
		String businessJustification = (String) voucherDetail.get("business_justification");
		String requestForUser = (String) voucherDetail.get("request_for");
		//JSONArray mtVouchers = (JSONArray) voucherDetail.get("vouchers");
		Assert.assertTrue(clickElement("request_vouchers_voucher_page"), "Failed to click voucher page");
		int numberOfVouchers =0;
		
		WebElement RequestDropdown = waitForElement("request_for_voucher_page");
		log("Default option selected:"+ RequestDropdown.getText());
		if(requestForUser.equals("On Behalf"))
		{
			String RequestForEmailAdd = (String)voucherDetail.get("request_email");
			String RequestorName= (String)voucherDetail.get("requestor_name");
			WebElement RequestFor = waitForElement("request_for_voucher_page");
			RequestFor.click();
			Select select =new Select(RequestFor);
			select.selectByVisibleText(requestForUser);
			String requestForEmailFieldLocator = getUILocator("search_field_on_behalf_voucher_modal_dialog");
			WebElement requestForEmailField = waitForElement(requestForEmailFieldLocator);
			requestForEmailField.sendKeys(RequestForEmailAdd);
			requestForEmailField.sendKeys(Keys.ENTER);
			String RequestForEmail = getUILocator("request_email_on_behalf_voucher_modal_dialog");
			RequestForEmail = RequestForEmail.replaceAll("<REPLACE_BEHALF_OF_EMAIL>", RequestForEmailAdd);
			log(RequestForEmail);
			
			String RequestForName = getUILocator("request_email_on_behalf_voucher_modal_dialog");
			RequestForName = RequestForName.replaceAll("<REPLACE_BEHALF_OF_EMAIL>", RequestorName);
			log(RequestForName);
			Assert.assertNotNull(waitForElement("label_request_on_behalf_voucher_modal_dialog"), "Failed to open model window");
			Assert.assertNotNull(waitForElement(RequestForName), "Failed to Find Requestor Name");
			Assert.assertNotNull(clickElement(RequestForEmail), "Failed to find email in model window");
			AppUtilities.delay(2000);
			Assert.assertNotNull(clickElement("select_on_behalf_voucher_modal_dialog"), "Failed to select email in model window");
			AppUtilities.delay(2000);

		/*
			WebElement voucherSearch = waitForElement("search_field_on_behalf_voucher_modal_dialog");
			voucherSearch.sendKeys(RequestForEmailAdd);
			voucherSearch.sendKeys(Keys.RETURN);
			AppUtilities.delay(5000);
		
			String ReqName= waitForElement("requestor_name_voucher_page").getText();
			String ReqEmail= waitForElement("requestor_email_voucher_page").getText();
			Assert.assertTrue(ReqName.contains(RequestorName),"Failed to find the Requestor Name: "+ RequestorName);
			Assert.assertTrue(ReqEmail.contains(RequestForEmailAdd),"Failed to find the Requestor Email: "+ RequestForEmailAdd);
			*/
			String requestOnBehalfNameFieldLocator = getUILocator("requestor_name_voucher_page");
			requestOnBehalfNameFieldLocator= requestOnBehalfNameFieldLocator.replaceAll("<REPLACE_NAME>", RequestorName);
			Assert.assertNotNull(waitForElement(requestOnBehalfNameFieldLocator), "Failed to find On Behalf of Name");
			
			String requestOnBehalfEmailFieldLocator = getUILocator("requestor_email_voucher_page");
			requestOnBehalfEmailFieldLocator= requestOnBehalfEmailFieldLocator.replaceAll("<REPLACE_EMAIL>", RequestForEmailAdd);
			Assert.assertNotNull(waitForElement(requestOnBehalfEmailFieldLocator), "Failed to find On Behalf of email");
		
		}
		Assert.assertTrue(clickElement("region_dropdown_voucher_page"), "Failed to click region dropdown");
		Assert.assertTrue(clickElement("region_dropdown_value_voucher_page"), "Failed to choose region dropdown value");
		Assert.assertTrue(clickElement("city_dropdown_voucher_page"), "Failed to click city dropdown");
		Assert.assertTrue(clickElement("city_dropdown_value_voucher_page"), "Failed to choose city dropdown value");
		WebElement e = waitForElement("business_justification_dropdown_voucher_page");
		log(e.getText());
		Assert.assertTrue(clickElement("business_justification_dropdown_voucher_page"), "Failed to click business justification drop down");
		Assert.assertTrue(clickElement("business_justification_dropdown_value_voucher_page"), "failed to click business jusitification value in drop down");
		Assert.assertNotNull(typeText("business_justification_voucher_page", businessJustification), "Failed to enter Business Justification");
		
		return this;
	}
	
	public MenuMakerApp saveVoucher()
	{
		Assert.assertTrue(clickElement("save_button_voucher_page"), "Failed to click save button");
		Assert.assertNotNull(waitForElement("voucher_save_status"), "Failed to find save status");
		voucherStatus= "Draft";
		return this;
	}

	public MenuMakerApp submitVoucher()
	{
		Assert.assertTrue(clickElement("submit_button_voucher_page"), "Failed to click save button");
		Assert.assertNotNull(waitForElement("voucher_save_status"), "Failed to find save status");
		voucherStatus= "Pending Approval";
		AppUtilities.delay(3000);
		/* Need to be enabled after defect fix
		 * validateFieldsAfterSubmit();
		 */
		//Add below only for meal voucher
		//Assert.assertTrue(waitForElementWithText("txt_voucher_expires_in_voucher_page","Vouchers expire 90 days from approval date"),"Failed to find Expiration text");
		return this;
	}
	
	public MenuMakerApp validateFieldsAfterSubmit(){
		
		WebElement bj= waitForElement("business_justification_voucher_page");
		boolean bjState = bj.isEnabled();
		Assert.assertFalse(bjState, "The business justification field is enabled");
		/*
		Assert.assertFalse(typeText("business_justification_voucher_page", "Trying to enter text"), "Able to enter Business Justification");
		
		try{	
			//WebElement bj= waitForElement("business_justification_voucher_page");
			//bj.sendKeys("Trying to enter text");
			
			}
			catch(Exception e){
				log("User cannot enter in business Justification page after submit"+e);
			}
		*/
		return this;
	}
	public MenuMakerApp createDeleteVouchers(JSONArray voucherDetails, String empName){
		
		Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		for (Object voucher: voucherDetails){
			JSONObject voucherDetail = (JSONObject) voucher;
			Assert.assertNotNull(createVoucher(voucherDetail,empName), "Failed to create voucher with details"+voucherDetails.toString());
			Assert.assertNotNull(saveVoucher(), "Failed to save voucher details");
		}
		Assert.assertTrue(waitForElementWithText("quantity_voucher_page", Integer.toString(totalVoucherQuantity)), "Failed to find the Total quantity");
		Assert.assertTrue(waitForElementWithText("totals_voucher_page", Integer.toString(totalVoucherAmount)), "Failed to find the Totals of the voucher");
		return this;
	}
	
	public MenuMakerApp deleteVoucher(JSONObject voucherDetail){
		log(voucherDetail.toJSONString());
		String plannedUseType = (String) voucherDetail.get("planned_use");
		String value = (String) voucherDetail.get("value");
		String quantity = (String) voucherDetail.get("quantity");
		int qty = Integer.parseInt(quantity);
		String totalVoucherValue = (String) voucherDetail.get("total_voucher_value");
		int deleteVouchertotal = Integer.parseInt(totalVoucherValue);
		
		List <WebElement> vouchersList= waitForElements("number_of_rows");
		int noOfVouchers= vouchersList.size();
		
		for(int i=1; i<noOfVouchers; i++){	
			AppUtilities.delay(5000);
			String WEPlannedUseType= getUILocator("planned_use_voucher_page1");
			WEPlannedUseType =WEPlannedUseType.replaceAll("<REPLACE_VOUCHER_INDEX>", Integer.toString(i+1));
			WebElement plannedUse = waitForElement(WEPlannedUseType);
			log(plannedUse.getText());
			//String selectedOption = plannedUse.findElement(By.xpath("option[@selected='selected']")).getText();
			if (plannedUse.getText().equals(plannedUseType))
			{
				String WEVoucherValue = getUILocator("voucher_value_voucher_page1");
				WEVoucherValue = WEVoucherValue.replaceAll("<REPLACE_VOUCHER_INDEX>", Integer.toString(i));
				WebElement valueOfVoucherTypeSelected = waitForElement(WEVoucherValue);
				String valueOfSelectedVoucher= valueOfVoucherTypeSelected.getText();
				log(valueOfSelectedVoucher);
				if(valueOfSelectedVoucher.equals(value)){
					log("In first if loop");
					String voucherTotal= getUILocator("voucher_total_voucher_page1");
					voucherTotal= voucherTotal.replaceAll("<REPLACE_VOUCHER_INDEX>", Integer.toString(i));
					WebElement total = waitForElement(voucherTotal);
					log("The total is: "+total.getText());
					log("The totalvouchervalue is: "+totalVoucherValue);
					boolean result = (total.getText().contains(totalVoucherValue));
					log("The result is: "+result);
					if(total.getText().contains(totalVoucherValue))
					{
						log("In deleting voucher segment");
						String minusButton = getUILocator("minus_button_index_voucher_page");
						minusButton= minusButton.replaceAll("<REPLACE_VOUCHER_INDEX>",Integer.toString(i));
						Assert.assertTrue(clickElement(minusButton),"Failed to click minus button");
					}
				}
			}
		}
		WebElement e = waitForElement("quantity_voucher_page");
		String finalValue1= e.getText();
		int finalValue = Integer.parseInt(finalValue1);
		log("final value is: "+finalValue);
		log("The total voucher quantity is: "+Integer.toString(totalVoucherQuantity-qty));
		log(finalValue+ Integer.toString(totalVoucherQuantity-qty));
		Assert.assertTrue(finalValue >= (totalVoucherQuantity-qty), "Failed to find the Total quantity");
		
		e = waitForElement("totals_voucher_page");
		finalValue1= e.getText();
		log("The final value is: "+finalValue1);
		String split[] = finalValue1.split("\\$");
		log("The string is: "+split[1]);
		Double afterSplit = Double.parseDouble(split[1]);
		finalValue = afterSplit.intValue();
		log("The total voucher quantity is: "+(totalVoucherAmount-deleteVouchertotal));
		log(finalValue+ Integer.toString(totalVoucherAmount-deleteVouchertotal));
		Assert.assertTrue(finalValue >= (totalVoucherAmount-deleteVouchertotal), "Failed to find the Totals of the voucher");
		
		//Assert.assertTrue(waitForElementWithText("totals_voucher_page", Integer.toString(totalVoucherAmount-deleteVouchertotal)), "Failed to find the Totals of the voucher");
		log("Successfully deleted the created voucher");
		return this;
	}
	public MenuMakerApp createMealProgram(JSONObject voucherDetail, String empName){
		
		String businessJustification = (String) voucherDetail.get("business_justification");
		String requestForUser = (String) voucherDetail.get("request_for");
		String region=(String) voucherDetail.get("region");
		String city=(String) voucherDetail.get("city");
		String businessJustificationOption=(String) voucherDetail.get("business_justification_option");
		String svpOption=(String) voucherDetail.get("svp_option");
		String dollarLimit = (String) voucherDetail.get("dollar_limit");
		String prgmName = (String) voucherDetail.get("program_name");
		String prgmValue =(String) voucherDetail.get("value");
		String prgmFisicalYear = (String) voucherDetail.get("fisical_year");
		JSONArray weekdays = (JSONArray) voucherDetail.get("usage_day");
		JSONArray costCenters = (JSONArray) voucherDetail.get("cost_center");
		JSONObject voucherUsage = (JSONObject) voucherDetail.get("usage_time");
		String startDate = (String) voucherUsage.get("from");
		String endDate = (String) voucherUsage.get("to");
		
		Assert.assertTrue(clickElement("meal_program_voucher_page"), "Failed to click voucher page");
		log(requestForUser);
		WebElement RequestDropdown = waitForElement("request_for_voucher_page");
		log("Default option selected:"+ RequestDropdown.getText());
		
		if(requestForUser.equals("On Behalf"))
		{
			String RequestForEmailAdd = (String)voucherDetail.get("request_email");
			String RequestorName= (String)voucherDetail.get("requestor_name");
			WebElement RequestFor = waitForElement("request_for_voucher_page");
			RequestFor.click();
			Select select =new Select(RequestFor);
			select.selectByVisibleText(requestForUser);
			AppUtilities.delay(10000);
			String requestForEmailFieldLocator = getUILocator("search_field_on_behalf_voucher_modal_dialog");
			WebElement requestForEmailField = waitForElement(requestForEmailFieldLocator);
			requestForEmailField.sendKeys(RequestForEmailAdd);
			requestForEmailField.sendKeys(Keys.ENTER);
			String RequestForEmail = getUILocator("request_email_on_behalf_voucher_modal_dialog");
			RequestForEmail = RequestForEmail.replaceAll("<REPLACE_BEHALF_OF_EMAIL>", RequestForEmailAdd);
			log(RequestForEmail);
			Assert.assertNotNull(waitForElement("label_request_on_behalf_voucher_modal_dialog"), "Failed to open model window");
			Assert.assertNotNull(clickElement(RequestForEmail), "Failed to find email in model window");
			Assert.assertTrue(clickElement("select_on_behalf_voucher_modal_dialog"), "Failed to click Select button in on behalf popup");
			AppUtilities.delay(2000);
			String requestOnBehalfNameFieldLocator = getUILocator("requestor_name_voucher_page");
			requestOnBehalfNameFieldLocator= requestOnBehalfNameFieldLocator.replaceAll("<REPLACE_NAME>", RequestorName);
			Assert.assertNotNull(waitForElement(requestOnBehalfNameFieldLocator), "Failed to find On Behalf of Name");
			
			String requestOnBehalfEmailFieldLocator = getUILocator("requestor_email_voucher_page");
			requestOnBehalfEmailFieldLocator= requestOnBehalfEmailFieldLocator.replaceAll("<REPLACE_EMAIL>", RequestForEmailAdd);
			Assert.assertNotNull(waitForElement(requestOnBehalfEmailFieldLocator), "Failed to find On Behalf of email");
			/*
			String RequestForEmailAdd = (String)voucherDetail.get("request_email");
			WebElement RequestFor = waitForElement("request_for_voucher_page");
			RequestFor.click();
			Select select =new Select(RequestFor);
			select.selectByVisibleText(requestForUser);
			String RequestForEmail = getUILocator("request_email_on_behalf_voucher_modal_dialog");
			RequestForEmail = RequestForEmail.replaceAll("<REPLACE_BEHALF_OF_EMAIL>", RequestForEmailAdd);
			log(RequestForEmail);
			Assert.assertNotNull(waitForElement("label_request_on_behalf_voucher_modal_dialog"), "Failed to open model window");
			Assert.assertNotNull(clickElement(RequestForEmail), "Failed to find email in model window");
			AppUtilities.delay(2000);
			Assert.assertNotNull(clickElement("select_on_behalf_voucher_modal_dialog"), "Failed to select email in model window");
			*/
		}
		Assert.assertTrue(clickElement("region_dropdown_voucher_page"), "failed to click region dropdown");
		String selectRegion = getUILocator("region_dropdown_value_voucher_page");
		selectRegion = selectRegion.replaceAll("<REPLACE_TEXT>", region);
		Assert.assertTrue(clickElement(selectRegion), "Failed to choose region dropdown value");
		AppUtilities.delay(2000);		
		Assert.assertTrue(clickElement("city_dropdown_voucher_page"), "failed to click city dropdown");
		String selectCity = getUILocator("city_dropdown_value_voucher_page");
		selectCity = selectCity.replaceAll("<REPLACE_TEXT>", city);
		log("selectCity"+selectCity);
		Assert.assertTrue(clickElement(selectCity), "Failed to click city value");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("program_svp_voucher_page"), "failed to click SVP drop down");
		
		String selectSVPOption = getUILocator("program_svp_value_voucher_page");
		selectSVPOption = selectSVPOption.replaceAll("<REPLACE_TEXT>", svpOption);
		log("selectSVPOption:"+selectSVPOption);
		Assert.assertTrue(clickElement(selectSVPOption), "Failed to click svp drop down value");
		AppUtilities.delay(5000);
		/*
		Assert.assertTrue(clickElement("program_department_voucher_page"), "Failed to click department popup"); Xpath://div[contains(@class, 'ac-select-text-wrapper')]//input[contains(@class, 'ac-select-text')]
		Assert.assertTrue(clickElement("program_department_value_voucher_page"), "Failed to click department value"); Xpath://div[contains(@class, 'ac-select-list')]//li[contains(@class, 'ng-binding') and contains(@title,'0056/0916')], //div[contains(@class, 'ac-select-list')]//li[contains(@class, 'ng-binding') and contains(@title,'0056/0916')]
		Assert.assertNotNull(typeText("dollar_limit_voucher_page", dollarLimit), "Failed to enter dollar limit"); Xpath: //div[contains(@ng-repeat,'costCenter in vm.mealProgramRequest.programDetails.svp.costCenters')]//input[@name='dollarLimit0']
		//input[contains(@id,'plus')]/../../div/input[@placeholder='Please select...']
		 * //*[text()='0056/0106 - CADM OU US Bonus/SBC']
		 * dollarLimit0
		
		*/
		int index = 0;
		for(Object costCenter: costCenters){
			JSONObject deptAllocation = (JSONObject) costCenter;
			Assert.assertNotNull(addCostCenter(deptAllocation, index), "Failed to add department details");
			index++;
			}
	/*
		Assert.assertTrue(clickElement("program_department_voucher_page"), "Failed to click department popup");
		checkPageIsReady();
		Assert.assertTrue(clickElement("program_department_value_voucher_page"), "Failed to click department value");
		checkPageIsReady();
		Assert.assertNotNull(typeText("dollar_limit_voucher_page", dollarLimit), "Failed to enter dollar limit");*/
		
		Assert.assertTrue(clickElement("program_business_justification_voucher_page"), "Failed to click business justification dropdown");
		AppUtilities.delay(5000);
		//Assert.assertTrue(clickElement("program_business_justification_value_voucher_page"), "Failed to click the business justification value dropdown");
		String selectBusinessJustificationPlannedUse = getUILocator("program_business_justification_value_voucher_page");
		selectBusinessJustificationPlannedUse = selectBusinessJustificationPlannedUse.replaceAll("<REPLACE_TEXT>", businessJustificationOption);
		log("selectBusinessJustificationPlannedUse"+selectBusinessJustificationPlannedUse);
		Assert.assertTrue(clickElement(selectBusinessJustificationPlannedUse), "Failed to select business jusitification value in drop down");
				
		Assert.assertNotNull(typeText("business_justification_voucher_page", businessJustification), "Failed to enter Business Justification");
		Assert.assertNotNull(typeText("program_name_voucher_page", prgmName), "Failed to enter Business Justification");
		
		for(Object day: weekdays){
		Assert.assertNotNull(selectWeekDay(day.toString()), "Failed to select weekday");
		}
		Assert.assertNotNull(waitForElementWithText("program_value_voucher_page",prgmValue), "Failed to find Program value");
		Assert.assertTrue(clickElement("meal_program_hours_start_time_hour_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_start_time_hour_value_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_start_time_min_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_start_time_min_value_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_start_time_format_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_start_time_format_value_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_end_time_hour_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_end_time_hour_value_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_end_time_min_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_end_time_min_value_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_end_time_format_voucher_page"), "Failed to enter start time");
		Assert.assertTrue(clickElement("meal_program_hours_end_time_format_value_voucher_page"), "Failed to enter start time");
		//Assert.assertTrue(clickElement("program_fiscal_year_voucher_page"), "Failed to click fiscal year");
		
		WebElement e = waitForElement("program_fiscal_year_voucher_page");
		e.click();
		AppUtilities.delay(2000);
		Select fiscalYear = new Select(e);
		fiscalYear.selectByVisibleText(prgmFisicalYear);
		AppUtilities.delay(2000);
		//Assert.assertNotNull(saveVoucher(), "Failed to find save status");
		//Assert.assertNotNull(submitVoucher(), "Failed to find submit status");
		/*Assert.assertTrue(clickElement("save_button_voucher_page"), "Failed to click save button");
		Assert.assertNotNull(waitForElement("voucher_save_status"), "Failed to find save status");
		Assert.assertTrue(clickElement("submit_button_voucher_page"), "Failed to click save button");
		Assert.assertNotNull(waitForElement("voucher_save_status"), "Failed to find save status");*/
		return this;
	}
	
public MenuMakerApp addCostCenter(JSONObject costCenter, int index) {
	
	if (index>0) {
		String plusButton = getUILocator("plus_button_mealprogram_page");
		plusButton = plusButton.replaceAll("<REPLACE_INDEX>", index-1+"");
		Assert.assertTrue(clickElement(plusButton), "Failed to click department value");	
		checkPageIsReady();
	}
	String dept= (String) costCenter.get("dept_data");
	String dollarLimitValue =  (String) costCenter.get("dollar_limit");
	Assert.assertTrue(clickElement("program_department_voucher_page"), "Failed to click department popup");
	checkPageIsReady();
	Assert.assertNotNull(typeText("program_department_voucher_page", dept), "Failed to enter dollar limit");
	String selectDept = getUILocator("program_department_value_voucher_page");
	selectDept = selectDept.replaceAll("<REPLACE_TEXT>", dept);
	Assert.assertTrue(clickElement(selectDept), "Failed to click department value");
	checkPageIsReady();
	String dollarLimit = getUILocator("dollar_limit_voucher_page");
	dollarLimit = dollarLimit.replaceAll("<REPLACE_INDEX>", index+"");
	
	Assert.assertNotNull(typeText(dollarLimit, dollarLimitValue), "Failed to enter dollar limit");
		return this;
	}

public MenuMakerApp validateUserDetail(String username, String empname, String voucherType){
		log(username+empname+voucherType);
		Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
		if(voucherType.equals("meal program")){
		Assert.assertTrue(clickElement("meal_program_voucher_page"), "Failed to click voucher page");
		} else if (voucherType.equals("meal voucher")){
		Assert.assertTrue(clickElement("request_vouchers_voucher_page"), "Failed to click voucher page");
		}
		AppUtilities.delay(5000);
		String employeeName = getUILocator("initator_name_voucher_page");
		String email = getUILocator("initator_email_voucher_page");
		employeeName = employeeName.replaceAll("<REPLACE_USERNAME>", empname);
		String emailAddress = username+"@apple.com";
		email =email.replaceAll("<REPLACE_EMAIL>", emailAddress);
		Assert.assertNotNull(waitForElement(employeeName), "Failed to find employee name:"+empname);
		Assert.assertNotNull(waitForElement(email), "Failed to find employee email:"+emailAddress);
		log("Successfully validated user details");
		return this;
	}

public MenuMakerApp validateDefaultValueRequestFor(String voucherType){
	Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
	if(voucherType.equals("meal program")){
	Assert.assertTrue(clickElement("meal_program_voucher_page"), "Failed to click voucher page");
	} else if (voucherType.equals("meal voucher")){
	Assert.assertTrue(clickElement("request_vouchers_voucher_page"), "Failed to click voucher page");
	}
	WebElement RequestFor = waitForElement("request_for_voucher_page").findElement(By.xpath("option[@selected='selected']"));
	log(RequestFor.getText());
	Assert.assertTrue((RequestFor.getText().equals("Myself")));
	//Assert.assertTrue(clickElement("cancel_button_voucher_page"), "Failed to click the Cancel button");
	AppUtilities.delay(5000);
	log("Verified default value for Request for");
	return this;
}

public MenuMakerApp verifyMTCancelButton() {
	Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
	AppUtilities.delay(5000);
	Assert.assertTrue(clickElement("request_vouchers_voucher_page"), "Failed to click Request voucher page");
	AppUtilities.delay(3000);
	String businessJustificationLocator = getUILocator("business_justification_voucher_page");
	Assert.assertTrue(typeText(businessJustificationLocator, "Hello"), "Failed to type the text");
	Assert.assertTrue(clickElement("cancel_button_voucher_page"), "Failed to click the Cancel button");
	AppUtilities.delay(5000);
	WebElement businessJustificationField = waitForElement(businessJustificationLocator);
	String businessJustificationValue = businessJustificationField.getAttribute("Value");
	if (businessJustificationValue == null) {
		Assert.assertTrue(true);
	}
	return this;	
}

public MenuMakerApp verifyMPCancelButton() {
	Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
	AppUtilities.delay(5000);
	Assert.assertTrue(clickElement("meal_program_voucher_page"), "Failed to click Request voucher page");
	AppUtilities.delay(3000);
	String businessJustificationLocator = getUILocator("business_justification_voucher_page");
	Assert.assertTrue(typeText(businessJustificationLocator, "Hello"), "Failed to type the text");
	Assert.assertTrue(clickElement("cancel_button_voucher_page"), "Failed to click the Cancel button");
	AppUtilities.delay(5000);
	WebElement businessJustificationField = waitForElement(businessJustificationLocator);
	String businessJustificationValue = businessJustificationField.getAttribute("Value");
	log("The  business justification field value after cancel is: "+businessJustificationValue);
	if (businessJustificationValue == null) {
		Assert.assertTrue(true);
	}
	return this;	
}

public MenuMakerApp validateBusinessJustifcation(String voucherType, String dollarLimit){
	Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
	if(voucherType.equals("meal program")){
	Assert.assertTrue(clickElement("meal_program_voucher_page"), "Failed to click voucher page");
	//String dollarLimit = (String) voucherDetail.get("dollar_limit");
	Assert.assertTrue(clickElement("region_dropdown_voucher_page"), "failed to click region dropdown");
	Assert.assertTrue(clickElement("region_dropdown_value_voucher_page"), "failed to click region dropdown value");
	Assert.assertTrue(clickElement("city_dropdown_voucher_page"), "failed to click city dropdown");
	Assert.assertTrue(clickElement("city_dropdown_value_voucher_page"), "failed to click city dropdown value");
	Assert.assertTrue(clickElement("program_svp_voucher_page"), "failed to click SVP drop down");
	AppUtilities.delay(5000);
	Assert.assertTrue(clickElement("program_department_voucher_page"), "Failed to click department popup");
	Assert.assertTrue(clickElement("program_department_value_voucher_page"), "Failed to click department value");
	Assert.assertNotNull(typeText("dollar_limit_voucher_page", dollarLimit), "Failed to enter dollar limit");
	} else if (voucherType.equals("meal voucher")){
	Assert.assertTrue(clickElement("request_vouchers_voucher_page"), "Failed to click voucher page");
	}

	if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")) {
		try{
			AppUtilities.delay(2000);	
		WebElement saveBtn = waitForElement("save_button_voucher_page");
		saveBtn.click();
		
		} catch (Exception e){
			
			String exceptionContent = "Exception"+e;
			log(exceptionContent);
			Assert.assertTrue(exceptionContent.contains("required fields "),"Failed to contain text");
		}
		} else if (StringUtils.containsIgnoreCase(getBrowserName(), "firefox")){
		Assert.assertTrue(clickElement("save_button_voucher_page"), "Failed to click save button");	
		AppUtilities.delay(2000);
		//Validating the error message
		driver.switchTo().alert();
		String actualAlertText = driver.switchTo().alert().getText();
		boolean compareResult  = actualAlertText.contains("All required fields must be completed.");
		Assert.assertTrue(compareResult, "The alert is not displayed");
        driver.switchTo().alert().accept();
        Assert.assertNotNull(waitForElement("required_error_business_justification_voucher_page"), "Failed to find the required error message");
    	}
	Assert.assertTrue(clickElement("cancel_button_voucher_page"), "failed to click Cancel button");
	log("Successfully validated Business Justification field");
	return this;
}

public MenuMakerApp validateVoucherName(JSONObject testData){
	String voucherType = (String) testData.get("voucher_type");
	String Justification = (String) testData.get("business_justification");
	log("The voucher type is: "+voucherType);
	log("The Justification type is: "+Justification);
	
	Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
	if(voucherType.equals("meal program")){
	log("In Meal program");
	String dollarLimit= (String) testData.get("dollar_limit");
	Assert.assertTrue(clickElement("meal_program_voucher_page"), "Failed to click voucher page");
	Assert.assertTrue(clickElement("region_dropdown_voucher_page"), "failed to click region dropdown");
	Assert.assertTrue(clickElement("region_dropdown_value_voucher_page"), "failed to click region dropdown value");
	Assert.assertTrue(clickElement("city_dropdown_voucher_page"), "failed to click city dropdown");
	Assert.assertTrue(clickElement("city_dropdown_value_voucher_page"), "failed to click city dropdown value");
	Assert.assertTrue(clickElement("program_svp_voucher_page"), "failed to click SVP drop down");
	AppUtilities.delay(5000);
	Assert.assertTrue(clickElement("program_department_voucher_page"), "Failed to click department popup");
	Assert.assertTrue(clickElement("program_department_value_voucher_page"), "Failed to click department value");
	Assert.assertNotNull(typeText("dollar_limit_voucher_page", dollarLimit), "Failed to enter dollar limit");
	Assert.assertNotNull(typeText("business_justification_voucher_page", Justification), "Failed to enter dollar limit");
	//Assert.assertTrue(clickElement("save_button_voucher_page"), "Failed to click save button");
	//Assert.assertNotNull(waitForElement("required_error_program_name_voucher_page"), "Failed to find the required error message");
	
	} else if (voucherType.equals("meal voucher")){
	Assert.assertTrue(clickElement("request_vouchers_voucher_page"), "Failed to click voucher page");
	Assert.assertNotNull(typeText("business_justification_voucher_page", Justification), "Failed to enter dollar limit");
	//Assert.assertTrue(clickElement("save_button_voucher_page"), "Failed to click save button");
	//Assert.assertNotNull(waitForElement("required_error_voucher_type_voucher_page"), "Failed to find the required error message");
	//Assert.assertNotNull(waitForElement("required_error_quantity_voucher_page"), "Failed to find the required error message");
	if(StringUtils.containsIgnoreCase(getBrowserName(), "safari")) {
		try{
			AppUtilities.delay(2000);	
		WebElement saveBtn = waitForElement("save_button_voucher_page");
		saveBtn.click();
		
		} catch (Exception e){
			
			String exceptionContent = "Exception"+e;
			log(exceptionContent);
			Assert.assertTrue(exceptionContent.contains("required"),"Failed to contain text");
		}
		} else if (StringUtils.containsIgnoreCase(getBrowserName(), "firefox")){
		Assert.assertTrue(clickElement("save_button_voucher_page"), "Failed to click save button");	
		AppUtilities.delay(2000);
		//Validating the error message
		driver.switchTo().alert();
		String actualAlertText = driver.switchTo().alert().getText();
		boolean compareResult  = actualAlertText.contains("required");
		Assert.assertTrue(compareResult, "The alert is not displayed");
        driver.switchTo().alert().accept();
        Assert.assertNotNull(waitForElement("required_error_quantity_voucher_page"), "Failed to find the required error message");
    	}
	}
	Assert.assertTrue(clickElement("cancel_button_voucher_page"), "Failed to click the Cancel button");
	AppUtilities.delay(5000);
	log("Successfully validated voucher name");
	return this;
}


public MenuMakerApp verifyChargeDepartmentDetails(JSONObject voucherDetail){
	String voucherType = (String) voucherDetail.get("voucher_type");
	String deptCode = (String) voucherDetail.get("dept_code");
	Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
	if(voucherType.equals("meal program")) {
		Assert.assertTrue(clickElement("meal_program_voucher_page"), "Failed to click voucher page");
		String dollarLim = (String) voucherDetail.get("dollar_limit");
		//SVP details from test data has to be modified once we get the detailed SVP- Department match, below lines of code has to be modified accordingly
		String svp = (String) voucherDetail.get("svp");
		String deptName = (String) voucherDetail.get("dept_name");
		//String chargeSVPLocator = getUILocator("svp_meal_program_voucher_page").replaceAll("<REPLACE_SVP>",svp);
		//Assert.assertNotNull(waitForElement(chargeSVPLocator), "Failed to find SVP field and its value");
		Assert.assertTrue(clickElement("program_department_voucher_page"), "Failed to click department popup");
		Assert.assertTrue(clickElement("program_department_value_voucher_page"), "Failed to click department value");
		String dollarLimit = getUILocator("dollar_limit_voucher_page");
		Assert.assertTrue(typeText(dollarLimit,dollarLim),"Failed to enter the dollar limit");
	} 
	else if (voucherType.equals("meal voucher")) {
		Assert.assertTrue(clickElement("request_vouchers_voucher_page"), "Failed to click voucher page");
		String compCode = (String) voucherDetail.get("comp_code");
		String departmentCode = getUILocator("department_code_voucher_page");
		departmentCode = departmentCode.replaceAll("<REPLACE_DEPARTMENT_CODE>",deptCode );
		Assert.assertTrue(waitForElementWithText(departmentCode,deptCode), "Failed to find the department code");
		String companyCode = getUILocator("company_code_voucher_page");
		companyCode = companyCode.replaceAll("<REPLACE_COMPANY_CODE>",compCode );
		Assert.assertTrue(waitForElementWithText(companyCode,compCode),"Failed to find the company code");
	}
	Assert.assertTrue(clickElement("cancel_button_voucher_page"), "Failed to click the Cancel button");
	AppUtilities.delay(5000);
	log("Verified charge department details");
	return this;
}

public MenuMakerApp validateMinusButtonForaVoucher(String voucherType){
	Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
	Assert.assertTrue(clickElement("request_vouchers_voucher_page"), "Failed to click voucher page");
	
	List <WebElement> vouchers = waitForElements("vouchers_voucher_page");
	int sizeOfVoucherList= vouchers.size();
	log(Integer.toString(sizeOfVoucherList));
	if(sizeOfVoucherList == 1)
	{
		for(WebElement e : vouchers) {
			e.isDisplayed();
			Assert.assertNull(waitForElement("minus_button_voucher_page",20), "Minus button is displayed");
			}
	}
	log("Successfully validated minus button for a voucher");
	return this;
}


	private MenuMakerApp selectWeekDay(String day){
		String weekdayToSelect= getUILocator("weekday_select_voucher_page");;
		log(day);
		switch (day){
		case "Sunday":
			 weekdayToSelect= weekdayToSelect.replaceAll("<REPLACE_INDEX>", "1");
		case "Monday":
			 weekdayToSelect= weekdayToSelect.replaceAll("<REPLACE_INDEX>", "2");
		case "Tuesday":
			 weekdayToSelect= weekdayToSelect.replaceAll("<REPLACE_INDEX>", "3");
		case "Wednesday":
			 weekdayToSelect= weekdayToSelect.replaceAll("<REPLACE_INDEX>", "4");
		case "Thrusday":
			 weekdayToSelect= weekdayToSelect.replaceAll("<REPLACE_INDEX>", "5");
		case "Friday":
			 weekdayToSelect= weekdayToSelect.replaceAll("<REPLACE_INDEX>", "6");
		case "Saturday":
			 weekdayToSelect= weekdayToSelect.replaceAll("<REPLACE_INDEX>", "7");
		}
		
		Assert.assertTrue(clickElement(weekdayToSelect),"Failed to select week day");
		return this;
	}
	
	public MenuMakerApp verifyRequestOnBehalf(JSONObject voucherDetail, String empName){
			Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
			String voucherType = (String) voucherDetail.get("voucher_type");
			
			if (voucherType.equals("meal voucher"))
			{
				Assert.assertTrue(clickElement("request_vouchers_voucher_page"), "Failed to click voucher page");
				
			}else if (voucherType.equals("meal program"))
			{
				Assert.assertTrue(clickElement("meal_program_voucher_page"), "Failed to click voucher page");
			}
				//String businessJustification = (String) voucherDetail.get("business_justification");
				String requestForUser = (String) voucherDetail.get("request_for");
				//String plannedUseType = (String) voucherDetail.get("planned_use");
				//String voucherValue = (String) voucherDetail.get("value");
				//String voucherQuantity = (String) voucherDetail.get("quantity");
				//String totalVoucherValue = (String) voucherDetail.get("total_voucher_value");
				
				WebElement RequestDropdown = waitForElement("request_for_voucher_page");
				log("Default option selected:"+ RequestDropdown.getText());
				if(requestForUser.equals("On Behalf"))
				{
				String RequestForEmailAdd = (String)voucherDetail.get("request_email");
				String RequestorName= (String)voucherDetail.get("requestor_name");
				WebElement RequestFor = waitForElement("request_for_voucher_page");
				RequestFor.click();
				Select select =new Select(RequestFor);
				select.selectByVisibleText(requestForUser);
				AppUtilities.delay(15000);
								
				String requestForEmailFieldLocator = getUILocator("search_field_on_behalf_voucher_modal_dialog");
				WebElement requestForEmailField = waitForElement(requestForEmailFieldLocator);
				requestForEmailField.sendKeys(RequestForEmailAdd);
				requestForEmailField.sendKeys(Keys.ENTER);
				
				String RequestForEmail = getUILocator("request_email_on_behalf_voucher_modal_dialog");
				RequestForEmail = RequestForEmail.replaceAll("<REPLACE_BEHALF_OF_EMAIL>", RequestForEmailAdd);
				log(RequestForEmail);
				Assert.assertNotNull(waitForElement("label_request_on_behalf_voucher_modal_dialog"), "Failed to open model window");
				Assert.assertNotNull(clickElement(RequestForEmail), "Failed to find email in model window");
				Assert.assertTrue(clickElement("select_on_behalf_voucher_modal_dialog"), "Failed to click on select button in on behalf");
				AppUtilities.delay(2000);
				}
				log("Successfully verified request on behalf");
		return this;
	}
		public MenuMakerApp validateRequestForUser(JSONObject voucherDetail){
		String RequestForEmailAdd = (String)voucherDetail.get("request_email");
		String RequestorName= (String)voucherDetail.get("requestor_name");
		//Assert.assertNotNull(clickElement("select_on_behalf_voucher_modal_dialog"), "Failed to select email in model window");
		AppUtilities.delay(2000);
		
		WebElement Business = waitForElement("business_justification_voucher_page");
		Point p = Business.getLocation();
		((JavascriptExecutor)driver).executeScript("window.scroll(" + p.getX() + "," + (p.getY() - 500) + ");");
		log("Brought the Requestor informations into view");
		AppUtilities.delay(2000);		
		
		String requestOnBehalfNameFieldLocator = getUILocator("requestor_name_voucher_page");
		requestOnBehalfNameFieldLocator= requestOnBehalfNameFieldLocator.replaceAll("<REPLACE_NAME>", RequestorName);
		Assert.assertNotNull(waitForElement(requestOnBehalfNameFieldLocator), "Failed to find On Behalf of Name");
		
		String requestOnBehalfEmailFieldLocator = getUILocator("requestor_email_voucher_page");
		requestOnBehalfEmailFieldLocator= requestOnBehalfEmailFieldLocator.replaceAll("<REPLACE_EMAIL>", RequestForEmailAdd);
		Assert.assertNotNull(waitForElement(requestOnBehalfEmailFieldLocator), "Failed to find On Behalf of email");
		Assert.assertTrue(clickElement("cancel_button_voucher_page"), "Failed to click cancel button");
		AppUtilities.delay(5000);
		/*
		String ReqName= waitForElement("requestor_name_voucher_page").getText();
		String ReqEmail= waitForElement("requestor_email_voucher_page").getText();
		Assert.assertTrue(ReqName.contains(RequestorName),"Failed to find the Requestor Name: "+ RequestorName);
		Assert.assertTrue(ReqEmail.contains(RequestForEmailAdd),"Failed to find the Requestor Email: "+ RequestForEmailAdd);*/
		return this;
		}
		
		public MenuMakerApp cancelRequestForUser(){
			Assert.assertNotNull(clickElement("cancel_on_behalf_voucher_modal_dialog"), "Failed to select email in model window");
			AppUtilities.delay(2000);
			Assert.assertTrue(clickElement("cancel_button_voucher_page"), "Failed to click cancel button");
			AppUtilities.delay(5000);
			log("Successfully verified cancel request on behalf");
			return this;
			}
		
		public MenuMakerApp cancelCreateVouchers(JSONArray voucherDetails, String empName){
			
			Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
			Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
			for (Object voucher: voucherDetails){
				JSONObject voucherDetail = (JSONObject) voucher;
				Assert.assertNotNull(createVoucher(voucherDetail,empName), "Failed to create voucher with details"+voucherDetails.toString());
				Assert.assertNotNull(cancelVoucher(), "Failed to save voucher details");
			}
			Assert.assertTrue(clickElement("cancel_button_voucher_page"), "Failed to click cancel button");
			AppUtilities.delay(5000);
			log("Verified cancellation of created vouchers");
			return this;
		}
		
		public MenuMakerApp cancelVoucher(){
			String businessJustificationFieldLocator = getUILocator("voucher_business_justification_tooltip_voucher_page").replaceAll("<REPLACE_TOOLTIP_MESSAGE>", "Work Late Dinner");
			Assert.assertNotNull(waitForElement(businessJustificationFieldLocator), "failed to find business justification tooltip");
			Assert.assertTrue(clickElement("cancel_button_voucher_page"), "Failed to click cancel button");
			String businessJustificationFieldLocator1 = getUILocator("voucher_business_justification_tooltip_voucher_page").replaceAll("<REPLACE_TOOLTIP_MESSAGE>", "");
			Assert.assertNotNull(waitForElement(businessJustificationFieldLocator1), "failed to find business justification tooltip");
			//Assert.assertNull(waitForElement("business_justification_voucher_page"), "Failed to enter Business Justification");
			//Assert.assertNotNull(waitForElement("voucher_quantity_voucher_page1"), "Failed to clear the quantity");
			
			return this;
		}
		public MenuMakerApp validateMyRequest(JSONArray voucherDetails, String empName){
			
			Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
			Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
			for (Object voucher: voucherDetails){
				JSONObject voucherDetail = (JSONObject) voucher;
				Assert.assertNotNull(createVoucher(voucherDetail,empName), "Failed to create voucher with details"+voucherDetails.toString());
			//	Assert.assertTrue(waitForElementWithText("quantity_voucher_page", Integer.toString(totalVoucherQuantity)), "Failed to find the Total quantity");
			//	Assert.assertTrue(waitForElementWithText("totals_voucher_page", Integer.toString(totalVoucherAmount)), "Failed to find the Totals of the voucher");
				Assert.assertNotNull(saveVoucher(),"Failed to save voucher");
				Assert.assertNotNull(submitVoucher(),"Failed to submit the voucher");
				changeStatus("APPROVED");
				Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
				AppUtilities.delay(3000);
				Assert.assertTrue(clickElement("myrequest_tab_voucher_page"),"Failed to click on my Request page");
				
			}
			Assert.assertNotNull(waitForElement("label_myrequests_my_request_page"), "Failed to find the Totals of the voucher");
			
			selectRequestTypeStatus();
			
			if (voucherTypeInTest.equals("Meal Voucher"))
			{
				validateVoucher();
				
			}else if(voucherTypeInTest.equals("Meal Program")) {
				validateProgram();
			}
			log("Successfully validated the request details");
			return this;
		}
		public MenuMakerApp validateApprovalFlow(JSONArray voucherDetails, String empName){
			
			Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
			Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
			for (Object voucher: voucherDetails){
				JSONObject voucherDetail = (JSONObject) voucher;
				Assert.assertNotNull(createVoucher(voucherDetail,empName), "Failed to create voucher with details"+voucherDetails.toString());
				Assert.assertNotNull(saveVoucher(),"Failed to save voucher");
				approvalFlow(voucherDetail);
				Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
				AppUtilities.delay(3000);
				Assert.assertTrue(clickElement("myrequest_tab_voucher_page"),"Failed to click on my Request page");
				
			}
			return this;
		}
		
		public MenuMakerApp voucherDetailDistributePage(JSONArray voucherDetails, String empName){
			
			Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
			Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
			
			int i=0;
			for (Object voucher: voucherDetails){
				JSONObject vouchersDetailedListObject = (JSONObject) voucher;
				JSONArray vouchersDetailedList = (JSONArray) vouchersDetailedListObject.get("vouchers");
				
				for(Object voucherListitem: vouchersDetailedList){
					validateDistributedVoucher((JSONObject)voucherListitem,i);
					i++;
				}	
				Assert.assertTrue(waitForElement("total_voucher_quantity_distribute_page").getText().contains(Integer.toString(totalVoucherQuantity)), "Failed to validate total quantity");
				Assert.assertTrue(waitForElement("total_voucher_value_distribute_page").getText().contains(Integer.toString(totalVoucherAmount)), "Failed to validate total quantity");
				Assert.assertTrue(waitForElement("total_vouchers_available_distribute_page").getText().contains(Integer.toString(totalVoucherQuantity)), "Failed to validate total quantity");
			}

			return this;
		}
		
		private MenuMakerApp validateDistributedVoucher(JSONObject voucherDetail, int index){

			String plannedUseType = (String) voucherDetail.get("planned_use");
			String voucherValue = (String) voucherDetail.get("value");
			String voucherQuantity = (String) voucherDetail.get("quantity");
			String totalVoucherValue = (String) voucherDetail.get("total_voucher_value");
			log(plannedUseType);

			String WEPlannedUseType= getUILocator("voucher_type_distribute_page");
			WEPlannedUseType =WEPlannedUseType.replaceAll("<REPLACE_INDEX>", Integer.toString(index));
			WebElement plannedUse = waitForElement(WEPlannedUseType);
			log("Default option selected:"+ plannedUse.getText());
			
			String WEVoucherValue = getUILocator("voucher_denomination_distribute_page");
			WEVoucherValue = WEVoucherValue.replaceAll("<REPLACE_INDEX>", Integer.toString(index));
			Assert.assertNotNull(waitForElement(WEVoucherValue), "Failed to find the voucher Value field");
			log(waitForElement(WEVoucherValue).getText() +" "+voucherValue);
			
			String voucherQty = getUILocator("voucher_quantity_distribute_page");
			voucherQty =voucherQty.replaceAll("<REPLACE_INDEX>", Integer.toString(index));
			WebElement WEVoucherQty = waitForElement(voucherQty);
			log("Default option selected:"+ WEVoucherQty.getText()+ " "+voucherQuantity);
			
			String voucherTotal= getUILocator("voucher_total_distribute_page");
			voucherTotal= voucherTotal.replaceAll("<REPLACE_INDEX>", Integer.toString(index));
			WebElement e = waitForElement(voucherTotal);
			Assert.assertTrue(e.getText().contains(totalVoucherValue), "Voucher Values doesnt match");
			//Assert.assertTrue(waitForElementWithText(voucherTotal, "$ "+totalVoucherValue),"Voucher values doesnt match");
			
			String voucherAvailable = getUILocator("vouchers_available_distribute_page");
			voucherAvailable =voucherAvailable.replaceAll("<REPLACE_INDEX>", Integer.toString(index));
			WebElement WEVoucherAvailable = waitForElement(voucherAvailable);
			log("Default option selected:"+ WEVoucherAvailable.getText());
			return this;
		}
		
		public MenuMakerApp addEmailIdDistributeScreen(JSONArray vouchersToCreate){
			log(vouchersToCreate.toJSONString());
			JSONObject voucher = (JSONObject)vouchersToCreate.get(0);
			JSONArray distributeEmailIds = (JSONArray) voucher.get("emails");
			for(int i = 0; i < distributeEmailIds.size(); i++) {
				String emailId = (String)distributeEmailIds.get(i);
				Assert.assertTrue(clickElement("add_recipients_button_distribute_page"), "Failed to click add recipients button");
				Assert.assertNotNull(waitForElement("add_recipients_header_modal_dialog_distribute_page"), "Failed to open model window");
				
				WebElement requestForEmailField = waitForElement("search_recipient_modal_dialog_distribute_page");
				requestForEmailField.sendKeys(emailId);
				requestForEmailField.sendKeys(Keys.ENTER);
				
				String RequestForEmail = getUILocator("request_email_on_behalf_voucher_modal_dialog");
				RequestForEmail = RequestForEmail.replaceAll("<REPLACE_BEHALF_OF_EMAIL>", emailId);
				log(RequestForEmail);
				Assert.assertNotNull(clickElement(RequestForEmail), "Failed to find email in model window");
				//WebElement e = waitForElement("select_on_behalf_voucher_modal_dialog");
				Assert.assertTrue(clickElement("select_on_behalf_voucher_modal_dialog"), "Failed to click Select button in on behalf popup");
				AppUtilities.delay(2000);
				
				Assert.assertNotNull(waitForElement("add_recipients_button_distribute_page"), "Failed to find Add recipients");
				String emailIdInDistributePage = getUILocator("default_ticket_email_after_adding_email_distribute_page");
				emailIdInDistributePage= emailIdInDistributePage.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
				log(waitForElement(emailIdInDistributePage).getText());
				String ticketInDistributePage = getUILocator("default_ticket_type_after_adding_email_distribute_page");
				ticketInDistributePage= ticketInDistributePage.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
				log(waitForElement(ticketInDistributePage).getText());
				String nameInDistributePage = getUILocator("default_ticket_name_after_adding_email_distribute_page");
				nameInDistributePage= nameInDistributePage.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
				log(waitForElement(nameInDistributePage).getText());
				String valueInDistributePage = getUILocator("default_ticket_value_after_adding_email_distribute_page");
				valueInDistributePage= valueInDistributePage.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
				log(waitForElement(valueInDistributePage).getText());
				//log(waitForElement("default_ticket_qty_after_adding_email_distribute_page").getText());
				//log(waitForElement("default_ticket_total_voucher_value_after_adding_email_distribute_page").getText());
				
				
			}
			//waitForElementWithText("default_ticket_email_after_adding_email_distribute_page", (String)distributeEmailIds.get(0));
			
			return this;
		}
		
		public MenuMakerApp approvalFlow(JSONObject voucherDetail){
			
			Assert.assertNotNull(waitForElement("approval_flow_displayed_voucher_page"),"Failed to find approval work flow");
			List <WebElement> titles = waitForElements("node_title_on_voucher_page");
			
			for (WebElement f : titles){
				
				log(f.getText());
			}
			for (WebElement e : titles){
				
				String role = e.getText();
				log(role);
				if(role.equals("Initiator")){
					e.click();
					
					break;
					}
			}
			
			
			return this;
		}
		public MenuMakerApp distributeVoucher(JSONArray voucherDetails, String empName){
			
			log (temp);
			Assert.assertTrue(clickElement("myrequest_tab_voucher_page"), "Failed to click my request link");
			
			String strItem = getUILocator("distribute_column_voucherValue_my_request_page");
			strItem = strItem.replaceAll("<REPLACE_ROWID>", temp);
			strItem = strItem.replaceAll("<TOTAL_VOUCHER_QUANTITY>", Integer.toString(totalVoucherQuantity));
			Assert.assertNotNull(waitForElement(strItem),"Failed to find the quantity in distribute column");
			
			strItem = getUILocator("distribute_column_my_request_page");
			strItem = strItem.replaceAll("<REPLACE_ROWID>", temp);
			Assert.assertTrue(clickElement(strItem), "Failed to click voucher remaining link");
			Assert.assertNotNull(waitForElement("distribute_button_distribute_page"),"Failed to navigate to distribute page");
			AppUtilities.delay(5000);
			
			return this;
		}
		
		public MenuMakerApp distributeMealProgram(JSONArray voucherDetails, String empName){
			
			log (temp);
			Assert.assertTrue(clickElement("myrequest_tab_voucher_page"), "Failed to click my request link");
			
			String strItem = getUILocator("distribute_column_meal_program_my_request_page");
			strItem = strItem.replaceAll("<REPLACE_ROWID>", temp);
			Assert.assertTrue(clickElement(strItem),"Failed to click the distribute in distribute column");
			AppUtilities.delay(5000);
			
			return this;
		}
		
		public MenuMakerApp voucherExpiryDate(){
			
			Assert.assertTrue(waitForElementWithText("voucher_expires_distribute_page","Voucher Expires"),"Failed to find element with the voucher expiry text");
			return this;
		}
		
		
		private void changeStatus(){
			
			AppUtilities.delay(5000);
			JDBCUtil voucherReady = new JDBCUtil();
			try {
				voucherReady.getPropValues();
				voucherReady.CreateConn();
				voucherReady.markVoucherApproved();
				//voucherStatus = voucherReady.changeStatus(voucherTypeInTest,statusToUpdate)	
				voucherStatus = "Approved";
			} catch (IOException e) {
				log("Exception occured while updating JDBC Call"+e);
			}
			
		}
		private void changeStatus(String statusToUpdate){
			
			
			AppUtilities.delay(5000);
			JDBCUtil voucherReady = new JDBCUtil();
			try {
				voucherReady.getPropValues();
				voucherReady.CreateConn();
				//voucherReady.markVoucherApproved();
				if (voucherTypeInTest.equals("Meal Voucher")){
				voucherStatus = voucherReady.changeStatus("MEAL_TICKET",statusToUpdate);	
				voucherStatus = "Approved"; 
				}else if (voucherTypeInTest.equals("Meal Program")){
				voucherStatus = voucherReady.changeStatus("MEAL_PROGRAM",statusToUpdate);	
				voucherStatus = "Approved";
				}
				
				
			} catch (IOException e) {
				log("Exception occured while updating JDBC Call"+e);
			}
			
		}
		
		private MenuMakerApp selectRequestTypeStatus(){
			AppUtilities.delay(4000);
			WebElement requestType = waitForElement("filter_request_type_my_request_page");
			log("Default option selected:"+ requestType.getText());
			requestType.click();
			log(voucherTypeToSelect +voucherStatus);
			Select select =new Select(requestType);
			select.selectByValue(voucherTypeToSelect);
			//log("Option selected:"+ requestType.getText());
			String modifiedStatusForFilter = voucherStatus;
			if(voucherStatus.equals("APPROVED")||voucherStatus.equals("DRAFT")){
			String status = voucherStatus.toLowerCase();
			modifiedStatusForFilter = status.substring(0, 1).toUpperCase() +status.substring(1);
			log(modifiedStatusForFilter);
			}
			WebElement requestStatus = waitForElement("filter_request_status_my_request_page");
			log("Default option selected:"+ requestStatus.getText());
			requestStatus.click();
			Select selectStatus =new Select(requestStatus);
			selectStatus.selectByVisibleText(modifiedStatusForFilter);
			log("Option selected:"+ requestStatus.getText());
			AppUtilities.delay(10000);
			return this;
		}
		
		private MenuMakerApp validateVoucher(){
			
			List <WebElement> myRequests = waitForElements("rows_my_request_page");
			
			log(Integer.toString(myRequests.size()));
			log(voucherTypeInTest +": " +voucherStatus);

			for (int i=0; i< myRequests.size(); i++)
			{
				log("In validate voucher");
				String typeColumn = getUILocator("type_column_my_request_page");
				typeColumn =typeColumn.replaceAll("<REPLACE_ROWID>", Integer.toString(i));
				WebElement Type=	waitForElement(typeColumn);
				if(Type.getText().equals(voucherTypeInTest)){
					log(Type.getText());
					String qtyColumn = getUILocator("quantity_column_my_request_page");
					qtyColumn =qtyColumn.replaceAll("<REPLACE_ROWID>", Integer.toString(i));
					WebElement Quantity=waitForElement(qtyColumn);
					if(Quantity.getText().equals(Integer.toString(totalVoucherQuantity))){
						log(Quantity.getText());
						String dateColumn = getUILocator("request_date_column_my_request_page");
						dateColumn =dateColumn.replaceAll("<REPLACE_ROWID>", Integer.toString(i));
						WebElement date=waitForElement(dateColumn);
						String todaydate = new SimpleDateFormat("MMMMM dd, yyyy").format(new java.util.Date());
						if(date.getText().equals(todaydate)){
							log(date.getText());
							String totalColumn = getUILocator("total_column_my_request_page");
							totalColumn =totalColumn.replaceAll("<REPLACE_ROWID>", Integer.toString(i));
							WebElement Total=waitForElement(totalColumn);
							if(Total.getText().equals(Integer.toString(totalVoucherAmount))){
								log(Total.getText());
								String statusColumn = getUILocator("status_column_my_request_page");
								statusColumn =statusColumn.replaceAll("<REPLACE_ROWID>", Integer.toString(i));
								WebElement Status=waitForElement(statusColumn);
								log(voucherStatus);
								if(Status.getText().equals(voucherStatus)){
									log("Gonna click");
									Status.getText();
									Status.click();
									temp= Integer.toString(i);
									AppUtilities.delay(5000);
									takeScreenshotNow();
									break;
								}
								else{
									
									log(Status.getText());
								}
							}
						}
					}
				}
				
			}
			return this;
		}
		
		private MenuMakerApp validateProgram(){
			
			List <WebElement> myRequests = waitForElements("rows_my_request_page");
			
			log(Integer.toString(myRequests.size()));
			
			
			
			for (int i=0; i< myRequests.size(); i++)
			{
				log("In validate voucher");
				String typeColumn = getUILocator("type_column_my_request_page");
				typeColumn =typeColumn.replaceAll("<REPLACE_ROWID>", Integer.toString(i));
				WebElement Type= waitForElement(typeColumn);
				if(Type.getText().equals(voucherTypeInTest)){
					log(Type.getText());
					/*String qtyColumn = getUILocator("quantity_column_my_request_page");
					qtyColumn =qtyColumn.replaceAll("<REPLACE_ROWID>", Integer.toString(i));
					WebElement Quantity=waitForElement(qtyColumn);
					log(Integer.toString(totalVoucherQuantity)+Quantity.getText());
					if(Quantity.getText().equals(Integer.toString(totalVoucherQuantity))){
						log(Quantity.getText());*/
						String dateColumn = getUILocator("request_date_column_my_request_page");
						dateColumn =dateColumn.replaceAll("<REPLACE_ROWID>", Integer.toString(i));
						WebElement date=waitForElement(dateColumn);
						String todaydate = new SimpleDateFormat("MMMMM dd, yyyy").format(new java.util.Date());
						if(date.getText().equals(todaydate)){
							log(date.getText());
							/*String totalColumn = getUILocator("total_column_my_request_page");
							totalColumn =totalColumn.replaceAll("<REPLACE_ROWID>", Integer.toString(i));
							WebElement Total=waitForElement(totalColumn);
							if(Total.getText().equals(Integer.toString(totalVoucherAmount))){
								log(Total.getText());*/
								String statusColumn = getUILocator("status_column_my_request_page");
								statusColumn =statusColumn.replaceAll("<REPLACE_ROWID>", Integer.toString(i));
								WebElement Status=waitForElement(statusColumn);
								log(voucherStatus);
								if(Status.getText().equals(voucherStatus)){
									log("Gonna click");
									Status.getText();
									Status.click();
									temp= Integer.toString(i);
									AppUtilities.delay(5000);
									takeScreenshotNow();
									break;
								}
								else{
									
									log(Status.getText());
								}
							}
						}
					//}
				//}
			}
			
		return this;
	}
		
	private MenuMakerApp voucherApproval(JSONArray voucherDetails, String status){
		
		Assert.assertTrue(clickElement("myrequest_tab_voucher_page"), "Failed to click my request link");
		String strItem = getUILocator("pending_actions_button_myrequestpage");
		strItem = strItem.replaceAll("<REPLACE_ROWID>", temp);
		strItem = strItem.replaceAll("<REPLACE_ACTION>", status);
		Assert.assertNotNull(clickElement(strItem),"Failed to Approve the voucher");
		waitForElement("voucher_save_status");
		AppUtilities.delay(2000);
		WebElement e = waitForElement("status_column_my_request_page");
		Assert.assertTrue(e.getText().contains(status),"Failed to find the updated status");;
		AppUtilities.delay(5000);
		
		return this;
	}
	
	public MenuMakerApp rejectVoucher(JSONArray voucherDetails, String empName){
		String voucherStatusToUpdate = "Reject";
		voucherApproval(voucherDetails,voucherStatusToUpdate);
		return this;
	}
	public MenuMakerApp ApproveVoucher(JSONArray voucherDetails, String empName){
		String voucherStatusToUpdate = "Approve";
		voucherApproval(voucherDetails,voucherStatusToUpdate);
		return this;
	}
	
	public MenuMakerApp addDelegates(JSONArray delegates){
		log(delegates.toJSONString());
		Assert.assertTrue(clickElement("delegate_button_distribute_page"),"Failed to click on delegate button");
		AppUtilities.delay(5000);
		for (Object e : delegates){
			
			JSONObject delegate = (JSONObject) e;
			addDelegate(delegate);
		}
		Assert.assertTrue(clickElement("done_button_delegate_popup"),"Failed to click on done button");
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"),"Failed to find the save status button");
		Assert.assertNotNull(waitForElement("caffemac_logo"), "Failed to navigate find distribute button");
		return this;
	}
	
	public MenuMakerApp addOtherTypeDelegates(JSONArray delegates){
		log(delegates.toJSONString());
		Assert.assertTrue(clickElement("delegate_button_distribute_page"),"Failed to click on delegate button");
		for (Object e : delegates){
			
			JSONObject delegate = (JSONObject) e;
			addDelegate(delegate);
		}
		//Assert.assertTrue(clickElement("done_button_delegate_popup"),"Failed to click on done button");
		//Assert.assertNotNull(waitForElement("customize_food_item_save_status"),"Failed to find the save status button");
		//Assert.assertNotNull(waitForElement("label_delegate_recipients_delegate_popup"), "Failed to navigate find distribute button");
		return this;
	}
	
	private MenuMakerApp addDelegate(JSONObject delegate){
		
		String delegateName = (String) delegate.get("delegate_name");
		String delegateEmail = (String) delegate.get("delegate_email");
		String delegateType = (String) delegate.get("employee_type");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("add_delegate_button_delegate_popup"), "Failed to click add recipient link");
		
		WebElement e= waitForElement("search_recipients_delegate_popup");
		e.clear();
		e.sendKeys(delegateName);
		e.sendKeys(Keys.ENTER);
		AppUtilities.delay(3000);
		
		//Assert.assertNotNull(waitForElement("label_delegate_recipients_delegate_popup"), "Failed to find delegate recipients pop up");
		//Assert.assertTrue(clickElement("add_recipient_delegate_popup"), "Failed to click recipient link");
		//Assert.assertNotNull(waitForElement(strItem), "Failed to find the email in delegate popup");
		if (delegateType.equals("Type1")){
			String strItem = getUILocator("recipient_email_list_delegate_popup");
			strItem = strItem.replaceAll("<RECIPIENT_EMAIL>", delegateEmail);
			Assert.assertTrue(clickElement(strItem), "Failed to click recipient link");
				
		clickElement("add_recipient_delegate_popup");
		waitForElement(strItem);
		}
		return this;
	}
	
	public MenuMakerApp verifyExistingDelegate(JSONArray delegates){
		//log(delegates.toJSONString());
		Assert.assertTrue(clickElement("delegate_button_distribute_page"),"Failed to click on delegate button");
		
		List <WebElement> delegateList = waitForElements("recipients_delegate_popup");
		int i = delegateList.size();
		log(Integer.toString(i));

		for(int j=0; j<delegateList.size();j++){
			String strItem = getUILocator("delegate_name_after_select");
			strItem = strItem.replaceAll("<REPLACE_INDEX>", Integer.toString(j+2));
			log(waitForElement(strItem).getText());
			String strItem1 = getUILocator("delegate_email_after_select");
			strItem1 = strItem1.replaceAll("<REPLACE_INDEX>", Integer.toString(j+2));
			log(waitForElement(strItem1).getText());
			String strItem2 = getUILocator("delegate_dept_after_select");
			strItem2 = strItem2.replaceAll("<REPLACE_INDEX>", Integer.toString(j+2));
			log(waitForElement(strItem2).getText());
			
		}
		
		/*for (WebElement e : delegateList){
			AppUtilities.delay(3000);
			
			driver.findElement(arg0)
			WebElement delegateName = e.findElement(By.xpath("/div[2]/span[contains(@class,'ng-binding')]"));
			log(delegateName.getText());
			AppUtilities.delay(3000);
			WebElement delegateEmail = e.findElement(By.xpath("/div[3]/span[contains(@class,'ng-binding')]"));
			log(delegateEmail.getText());
			AppUtilities.delay(3000);
			WebElement delegateDepartment = e.findElement(By.xpath("/div[4]/span[contains(@class,'ng-binding')]"));
			log(delegateDepartment.getText());
		}*/
		Assert.assertTrue(clickElement("done_button_delegate_popup"),"Failed to click on done button");
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"),"Failed to find the save status button");
		Assert.assertNotNull(waitForElement("caffemac_logo"), "Failed to navigate find distribute button");
		return this;
	}

	public MenuMakerApp submitSavedVoucher(JSONArray voucherDetails, String empName, String modifyBusinessJustification){
			
			Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
			Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
			for (Object voucher: voucherDetails){
				JSONObject voucherDetail = (JSONObject) voucher;
				Assert.assertNotNull(createVoucher(voucherDetail,empName), "Failed to create voucher with details"+voucherDetails.toString());
				//Assert.assertTrue(waitForElementWithText("quantity_voucher_page", Integer.toString(totalVoucherQuantity)), "Failed to find the Total quantity");
				//Assert.assertTrue(waitForElementWithText("totals_voucher_page", Integer.toString(totalVoucherAmount)), "Failed to find the Totals of the voucher");
				Assert.assertNotNull(saveVoucher(),"Failed to save voucher");
			
			Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");	
			Assert.assertTrue(clickElement("myrequest_tab_voucher_page"),"Failed to click on my Request page");
				
			}
			AppUtilities.delay(15000);
			Assert.assertNotNull(waitForElement("label_myrequests_my_request_page"), "Failed to find the Totals of the voucher");
			String numberOfVouchers = waitForElement("label_myrequests_my_request_page").getText();
			log(numberOfVouchers/*.substring(13, 16)*/);
			
			//String status = "DRAFT";
			//String Status = "Draft";
			selectRequestTypeStatus();
			
			if (voucherTypeInTest.equals("Meal Voucher")){
				//voucherTypeInTest= "Meal Voucher";
				validateVoucher();
			}else if (voucherTypeInTest.equals("Meal Program")){
				//voucherTypeInTest= "Meal Program";
				validateProgram();
			}
			if(modifyBusinessJustification != null){
			modifyVoucher(modifyBusinessJustification);
			}
			Assert.assertNotNull(submitVoucher(),"Failed to submit the voucher");
			log("Successfully submitted the saved voucher");
			return this;
		}
	
	private void modifyVoucher(String modifyBusinessJustification){
		
		log("In modify page");
		Assert.assertNotNull(typeText("business_justification_voucher_page", modifyBusinessJustification), "Failed to enter Business Justification");
		AppUtilities.delay(3000);
	}
	
	public MenuMakerApp validateEscapeButtonInCustomizationPopup(JSONObject customItemDetail){
	//createCategory(customItemDetail);
	try {
		Robot r;
		r = new Robot();
		r.keyPress(KeyEvent.VK_ESCAPE);
	} catch (AWTException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	Assert.assertNotNull(waitForElement("lunch_meal_time"),"Failed to find meal time");
	return this;
	}
	
	public MenuMakerApp addNewIngredients(JSONArray ingredientDetails, String caffeRegion){
		
		Assert.assertNotNull(ingredientDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(ingredientDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		
		//Block Commented by Chithra - DB update code to be replaced with UI code
		/*//removing existing ingredient with same name
		for (Object ingredient: ingredientDetails){
			JSONObject ingredientDetail = (JSONObject) ingredient;
			String ingredientName = (String) ingredientDetail.get("ingredient_name");
				//deleteIngredient(ingredientDetail);
			String dbIngredientCategory = null;
				//driver.navigate().refresh();
			if (ingredientDetail.get("category").equals("Fruit")){
					dbIngredientCategory="fruit";
			}
			try{
				JDBCUtil del = new JDBCUtil();
				del.CreateConn();
				del.deleteIngredientInDb(dbIngredientCategory,ingredientName,caffeRegion);
				del.CloseConn();
			} catch (Exception e){
					log(e.getMessage());
			}
		}*/
		Assert.assertTrue(clickElement("pantry_page"), "Failed to click voucher page");
		Assert.assertTrue(clickElement("ingredients_tab"), "Failed to click voucher page");
		Assert.assertTrue(clickElement("caffe_select_region_default"), "Failed to click voucher page");
		
		String selectRegion = getUILocator("caffe_select_region_ingredients_page");
		selectRegion = selectRegion.replaceAll("<REPLACE_CAFFE_REGION_NAME>", caffeRegion);
		Assert.assertTrue(clickElement(selectRegion), "Failed to click voucher page");
		
		for (Object ingredient: ingredientDetails){
			JSONObject ingredientDetail = (JSONObject) ingredient;
			Assert.assertNotNull(addNewIngredient(ingredientDetail), "Failed to create voucher with details"+ingredientDetails.toString());
			verifyNewIngredient(ingredientDetail);
		}
		//Assert.assertNotNull(waitForElement("label_myrequests_my_request_page"), "Failed to find the Totals of the voucher");
	
		return this;
	}
	
	public MenuMakerApp addNewIngredient(JSONObject ingredientDetail){
		
		Assert.assertTrue(clickElement("add_ingredients_ingredients_page"),  "Failed to click the add ingredient");
		
		String ingredientName= (String) ingredientDetail.get("ingredient_name");
		String ingredientSKU= (String) ingredientDetail.get("sku");
		String ingredientNotes= (String) ingredientDetail.get("notes");
		String ingredientCategory= (String) ingredientDetail.get("category");
		/*String ingredientNameLocator = getUILocator("ingredient_name_ingredients_table");
		ingredientNameLocator = ingredientNameLocator.replaceAll("<REPLACE_INGREDIENT_NAME>", ingredientName);*/
		
		Assert.assertNotNull(waitForElement("header_add_ingredients_popup"),"Failed");
		
		//checkPageIsReady();
		AppUtilities.delay(10000);
		Assert.assertTrue(clickElement("ingredient_name_add_ingredients_popup"),  "Failed to click the add ingredient");
		
		//RandomName Creation for ingredient name to avoid duplicates		
		int randNum = (int) (Math.random() * 10000);
		ingredientName=ingredientName+randNum;
		log(ingredientName);
		writeDataInRunStore("ingredientName",ingredientName);
		
		Assert.assertNotNull(typeText("ingredient_name_add_ingredients_popup", ingredientName),"Failed");
		AppUtilities.delay(2000);
		Assert.assertNotNull(typeText("ingredient_sku_add_ingredients_popup",ingredientSKU),"Failed");
		AppUtilities.delay(2000);
		Assert.assertNotNull(typeText("ingredient_notes_add_ingredients_popup", ingredientNotes),"Failed");
		//Image upload for ingredient is not working currently
		//Assert.assertNotNull(uploadImageToIngredient(ingredientDetail),"Failed");
		WebElement categoryDefault = waitForElement("ingredient_select_category_add_ingredients_popup");
		categoryDefault.click();
		AppUtilities.delay(2000);
		Select category = new Select (categoryDefault);
		category.selectByVisibleText(ingredientCategory);
		Assert.assertTrue(clickElement("ingredient_done_button_ingredients_popup"),  "Failed to click the add ingredient");
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"),"Failed");
		Assert.assertTrue(clickElement("ingredient_cancel_button_ingredients_popup"),  "Failed to click the add ingredient");
		
		return this;
	}
	
	public MenuMakerApp verifyNewIngredient(JSONObject ingredientDetail){
		
		//Assert.assertTrue(clickElement("add_ingredients_ingredients_page"),  "Failed to click the add ingredient");
		
		String ingredientName= readDataFromRunStore("ingredientName");
		String ingredientSKU= (String) ingredientDetail.get("sku");
		String ingredientNotes= (String) ingredientDetail.get("notes");
		String ingredientCategory= (String) ingredientDetail.get("category");
		Assert.assertNotNull(waitForElement("search_ingredients_ingredients_page"),"Failed");
		Assert.assertNotNull(selectCategory(ingredientCategory),"Failed");
		Assert.assertNotNull(typeText("search_ingredients_ingredients_page", ingredientName),"Failed");
		//Added by Chithra
		keyboard.type(Key.ENTER);
		AppUtilities.delay(2000);
		
		//Updated by Chithra
		//Assert.assertNotNull(selectIngredient(ingredientName),"Failed");
		Assert.assertNotNull(waitForElement("ingredient_name_ingredients_table"),"Failed");
		Assert.assertTrue(clickElement("ingredient_name_ingredients_table"),"Failed");
		AppUtilities.delay(5000);
		Assert.assertNotNull(waitForElement("header_add_ingredients_popup"),"Failed");
				
		return this;
	}
	
	public MenuMakerApp selectIngredient(String ingredientName){
		String ingredientNameLocator = getUILocator("ingredient_name_ingredients_table");
		ingredientNameLocator = ingredientNameLocator.replaceAll("<REPLACE_INGREDIENT_NAME>", ingredientName);
		Assert.assertTrue(clickElement(ingredientNameLocator),  "Failed to click the ingredient name");
		Assert.assertNotNull(waitForElement("header_add_ingredients_popup"),"Failed");
		
		return this;
	}
	
	public MenuMakerApp selectCategory(String ingredientCategory){
		String categoryType = getUILocator("ingredient_category_type_select");
		categoryType = categoryType.replaceAll("<REPLACE_CATEGORY>", ingredientCategory);
		Assert.assertTrue(clickElement(categoryType),  "Failed to click the category");
		
		return this;
	}
	
	public MenuMakerApp deleteIngredients(JSONArray ingredientDetails, String caffeRegion){
		
		Assert.assertNotNull(ingredientDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(ingredientDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		
		//Block Commented by Chithra - DB update code to be replaced with UI code
		/*//removing existing ingredient with same name
				for (Object ingredient: ingredientDetails){
					JSONObject ingredientDetail = (JSONObject) ingredient;
					String ingredientName = (String) ingredientDetail.get("ingredient_name");
						//deleteIngredient(ingredientDetail);
					String dbIngredientCategory = null;
						//driver.navigate().refresh();
					if (ingredientDetail.get("category").equals("Fruit")){
							dbIngredientCategory="fruit";
					}
					try{
						JDBCUtil del = new JDBCUtil();
						del.CreateConn();
						del.deleteIngredientInDb(dbIngredientCategory,ingredientName,caffeRegion);
						del.CloseConn();
					} catch (Exception e){
							log(e.getMessage());
					}
				}*/
		Assert.assertTrue(clickElement("pantry_page"), "Failed to click voucher page");
		Assert.assertTrue(clickElement("ingredients_tab"), "Failed to click voucher page");
		Assert.assertTrue(clickElement("caffe_select_region_default"), "Failed to click voucher page");
		
		String selectRegion = getUILocator("caffe_select_region_ingredients_page");
		selectRegion = selectRegion.replaceAll("<REPLACE_CAFFE_REGION_NAME>", caffeRegion);
		Assert.assertTrue(clickElement(selectRegion), "Failed to click voucher page");
			
		Assert.assertTrue(clickElement("ingredients_tab"), "Failed to click voucher page");
		
		for (Object ingredient: ingredientDetails){
			JSONObject ingredientDetail = (JSONObject) ingredient;
			Assert.assertNotNull(addNewIngredient(ingredientDetail), "Failed to create voucher with details"+ingredientDetails.toString());
			verifyNewIngredient(ingredientDetail);
			deleteIngredient(ingredientDetail,caffeRegion);
		}
		//Assert.assertNotNull(waitForElement("label_myrequests_my_request_page"), "Failed to find the Totals of the voucher");
	
		return this;
	}
	
	public MenuMakerApp deleteIngredient(JSONObject ingredientDetail, String caffeRegion){
		String ingredientCategory = (String)ingredientDetail.get("category");
		String ingredientName = (String)ingredientDetail.get("ingredient_name");
		
		//String AlertText = "Are you sure you want to delete ("+ingredientName+")?";
		if (ingredientName.equals("Fruit")){
			ingredientName = "fruit";
		}
		try{
		AppUtilities.delay(4000);	
		
		WebElement e = waitForElement("ingredient_delete_button_ingredients_popup");
		//((JavascriptExecutor)driver).executeScript("deleteIngredient();");
		/*((JavascriptExecutor)driver).executeScript("confirm = function(message){return true;};");
		((JavascriptExecutor)driver).executeScript("alert = function(message){return true;};");
		((JavascriptExecutor)driver).executeScript("prompt = function(message){return true;}");*/
		e.click();
		
		//need to write code for firefox
		} catch(Exception e){
		//	Exception handling for safari
			String exceptionContent = "Exception"+e;
			log(exceptionContent);
			Alert alertObject = driver.switchTo().alert();
			log("Delete button clicked, alert to confirm: "+alertObject.getText());
			alertObject.accept();
		
			/*String exceptionContent = "Exception"+e;
			log(exceptionContent);
			log("I am here"+AlertText);
			//Assert.assertTrue(exceptionContent.contains(AlertText), "Failed to display alert message");
			//db handler to delete item
			//delete from global_ingrednt where global_ingredient_category_id = (select id from global_ingredient_category where category_name = 'fruit') and ingredient_name = 'BlueBerry'
			*/
			/*JDBCUtil del = new JDBCUtil();
			del.CreateConn();
			del.deleteIngredientInDb(ingredientCategory,ingredientName, caffeRegion);
			del.CloseConn();
			log("Deleted Ingredient");*/
		}
		
		return this;
	}
	
	private MenuMakerApp uploadImageToIngredient(JSONObject ingredientDetail) {
		
		String strImageFilePath =(String)ingredientDetail.get("food_item_image_path");
		if(StringUtils.isBlank(strImageFilePath)) {
			log("Image file path is not configured for this food item. Ignoring the file upload");
			return this;
		}
		log("Checking availability of the given file:" + strImageFilePath);
		
		strImageFilePath = strBaseDir + strImageFilePath; 
		
		log(strImageFilePath);
		
		File f = new File(strImageFilePath);
		
		if(! (f.exists() && f.isFile())) {
			strImageFilePath = strBaseDir + File.separator + strImageFilePath;
			log("File doesnt exist. Checking with the framework base dir:" + strImageFilePath);
			f = new File(strImageFilePath);
		}
		Assert.assertTrue(f.exists() && f.isFile(), "Failed to check the given image file");
	
		String strFileUploadButton = getUILocator("ingredient_upload_image_button_add_ingredients_popup");
		WebElement e = waitForElement(strFileUploadButton);
		Assert.assertNotNull(e, "Failed to find the file upload button for the food item");
		//e.sendKeys(strImageFilePath);
		e.click();	
		keyboard.type(Key.ENTER);
		log("The upload button has been clicked");
		AppUtilities.delay(20000);
		
		StringSelection selection = new StringSelection(strImageFilePath);
	    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	    clipboard.setContents(selection, selection);
		log("data has been copied to clipboard");
	
		//keyboard.type(Key.CMD + Key.SHIFT + "g");
		
		
		r.keyPress(KeyEvent.VK_META);
		r.keyPress(KeyEvent.VK_SHIFT);
		r.keyPress(KeyEvent.VK_G);
		AppUtilities.delay(500);
		r.keyRelease(KeyEvent.VK_G);
		r.keyRelease(KeyEvent.VK_SHIFT);
		r.keyRelease(KeyEvent.VK_META);
		
		
		log("CMD + SHIFT key has been clicked");
		AppUtilities.delay(5000);
		
		keyboard.paste(strImageFilePath);
		/*
		r.keyPress(KeyEvent.VK_META);
		r.keyPress(KeyEvent.VK_V);
		AppUtilities.delay(500);
		r.keyRelease(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_META);
		*/
		log("Paste action has been simulated");

		/*
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		*/
		keyboard.type(Key.ENTER);
		log("Simulated Enter #1");
		
		AppUtilities.delay(2000);
		
		/*
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		*/

		keyboard.type(Key.ENTER);
		log("Simualted Enter #2");
		AppUtilities.delay(5000);
		
		//TODO::Need to work on this as sikuli fails now to find the image in the browser
		//check the given file is shown
		//Assert.assertTrue(isImageFoundInScreen(strImageFilePath), "Failed to find the uploaded image in the screen");
		
		Assert.assertNotNull(waitForElement("customize_food_item_save_status"), "Failed as the save status is found after clicking Save button in file upload");
		
		return this;
	}
	
	public MenuMakerApp navigateToMenuPage(){
		driver.navigate().refresh();
		Assert.assertTrue(clickElement("menu_page"), "Failed to navigate to menu page");
		Assert.assertNotNull(waitForElement("dinner_meal_time"), "Failed to find the Dinner Menu after login");	
		
		return this;
	}
	
	//Added by Chithra
	public MenuMakerApp createVoucherAndApprove(JSONArray voucherDetails, String empName){
		final String status = "Approved";
		Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		for (Object voucher: voucherDetails){
			JSONObject voucherDetail = (JSONObject) voucher;
			Assert.assertNotNull(createVoucher(voucherDetail,empName), "Failed to create voucher with details"+voucherDetails.toString());
		}
		Assert.assertNotNull(saveVoucher(),"Failed to save voucher");
		AppUtilities.delay(5000);
		Assert.assertNotNull(submitVoucher(),"Failed to submit the voucher");
		AppUtilities.delay(5000);
		
		Assert.assertNotNull(waitForElements("approval_flow_members_list_box_voucher_page"), "Failed to find the Approval route flow for submitted Voucher");	
		int size = waitForElements("approval_flow_members_list_box_voucher_page").size();
		
		log("Number of Approvals Required: " + size);
		for(int i=0; i<size-1;i++) {
			Assert.assertNotNull(waitForElement("approve_button_voucher_page"), "Failed to find the Approve button");
			Assert.assertNotNull(clickElement("approve_button_voucher_page"), "Failed to find the Approve button");
			Assert.assertNotNull(waitForElement("voucher_save_status"), "Failed to find save status");
		}
			
		AppUtilities.delay(5000);
		log("Validation of Approval Status of Ticket");
		Assert.assertNotNull(waitForElements("approval_page_approved_status_message"), "Failed to find the Approval route with status Approved");
		/*
		List<WebElement> approvalMemberList = waitForElements("approval_page_approved_status_message");
		for(int i=1; i<=approvalMemberList.size()-1;i++) {
			log("Approval Status of "+i+" memeber in Approval Flow: " + approvalMemberList.get(i).getText());
			Assert.assertTrue(approvalMemberList.get(i).getText().contains(status),"Failed since status is not approved for the approval node:" + i); 			
		}*/
		
		return this;
	}
	
	//Jan 24 Added by Chithra
	public MenuMakerApp validateMyRequestDelegate(JSONArray voucherDetails, String empName, String requestStatus){
		
		Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("myrequest_tab_voucher_page"),"Failed to click on my Request page");
		
		Assert.assertNotNull(waitForElement("label_myrequests_my_request_page"), "Failed to find the Totals of the voucher");
		
		voucherStatus = requestStatus;
		selectRequestTypeStatus();
		
		log("Select Status completed");
		
		voucherTypeInTest="Meal Voucher";
		
		if (voucherTypeInTest.equals("Meal Voucher"))
		{
			validateVoucher();
			
		}else if(voucherTypeInTest.equals("Meal Program")) {
			validateProgram();
		}
		log("Successfully validated the request details");
		
		Assert.assertNotNull(waitForElement("select_type_data_myrequestpage"), "Failed to find the Totals of the voucher");
		Assert.assertTrue(clickElement("select_type_data_myrequestpage"), "Failed to click voucher page");
		AppUtilities.delay(3000);
		return this;
	}
	
	
	/*public MenuMakerApp createMealProgramAndApprove(JSONArray voucherDetails, String empName){
		final String status = "Approved";
		Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		for (Object voucher: voucherDetails){
			JSONObject voucherDetail = (JSONObject) voucher;
			Assert.assertNotNull(createVoucher(voucherDetail,empName), "Failed to create voucher with details"+voucherDetails.toString());
		}
		Assert.assertNotNull(saveVoucher(),"Failed to save voucher");
		Assert.assertNotNull(submitVoucher(),"Failed to submit the voucher");
		AppUtilities.delay(5000);
		
		Assert.assertNotNull(waitForElements("approval_flow_members_list_box_voucher_page"), "Failed to find the Approval route flow for submitted Voucher");	
		int size = waitForElements("approval_flow_members_list_box_voucher_page").size();
		
		log("Number of Approvals Required: " + size);
		for(int i=0; i<size-1;i++) {
			Assert.assertNotNull(waitForElement("approve_button_voucher_page"), "Failed to find the Approve button");
			Assert.assertNotNull(clickElement("approve_button_voucher_page"), "Failed to find the Approve button");
			Assert.assertNotNull(waitForElement("voucher_save_status"), "Failed to find save status");
		}
			
		AppUtilities.delay(5000);
		log("Validation of Approval Status of Ticket");
		Assert.assertNotNull(waitForElements("approval_page_approved_status_message"), "Failed to find the Approval route with status Approved");
		
		List<WebElement> approvalMemberList = waitForElements("approval_page_approved_status_message");
		for(int i=1; i<=approvalMemberList.size();i++) {
			log("Approval Status of "+i+" memeber in Approval Flow: " + approvalMemberList.get(i).getText());
			if(approvalMemberList.get(i).getText().contains(status)) {
				log("Approval Successful");
			}
		}
		
		return this;
	}*/
	
	public MenuMakerApp validateMealVoucherDistribute(JSONArray voucherDetails, String empName, String requestStatus, String email){
		Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("myrequest_tab_voucher_page"),"Failed to click on my Request page");
		Assert.assertNotNull(waitForElement("label_myrequests_my_request_page"), "Failed to find the Totals of the voucher");
		voucherStatus = requestStatus;
		voucherTypeInTest="0";
		selectRequestTypeStatus();
		AppUtilities.delay(3000);		
		Assert.assertNotNull(waitForElement("select_type_data_myrequestpage"), "Failed to find the Totals of the voucher");
		Assert.assertTrue(clickElement("select_type_data_myrequestpage"), "Failed to click voucher page");
		AppUtilities.delay(3000);
		Assert.assertNotNull(waitForElement("add_recipient_link_distribute_page"), "Failed to find the Add Recipient link in Distribute page");
		Assert.assertTrue(clickElement("add_recipient_link_distribute_page"),"Failed to click on Add Recipient link in Distribute page");
		
		AppUtilities.delay(3000);
		
		Assert.assertNotNull(waitForElement("add_recipients_header_modal_dialog_distribute_page"), "Failed to find the Add Recipient Label in Add Recipient modal");
		Assert.assertNotNull(waitForElement("search_recipient_modal_dialog_distribute_page"), "Failed to find the Search Field in Add Recipient modal");
		
		WebElement e= waitForElement("search_recipient_modal_dialog_distribute_page");
		e.clear();
		e.sendKeys(empName);
		e.sendKeys(Keys.ENTER);
		AppUtilities.delay(3000);
		
		Assert.assertNotNull(waitForElement("select_recipient_data_addrecipientmodal"), "Failed to find the receipient search data in Add Recipient dialog");
		Assert.assertTrue(clickElement("select_recipient_data_addrecipientmodal"),"Failed to click on receipient search data in Add Recipient dialog");
		
		Assert.assertNotNull(waitForElement("select_button_addrecipientmodal"), "Failed to find the Select button in Add Recipient dialog");
		Assert.assertTrue(clickElement("select_button_addrecipientmodal"),"Failed to click on Select button in Add Recipient dialog");
		AppUtilities.delay(3000);
		
		Assert.assertNotNull(waitForElement("default_ticket_type_after_adding_email_distribute_page"), "Failed to find the Recipient Vocher Type data in Distribute page");
		Assert.assertNotNull(waitForElement("default_ticket_name_after_adding_email_distribute_page"), "Failed to find the Recipient Name data data in Distribute page");
		
		Assert.assertNotNull(waitForElement("distribute_button_distribute_page"), "Failed to find the Distribute button in Distribute page");
		Assert.assertTrue(clickElement("distribute_button_distribute_page"),"Failed to click on Distribute button in Distribute page");
		
		AppUtilities.delay(3000);
		Assert.assertNotNull(waitForElement("header_label_distributesummarydialog"), "Failed to find the Distributive summary modal");
		Assert.assertNotNull(waitForElement("successful_distribution_label_distributesummarydialog"), "Failed to find the successful message in Distributive summary modal");
		Assert.assertTrue(clickElement("ok_button_distributesummarydialog"),"Failed to click on Ok button in Distributive summary modal");
		
		AppUtilities.delay(3000);	
		
		Assert.assertNotNull(waitForElement("distribution_success_message_distribute_page"), "Failed to find the Distibution success message in Distribute page");
		
		return this;
	}
	
	public MenuMakerApp validateMealProgramDistribute(JSONArray voucherDetails, String requestStatus, String dsitributeName){
		Assert.assertNotNull(voucherDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(voucherDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		Assert.assertTrue(clickElement("voucher_page"), "Failed to click voucher page");
		
		Assert.assertTrue(clickElement("myrequest_tab_voucher_page"),"Failed to click on my Request page");
		Assert.assertNotNull(waitForElement("label_myrequests_my_request_page"), "Failed to find the Totals of the voucher");
		voucherStatus = requestStatus;
		
		selectRequestTypeStatus();
			
		Assert.assertNotNull(waitForElement("select_type_data_myrequestpage"), "Failed to find the Totals of the voucher");
		Assert.assertTrue(clickElement("select_type_data_myrequestpage"), "Failed to click voucher page");
		
		
		Assert.assertNotNull(waitForElement("not_enrolled_default_meal_program_distribute_page"), "Failed to find the Not Enrolled tab");
		
		
		Assert.assertNotNull(waitForElement("department_select_meal_program_distribute_page"), "Failed to find the Department drop down in Meal Program Distribute page");
		Assert.assertTrue(clickElement("department_select_meal_program_distribute_page"), "failed to click Department drop down in Meal Program Distribute page");
		Assert.assertTrue(clickElement("department_select_value_meal_program_distribute_page"), "failed to click Department drop down option in Meal Program Distribute page");
		
		Assert.assertNotNull(typeText("search_member_field_meal_program_distribute_page", dsitributeName), "Failed to enter member for enrollment");
				
		Assert.assertTrue(clickElement("search_button_meal_program_distribute_page"), "failed to click Search button in Meal Program Distribute page");
		AppUtilities.delay(3000);			
		Assert.assertNotNull(waitForElement("select_member_checkbox_meal_program_distribute_page"), "Failed to find the check box to select memeber for enrollment in Meal Program Distribute page");
		Assert.assertTrue(clickElement("select_member_checkbox_meal_program_distribute_page"), "Failed to click the check box to select memeber for enrollment in Meal Program Distribute page");
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("update_button_meal_program_distribute_page"), "Failed to click the update button in Meal Program Distribute page");
		
		Assert.assertNotNull(waitForElement("voucher_save_status"), "Failed to find save status");
		
		Assert.assertNotNull(waitForElement("enrolled_tab_meal_program_distribute_page"), "Failed to find the Enrolled tab in Meal Program Distribute page");
		Assert.assertTrue(clickElement("enrolled_tab_meal_program_distribute_page"), "Failed to click the Enrolled tab in Meal Program Distribute page");
		
		String enrolledName = getUILocator("search_result_name_data_meal_program_distribute_page");	
		enrolledName=enrolledName.replaceAll("<REPLACE_TEXT>",dsitributeName );
		
		log("enrolledName: "+enrolledName);
		AppUtilities.delay(3000);
		Assert.assertNotNull(waitForElement(enrolledName), "Failed to find the Enrolled person name under Enrolled tab after distribution in Meal Program Distribute page");
		
		Assert.assertNotNull(waitForElement("resend_button_meal_program_distribute_page"), "Failed to find the Resend button under Enrolled tab after distribution in Meal Program Distribute page");
		
		Assert.assertNotNull(waitForElement("select_member_checkbox_meal_program_distribute_page"), "Failed to find the check box to select memeber for enrollment in Meal Program Distribute page");
		Assert.assertTrue(clickElement("select_member_checkbox_meal_program_distribute_page"), "Failed to click the check box to select memeber for enrollment in Meal Program Distribute page");
		
		Assert.assertTrue(clickElement("update_button_meal_program_distribute_page"), "Failed to click the update button in Meal Program Distribute page");
		
		Assert.assertNotNull(waitForElement("voucher_save_status"), "Failed to find save status");
		
		return this;
	}
	
	
	//Added by Chithra
	public MenuMakerApp editIngredients(JSONArray ingredientDetails, String caffeRegion){
		
		Assert.assertNotNull(ingredientDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(ingredientDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		
		
		Assert.assertTrue(clickElement("pantry_page"), "Failed to click voucher page");
		Assert.assertTrue(clickElement("ingredients_tab"), "Failed to click voucher page");
		Assert.assertTrue(clickElement("caffe_select_region_default"), "Failed to click voucher page");
		
		String selectRegion = getUILocator("caffe_select_region_ingredients_page");
		selectRegion = selectRegion.replaceAll("<REPLACE_CAFFE_REGION_NAME>", caffeRegion);
		Assert.assertTrue(clickElement(selectRegion), "Failed to click voucher page");
		
		for (Object ingredient: ingredientDetails){
			JSONObject ingredientDetail = (JSONObject) ingredient;
			Assert.assertNotNull(addNewIngredient(ingredientDetail), "Failed to create voucher with details"+ingredientDetails.toString());
			verifyNewIngredient(ingredientDetail);
			Assert.assertNotNull(uploadImageFile(ingredientDetail,"ingredient_upload_image_button_add_ingredients_popup"), "Failed to upload the image for the ingredient");
			Assert.assertNotNull(typeText("ingredient_notes_add_ingredients_popup", "Updated for testing"),"Failed");
			Assert.assertTrue(clickElement("ingredient_done_button_ingredients_popup"), "Failed to click Update page");
		}
		
		return this;
	}
	
	public MenuMakerApp uploadImageFile(JSONObject jsonObjectWithFilePath, String locator) {
		String strImageFilePath =(String)jsonObjectWithFilePath.get("image_path");
		if(StringUtils.isBlank(strImageFilePath)) {
			log("Image file path is not configured for this food item. Ignoring the file upload");
			return this;
		}
		log("Checking availability of the given file:" + strImageFilePath);
		
		strImageFilePath = strBaseDir + strImageFilePath; 
		
		log(strImageFilePath);
		
		File f = new File(strImageFilePath);
		
		if(! (f.exists() && f.isFile())) {
			strImageFilePath = strBaseDir + strImageFilePath;
			log("File doesnt exist. Checking with the framework base dir:" + strImageFilePath);
			f = new File(strImageFilePath);
		}
		Assert.assertTrue(f.exists() && f.isFile(), "Failed to check the given image file");
		
		AppUtilities.delay(6000);
		
		//Commented below code line for handling string replacement - Chithra Jan 31
		//String strFileUploadButton = getUILocator(locator);
		WebElement e = waitForElement(locator);
		Assert.assertNotNull(e, "Failed to find the file upload button");
		//e.sendKeys(strImageFilePath);
		e.click();	
		keyboard.type(Key.ENTER);
		log("The upload button has been clicked");
		AppUtilities.delay(20000);
		
		StringSelection selection = new StringSelection(strImageFilePath);
	    Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	    clipboard.setContents(selection, selection);
		log("data has been copied to clipboard");
	
		//keyboard.type(Key.CMD + Key.SHIFT + "g");
		
		
		r.keyPress(KeyEvent.VK_META);
		r.keyPress(KeyEvent.VK_SHIFT);
		r.keyPress(KeyEvent.VK_G);
		AppUtilities.delay(500);
		r.keyRelease(KeyEvent.VK_G);
		r.keyRelease(KeyEvent.VK_SHIFT);
		r.keyRelease(KeyEvent.VK_META);
		
		
		log("CMD + SHIFT key has been clicked");
		AppUtilities.delay(5000);
		
		keyboard.paste(strImageFilePath);
		/*
		r.keyPress(KeyEvent.VK_META);
		r.keyPress(KeyEvent.VK_V);
		AppUtilities.delay(500);
		r.keyRelease(KeyEvent.VK_V);
		r.keyRelease(KeyEvent.VK_META);
		*/
		log("Paste action has been simulated");

		/*
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		*/
		keyboard.type(Key.ENTER);
		log("Simulated Enter #1");
		
		AppUtilities.delay(2000);
		
		/*
		r.keyPress(KeyEvent.VK_ENTER);
		r.keyRelease(KeyEvent.VK_ENTER);
		*/

		keyboard.type(Key.ENTER);
		log("Simualted Enter #2");
		AppUtilities.delay(5000);
		
		AppUtilities.delay(5000);
		
		return this;
	}
	
	public MenuMakerApp removeAttachment(JSONArray ingredientDetails, String caffeRegion){
		
		Assert.assertNotNull(ingredientDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(ingredientDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		
		
		Assert.assertTrue(clickElement("pantry_page"), "Failed to click voucher page");
		Assert.assertTrue(clickElement("ingredients_tab"), "Failed to click voucher page");
		Assert.assertTrue(clickElement("caffe_select_region_default"), "Failed to click voucher page");
		
		String selectRegion = getUILocator("caffe_select_region_ingredients_page");
		selectRegion = selectRegion.replaceAll("<REPLACE_CAFFE_REGION_NAME>", caffeRegion);
		Assert.assertTrue(clickElement(selectRegion), "Failed to click voucher page");
		
		for (Object ingredient: ingredientDetails){
			JSONObject ingredientDetail = (JSONObject) ingredient;
			Assert.assertNotNull(addNewIngredient(ingredientDetail), "Failed to create voucher with details"+ingredientDetails.toString());
			verifyNewIngredient(ingredientDetail);
			//Updated by Chithra - Jan 31
			Assert.assertNotNull(uploadImageFile(ingredientDetail, getUILocator("ingredient_upload_image_button_add_ingredients_popup")), "Failed to upload the image for the ingredient");
			Assert.assertNotNull(typeText("ingredient_notes_add_ingredients_popup", "Updated for testing"),"Failed while uploading attachment image");
			Assert.assertTrue(clickElement("ingredient_done_button_ingredients_popup"), "Failed to click Update button");
			verifyNewIngredient(ingredientDetail);
			Assert.assertNotNull(waitForElement("ingredient_remove_image_button_ingredients_popup"), "Failed to find Remove Image button");
			Assert.assertTrue(clickElement("ingredient_remove_image_button_ingredients_popup"), "Failed to click Remove Image button");
			AppUtilities.delay(3000);
			Assert.assertNotNull(waitForElement("ingredient_default_image_ingredients_popup"), "Failed to find save status");
			log("Image Attachment removed successfully");
		}
		
		return this;
	}
	
	public MenuMakerApp createAnnouncement(JSONArray announcementDetails, String caffeRegion, boolean isFutureDateToBeSelect){
		
		
		Assert.assertNotNull(announcementDetails, "Failed as the vouchers to be created found to be null");
		Assert.assertTrue(announcementDetails.size() > 0, "Failed as the vouchers to be created found to be empty");
		
		
		Assert.assertTrue(clickElement("admin_page"), "Failed to click admin page");
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("current_caffe_region"), "Failed to click voucher page");
		
		String selectRegion = getUILocator("select_caffe_region");
		selectRegion = selectRegion.replaceAll("<REPLACE_CAFFE_REGION>", caffeRegion);
		Assert.assertTrue(clickElement(selectRegion), "Failed to click voucher page");
		AppUtilities.delay(6000);
		
		for (Object announcement: announcementDetails){
			JSONObject announcementDetail = (JSONObject) announcement;
			Assert.assertNotNull(addNewAnnouncement(announcementDetail,isFutureDateToBeSelect), "Failed to create announcement with details"+announcementDetail.toString());
		}
		
		return this;
	}
	
	public MenuMakerApp selectUserRole(String caffeRegion, String leadChef, String caffeAdmin, String refundAdmin) {

		int leafChefIndex = 1;
		int caffeAdminIndex = 2;
		int refundAdminIndex = 3;

		Assert.assertTrue(clickElement("admin_page"), "Failed to click admin page");
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("user_role_tab"), "Failed to click user Role tab page");
		AppUtilities.delay(3000);
		Assert.assertTrue(clickElement("current_caffe_region"), "Failed to click voucher page");

		String selectRegion = getUILocator("select_caffe_region");
		selectRegion = selectRegion.replaceAll("<REPLACE_CAFFE_REGION>", caffeRegion);
		Assert.assertTrue(clickElement(selectRegion), "Failed to click voucher page");
		AppUtilities.delay(6000);

		List<WebElement> userRoleList = waitForElements("user_role_search_field");
		List<WebElement> addUserRole = waitForElements("add_button_user_role");
		// Search user role for Lead Chef

		String userLabel = getUILocator("user_labels_lead_chef");
		userLabel = userLabel.replaceAll("<REPLACE_TEXT>", leadChef);

		if (waitForElement(userLabel) != null) {
			log("User" + leadChef + " added already as Lead Chef");
			log("User already available as admin... Delete and readd flow");
			String deleteLCLoc = getUILocator("delete_role_leadChef_admin_page").replaceAll("<REPLACE_TEXT>", leadChef);
			deleteLCLoc = deleteLCLoc.replaceAll("<REPLACE_INDEX>", Integer.toString(leafChefIndex));
			Assert.assertTrue(clickElement(deleteLCLoc), "Failed to seelct user name from list visible");
			log("Adding Refund Admin with given test data");
			WebElement refundAdminLocator = userRoleList.get(0);
			refundAdminLocator.sendKeys(leadChef);
			String userRoleLocator = getUILocator("select_name_user_role").replaceAll("<REPLACE_TEXT>", leadChef);
			Assert.assertTrue(clickElement(userRoleLocator), "Failed to select user name from list visible");
			AppUtilities.delay(2000);
			if (addUserRole.get(0).isEnabled()) {
				addUserRole.get(0).click();
				AppUtilities.delay(2000);
				log("Successfully clicked on Add user Role button");
			}
		}
		String userLabel1 = getUILocator("user_labels_caffe_admin");
		userLabel1 = userLabel1.replaceAll("<REPLACE_TEXT>", caffeAdmin);
		if (waitForElement(userLabel1) != null) {
			log("User" + caffeAdmin + " added already as Caffe Admin");
			log("User already available as admin... Delete and readd flow");
			String deleteCALoc = getUILocator("delete_role_caffeeAdmin_admin_page").replaceAll("<REPLACE_TEXT>",
					caffeAdmin);
			deleteCALoc = deleteCALoc.replaceAll("<REPLACE_INDEX>", Integer.toString(caffeAdminIndex));
			Assert.assertTrue(clickElement(deleteCALoc), "Failed to seelct user name from list visible");
			log("Adding Refund Admin with given test data");
			WebElement refundAdminLocator = userRoleList.get(1);
			refundAdminLocator.sendKeys(caffeAdmin);
			AppUtilities.delay(2000);
			String userRoleLocator = getUILocator("select_name_user_role").replaceAll("<REPLACE_TEXT>", caffeAdmin);
			Assert.assertTrue(clickElement(userRoleLocator), "Failed to select user name from list visible");
			AppUtilities.delay(2000);
			if (addUserRole.get(1).isEnabled()) {
				addUserRole.get(1).click();
				AppUtilities.delay(2000);
				log("Successfully clicked on Add user Role button");
			}
		}
		String userLabel2 = getUILocator("user_labels_refund_admin");
		userLabel2 = userLabel2.replaceAll("<REPLACE_TEXT>", refundAdmin);
		if (waitForElement(userLabel2) != null) {
			log("User" + refundAdmin + " added already as Refund Admin");
			log("User already available as admin... Delete and readd flow");
			String deleteRALoc = getUILocator("delete_role_refundAdmin_admin_page").replaceAll("<REPLACE_TEXT>",
					refundAdmin);
			deleteRALoc = deleteRALoc.replaceAll("<REPLACE_INDEX>", Integer.toString(refundAdminIndex));
			Assert.assertTrue(clickElement(deleteRALoc), "Failed to seelct user name from list visible");
			log("Adding Refund Admin with given test data");
			WebElement refundAdminLocator = userRoleList.get(2);
			refundAdminLocator.sendKeys(refundAdmin);
			AppUtilities.delay(2000);
			String userRoleLocator = getUILocator("select_name_user_role").replaceAll("<REPLACE_TEXT>", refundAdmin);
			Assert.assertTrue(clickElement(userRoleLocator), "Failed to select user name from list visible");
			AppUtilities.delay(2000);
			if (addUserRole.get(2).isEnabled()) {
				addUserRole.get(2).click();
				AppUtilities.delay(2000);
				log("Successfully clicked on Add user Role button");
			}
		}
		AppUtilities.delay(2000);
		// Save Changes
		Assert.assertNotNull(waitForElement("save_admin_page"), "Failed to find save button for user role changes");
		Assert.assertTrue(clickElement("save_admin_page"), "Failed to save user role changes");
		AppUtilities.delay(2000);
		return this;
	}

	public MenuMakerApp addNewAnnouncement(JSONObject announcementDetail, boolean isFutureDateToBeSelect){
		int i=0;
		String announcementTitle= (String) announcementDetail.get("title");
		String announcementDescription= (String) announcementDetail.get("description");
		JSONArray locationDetails = (JSONArray) announcementDetail.get("location");
		Assert.assertTrue(clickElement("add_announcement_link_admin_page"),  "Failed to click the add announcement link");
		AppUtilities.delay(2000);
		
		//RandomName Creation for title		
		int randNum = (int) (Math.random() * 1000);
		announcementTitle=announcementTitle+randNum;
		log(announcementTitle);		
				
		//Announcement Title Enter for latest announcement 
		Assert.assertNotNull(waitForElements("announcement_title_announcement_page"), "Failed to find the announcement title field locators");
		List<WebElement> announcementTitleLocators = waitForElements("announcement_title_announcement_page");
		String announcementLocatorField;
		if(announcementTitleLocators.size()>1) {
			i=announcementTitleLocators.size()-1;			
		}else {
			i=0;
		}
		announcementLocatorField = getUILocator("announcement_title_field_announcement_page");
		announcementLocatorField=announcementLocatorField.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
		
		WebElement titleField = waitForElement(announcementLocatorField);
		titleField.sendKeys(announcementTitle);
		AppUtilities.delay(2000);
		//Announcement DateTime Field for latest announcement 
		i=0;
		Assert.assertNotNull(waitForElements("announcement_date_time_announcement_page"), "Failed to find the announcement datetime field locators");
		List<WebElement> announcementDateTimeLocators = waitForElements("announcement_date_time_announcement_page");
		String announcementDateTimeLocatorField;
		if(announcementDateTimeLocators.size()>1) {
			i=announcementDateTimeLocators.size()-1;		
		}else {
			i=0;
		}
		announcementDateTimeLocatorField = getUILocator("announcement_date_time_field_announcement_page");
		announcementDateTimeLocatorField=announcementDateTimeLocatorField.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			
		DateFormat dateFmt = new SimpleDateFormat("MMM dd, yyyy");
		Date date = new Date();
		String currDate= dateFmt.format(date);
		WebElement dateTimeField = waitForElement(announcementDateTimeLocatorField);
		dateTimeField.sendKeys(currDate);
		
		//Announcement Description Field for latest announcement 
		i=0;
		Assert.assertNotNull(waitForElements("announcement_description_announcement_page"), "Failed to find the announcement description field locators");
		List<WebElement> announcementDescriptionLocators = waitForElements("announcement_description_announcement_page");
		String announcementDescriptionLocatorField;
		if(announcementDescriptionLocators.size()>1) {
			i=announcementDescriptionLocators.size()-1;	
		}else {
			i=0;
		}
		announcementDescriptionLocatorField = getUILocator("announcement_description_field_announcement_page");
		announcementDescriptionLocatorField=announcementDescriptionLocatorField.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
				
		WebElement descriptionField = waitForElement(announcementDescriptionLocatorField);
		descriptionField.sendKeys(announcementDescription);
		
		//Select Location link for latest announcement 
		i=0;
		Assert.assertNotNull(waitForElements("announcement_select_location_announcement_page"), "Failed to find the select location link locators");
		List<WebElement> announcementSelectLocationLocators = waitForElements("announcement_select_location_announcement_page");
		String announcementSelectLocationLink;
		if(announcementSelectLocationLocators.size()>1) {
			i=announcementSelectLocationLocators.size()-1;			
		}else {
			i=0;
		}
		announcementSelectLocationLink = getUILocator("announcement_select_location_link_announcement_page");
		announcementSelectLocationLink=announcementSelectLocationLink.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
							
		WebElement selectLocationLink = waitForElement(announcementSelectLocationLink);
		selectLocationLink.click();
			
		//Location check box selection
		int index=0;
		Assert.assertNotNull(waitForElement("header_select_location_popup"), "Failed to find the Select locations popup");
		Assert.assertNotNull(locationDetails, "Failed as the location to be added found to be null");
		Assert.assertTrue(locationDetails.size() > 0, "Failed as the location to be added found to be empty");
				
		for (Object locationDetail: locationDetails){
			JSONObject locDetail = (JSONObject) locationDetail;
			String locationName = (String) locDetail.get("location_name");
			String locationType = (String) locDetail.get("location_type");
			//Select Location Type drop down for latest announcement 
			Select select = new Select(waitForElement("location_type_drop_down_select_locations_page"));
			select.selectByVisibleText(locationType);
			AppUtilities.delay(3000);
			//Click on location check box
			List<WebElement> locationLabelLocators = waitForElements("location_label_locations_page");
			
			for(int j=0; j<locationLabelLocators.size(); j++) {
				if(locationLabelLocators.get(j).getText().equalsIgnoreCase(locationName)) {
					index=j;
				}
			}			
			index=index+1;
			
			String locationNameLabel = getUILocator("location_checkbox_select_locations_page");
			locationNameLabel=locationNameLabel.replaceAll("<REPLACE_INDEX>", Integer.toString(index));	
			WebElement LocationNameCheckBox = waitForElement(locationNameLabel);
			LocationNameCheckBox.click();	
		}
		Assert.assertNotNull(waitForElement("ok_button_select_locations_page"),"Failed to find Ok button in Select locations popup");
		Assert.assertTrue(clickElement("ok_button_select_locations_page"),"Failed to click Ok button in Select locations popup");
		AppUtilities.delay(3000);
		String locationLabelValidation =  getUILocator("location_label_announcement_page");
		locationLabelValidation=locationLabelValidation.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
		log("Location validation message: "+waitForElement(locationLabelValidation).getText());
		Assert.assertTrue(waitForElement(locationLabelValidation).getText().equalsIgnoreCase(locationDetails.size()+" location selected"),"Failed to find the location selected message");
		
		//FutureDate Selection
		log("isFutureDateToBeSelected: "+isFutureDateToBeSelect);
		
		if(isFutureDateToBeSelect) {
			//Selection of Future Date for Start Date
			i=0;
			Assert.assertNotNull(waitForElements("announcement_startdate_announcement_page"), "Failed to find the start date picker field locators");
			List<WebElement> announcementStartDateLocators = waitForElements("announcement_startdate_announcement_page");
			String announcementStartDateFieldLocator;
			if(announcementStartDateLocators.size()>1) {
				i=announcementStartDateLocators.size()-1;			
			}else {
				i=0;
			}
			announcementStartDateFieldLocator = getUILocator("announcement_startdate_field_announcement_page");
			announcementStartDateFieldLocator=announcementStartDateFieldLocator.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			log("announcementStartDateFieldLocator: "+announcementStartDateFieldLocator+" i:"+i);	
			
			WebElement startDateField = waitForElement(announcementStartDateFieldLocator);
			startDateField.click();
			AppUtilities.delay(6000);
			
			String futureMonthButtonStartDate = getUILocator("futuremonthbutton_startdate_calendarpicker_announcement_page");
			futureMonthButtonStartDate=futureMonthButtonStartDate.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			log("futureMonthButtonStartDate: "+futureMonthButtonStartDate+" i:"+i);	
			
			WebElement startDateFutureMonthButton = waitForElement(futureMonthButtonStartDate);
			startDateFutureMonthButton.click();
			AppUtilities.delay(6000);
			
			/*String futureMonthDayButtonStartDate = getUILocator("announcement_startdate_selectDay_announcement_page");
			futureMonthDayButtonStartDate=futureMonthDayButtonStartDate.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			futureMonthDayButtonStartDate=futureMonthDayButtonStartDate.replaceAll("<REPLACE_DAY>", "07");
			log("futureMonthDayButtonStartDate: "+futureMonthDayButtonStartDate+" i:"+i);	
			
			WebElement startDayFutureMonthButton = waitForElement(futureMonthDayButtonStartDate);
			startDayFutureMonthButton.click();
			AppUtilities.delay(6000);*/
			
			keyboard.type(Key.ENTER);
			AppUtilities.delay(3000);
			
			String announcementEndDateFieldLocator= getUILocator("announcement_enddate_field_announcement_page");
			announcementEndDateFieldLocator=announcementEndDateFieldLocator.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			log("announcementEndDateFieldLocator: "+announcementEndDateFieldLocator+" i:"+i);	
			
			WebElement endDateField = waitForElement(announcementEndDateFieldLocator);
			endDateField.click();
			AppUtilities.delay(3000);
						
			String futureMonthButtonEndDate = getUILocator("futuremonthbutton_enddate_calendarpicker_announcement_page");
			futureMonthButtonEndDate=futureMonthButtonEndDate.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			log("futureMonthButtonEndDate: "+futureMonthButtonEndDate+" i:"+i);	
			
			WebElement endDateFutureMonthButton = waitForElement(futureMonthButtonEndDate);
			endDateFutureMonthButton.click();
			AppUtilities.delay(3000);
			endDateFutureMonthButton.click();
			AppUtilities.delay(3000);
			
			/*String futureMonthDayButtonEndDate = getUILocator("announcement_enddate_selectDay_announcement_page");
			futureMonthDayButtonEndDate=futureMonthDayButtonEndDate.replaceAll("<REPLACE_INDEX>", Integer.toString(i));
			futureMonthDayButtonEndDate=futureMonthDayButtonEndDate.replaceAll("<REPLACE_DAY>", "09");
			log("futureMonthDayButtonEndDate: "+futureMonthDayButtonEndDate+" i:"+i);	
			
			WebElement endDayFutureMonthButton = waitForElement(futureMonthDayButtonEndDate);
			endDayFutureMonthButton.click();
			AppUtilities.delay(6000);
			*/
			
			keyboard.type(Key.ENTER);
			AppUtilities.delay(3000);
			
			log("Successfully selected future dates for Start and End Display Range fields");
		}
		
		
		//Save button Click		
		i=0;
		Assert.assertNotNull(waitForElements("save_buttons_announcement_page"), "Failed to find the save button locators");
		List<WebElement> announcementSaveButtonLocators = waitForElements("save_buttons_announcement_page");
		String announcementSaveButtonLocator;
		if(announcementSaveButtonLocators.size()>1) {
			i=announcementSaveButtonLocators.size()-1;
		}else {
			i=0;
		}
		announcementSaveButtonLocator = getUILocator("save_button_announcement_page");
		announcementSaveButtonLocator=announcementSaveButtonLocator.replaceAll("<REPLACE_INDEX>", Integer.toString(i));				
		WebElement saveButton = waitForElement(announcementSaveButtonLocator);
		saveButton.click();			
		Assert.assertNotNull(waitForElement("voucher_save_status"), "Failed to find save status");		
		AppUtilities.delay(3000);
		//Publish button Click
		String announcementPublishButtonLocator = getUILocator("publish_button_announcement_page");
		announcementPublishButtonLocator=announcementPublishButtonLocator.replaceAll("<REPLACE_INDEX>", Integer.toString(i));		
		WebElement publishButton = waitForElement(announcementPublishButtonLocator);
		publishButton.click();			
		Assert.assertNotNull(waitForElement("voucher_save_status"), "Failed to find save status");
		AppUtilities.delay(4000);
		
		return this;
	}
	
}

/*Assert.assertNotNull(selectMealTimeCaffeLocationStation(itemDetails), "Failed to select the meal-time, Caffe Location and Station");

String select_station = (String)itemDetails.get("select_station");
String strAddDishLink = getUILocator("add_dish_link");
strAddDishLink = strAddDishLink.replaceAll("<REPLACE_STATION_NAME>", select_station);

Assert.assertTrue(clickElement(strAddDishLink), "Failed to click Add Dish on the selected Station:" + select_station);
log("Clicked on Add Dish link");
AppUtilities.delay(2000);


Assert.assertNotNull(enterFoodItemNameDetails(itemDetails), "Failed while entering the new item name / desc / price details");
Assert.assertNotNull(enterFoodItemNutritionDetails(itemDetails), "Failed while entering the new item nutrition and serving details");
Assert.assertNotNull(enterServingDetails(itemDetails), "Failed while entering the new item nutrition and serving details");

JSONArray components = (JSONArray)itemDetails.get("components");
int index = 0;
for(Object c : components) {
	JSONObject component  = (JSONObject)c;
	Assert.assertNotNull(enterFoodItemComponentDetails(index, component), "Failed to add the component");	
	index++;
}

Assert.assertTrue(clickElement("add_new_item_save"), "Failed to click the save button");

AppUtilities.delay(5000);
log("After 5 seconds delay");

Assert.assertNotNull(waitForElement("customize_food_item_save_status"));

String stationIdPicker = getUILocator("station_food_station_menuContainer_body");
stationIdPicker = stationIdPicker.replaceAll("<REPLACE_STATION_NAME>", select_station);
WebElement stationIDElement = waitForElement(stationIdPicker);
Assert.assertNotNull(stationIDElement, "Failed to find the element which contains food item id");
AppUtilities.delay(5000);
log("After 5 seconds delay");
String foodStationRuntimeId = stationIDElement.getAttribute("data-food-station-id");
log("Food Station run-time id:" + foodStationRuntimeId);
Assert.assertTrue(StringUtils.isNotEmpty(foodStationRuntimeId), "Failed to get the food station run-time id");*/
