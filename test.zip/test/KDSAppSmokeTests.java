package com.apple.ist.caffemac.test;

import java.io.File;
import java.io.FileReader;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.testng.annotations.Test;

import com.apple.ist.caffemac.test.util.AppUtilities;

public class KDSAppSmokeTests extends KDSApp {

	@Test(dataProvider = "loadTestData")
	public void verifyCaffeAndStationsConfiguration(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyRefundCaffeAndStations(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String orderDate =  (String)testData.get("j_order_date");
		String orderMethod =  (String)testData.get("j_order_method");
		String caffeName =  (String)testData.get("configure_caffe_station");
		String stationName =  (String)testData.get("j_station_name");
		String paymentMode =  (String)testData.get("j_payment_mode");
		
		String name =  (String)testData.get("j_refund_name");
		String orderNumber =  (String)testData.get("j_refund_order_number");
		String transactionId =  (String)testData.get("j_refund_transaction_id");
		
		
		//JSONArray optionalItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.clickOnRefund()
			.validateCaffeNameAndOrderDate(caffeName, orderDate)
			.validateOrderMethod(orderMethod)
			.validateStationName(stationName,paymentMode)
			.searchRefund()
		
			
			
			
		.quitApp();	
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void verifyRefundCaffeAndStationsWithOpition(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String orderDate =  (String)testData.get("j_order_date");
		String orderMethod =  (String)testData.get("j_order_method");
		String caffeName =  (String)testData.get("configure_caffe_station");
		String stationName =  (String)testData.get("j_station_name");
		String paymentMode =  (String)testData.get("j_payment_mode");
		
		String name =  (String)testData.get("j_refund_name");
		String orderNumber =  (String)testData.get("j_refund_order_number");
		String transactionId =  (String)testData.get("j_refund_transaction_id");
		
		
		//JSONArray optionalItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.clickOnRefund()
			.validateCaffeNameAndOrderDate(caffeName, orderDate)
			.validateOrderMethod(orderMethod)
			.validateStationName(stationName,paymentMode)
			.searchRefund()
			.validateRefundSearchName(name)
			.validateRefundSearchOrderNumber(orderNumber)
			.validateRefundSearchTransactionId(transactionId)
			
			
			
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCompleteOrder(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_1");
		//Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		//JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		//log("prev data:" + prevData.toJSONString());
		//log("customized run data:" + prevRunData.toJSONString());
		//if(prevRunData != null) {
			//log("Customized KDS data is:" + prevRunData.toJSONString());
			//ordersToCheck = (JSONArray)prevRunData.get("order_list");
		//}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCheck)
			.completeGivenOrders(ordersToCheck)
		.quitApp();	
	}
	
	
	@Test(dataProvider = "loadTestData")
	public void verifyCancelOrder(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_1");
		//Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		//JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		//log("prev data:" + prevData.toJSONString());
		//log("customized run data:" + prevRunData.toJSONString());
		//if(prevRunData != null) {
			//log("Customized KDS data is:" + prevRunData.toJSONString());
			//ordersToCheck = (JSONArray)prevRunData.get("order_list");
		//}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCheck)
			.completeGivenOrders(ordersToCheck)
		.quitApp();	
	}
	/*
	@Test(dataProvider = "loadTestData")
	public void verifyCaffeAndStationsConfiguration(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void verifyCapValueInAvailabilityPopUp(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyCapValue(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validateCapValueInAvailabilityPopUp(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateCapField(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validateRegisteredStationin2up(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateStationsin2up(menuItemsToSelect)
		    .quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validate2UpWithMoreThan2St(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validate2UpMoreThan2Sta(menuItemsToSelect)
		    .quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validate2UpOrderTotal(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validate2UpOrderTotalWithDashboard(menuItemsToSelect)
		    .quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validate2UpOrderWaitTime(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validate2UpOrderWaitTimeObject(menuItemsToSelect)
		    .quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validateDashboardWaitTime(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateDashboardWaitTimeObjectStationName(menuItemsToSelect)
		    .quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validateNoToggleStaNoWaitTimeDashBoard(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateNoToggleStationNoWaitTimeDashBoard(menuItemsToSelect)
		    .quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validateDashboardWaitTimePlus(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateDashboardWaitTimeObjectPlus(menuItemsToSelect)
		    .quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validateDashboardWaitTimeMinus(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateDashboardWaitTimeObjectMinus(menuItemsToSelect)
		    .quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validateCapValueWithSpecialCharacters(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateCapFieldWithSplChar(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validateAvailableButtonInAvailabilityPopUp(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateAvailabilityButton(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public  void validateStationsInAvailability(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validateAvailabilityButton(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData", dependsOnMethods = {"verifyCaffeAndStationsConfiguration"})
	public void verifyPendingCustomizedOrders(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		log("Data 1 " + ordersToCheck);
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYCUSTOMIZINGITEM_KIOSK_SPECIAL_CUSTOMIZED_1");
		log("Data 2 " + prevData);
		//JSONObject prevData = getTempData("KIOSK_SPECIAL_CUSTOMIZED_1");
		Assert.assertNotNull(prevData, "Failed to verify the pending customized orders as the previous order details are found to be null");
		JSONObject prevRunData = convertPrevRunData("CUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCheck = (JSONArray)prevRunData.get("order_list");
		}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData", dependsOnMethods = {"verifyPendingCustomizedOrders"})
	public void verifyPendingStandardOrders(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");

		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_1");
		Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		//JSONObject prevData = getTempData();
		JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCheck = (JSONArray)prevRunData.get("order_list");
		}
		
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData", dependsOnMethods = {"verifyPendingStandardOrders"})
	public void verifyCompleteOrders(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_1");
		Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		//JSONObject prevData = getTempData("KIOSK_STANDARD_NONCUSTOMIZED_ORDER_1");
		JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCheck = (JSONArray)prevRunData.get("order_list");
			//testData = prevRunData;
		}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCheck)
			.completeGivenOrders(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCancelledOrders(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCancel = (JSONArray)testData.get("order_list");
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_2");
		Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		//JSONObject prevData = getTempData("KIOSK_STANDARD_NONCUSTOMIZED_ORDER_2");
		JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCancel = (JSONArray)prevRunData.get("order_list");
			//testData = prevRunData;
		}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCancel)
			.cancelGivenOrders(ordersToCancel)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData", dependsOnMethods = {"verifyCompleteOrders"})
	public void verifyDisplayCompletedOrders(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_1");
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		//JSONObject prevData = getTempData("KIOSK_STANDARD_NONCUSTOMIZED_ORDER_1");
		JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCheck = (JSONArray)prevRunData.get("order_list");
			//testData = prevRunData;
		}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyGivenOrdersAreCompleted(ordersToCheck)
		.quitApp();	
	}
	
	@Test(dataProvider = "loadTestData")
	public void verifyCancellOrderFromOrderHistory(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_3");
		Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		//JSONObject prevData = getTempData("KIOSK_STANDARD_NONCUSTOMIZED_ORDER_3");
		JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		log("prev data:" + prevData.toJSONString());
		log("customized run data:" + prevRunData.toJSONString());
		if(prevRunData != null) {
			log("Customized KDS data is:" + prevRunData.toJSONString());
			ordersToCheck = (JSONArray)prevRunData.get("order_list");
			//testData = prevRunData;
		}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.verifyLandingPageWithPendingOrders(ordersToCheck)
			.completeGivenOrders(ordersToCheck)
			.cancelGivenOrdersFromOrderHistory(ordersToCheck)
		.quitApp();	
	}
	*/
	private JSONObject convertPrevRunData(String category, JSONObject source) {
		if(source == null) {
			log("The source while converting the prev rundata found to be null");
			return null;
		}
		log("Prev run data found as:" + source.toJSONString());
		/*
		JSONObject result = (JSONObject)source.clone();
		
		JSONArray foodItems = (JSONArray)result.get("food_items_to_order");
		String order_person_name = (String)result.get("order_person_name");
		for(Object o : foodItems) {
			JSONObject foodItem = (JSONObject)o;
			String orderid = (String)foodItem.get("orderid");
			if(StringUtils.isNotBlank(orderid)) {
				orderid = orderid.replaceAll("Order #", "");
				orderid = orderid.replaceAll("#", "");
			}
			foodItem.put("order_id", orderid);
			foodItem.put("order_by", order_person_name);
			foodItem.put("food_item_count", 1);
			foodItem.put("is_order_from_kiosk", true);
			foodItem.remove("orderid");
		}
		result.put("order_list", foodItems);
		result.remove("food_items_to_order");
		result.remove("order_person_name");
		*/
		
		JSONObject result = new JSONObject();
		
		JSONArray foodItems = new JSONArray();
		String orderid = (String)source.get("orderid");
		if(StringUtils.isNotBlank(orderid)) {
			orderid = orderid.replaceAll("Order #", "");
			orderid = orderid.replaceAll("#", "");
		}
		source.put("order_id", orderid);
		source.put("order_by", (String)source.get("order_person_name"));
		source.put("food_item_count", 1);
		source.put("is_order_from_kiosk", false);
		source.remove("orderid");
		
		foodItems.add(source);
		
		result.put("order_list", foodItems);
				
		return result;
	}
	
	private JSONObject getTempData(String aKey) {
		
		JSONObject j = null;
		
		try {
			JSONParser p = new JSONParser();
			Properties prop = new Properties();
			FileReader reader = new FileReader(AppUtilities.getFile(strBaseDir + File.separator + "run_data.txt"));
			prop.load(reader);
			j = (JSONObject)p.parse(prop.getProperty(aKey));
		} catch(Exception e) {
			e.printStackTrace();
		}
		return j;
	}
	
	//Smoke Test
	@Test(dataProvider = "loadTestData")
	public void verifyCompleteOrderFromOrderList(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		JSONArray ordersToCheck = (JSONArray)testData.get("order_list");
		JSONObject prevData = (JSONObject)getPreviousExecutionResultsFromStore("VERIFYORDERBYDIRECT_KIOSK_STANDARD_NONCUSTOMIZED_1");
		//Assert.assertNotNull(prevData, "Test data dependent on previous tests execution found to be null.");
		//JSONObject prevRunData = convertPrevRunData("NONCUSTOMIZED", prevData);
		//log("prev data:" + prevData.toJSONString());
		//log("customized run data:" + prevRunData.toJSONString());
		//if(prevRunData != null) {
			//log("Customized KDS data is:" + prevRunData.toJSONString());
			//ordersToCheck = (JSONArray)prevRunData.get("order_list");
		//}
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			//.verifyLandingPageWithPendingOrders(ordersToCheck)
			.completeOrders(ordersToCheck)
		.quitApp();	
	}
	
	// Smoke Test
	@Test(dataProvider = "loadTestData")
	public  void validateSelectMoreThan2Stations(JSONObject testData) throws Exception {
		
		log("Data:" + testData.toJSONString());
		String station =  (String)testData.get("configure_caffe_station");
		JSONArray menuItemsToSelect = (JSONArray)testData.get("enable_menu_items");
		
		launch()
			.login()
			.enableSecuritySettings()
			.selectStationAndMenuItems(station, menuItemsToSelect)
			.validate2UpMoreThan2Sta(menuItemsToSelect)
		    .quitApp();	
	}
	
}
