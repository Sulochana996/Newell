#!/bin/bash

serverName=$1

if [ $# != 1 ]
then
    echo "Usage: ./pid-for-server.sh <Server name>"
    exit 1
fi

info=`ps -ef | grep -v "grep" | grep -v "pid-for-server.sh" | grep -v "kill-server.sh" |  grep -v "kill_appium_server.sh" | grep -i $serverName`
echo $info | perl -nle 'print $1 if /\w+ ([0-9]+)/'
#ps -ef | grep -v "grep" | grep -v "pid-for-server.sh" | grep -v "kill-server.sh" | grep -i $serverName | perl -nle 'print $1 if /\w+ ([0-9]+)/'
#echo $info | perl -nle 'print $1 if /\w+ ([0-9]+)/'
