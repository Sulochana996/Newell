package com.apple.ist.caffemac.test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;

import com.apple.ist.caffemac.test.common.MobileApplicationTestBase;
import com.apple.ist.caffemac.test.util.AppUtilities;

import io.appium.java_client.MobileElement;
import org.openqa.selenium.remote.RemoteWebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.appium.java_client.SwipeElementDirection;
import io.appium.java_client.TouchAction;
import io.appium.java_client.ios.IOSElement;

public class KDSApp extends MobileApplicationTestBase {

	public static final int MAXORDERS_PER_VIEW = 12;
	public static final int MAXORDERS_PER_ORDER_HISTORY = 5;
	public static final String APPNAME= "kds";
	public String temp;
	public String applicationUserName; 
	public String applicationUserPassword; 
	
	public KDSApp() {
		super(APPNAME);
	}
	

	public KDSApp(JSONObject dataObject, JSONObject runParams) {
		super(APPNAME);
		appObject = dataObject;
		initWithParams(runParams);
	}
	
	public KDSApp launch() throws Exception {
		launchAppleConnect_iPad();
		appleConnectLogin();
		//quitApp();
		applicationUserName = getAppLoginUsername();
		applicationUserPassword = getAppLoginPassword();
		Assert.assertTrue(launchApp_iPad(), "Failed in launching the App:" + APPNAME);
		return this;
	}
	
	public List<String> registerStations() {
		List<String> value = new ArrayList<String>();
		Assert.assertTrue(clickElement("btn_2up"), "failed to click 2 up button");
		List<WebElement> stations = driver.findElements(By.className("UIATableCell"));
		for(int i=0; i<stations.size(); i++) {
			value.add((stations.get(i)).getAttribute("name"));
				log("Reading the item of:" +(stations.get(i)).getAttribute("name"));
		}
		Assert.assertTrue(clickElement("btn_2up"), "failed to click 2 up button");
		return value;
		//return this;
	}
	
	public KDSApp appleConnectLogin() {
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("button_appleconnect_settings"), "Failed to find the settings button");
		Assert.assertTrue(clickElement("button_appleconnect_advanced_settings"), "Failed to find the advanced settins screen");
		Assert.assertTrue(clickElement("button_appleconnect_reset"), "Failed to click the appleconnect reset button");
		String alertResetAppleConnectLocator = getUILocator("alert_reset_appleconnect_button");
		MobileElement alertResetAppleConnect = isElementPresent(alertResetAppleConnectLocator);
		if (alertResetAppleConnect!=null) {
			Assert.assertTrue(clickElement(alertResetAppleConnectLocator), "Failed to click reset appleconnect alert message");
		}
		
		//driver.getKeyboard().
		Assert.assertTrue(clickElement("switchbutton_appleconnect_prompt_environment"), "Failed to click the prompt for environment button");
		/*
		MobileElement environmentSwitch = waitForElement("switchbutton_appleconnect_prompt_environment");
		String environmentSwitchValue = environmentSwitch.getAttribute("value");
		log(environmentSwitchValue);
		if (environmentSwitchValue.equals("false")) {
			Assert.assertTrue(clickElement("switchbutton_appleconnect_prompt_environment"), "Failed to click the prompt for environment button");
		}*/
		Assert.assertTrue(clickElement("button_appleconnect_accounts"), "Failed to find the accounts button");
    	//Assert.assertTrue(clickElement("button_appleconnect_signin_when_signedin"), "Failed to find the isgn in button");
		Assert.assertTrue(clickElement("button_appleconnect_signin"), "Failed to find the sign in button");
		Assert.assertTrue(clickElement("button_appleconnect_useracceptance"), "Failed to find the user acceptance popup");
		AppUtilities.delay(5000);
		driver.getKeyboard();
		Assert.assertTrue(clickElement("textfield_appleconnect_username"), "Failed to find the apple connect username field");
		//Assert.assertTrue(clickElement("button_appleconnect_username_clear"), "Failed to click clear button");
		Assert.assertTrue(typeText("textfield_appleconnect_username", getAppLoginUsername()), "Failed to type the login username");
		Assert.assertTrue(typeText("textfield_appleconnect_password", getAppLoginPassword()), "Failed to type the login password");
		MobileElement passwordField = waitForElement("textfield_appleconnect_password");
		passwordField.sendKeys(Keys.RETURN);
		AppUtilities.delay(4000);
	    return this;
	    }
	
	public void quitApp() {
		closeApp();
	}
	
	public KDSApp login(String userName,String password){
		applicationUserName =userName;
		applicationUserPassword = password;
		login();
		return this;
	}
	public KDSApp login() {		
		AppUtilities.delay(10000);
		
		//handleAlertOnLaunch();
		//driver.rotate(ScreenOrientation.LANDSCAPE);
		Assert.assertNotNull(waitForElement("btn_settings"), "Failed to find the Settings button in landing page field");
		Assert.assertNotNull(waitForElement("btn_orderhistory"), "Failed to find the Order History button in landing page field");

		Assert.assertTrue(clickElement("btn_settings"), "Failed to click Settings button in landing page field");
		Assert.assertNotNull(waitForElement("welcome_text"));
		AppUtilities.delay(5000);

		String userName= getAppLoginUsername();
		String pass= getAppLoginPassword();
		driver.getKeyboard().sendKeys(userName); //getAppLoginUsername()
		AppUtilities.delay(1000);
		driver.getKeyboard().sendKeys(Keys.RETURN);
		AppUtilities.delay(1000);
		
		String alert = driver.switchTo().alert().getText();
		if (alert != null) {
		driver.switchTo().alert().dismiss();
		MobileElement welcome1 = waitForElement("welcome_text");
		driver.getKeyboard().sendKeys(pass); //getAppLoginPassword()
		AppUtilities.delay(1000);
		driver.getKeyboard().sendKeys(Keys.RETURN);
		AppUtilities.delay(3000);
		}else {
			driver.getKeyboard().sendKeys(pass);
			AppUtilities.delay(1000);
			driver.getKeyboard().sendKeys(Keys.RETURN);
			AppUtilities.delay(3000);
		}
				
		Assert.assertNotNull(waitForElement("cell_app_settings_cafe_stations"), "Failed to find the Cafe stations after login");
		/*int registeredStationSize = registeredStation.size();
		if (registeredStationSize >=1 ) {
			String strItemLocator = getUILocator("cell_station_to_select");
			for (int i=0; i<registeredStation.size(); i++) {
				log("The registered Stations are: "+registeredStation.get(i));
				Assert.assertTrue(clickElement(strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>",registeredStation.get(i).toString())), "Failed to unselect the station's name");
			}
		}*/
		AppUtilities.delay(1000);
		
		//Signing in again after deselecting the stations in register screen
		/*Assert.assertTrue(clickElement("btn_settings"), "Failed to click the Settings button in landing page field");
		Assert.assertTrue(typeText("textfield_appleconnect_username", applicationUserName), "Failed to type the login username");
		Assert.assertTrue(typeText("textfield_appleconnect_password", applicationUserPassword), "Failed to type the login password");
		MobileElement passwordField1 = waitForElement("textfield_appleconnect_password");
		passwordField1.sendKeys(Keys.RETURN);*/
		
		return this;
	}
	
	private void handleAlertOnLaunch() {
		log("Awaiting for the certificate alert on launch and clicking ok button...");
		clickElement("no_certificate_alert_text");
	}
	
	public KDSApp enableSecuritySettings() {
		Assert.assertTrue(clickElement("cell_app_settings_ssl_certificate"), "Failed to click the SSL Certificate Cell option");
		Assert.assertTrue(clickElement("btn_app_settings_download_install_certificate"), "Failed to click the Download / Install Certificate button");
		Assert.assertNotNull(waitForElement("static_success_download_certificate"), "Failed to find the success message after clicking the download/install certificate button");
		
		Assert.assertTrue(clickElement("cell_app_settings_cafe_stations"), "Failed to click the Cafe / Stations Cell option");
		Assert.assertNotNull(waitForElement("cell_app_settings_select_cafe"), "Failed to find the Select Cafe cell option");
		log("Successfully downloaded the certificate");
		return this;
	}
	
	public KDSApp verifyCapValue(JSONArray orderList) {
		Assert.assertTrue(clickElement("btn_available"), "Failed to click the Available button");
		AppUtilities.delay(1000);
		for(Object i : orderList) {
			JSONObject itemsToChoose = (JSONObject)i;
			String menuItem = (String)itemsToChoose.get("food_item_name");
			String capValue = (String)itemsToChoose.get("cap_value");
			log("Food item name is: " + menuItem);
			String ItemLocator = getUILocator("cell_item_available_capfield").replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			//String capLocator = ItemLocator.replaceAll("<REPLACE_CAP_VALUE>", capValue);
			//Assert.assertTrue(clickElement(capLocator), "Failed to find the Cap");
			Assert.assertNotNull(waitForElementAndGetText(ItemLocator), "Failed to validate Cap value");
			
			}
		
		log("The Cap value is present in Availability popup");
		return this;
	}
	
	public KDSApp validateCapField(JSONArray orderList) {
		//Assert.assertTrue(clickElement("btn_available"), "Failed to click the Available button");
		String capValueTyped = "12";
		String capValueInAvailability = capValueTyped.substring(0, Math.min(capValueTyped.length(), 4));
		log("The substring cap value is: "+capValueInAvailability);
		AppUtilities.delay(1000);
		for(Object i : orderList) {
			JSONObject itemsToChoose = (JSONObject)i;
			String menuItem = (String)itemsToChoose.get("food_item_name");
			String capValue = (String)itemsToChoose.get("cap_value");
			log("Food item name is: " + menuItem);
			String ItemLocator = getUILocator("cell_item_available_capfield").replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			String capLocator = ItemLocator.replaceAll("<REPLACE_CAP_VALUE>", capValue);
			Assert.assertTrue(clickElement(capLocator), "Failed to find the Cap");
			Assert.assertTrue(typeText(capLocator, capValueTyped), "Failed to type the cap value");
			
			String capLocator1 = getUILocator("cell_item_available_capfield").replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			String capLocatorValue = capLocator1.replaceAll("<REPLACE_CAP_VALUE>", capValueInAvailability);
			Assert.assertNotNull(waitForElement(capLocatorValue), "Failed to validate Cap value");
			
			Assert.assertTrue(typeText(capLocatorValue, capValue), "Failed to type the cap value");
			
			
			}
		
		log("The Cap field is present in Availability popup");
		return this;
	}
	
	public KDSApp validateCapFieldWithSplChar(JSONArray orderList) {
		String capValueTyped = "@#$%@#";
		AppUtilities.delay(1000);
		for(Object i : orderList) {
			JSONObject itemsToChoose = (JSONObject)i;
			String menuItem = (String)itemsToChoose.get("food_item_name");
			String capValue = (String)itemsToChoose.get("cap_value");
			log("Food item name is: " + menuItem);
			String ItemLocator = getUILocator("cell_item_available_capfield").replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			String capLocator = ItemLocator.replaceAll("<REPLACE_CAP_VALUE>", capValue);
			Assert.assertTrue(clickElement(capLocator), "Failed to find the Cap");
			Assert.assertTrue(typeText(capLocator, capValueTyped), "Failed to type the cap value");
			Assert.assertTrue(clickElement("cell_item_order_history_availbility_open"), "Failed to click the order history button");
			AppUtilities.delay(1000);
			Assert.assertTrue(clickElement("btn_available"), "Failed to click the Available button");
			AppUtilities.delay(1000);
			Assert.assertNotNull(waitForElement(capLocator), "Failed to validate Cap value");
			}
		
		log("Validated the cap field with special characters");
		return this;
		
	}
	
	public KDSApp validateAvailabilityButton(JSONArray orderList) {
		//Assert.assertTrue(clickElement("btn_available"), "Failed to click the Available button");
		AppUtilities.delay(1000);
		for(Object i : orderList) {
			JSONObject itemsToChoose = (JSONObject)i;
			String menuItem = (String)itemsToChoose.get("food_item_name");
			String ItemLocator = getUILocator("cell_item_available_switch_button").replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			WebElement soldOutButton = waitForElement(ItemLocator);
			String soldOutButtonValue = soldOutButton.getAttribute("value");
			if (soldOutButtonValue.equals("1")) {
				Assert.assertTrue(clickElement(ItemLocator), "Failed to click the availability button");
			}
		}
		
		log("Validated the availability button in availability popup");
		return this;
	}
	
	public KDSApp validateAvailabilityButton1(JSONArray orderList, boolean status) {
		Assert.assertTrue(clickElement("btn_available"), "Failed to click the Available button");
		AppUtilities.delay(1000);
		for(Object i : orderList) {
			JSONObject itemsToChoose = (JSONObject)i;
			String menuItem = (String)itemsToChoose.get("food_item_name");
			String ItemLocator = getUILocator("cell_item_available_switch_button").replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			WebElement soldOutButton = waitForElement(ItemLocator);
			String soldOutButtonValue = soldOutButton.getAttribute("value");
			if (status == false) {
				if (soldOutButtonValue.equals("1")) {
					Assert.assertTrue(clickElement(ItemLocator), "Failed to click the availability button");
				}
			}
			if (status == true) {
				if (soldOutButtonValue.equals("0")) {
					Assert.assertTrue(clickElement(ItemLocator), "Failed to click the availability button");
				}
			}
		}
		
		log("The Cap field is present in Availability popup");
		return this;
	}
	
	public KDSApp validateStationsAvailability(JSONArray stationNames) {
		//Assert.assertTrue(clickElement("btn_available"), "Failed to click the Available button");
		AppUtilities.delay(1000);
		for(int i = 0; i < stationNames.size(); i++) {
			String stationsToChoose = (String)stationNames.get(i);
			log("The station names are: " +stationsToChoose);
			String stationLocator = getUILocator("cell_item_station_name_availability_page").replaceAll("<REPLACE_STATION_NAME>", stationsToChoose);
			Assert.assertNotNull(waitForElement(stationLocator),"Unable to find the station "+stationsToChoose +" in availability popup");
		}
		log("Successfully found all the registered stations in availability popup");
		Assert.assertTrue(clickElement("btn_available"), "Failed to click the Available button");
		return this;
	}
	
	public KDSApp validateStationsAvailability1(JSONArray stationNames) {
		Assert.assertTrue(clickElement("btn_available"), "Failed to click the Available button");
		AppUtilities.delay(1000);
		for(int i = 0; i < stationNames.size(); i++) {
			String stationsToChoose = (String)stationNames.get(i);
			log("The station names are: " +stationsToChoose);
			String stationLocator = getUILocator("cell_item_station_name_availability_page").replaceAll("<REPLACE_STATION_NAME>", stationsToChoose);
			Assert.assertNotNull(waitForElement(stationLocator),"Unable to find the station "+stationsToChoose +" in availability popup");
		}
		log("Successfully found all the registered stations in availability popup");
		return this;
	}
	
	public KDSApp selectStationIn2Up(JSONArray stationNames) {
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2 up button");
		AppUtilities.delay(1000);
		for(int i = 0; i < stationNames.size(); i++) {
			String stationsToChoose = (String)stationNames.get(i);
			log("The station names are: " +stationsToChoose);
			String stationLocator = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationsToChoose);
			Assert.assertTrue(clickElement(stationLocator), "Failed to check the station name in 2 up popup");
		}
		Assert.assertTrue(clickElement("btn_2up"), "Failed to close the 2 up button");
		log("Selected the station in 2 up");
		return this;
	}
	
	public KDSApp deselectStationsIn2Up(JSONArray deselectStationNames) {
		
		log("I am here");
		
		Boolean ArrayValue = deselectStationNames.isEmpty();
		//log(Integer.toString(deselectStationNames.size()));
		if (ArrayValue)
		{
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2 up button");
		AppUtilities.delay(1000);
		
		//List<WebElement> stations = driver.findElementsByXPath("//UIAApplication[1]/UIAWindow[1]/UIATableView[1]");
		
		//log("The stations are: "+stations);
		log(Integer.toString(deselectStationNames.size()));
		for(int i = 1; i <= deselectStationNames.size(); i++)
		{
			String stationLocator = getUILocator("cell_item_station_name_2up_page_id").replaceAll("<REPLACE_STATION_ID>", Integer.toString(i));
			AppUtilities.delay(5000);
			MobileElement Station =	isElementPresent(stationLocator); 
			//String Station = waitForElementAndGetText(stationLocator);
			//log(Station.getAttribute("value"));
		int Validate = Integer.parseInt(Station.getAttribute("value"));
		if	(Validate == 1)
			{
			log(stationLocator + "is being selected");
			Assert.assertTrue(clickElement(stationLocator), "Failed to deselect the station in 2 up popup");
			}
		}
		
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2 up button");
		String stationSelected = getUILocator("static_selected_stations_display").replaceAll("<REPLACE_STATION_NAME>", "Pizza, Vegan");
		Assert.assertEquals(waitForElementAndGetText(stationSelected), "Pizza, Vegan");
			log("inside if");
		}
		else {
			
			Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2 up button");
			AppUtilities.delay(1000);
			
			//List<WebElement> stations = driver.findElementsByXPath("//UIAApplication[1]/UIAWindow[1]/UIATableView[1]");
			
			log(Integer.toString(deselectStationNames.size()));
			for(int i = 0; i < deselectStationNames.size(); i++)
			{
				String StationName = (String) deselectStationNames.get(i);
				String stationLocator = getUILocator("cell_item_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>",StationName);
				AppUtilities.delay(5000);
				MobileElement Station =	isElementPresent(stationLocator); 
				//String Station = waitForElementAndGetText(stationLocator);
				//log(Station.getAttribute("value"));
			int Validate = Integer.parseInt(Station.getAttribute("value"));
			if	(Validate == 1)
				{
				log(stationLocator + "is being selected");
				Assert.assertTrue(clickElement(stationLocator), "Failed to deselect the station in 2 up popup");
				}
			}
			
			Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2 up button");
			String stationSelected = getUILocator("static_selected_stations_display").replaceAll("<REPLACE_STATION_NAME>", "Vegan");
			Assert.assertEquals(waitForElementAndGetText(stationSelected), "Vegan");
		}
		return this;
	}
	
	public KDSApp validateStationsin2up(JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2-up button");
		log("click the 2-up button is done");
		log("pick the first station from the station list to work on");
		String stationName1 = (String)itemsToChoose.get(1);
		
		String strStationName = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		log("the UI locator of the station to work on is " + strStationName);
		Assert.assertTrue(clickElement(strStationName), "Failed to click the toogle button for the first station on the 2 up screen");
		
		log("dismiss the 2up screen");
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		AppUtilities.delay(2000);
		
		log("click the 2-up button again to check the toggle button");
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2-up button");
		
		log("verify the value of the toggle button");
		log("print out the value of the attribute" + waitForElement(strStationName).getAttribute("value"));
		Assert.assertEquals(waitForElement(strStationName).getAttribute("value"),"1");
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement(strStationName), "Failed to click the toogle button for the first station on the 2 up screen");
		AppUtilities.delay(5000);
		log("Sucessfully verified stations in 2 up");
		return this;
	}
	
	public KDSApp validate2UpMoreThan2Sta(JSONArray itemsToChoose) {
		log("pick the first station from the station list to work on");
		
		//Click on Station Tab
		Assert.assertTrue(clickElement("stations_tab_kds_landing_page"), "Failed to click the toogle button for the first station on the 2 up screen");
				
		//To select station from UI
		
		List<WebElement> stationList = waitForElements("station_lists_station_tab");
		
		for(int i=0; i<=2; i++) {
			stationList.get(i).click();
			log("Clicked on the toogle button for the "+i+"station on the 2 up screen");
		}
		
		/*String stationName1 = (String)itemsToChoose.get(0);
		String strStationName1 = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		log("the UI locator of the station to work on is " + strStationName1);
		Assert.assertTrue(clickElement(strStationName1), "Failed to click the toogle button for the first station on the 2 up screen");
		
		log("pick the second station from the station list to work on");
		String stationName2 = (String)itemsToChoose.get(1);
		String strStationName2 = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName2);
		log("the UI locator of the station to work on is " + strStationName2);
		Assert.assertTrue(clickElement(strStationName2), "Failed to click the toogle button for the second station on the 2 up screen");
		
		log("pick the third station from the station list to work on and it should fail");
		String stationName3 = (String)itemsToChoose.get(2);
		String strStationName3 = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName3);
		log("the UI locator of the station to work on is " + strStationName3);
		Assert.assertTrue(clickElement(strStationName3), "Failed to click the toogle button for the third station on the 2 up screen");*/
		AppUtilities.delay(2000);
		
		log("check the alert message");
		
		String alertMsg = driver.switchTo().alert().getText();
		if (alertMsg != null) {
			Assert.assertEquals(alertMsg,"A maximum of 2 stations can be selected at a time");
			driver.switchTo().alert().dismiss();			
		}
		
		log("Sucessfully verified the error message when chosen more than 2 stations in 2 up");
		return this;
	}
	
	public KDSApp validate2UpOrderTotalWithDashboard(JSONArray itemsToChoose) {
		
		log("calculate the total order numbers from the 2Up window by selecting two stations");
		
		int TotalOrderFrom2Up = 0;
		
		for(int i = 0; i < 2; i++) {
			String stationName = (String)itemsToChoose.get(i);
			String strStationName = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName);
			log("the UI locator of the station to work on is " + strStationName);
			Assert.assertTrue(clickElement(strStationName), "Failed to click the toogle button");
			AppUtilities.delay(4000);
			
			String stationOrderCountLocator = getUILocator("toggle_ordernumber_textfield").replaceAll("<REPLACE_STATION_NAME>", stationName);
			log("the UI locator of the station to work on is " + stationOrderCountLocator);
			Assert.assertNotNull(waitForElement(stationOrderCountLocator), "Failed to find the order count in the 2up screen ");
			String strOrderNumber = waitForElement(stationOrderCountLocator).getAttribute("value");
			log("order number is " + strOrderNumber);
			TotalOrderFrom2Up += Integer.parseInt(strOrderNumber);
		}
		
		log("Total orders from the 2 up window" + TotalOrderFrom2Up);
		
		log("dismiss the 2up screen");
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		AppUtilities.delay(2000);
		
		log("get the total order number from the dashboard");
		String totalOrderFromDashBoard = waitForElement("dashboard_ordertotalnumber_button").getAttribute("label");
		log("totla order from Dashboard is " + totalOrderFromDashBoard);
		Assert.assertEquals(Integer.parseInt(totalOrderFromDashBoard), TotalOrderFrom2Up);
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2-up button");
		for(int i = 0; i < 2; i++) {
			String stationName = (String)itemsToChoose.get(i);
			String strStationName = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName);
			log("the UI locator of the station to work on is " + strStationName);
			Assert.assertTrue(clickElement(strStationName), "Failed to click the toogle button");
			AppUtilities.delay(4000);
		}
		log("Sucessfully verified total order for 2 up");
		return this;
	}
	
	public KDSApp validate2UpFordeActivatedStations(JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2-up button");
		log("click the 2-up button is done");
		log("Items to be ordered is:" + itemsToChoose.toJSONString());
    	JSONObject itemDetails = null;
    	for(Object item : itemsToChoose) {
            itemDetails = (JSONObject)item;
    	}
    	String strStationToSelect = (String)itemDetails.get("select_station");
    	String strStationName = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", strStationToSelect);
    	Assert.assertNull(waitForElement(strStationName), "The activated station is present in 2 up");
		
		return this;
	}
	
	public KDSApp validateAvailabilityForActivatedStations(JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("btn_available"), "Failed to click the 2-up button");
		log("click the Availability button is done");
		log("Items to be ordered is:" + itemsToChoose.toJSONString());
    	JSONObject itemDetails = null;
    	for(Object item : itemsToChoose) {
            itemDetails = (JSONObject)item;
    	}
    	String strStationToSelect = (String)itemDetails.get("select_station");
    	String strStationName = getUILocator("cell_item_station_name_availability_page").replaceAll("<REPLACE_STATION_NAME>", strStationToSelect);
    	strStationName = strStationName.replaceAll("<REPLACE_STATION_NAME>", strStationToSelect);
    	Assert.assertNotNull(waitForElement(strStationName), "The activated station is not present in Availability");
		
		return this;
	}
	
	public KDSApp validateAvailabilityFordeActivatedStations(JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("btn_available"), "Failed to click the 2-up button");
		log("click the Availability button is done");
		log("Items to be ordered is:" + itemsToChoose.toJSONString());
    	JSONObject itemDetails = null;
    	for(Object item : itemsToChoose) {
            itemDetails = (JSONObject)item;
    	}
    	String strStationToSelect = (String)itemDetails.get("select_station");
    	String strStationName = getUILocator("cell_item_station_name_availability_page").replaceAll("<REPLACE_STATION_NAME>", strStationToSelect);
    	strStationName = strStationName.replaceAll("<REPLACE_STATION_NAME>", strStationToSelect);
    	Assert.assertNull(waitForElement(strStationName), "The deactivated station is present in Availability");
		
		return this;
	}
	
	public KDSApp validateRemoveMenuItemInAvailability(JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("btn_available"), "Failed to click the 2-up button");
		log("click the Availability button is done");
		log("Items to be ordered is:" + itemsToChoose.toJSONString());
    	JSONObject itemDetails = null;
    	for(Object item : itemsToChoose) {
            itemDetails = (JSONObject)item;
    	}
    	String strFoodItemToSelect = (String)itemDetails.get("food_item_name");
    	String strStationName = getUILocator("cell_item_item_name_availability_page").replaceAll("<REPLACE_ITEM_NAME>", strFoodItemToSelect);
    	strStationName = strStationName.replaceAll("<REPLACE_ITEM_NAME>", strFoodItemToSelect);
    	Assert.assertNull(waitForElement(strStationName), "The removed menu item is present in Availability");
		
		return this;
	}

	
	public KDSApp validate2UpOrderWaitTimeObject(JSONArray itemsToChoose) {
		String stationName1 = (String)itemsToChoose.get(0);
		log("pick the first station from the station list to work on and get the current wait time");
		String strStationWaitTimeLocator = getUILocator("2up_station_waittime_text").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		log("the UI locator of the station to work on is " + strStationWaitTimeLocator);
		Assert.assertNotNull(waitForElement(strStationWaitTimeLocator), "Failed to find the wait time in the 2up screen ");
		String strWaitTime = waitForElement(strStationWaitTimeLocator).getAttribute("name");
		log("wait time for the station is " + strWaitTime);
		
		String strToggleButton = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		Assert.assertTrue(clickElement(strToggleButton), "failed to click the toogle button");
		AppUtilities.delay(2000);
		
		
		
		log("dismiss the 2up screen");
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		AppUtilities.delay(2000);
		
		
		log("get the current wait time from the dash board");
		String strDashboardWaittime= getUILocator("dashboard_waittime_waittime_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		String totalWaitFromDashBoard = waitForElement(strDashboardWaittime).getAttribute("name");
		log("totla order from Dashboard is " + totalWaitFromDashBoard);
		//Assert.assertEquals(totalWaitFromDashBoard,strWaitTime);
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		Assert.assertTrue(clickElement(strToggleButton), "failed to click the toogle button");
		log("Sucessfully verified wait time for 2 up orders");
		return this;
	}
	
	public KDSApp validate2UpForActivatedStations(JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2-up button");
		log("click the 2-up button is done");
		log("Items to be ordered is:" + itemsToChoose.toJSONString());
    	JSONObject itemDetails = null;
    	for(Object item : itemsToChoose) {
            itemDetails = (JSONObject)item;
    	}
    	String strStationToSelect = (String)itemDetails.get("select_station");
    	String strStationName = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", strStationToSelect);
    	Assert.assertNotNull(waitForElement(strStationName), "The activated station is present in 2 up");
		
		return this;
	}
	
	public KDSApp validateDashboardWaitTimeObjectStationName(JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2-up button");
		log("click the 2-up button is done");
		
		log("pick the first station from the station list to work on");
		String stationName1 = (String)itemsToChoose.get(0);
		log("The station name to compare is: "+stationName1);
		
		String strStationName = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		log("the UI locator of the station to work on is " + strStationName);
		Assert.assertTrue(clickElement(strStationName), "Failed to click the toogle button for the first station on the 2 up screen");
		
		log("dismiss the 2up screen");
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		AppUtilities.delay(2000);
		
		log("check dashboard for wait time station name");
		String strDashboardWaittime_stationname = getUILocator("dashboard_waittime_stationname").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		log("the UI locator of the station to work on is " + strDashboardWaittime_stationname);
		log("I am here");
		MobileElement WaitTimeDashboardStationName = waitForElement(strDashboardWaittime_stationname);
		String WaitTimeDahsboardStation = WaitTimeDashboardStationName.getText();
		Assert.assertEquals(WaitTimeDahsboardStation,stationName1 );
		AppUtilities.delay(5000);
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		Assert.assertTrue(clickElement(strStationName), "Failed to click the toogle button for the first station on the 2 up screen");
		log("Successfully validated the wait time for the station chosen in 2 up");
		return this;
	}
	
	public KDSApp reduceWaitTimeUntilMinusButtonDisabled(JSONArray itemsToChoose) {
		String stationName1 = (String)itemsToChoose.get(0);
		log("The station name to compare is: "+stationName1);
		
		String strStationName = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		log("the UI locator of the station to work on is " + strStationName);
		Assert.assertTrue(clickElement(strStationName), "Failed to click the toogle button for the first station on the 2 up screen");
		
		log("dismiss the 2up screen");
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		AppUtilities.delay(2000);
		
		String strMinusButton = getUILocator("dashboard_waittime_minus_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		log("find the minus button");
		Assert.assertNotNull(waitForElement(strMinusButton), "Failed to find the minus sign ");
		MobileElement strEnabled = waitForElement(strMinusButton);
		boolean enabledValue = strEnabled.isEnabled();
		if (enabledValue == true) {
			do {
				Assert.assertTrue(clickElement(strMinusButton), "Failed to click the minus button in wait time");
			} while (enabledValue == true);
		}
		log("is minus button enabled " + enabledValue);
		Assert.assertEquals(enabledValue, false);
		
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		Assert.assertTrue(clickElement(strStationName), "Failed to click the toogle button for the first station on the 2 up screen");
		log("Successfully reduced the wait time until the minus button gets disabled");
		
		return this;
	}
	
	public KDSApp validateNoToggleStationNoWaitTimeDashBoard(JSONArray itemsToChoose) {
		
		log("no toggle button is selected from 2up screen");
		Assert.assertEquals(waitForElement("dashboard_emtpy_bar").getAttribute("name"),"" );
		log("Validated wait time is not present when no station is chosen in 2 up");
		return this;
	}
	
	public KDSApp validateDashboardWaitTimeObjectPlus(JSONArray itemsToChoose) {
		String stationName1 = (String)itemsToChoose.get(0);
		log("pick the first station from the station list to work on and get the current wait time");
		String strStationWaitTimeLocator = getUILocator("2up_station_waittime_text").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		log("the UI locator of the station to work on is " + strStationWaitTimeLocator);
		Assert.assertNotNull(waitForElement(strStationWaitTimeLocator), "Failed to find the wait time in the 2up screen ");
		String strWaitTime = waitForElement(strStationWaitTimeLocator).getAttribute("name");
		log("wait time for the station is " + strWaitTime);
		
		String strToggleButton = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		Assert.assertTrue(clickElement(strToggleButton), "failed to click the toogle button");
		AppUtilities.delay(2000);
		log("dismiss the 2up screen");
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		AppUtilities.delay(2000);
		
		
		log("get the current wait time from the dash board");
		String strDashboardWaittime= getUILocator("dashboard_waittime_waittime_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		String totalWaitFromDashBoard = waitForElement(strDashboardWaittime).getAttribute("name");
		log("totla waittime from Dashboard is " + totalWaitFromDashBoard);
		String WaitArray[] = totalWaitFromDashBoard.split(" ");
		int WaitTimeInt = Integer.parseInt(WaitArray[0]);
		log("wait time derived from wait time " + WaitTimeInt);
		
		log("increase the wait time");
		String strPlusButton = getUILocator("dashboard_waittime_plus_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		Assert.assertNotNull(waitForElement(strPlusButton), "Failed to find the plus sign ");
		Assert.assertTrue(clickElement(strPlusButton), "failed to click the + button to increase the wait time");
		
		log("get the current wait time from the dash board");
		String strDashboardWaittimeAfter= getUILocator("dashboard_waittime_waittime_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		String totalWaitFromDashBoardAfter = waitForElement(strDashboardWaittimeAfter).getAttribute("name");
		log("totla waittime from Dashboard is " + totalWaitFromDashBoardAfter);
		String WaitArrayAfter[] = totalWaitFromDashBoardAfter.split(" ");
		int WaitTimeIntAfter = Integer.parseInt(WaitArrayAfter[0]);
		log("wait time derived from wait time " + WaitTimeIntAfter);
		
		Assert.assertEquals(WaitTimeIntAfter-1,WaitTimeInt);
		
		log("reset the wait time");
		String strMinusButton = getUILocator("dashboard_waittime_minus_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		AppUtilities.delay(8000);
		Assert.assertNotNull(waitForElement(strMinusButton), "Failed to find the minus sign ");
		Assert.assertTrue(clickElement(strMinusButton), "failed to click the - button to decrease the wait time");
		AppUtilities.delay(8000);
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		Assert.assertTrue(clickElement(strToggleButton), "failed to click the toogle button");
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		log("Successfully validated the addition of wait time");
		 return this;
		 
	}
	
	public KDSApp validateDashboardWaitTimeObjectMinus(JSONArray itemsToChoose) {
		selectStation2up(itemsToChoose);
		String stationName1 = (String)itemsToChoose.get(0);
		log(" wait time is default value, the minus button should be disabled");
		String strMinusButton = getUILocator("dashboard_waittime_minus_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		
		log("find the minus button");
		Assert.assertNotNull(waitForElement(strMinusButton), "Failed to find the minus sign ");
		MobileElement strEnabled = waitForElement(strMinusButton);
		boolean enabledValue = strEnabled.isEnabled();
		log("is minus button enabled " + enabledValue);
		Assert.assertEquals(enabledValue, false);
		String waitTime = getUILocator("dashboard_waittime_waittime_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		Assert.assertNotNull(waitForElement(waitTime), "Failed to find the wait time ");
		
		temp = waitForElement(waitTime).getText();
		log("Successfully validated the minus button of wait time");
		return this;
		
		 
	}
	
	public KDSApp selectStation2up(JSONArray itemsToChoose){
		
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2-up button");
		log("click the 2-up button is done");
		
		log("click the toggle button");
		String stationName1 = (String)itemsToChoose.get(0);
		log("pick the first station from the station list to work on and get the current wait time");
		String strStationWaitTimeLocator = getUILocator("2up_station_waittime_text").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		log("the UI locator of the station to work on is " + strStationWaitTimeLocator);
		Assert.assertNotNull(waitForElement(strStationWaitTimeLocator), "Failed to find the wait time in the 2up screen ");
		String strWaitTime = waitForElement(strStationWaitTimeLocator).getAttribute("name");
		log("wait time for the station is " + strWaitTime);
		//temp = strWaitTime;
		String strToggleButton = getUILocator("toggle_button_station_name_2up_page").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		Assert.assertTrue(clickElement(strToggleButton), "failed to click the toogle button");
		AppUtilities.delay(2000);

		log("dismiss the 2up screen");
		Assert.assertTrue(clickElement("btn_2up"), "fail to dismiss the screen");
		AppUtilities.delay(2000);
		return this;
	}
	
	public KDSApp validateGuestAppWaitTimeValidation(String waitTime, JSONArray menuItemsToSelect){
		selectStation2up(menuItemsToSelect);
		//validateDashboardWaitTimeObjectMinus(menuItemsToSelect);
		String stationName1 = (String)menuItemsToSelect.get(0);
		String waitTime1 = getUILocator("dashboard_waittime_waittime_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		Assert.assertNotNull(waitForElement(waitTime1), "Failed to find the wait time ");
		
		temp = waitForElement(waitTime1).getText();
		log("Successfully validated the minus button of wait time");
		log(temp);
		Assert.assertTrue(waitTime.contains(temp), "Failed to find the wait time");
		selectStation2up(menuItemsToSelect);
		return this;
	}
	
	public KDSApp minimumWaitTimeValue(String stationName1){
		
		//String stationName1 = (String)itemsToChoose.get(0);
		log(" wait time to set as default value, the minus button should be disabled");
		String strMinusButton = getUILocator("dashboard_waittime_minus_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		
		log("find the minus button");
		Assert.assertNotNull(waitForElement(strMinusButton), "Failed to find the minus sign ");
		MobileElement strEnabled = waitForElement(strMinusButton);
		boolean enabledValue = strEnabled.isEnabled();
		log("is minus button enabled " + enabledValue);
		while(enabledValue){
			strEnabled = waitForElement(strMinusButton);
			enabledValue = strEnabled.isEnabled();
			AppUtilities.delay(2000);
			log("is minus button enabled " + enabledValue);
			if(enabledValue){
			Assert.assertTrue(clickElement(strMinusButton), "fail to minimise the time");
			}
		}
		AppUtilities.delay(5000);
		String waitTime = getUILocator("dashboard_waittime_waittime_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		temp = waitForElement(waitTime).getText();
		
		return this;
	}
	
	public KDSApp resetWaitTime(JSONArray menuItemsToSelect){
		selectStation2up(menuItemsToSelect);
		String stationName1 = (String)menuItemsToSelect.get(0);
		minimumWaitTimeValue(stationName1);
		return this;
	}
	
	public KDSApp clickOnRefund(){
		String strItem="";
		strItem= getUILocator("lbl_refund");
		Assert.assertNotNull(waitForElement(strItem), "Failed to find the Refund");
		Assert.assertTrue(clickElement(strItem), "Failed to select the Refund");
		return this;
	}
	
	
	public KDSApp validateCaffeNameAndOrderDate(String caffeName,String orderDate) {
		String strItem="";

		strItem= getUILocator("lbl_refund_order_date");
		Assert.assertNotNull(waitForElement(strItem), "Failed to display the Order Date");
		
		strItem= getUILocator("lbl_refund_order_date_value");
		/*
		 strItem=getUILocator("lbl_refund_order_date_value").replaceAll("<RENAME_ORDER_DATE>", orderDate);
			Assert.assertNotNull(waitForElement(strItem), "Failed to click on listed Caffe name more information");
			Assert.assertTrue(clickElement(strItem), "Failed  to click on listed Caffe name more information");
			*/
	
		Assert.assertNotNull(waitForElement(strItem), "Failed to display the Order Date");
		
		strItem= getUILocator("lbl_refund_caffe_name");
		Assert.assertNotNull(waitForElement(strItem), "Failed to display the Caffe name");
		
		strItem= getUILocator("lbl_refund_caffe_more_info");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on Caffe name more information");
		Assert.assertTrue(clickElement(strItem), "Failed  to click on Caffe name more information");
		
		/*
		 strItem=getUILocator("refund_caffe_list").replaceAll("<RENAME_NAME>", caffeName);
			Assert.assertNotNull(waitForElement(strItem), "Failed to click on listed Caffe name more information");
			Assert.assertTrue(clickElement(strItem), "Failed  to click on listed Caffe name more information");
			*/
		
		
		
		/*
		
			List<WebElement> allTexts = driver.findElementsByXPath("//XCUIElementTypeStaticText");
			int a = allTexts.size();

			for (int i = 0; i < a; i++) {
				//To print all the caffe name

				System.out.println(allTexts.get(i).getText());
				
				// to click on choosed caffe name
				String value = allTexts.get(i).getText();
				if(value.equalsIgnoreCase(caffeName)) {
					Assert.assertNotNull(waitForElement(value), "Failed to click on listed Caffe name more information");
					Assert.assertTrue(clickElement(value), "Failed  to click on listed Caffe name more information");
					break;	
				}
				
			}*/
			
			return this;
	}
	
	public KDSApp validateOrderMethod(String orderMethod) {
		
		String strItem= "";
		
		strItem= getUILocator("lbl_refund_order_method");
		Assert.assertNotNull(waitForElement(strItem), "Failed to display Order Method ");
		//Assert.assertTrue(clickElement(strItem), "Failed  to display on Order Method more information");
		
		strItem= getUILocator("lbl_refund_order_method_more_info");
		Assert.assertNotNull(waitForElement(strItem), "Failed  to click on Order Method more information ");
		Assert.assertTrue(clickElement(strItem), "Failed  to click on Order Method more information");
		
		
	/*	
			List<WebElement> allTexts = driver.findElementsByXPath("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[3]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable[1]/XCUIElementTypeCell");
			int a = allTexts.size();
			
			
		    log("value of all text is "+allTexts);

			for (int i = 1; i <= a;i++) {
				
				 Offshoredelay();
				 
				
				String content= ("//XCUIElementTypeApplication[1]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther[3]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeTable[1]/XCUIElementTypeCell["+i+"]/XCUIElementTypeStaticText");
				 log("loop all texts"+content);	
				Offshoredelay();
				Assert.assertNotNull(waitForElement(content), "Failed  to click on Order Method informations ");
			//	Assert.assertTrue(clickElement(content), "Failed  to click on Order Method more information");
				
				
			}*/
		
			
			strItem=getUILocator("order_method_value").replaceAll("<RENAME_ORDER_METHOD>", orderMethod);
			Assert.assertNotNull(waitForElement(strItem), "Failed to click on listed Caffe name more information");
			Assert.assertTrue(clickElement(strItem), "Failed  to click on listed Caffe name more information");
			
			
			return this;
	}
	
	
	
	public KDSApp validateStationName(String stationName, String paymentMode){
		String strItem="";
		
		strItem= getUILocator("refund_station_name");
		Assert.assertNotNull(waitForElement(strItem), "Failed to display station label");

		strItem= getUILocator("refund_station_name_more_info");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on station more information");
		Assert.assertTrue(clickElement(strItem), "Failed to click on station more information");
		
		strItem=getUILocator("refund_station_name_list").replaceAll("<RENAME_NAME>", stationName);
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on listed station name ");
		Assert.assertTrue(clickElement(strItem), "Failed  to click on listed station name ");

		
		
		/*strItem= getUILocator("refund_station_page_back_button");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on Back button");
		Assert.assertTrue(clickElement(strItem), "Failed  to click on Back button");*/
		
		
		strItem= getUILocator("btn_payment_method");
		Assert.assertNotNull(waitForElement(strItem), "Failed to display Payment method");

		strItem= getUILocator("btn_payment_method_more_info");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on Payment method more information");
		Assert.assertTrue(clickElement(strItem), "Failed to click on Payment method more information");
		
		strItem=getUILocator("refund_payment_method").replaceAll("<RENAME_NAME>", paymentMode);
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on listed payment method");
		Assert.assertTrue(clickElement(strItem), "Failed  to click on listed Caffe payment method");
		
		
		
		return this;
	}
	
	
	public KDSApp validateRefundSearchName(String name){
		String strItem="";

		
		strItem=getUILocator("refund_name_text");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on listed station name ");
		String value= name.toString();
		driver.findElementByXPath(strItem).sendKeys(value);
		log("Refund Name :"+strItem);
		Assert.assertTrue(clickElement(strItem), "Failed  to click on listed station name ");

		return this;
	}
	
	public KDSApp validateRefundSearchOrderNumber(String orderNumber){
		String strItem="";
		
		strItem=getUILocator("refund_order_number").replaceAll("<RENAME_NAME>", orderNumber);
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on listed station name ");
		Assert.assertTrue(clickElement(strItem), "Failed  to click on listed station name ");

		return this;
	}
	


	
		public KDSApp validateRefundSearchTransactionId(String transactionId){	
			String strItem="";
		
		strItem=getUILocator("refund_transaction_id").replaceAll("<RENAME_NAME>", transactionId);
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on listed payment method");
		Assert.assertTrue(clickElement(strItem), "Failed  to click on listed Caffe payment method");
		
		
		
		return this;
	}
	

	
	public KDSApp searchRefund(){
		String strItem="";
		
		strItem= getUILocator("btn_refund_search");
		Assert.assertNotNull(waitForElement(strItem), "Failed to click on station more information");
		Assert.assertTrue(clickElement(strItem), "Failed to click on station more information");
		
		
		return this;
	}
	
	
	
	
	public KDSApp increaseWaitTime(String timeToIncrease,JSONArray menuItemsToSelect){
		try{
		selectStation2up(menuItemsToSelect);
		String stationName1 = (String)menuItemsToSelect.get(0);
		minimumWaitTimeValue(stationName1);
		log("abcdefgh");
		int n = Integer.parseInt(timeToIncrease);
		log(Integer.toString(n));
		int tempNum = Integer.parseInt(temp.replace(" min", ""));
		log(Integer.toString(tempNum));
		if (tempNum>n){
			minimumWaitTimeValue(stationName1);
		}
		log("hijklmnop");
		AppUtilities.delay(2000);
		log("Before adding through plus button: " +temp);
		//String strPlusButton = getUILocator("dashboard_waittime_plus_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		//log("Found the plus button");
		//Assert.assertNotNull(waitForElement(strPlusButton), "Failed to find the plus sign ");
		//MobileElement strEnabled = waitForElement(strPlusButton);
		/*boolean enabledValue = strEnabled.isEnabled();
		log("is plus button enabled " + enabledValue);
		Assert.assertEquals(enabledValue, true);*/
		AppUtilities.delay(2000);
		String waitTime = getUILocator("dashboard_waittime_waittime_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
		log("qrstuvwxyz");
		for(;tempNum<=n;tempNum++){

			String strPlusButton = getUILocator("dashboard_waittime_plus_button").replaceAll("<REPLACE_STATION_NAME>", stationName1);
			Assert.assertNotNull(waitForElement(strPlusButton), "Failed to find the plus sign ");
			Assert.assertTrue(clickElement(strPlusButton), "failed to click the + button to increase the wait time");
			AppUtilities.delay(4000);
			waitForElement(waitTime);
		}
		AppUtilities.delay(2000);
		Assert.assertNotNull(waitForElement(waitTime), "Failed to find the wait time ");
		
		temp = waitForElement(waitTime).getText();
		log (temp);}
		catch(Exception e){
			
			log("Exception occured when increasing KDS Time" +e);
		}
		return this;
	}
	public KDSApp selectStationAndMenuItems(String aStationName, JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("cell_app_settings_select_cafe"), "Failed to select the Cafe Location");
		Assert.assertNotNull(waitForElement("btn_back_to_cafe_stations_in_select_cafe_location"), "Failed to find the Back button in selecting the cafe locations");
		
		String cafeLocator = getUILocator("cell_select_cafe_location").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
		
		//Assert.assertNotNull(waitForElement(cafeLocator), "Failed to find the Cafe Location of:" + aStationName);
		
		MobileElement e= waitForElement(cafeLocator);
		swipeToDirection_iOS_XCTest(e,"u");
		
		
		//AppUtilities.delay(10000);
		AppUtilities.delay(10000);
		Assert.assertTrue(clickElement(cafeLocator), "Failed to select the Cafe Location:" + aStationName);
		
		/*MobileElement e = waitForElement(cafeLocator);
		//make sure it is selected
		Assert.assertNotNull(waitForElement("btn_back_to_cafe_stations_in_select_cafe_location"), "Failed to find the Back button in selecting the cafe locations");
		//cafeLocator = getUILocator("cell_default_cafe_selected").replaceAll("<REPLACE_CAFE_LOCATION>", aStationName);
		/*MobileElement caffe = waitForElement(cafeLocator);
		caffe.click();
		while(waitForElement(cafeLocator) == null){
			int i=0;
			Assert.assertNotNull(downScrollTo(caffe), "Failed to find the Selected Cafe Location of:" + aStationName);
			i++;
			if(i==10){
				//waitForElement(cafeLocator)
				break;
				
			}*/
		/*
		TouchAction action = new TouchAction(driver);
		action.press(320, 585).moveTo(320, 100).release().perform();
		AppUtilities.delay(10000);*/
		/*
		boolean status = false;
		if(driver != null) {
			
			//MobileElement e = waitForElement("xpath=//XCUIElementTypeCell[]") 
			HashMap scrollObject = new HashMap();
			scrollObject.put("direction", "up");
			scrollObject.put("element", ((RemoteWebElement) e).getId());
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("mobile: scroll", scrollObject);
		}*/
		//MobileElement caffe = waitForElement("xpath=//XCUIElementTypeCell[70]/XCUIElementTypeStaticText[1]");
		/*Assert.assertNotNull(upScrollTo(e), "Failed to find the Selected Cafe Location of:" + aStationName);
		Assert.assertNotNull(upScrollTo(e), "Failed to find the Selected Cafe Location of:" + aStationName);
		Assert.assertNotNull(upScrollTo(e), "Failed to find the Selected Cafe Location of:" + aStationName);
		AppUtilities.delay(10000);*/
		//Assert.assertTrue(clickElement(cafeLocator), "Failed to select the Cafe Location:" + aStationName);
		
	
		/*for (int i=1; i< 100; i++){
		log("incrementing the cells");
		"//XCUIElementTypeCell["+i+"]/XCUIElementTypeStaticText[@name=\"TestCaffe\"]"
		
		
		
		MobileElement caffe = (MobileElement) driver.findElement(By.xpath());
		if (caffe != null){
			log(i+"");
			caffe.click();
		}
		*/
		//"cell_default_cafe_selected": "xpath=//XCUIElementTypeCell/XCUIElementTypeStaticText[@name=\"<REPLACE_CAFE_LOCATION>\"]",
		
		
		//}
		
		//Assert.assertNotNull(clickElement(cafeLocator), "Failed to find the Selected Cafe Location of:" + aStationName);
		
		/*//To support selective stations
		String strItemLocator = getUILocator("cell_station_to_select");
		String strItemLocatorEnabled = getUILocator("cell_station_enabled");
		for(int i = 0; i < itemsToChoose.size(); i++) {
			AppUtilities.delay(2000);
			String menuItem = (String)itemsToChoose.get(i);
			String itemLocator = strItemLocator.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertTrue(tapElement(itemLocator), "Failed to select the Menu Item:" + menuItem);
			//wait for it to to enabled
			AppUtilities.delay(2000);
			String itemLocatorEnabled = strItemLocatorEnabled.replaceAll("<REPLACE_ITEM_TO_SELECT>", menuItem);
			Assert.assertNotNull(waitForElement(itemLocatorEnabled), "Failed to select the Item:" + menuItem);
			AppUtilities.delay(2000);
		}*/
		
	
		AppUtilities.delay(2000);
		//Assert.assertNotNull(waitForElement("btn_back_to_cafe_stations_in_select_cafe_location"), "Failed to find the Back button in selecting the cafe locations");
		//AppUtilities.delay(2000);
		if(waitForElement("select_all_stations",8) != null){
		Assert.assertTrue(clickElement("select_all_stations"), "Failed to select the Done button after selecting the menu items in the station");	
		AppUtilities.delay(2000);
		}
		Assert.assertTrue(clickElement("unselect_all_stations"), "Failed to select the Done button after selecting the menu items in the station");	
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("select_all_stations"), "Failed to select the Done button after selecting the menu items in the station");	
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("btn_cafe_settings_done"), "Failed to select the Done button after selecting the menu items in the station");	
		
		//wait for selected stations display in the landing page
		
		String strStationDisplayInLandingPage = getUILocator("static_selected_stations_display");
		strStationDisplayInLandingPage = strStationDisplayInLandingPage.replaceAll("<REPLACE_STATION_NAME>", "All Stations Selected");
		Assert.assertNotNull(waitForElement("btn_settings"), "Failed to find the Settings button in landing page field");
		
		//Assert.assertNotNull(waitForElement(strStationDisplayInLandingPage), "Failed to find the selected station in landing page");
		/*for(int i = 0; i < itemsToChoose.size(); i++) {
			String menuItem = (String)itemsToChoose.get(i);
			String itemLocator = strStationDisplayInLandingPage.replaceAll("<REPLACE_STATION_NAME>", menuItem);
			Assert.assertNotNull(waitForElement(itemLocator), "Failed to find the selected station:" + menuItem + " in landing page");
		}*/
		log("Successfully found all the seleced stations in the landing page");
		return this;
	}
	

	public KDSApp verifyGivenOrdersAreCompleted(JSONArray orderList) {
		
		for(Object i : orderList) {
			JSONObject orderDetails = (JSONObject)i;
			String orderID = (String)orderDetails.get("order_id");
			log("Opening the order by id:" + orderID);
			Assert.assertTrue(getOrderIndexById(orderID) == -1, "Failed as the completed order#:" + orderID + " is found in the order list");
			Assert.assertTrue(getOrderRowIndexFromInOrderHistory(orderID) != -1, "Failed as the completed order#" + orderID + " is not found in the completed order list");
		}
		
		log("The given order list items have been verified in the landing page which are pending for order completion");
		
		return this;
	}

	public KDSApp completeGivenOrders(JSONArray orderList) {
		
		for(Object i : orderList) {
			JSONObject orderDetails = (JSONObject)i;
			String orderID = (String)orderDetails.get("order_id");
			log("Opening the order by id:" + orderID);
			Assert.assertTrue(completeOrderById(orderDetails), "Failed to find the order id:" + orderID + " in the landing page");
			Assert.assertTrue(getOrderIndexById(orderID) == -1, "Failed as the completed order#:" + orderID + " is found in the order list");
			Assert.assertTrue(getOrderRowIndexFromInOrderHistory(orderID) != -1, "Failed as the completed order#" + orderID + " is not found in the completed order list");
		}
		
		log("The given order list items have been verified in the landing page which are pending for order completion");
		
		return this;
	}
	
	public KDSApp completeOrders(JSONArray orderList) {
		
		for(Object i : orderList) {
			JSONObject orderDetails = (JSONObject)i;
			String orderId = null;	
			
			if(waitForElement("tick_buttons")!=null) {
				String tickButton= getUILocator("tick_buttons");	
				Assert.assertTrue(clickElement(tickButton), "Failed to complete the order item");
				log("Successfully completed the order");
			}
			else {
				log("Currently no order details is available in UI");
				orderId="NoOrders";
			}
			
			AppUtilities.delay(2000);
			
		}		
		
		return this;
	}
	
	public KDSApp cancelGivenOrders(JSONArray orderList) {
		
		for(Object i : orderList) {
			JSONObject orderDetails = (JSONObject)i;
			String orderID = (String)orderDetails.get("order_id");
			log("Opening the order by id:" + orderID);
			Assert.assertTrue(openOrderById(orderDetails), "Failed to open the order id:" + orderID + " in the landing page");
			Assert.assertTrue(cancelOrderById(orderDetails), "Failed to cancel the order id:" + orderID + " in the landing page");
			Assert.assertFalse(getOrderIndexById(orderID) == -1, "Failed as the cancelled order#:" + orderID + " is found in the order list");
			Assert.assertTrue(getCancelledOrderRowIndexFromInOrderHistory(orderID) != -1, "Failed as the cancelled order#" + orderID + " is not found in the completed order list");
		}
		
		log("The given order list items have been cancelled in the landing page which are pending for order completion");
		
		return this;
	}
	
	private int getOrderIndexById(String orderId) {
		
		int orderIndex = -1;
		JSONArray existingOrdersList = getOrdersFromUI();
		log("The Existing order details from UI:" + existingOrdersList.toJSONString());
		int index = 0;
		for(Object i : existingOrdersList) {
			JSONObject order = (JSONObject)i;
			log("Existing order details:" + order.toJSONString());
			String order_id = (String)order.get("order_id");
			if(StringUtils.isNoneBlank(order_id)) {
				if(StringUtils.startsWith(order_id, "#")) {
					order_id = order_id.replaceAll("#", "");
				}
			}
			if(order_id.equalsIgnoreCase(orderId)) {
				orderIndex = index;
				break;
			}
			index++;
		}
		return orderIndex;
	}
	
	private JSONArray getCompletedOrdersFromOrderHistoryUI() {
		
		Assert.assertTrue(clickElement("btn_orderhistory"), "Failed to click on order history button");
		
		JSONArray completedOrderListFromUI = new JSONArray();
		List<WebElement> list = waitForElements("completed_orderlist_orderhistory");
		log("Number of orders in the order history:" + list.size());
		int index = 1;
		
		int maxOrders = MAXORDERS_PER_ORDER_HISTORY;
		if(maxOrders > list.size()) {
			maxOrders  = list.size();
		}
		String strLocatorOrderID = getUILocator("completed_orderlist_orderhistory") + "[" + index + "]/XCUIElementTypeStaticText[3]";
		waitForElement(strLocatorOrderID);
		
		for(index = 1; index <= maxOrders; index++) {

			JSONObject orderDetails = new JSONObject();
			strLocatorOrderID = getUILocator("completed_orderlist_orderhistory") + "[" + index + "]/XCUIElementTypeStaticText[3]";

			//MobileElement e = waitForElement(strLocatorOrderID);
			String orderIDFromUI = waitForElementAndGetText(strLocatorOrderID, 10);
			//Assert.assertNotNull(e, "Failed to get the order id from the cell index:" + index);
			//String orderIDFromUI = e.getAttribute("value");
			if(orderIDFromUI != null) {
				orderDetails.put("order_id", orderIDFromUI);
			}else {
				orderDetails.put("order_id", "FAIL");
			}
			completedOrderListFromUI.add(orderDetails);
		}
		log("List of completed orders found in the UI:" + completedOrderListFromUI.toJSONString());

		//close the order history
		Assert.assertTrue(clickElement("btn_orderhistory"), "Failed to click on order history button");
		return completedOrderListFromUI;
	}	
	
	private JSONArray getOrdersFromUI() {
		JSONArray orderListFromUI = new JSONArray();
		List<WebElement> list = waitForElements("order_list");
		log("Number of orders in the list:" + list.size());
		int index = 1;
		
		int maxOrders = MAXORDERS_PER_VIEW;
		if(maxOrders > list.size()) {
			maxOrders  = list.size();
		}
		String strLocatorOrderID = getUILocator("order_list") + "[" + index + "]//XCUIElementTypeStaticText[1]";
		waitForElement(strLocatorOrderID);
		
		for(index = 1; index <= maxOrders; index++) {

			JSONObject orderDetails = new JSONObject();
			strLocatorOrderID = getUILocator("order_list") + "[" + index + "]//XCUIElementTypeStaticText[1]";

			//MobileElement e = waitForElement(strLocatorOrderID);
			String orderIDFromUI = waitForElementAndGetText(strLocatorOrderID, 10);
			//Assert.assertNotNull(e, "Failed to get the order id from the cell index:" + index);
			//String orderIDFromUI = e.getAttribute("value");
			if(orderIDFromUI != null) {
				orderDetails.put("order_id", orderIDFromUI);
			} else {
				orderDetails.put("order_id", "FAIL");
			}
			orderListFromUI.add(orderDetails);
		}
		log("List of orders found in the UI:" + orderListFromUI.toJSONString());
		return orderListFromUI;
	}
	
	public KDSApp verifyLandingPageWithPendingOrders(JSONArray orderList) {
		
		log("Awaiting 10 seconds to list the orders to be loaded...");
		AppUtilities.delay(10000);	
		log("Waiting is over..");
			
		for(Object i : orderList) {
			JSONObject orderDetails = (JSONObject)i;
			String orderID = readDataFromRunStore("OrderId");
			if(orderID != null){
				orderDetails.put("order_id",orderID );
			 }else {
				 orderID = (String)orderDetails.get("order_id");
			 }
			log("Opening the order by id:" + orderID);
			Assert.assertNotNull(openOrderById(orderDetails), "Failed to find the order id:" + orderID + " in the landing page");
			Assert.assertNotNull(closeOrderById(orderDetails), "Failed to close the order id:" + orderID + " in the landing page");	
		}
		AppUtilities.delay(3000);	
		log("The given order list items have been verified in the landing page which are pending for order completion");
		return this;
	}
	public KDSApp OpenLandingPageOrders(JSONArray orderList) {
		
		log("Awaiting 10 seconds to list the orders to be loaded...");
		AppUtilities.delay(10000);	
		log("Waiting is over..");
			
		for(Object i : orderList) {
			JSONObject orderDetails = (JSONObject)i;
			String orderID = (String)orderDetails.get("order_id");
			log("Opening the order by id:" + orderID);
			Assert.assertNotNull(openOrderById(orderDetails), "Failed to find the order id:" + orderID + " in the landing page");
			//Assert.assertNotNull(closeOrderById(orderDetails), "Failed to close the order id:" + orderID + " in the landing page");	
		}
		log("The given order list items have been verified in the landing page which are pending for order completion");
		return this;
	}
	
	private boolean openOrderById(JSONObject orderDetails) {
		boolean status = false;
		int orderIdIndex = -1;
		int index = 0;
		log("The input order details:" + orderDetails.toJSONString());
		JSONArray existingOrdersList = getOrdersFromUI();	
		log("The Existing order details from UI:" + existingOrdersList.toJSONString());
		String orderId = (String)orderDetails.get("order_id");
		log("From JSON "+orderId);
		for(Object i : existingOrdersList) {
			JSONObject order = (JSONObject)i;
			log("Existing order details:" + order.toJSONString());
			String order_id = (String)order.get("order_id");
			log("The order id from UI:" + order_id);
			if(StringUtils.startsWith(order_id, "#")) {
				order_id = order_id.replaceAll("#", "");
				log(order_id);
			}
			if(order_id.equalsIgnoreCase(orderId)) {
				orderIdIndex = index;
				break;
			}
			index++;
		}
		log("The order has been found at index:" + orderIdIndex);
		Assert.assertTrue(orderIdIndex != -1, "Failed to find the order item of order id:" + orderId);
		String orderTile = getUILocator("order_list");
		orderIdIndex = orderIdIndex +1;
		orderTile = orderTile+"["+ orderIdIndex+"]";
		Assert.assertTrue(clickElement(orderTile),"Failed to click order tile"+ orderId);
		/*
		//cmd_to_perform_single_tap_to_complete_order
		String cmdToSingleTapOnElement = getUILocator("cmd_to_perform_single_tap_to_complete_order");
		cmdToSingleTapOnElement = cmdToSingleTapOnElement.replaceAll("<REPLACE_ORDER_INDEX>", Integer.toString(orderIdIndex));
		log("Executing the command to single tap on the order cell:" + cmdToSingleTapOnElement);
		driver.executeScript(cmdToSingleTapOnElement);
		*/
		log("Successfully opened the order by id:" + orderId);
		
		String orderBy = (String)orderDetails.get("order_by");
		String orderFoodItem = (String)orderDetails.get("food_item_name");
		boolean isOrderFromKiosk = (Boolean)orderDetails.get("is_order_from_kiosk");
		boolean isFoodItemCustomized = (Boolean)orderDetails.get("is_custom_item");
		JSONArray customized_food_items_to_change = (JSONArray)orderDetails.get("customize_food_item");
			
		/*String strItem = getUILocator("static_ordered_person_in_order_preview");
		String strOrderByLocator = strItem.replaceAll("<REPLACE_ORDERED_PERSON_NAME>", orderBy);
		AppUtilities.delay(5000);
		log("after delay");
		Assert.assertNotNull(waitForElement(strOrderByLocator), "Failed to find the order by:" + orderBy + " after opening the order id:" + orderId);
		
		strItem = getUILocator("static_orderno_in_order_preview");
		String strOrderIDLocator = strItem.replaceAll("<REPLACE_ORDER_ID>", orderId);
		AppUtilities.delay(2000);
		log("after delay");
		Assert.assertNotNull(waitForElement(strOrderIDLocator), "Failed to find the order id:" + orderId + " after opening the order id:" + orderId);
		
		strItem = getUILocator("static_food_item_name_in_order_preview");
		String strOrderFoodNameLocator = strItem.replaceAll("<REPLACE_ITEM_NAME>", orderFoodItem);
		AppUtilities.delay(2000);
		log("after delay");
		Assert.assertNotNull(waitForElement(strOrderFoodNameLocator), "Failed to find the order food item name:" + orderFoodItem + " after opening the order id:" + orderId);

		if(isOrderFromKiosk) {
			Assert.assertNotNull(waitForElement("image_kiosk_order_in_order_preview"), "Failed to find the order by Kiosk image after opening the order id:" + orderId);
		}
		if(isFoodItemCustomized) {
			String strTextViewCustomItem = getUILocator("textview_customized_item_details_in_order_preview");
			for(Object o : customized_food_items_to_change) {
				JSONObject customItemName = (JSONObject)o;
				JSONArray customItemsList = (JSONArray)customItemName.get("customize_food_items");
				for(Object c : customItemsList) {
					JSONObject name = (JSONObject)c;
					String custom_item = (String)name.get("customize_food_item_name");
					String strTextViewCustomItemLocator = strTextViewCustomItem.replaceAll("<REPLACE_CUSTOMIZED_ITEM>", custom_item);
					AppUtilities.delay(2000);
					Assert.assertNotNull(waitForElement(strTextViewCustomItemLocator), "Failed to find the order custom item: " + custom_item + " after opening the order id:" + orderId);
				}
			}
		}*/
		
		Assert.assertNotNull(waitForElement("btn_notify_in_order_preview"), "Failed to find the Notify User button after opening the order id:" + orderId);
		Assert.assertNotNull(waitForElement("btn_cancel_in_order_preview"), "Failed to find the Cancel Order button after opening the order id:" + orderId);
		Assert.assertNotNull(waitForElement("btn_print_in_order_preview"), "Failed to find the Print Order button after opening the order id:" + orderId);
		
		log("The Order preview items for the order id:" + orderId + " has been checked. ");
		
		status = true;
		return status;
	}
	
	public KDSApp NotifyCustomer(){
		//Assert.assertNotNull(waitForElement("btn_notify_in_order_preview"), "Failed to find the Notify User button after opening the order id:");
		Assert.assertTrue(tapElement("btn_notify_in_order_preview"), "Failed to click order by to close the preview of the order by id:");
		log("Notified sucessfully");
		AppUtilities.delay(5000);
		driver.switchTo().alert().accept();
		AppUtilities.delay(5000);
		log("Sucessfully Accepted alert");
		return this;
	}
	
	public KDSApp ValidatePrinterButton(){
		//Assert.assertNotNull(waitForElement("btn_print_in_order_preview"), "Failed to find the Notify User button after opening the order id:");
		log("Printer Button found");
		Assert.assertTrue(tapElement("btn_print_in_order_preview"), "Failed to Validate Printer button");
		AppUtilities.delay(5000);
		driver.switchTo().alert().accept();
		AppUtilities.delay(5000);
		//log("Sucessfully Accepted alert");
		return this;
	}
	
	public KDSApp CancelOrder(){
		//Assert.assertNotNull(waitForElement("btn_print_in_order_preview"), "Failed to find the Notify User button after opening the order id:");
		log("Cancel Button found");
		Assert.assertTrue(tapElement("btn_cancel_in_order_preview"), "Failed to Validate Printer button");
		AppUtilities.delay(5000);
		driver.switchTo().alert().accept();
		AppUtilities.delay(5000);
		//log("Sucessfully Accepted alert");
		return this;
	}
	
	private boolean closeOrderById(JSONObject orderDetails) {
		boolean status = false;
		int orderIdIndex = -1;
		int index = 0;
		String orderId = (String)orderDetails.get("order_id");
		
		
		String orderBy = (String)orderDetails.get("order_by");
		String orderName = (String)orderDetails.get("food_item_name");
			
		String strItem = getUILocator("btn_notify_in_order_preview");
		String strOrderByLocator = strItem.concat("/..");
		
		Assert.assertTrue(clickElement(strOrderByLocator), "Failed to click order by to close the preview of the order by id:" + orderId);
		log("Successfully closed the order by id:" + orderId);
		status = true;
		return status;
	}
	
	private boolean completeOrderById(JSONObject orderDetails) {
		boolean status = false;
		int orderIdIndex = -1;
		log("The input order details:" + orderDetails.toJSONString());
		String orderId = (String)orderDetails.get("order_id");
		
		orderIdIndex = getOrderIndexById(orderId);
		log("The order has been found at index:" + orderIdIndex);
		Assert.assertTrue(orderIdIndex != -1, "Failed to find the order item of order id:" + orderId);
		
		String tickButton= getUILocator("tick_button");
		tickButton= tickButton.replaceAll("<REPLACE_INDEX>", orderIdIndex+1 +"");
		Assert.assertTrue(clickElement(tickButton), "Failed to complete the order item of order id:"+orderId);

		log("Successfully completed the order with id:" + orderId);
		
		AppUtilities.delay(2000);
		status = true;
		return status;
	}	
	
	private boolean completeOrder(JSONObject orderDetails) {
		boolean status = false;
		int orderIdIndex = -1;
		log("The input order details:" + orderDetails.toJSONString());
		String orderId = (String)orderDetails.get("order_id");
		
		orderIdIndex = getOrderIndexById(orderId);
		log("The order has been found at index:" + orderIdIndex);
		Assert.assertTrue(orderIdIndex != -1, "Failed to find the order item of order id:" + orderId);
		
		//String strItem = getUILocator("btn_orderID_completed_order");
		//String OrderNowButton = strItem.replaceAll("<REPLACE_ORDER_INDEX>", Integer.toString(orderIdIndex));
		String OrderNowButton = getUILocator("order_list") + "[" + orderIdIndex + "].buttons()[0]";
		//click the same element again to close it
		AppUtilities.delay(5000);
		Assert.assertNotNull(waitForElement(OrderNowButton), "Failed to find the alert message");
		Assert.assertTrue(clickElement(OrderNowButton), "Failed to order by id:" + orderId);
		
		log("Successfully ordered by id:" + orderId);
		
		AppUtilities.delay(5000);
		status = true;
		return status;
	}
	
	private boolean cancelOrderById(JSONObject orderDetails) {
		boolean status = false;
		String orderId = (String)orderDetails.get("order_id");
		log("Cancelling the order:" + orderId);
		Assert.assertTrue(clickElement("btn_cancel_in_order_preview"), "Failed to click the cancel button of the opened order id:" + orderId);
		Assert.assertTrue(clickElement("btn_ok_ordercancel_alert_ok"), "Failed to click on the OK button of the Alert after clicking the Cancel button of order:" + orderId);
		try{
			driver.switchTo().alert().accept();
		} catch(Exception e){
			
		}
		AppUtilities.delay(5000);
		status = true;
		return status;
	}	
	
	private int getOrderRowIndexFromInOrderHistory(String orderId) {
		JSONArray completedOrders = getCompletedOrdersFromOrderHistoryUI();
		int orderIdIndex  = -1;
		int index = 0;
		for(Object i : completedOrders) {
			JSONObject item = (JSONObject)i;
			String order_id = (String)item.get("order_id");
			if(StringUtils.isNotBlank(order_id)) {
				if(StringUtils.startsWith(order_id, "#")) {
					order_id = order_id.replaceAll("#", "");
				}
			}
			if(order_id.equalsIgnoreCase(orderId)) {
				orderIdIndex = index;
				break;
			}
		}
		
		return orderIdIndex;
	}
	
	private int getCancelledOrderRowIndexFromInOrderHistory(String orderId) {
		JSONArray completedOrders = getCompletedOrdersFromOrderHistoryUI();
		int orderIdIndex  = -1;
		int index = 0;
		for(Object i : completedOrders) {
			JSONObject item = (JSONObject)i;
			String order_id = (String)item.get("order_id");
			if(StringUtils.isNotBlank(order_id)) {
				if(StringUtils.startsWith(order_id, "#")) {
					order_id = order_id.replaceAll("#", "");
				}
			}
			if(order_id.equalsIgnoreCase(orderId)) {
				orderIdIndex = index;
				break;
			}
		}
		
		return orderIdIndex;
	}
	
	public KDSApp cancelGivenOrdersFromOrderHistory(JSONArray orderList) {
		
		//Since this has been already done..
		//Assert.assertNotNull(completeGivenOrders(orderList), "Failed while completing the given orders");
		
		for(Object o : orderList) {
			JSONObject orderItem = (JSONObject)o;
			String orderID = (String)orderItem.get("order_id");
			Assert.assertNotNull(cancelGivenOrderFromOrderHistory(orderItem), "Failed to cancel the order id:" + orderID + " from the order history");
			Assert.assertNotNull(isGivenOrderFromOrderHistoryCancelled(orderItem), "Failed to order id:" + orderID + " is found as NOT cancelled from the order history");
		}
		
		return this;
	}
	
	public KDSApp cancelGivenOrderFromOrderHistory(JSONObject orderItem) {
		
		String orderID = (String)orderItem.get("order_id");
		int orderIndexInHistoryTable = getOrderRowIndexFromInOrderHistory(orderID);
		Assert.assertTrue(orderIndexInHistoryTable != -1, "Failed to find the order id:" + orderID + " in the order history table");
		Assert.assertTrue(clickElement("btn_orderhistory"), "Failed to click on order history button");
		String strOrderLocatorInHistory = getUILocator("completed_orderlist_orderhistory") + "[" + orderIndexInHistoryTable + "]";
		
		Assert.assertTrue(clickElement(strOrderLocatorInHistory), "Failed to click the order item from the order history list");
		Assert.assertTrue(clickElement("btn_cancel_in_orderhistory"), "Failed to click the cancel button of the order item from the order history list");
		
		Assert.assertTrue(clickElement("btn_ok_ordercancel_alert_ok"), "Failed to click the ok button on the cancel item alert dialog");
		Assert.assertTrue(clickElement("btn_back_in_orderhistory"), "Failed to click the back button from the order history details view");

		//close the order history
		Assert.assertTrue(clickElement("btn_orderhistory"), "Failed to click on order history button");
		
		return this;
	}
	
	public KDSApp givenOrderCompletedInOrderHistory(JSONArray orderList) {
	
		for(Object i : orderList) {
			JSONObject orderDetails = (JSONObject)i;
			String orderID = (String)orderDetails.get("order_id");
			log("Opening the order by id:" + orderID);
			int orderIndexInHistoryTable = getOrderRowIndexFromInOrderHistory(orderID);
			Assert.assertTrue(orderIndexInHistoryTable != -1, "Failed to find the order id:" + orderID + " in the order history table");
			Assert.assertTrue(clickElement("btn_orderhistory_old"), "Failed to click on order history button");
			String strOrderLocatorInHistory = getUILocator("completed_orderlist_orderhistory") + "[" + orderIndexInHistoryTable + "]";
			Assert.assertTrue(clickElement(strOrderLocatorInHistory), "Failed to click the order item from the order history list");
		}
		log("Given Order is found in the order history page");
		return this;
	}
		
	
	public KDSApp cancelOrder() {
		
		Assert.assertTrue(clickElement("btn_cancel_in_orderhistory"), "Failed to click the cancel button of the order item from the order history list");
		Assert.assertTrue(clickElement("btn_ok_ordercancel_alert_ok"), "Failed to click the ok button on the cancel item alert dialog");
		Assert.assertTrue(clickElement("btn_back_in_orderhistory"), "Failed to click the back button from the order history details view");
		//close the order history
		Assert.assertTrue(clickElement("btn_orderhistory"), "Failed to click on order history button");
		return this;
	}

	public KDSApp isGivenOrderFromOrderHistoryCancelled(JSONObject orderItem) {
		
		String orderID = (String)orderItem.get("order_id");
		int orderIndexInHistoryTable = getOrderRowIndexFromInOrderHistory(orderID);
		Assert.assertTrue(orderIndexInHistoryTable != -1, "Failed to find the order id:" + orderID + " in the order history table");
		Assert.assertTrue(clickElement("btn_orderhistory"), "Failed to click on order history button");
		String strOrderLocatorInHistory = getUILocator("completed_orderlist_orderhistory") + "[" + orderIndexInHistoryTable + "]";
		
		Assert.assertTrue(clickElement(strOrderLocatorInHistory), "Failed to click the order item from the order history list");
		
		MobileElement e = waitForElement("btn_cancel_in_orderhistory");
		Assert.assertFalse(e.isEnabled(), "Failed as the order id:" + orderID + " in the order history is not Cancelled");
		
		Assert.assertTrue(clickElement("btn_back_in_orderhistory"), "Failed to click the back button from the order history details view");

		//close the order history
		Assert.assertTrue(clickElement("btn_orderhistory"), "Failed to click on order history button");
		
		return this;
	}
	
	public KDSApp makeIngredientsAsSoldOut(JSONArray itemsToBeSoldOut) {
		
		//click the sold out menu
		Assert.assertTrue(clickElement("btn_soldout_item"), "Failed to click the SoldOut menu item in Navigation bar");
		
		
		
		
		
		for(Object i : itemsToBeSoldOut) {
			String nearBy = "";
			String ingredient = (String)i;
			String[] tokens = ingredient.split(":");
			if(tokens.length == 2) {
				nearBy = tokens[0];
				ingredient = tokens[1];
			}
			
			/*
			List<WebElement> list = waitForElements("cells_for_ingredients_list_soldout_menu");
			Assert.assertNotNull(list, "Failed as no ingredients menu item found as the list found as null");
			Assert.assertTrue(list.size() > 0, "Failed as no ingredients menu item found");
			
			int index = -1;
			int foundIndex = -1;
			for(WebElement e : list) {
				index++;
				String currentMenuItem =  e.getText();
				if(StringUtils.isNotBlank(currentMenuItem)) {
					if(StringUtils.contains(currentMenuItem, ingredient)) {
						log("Found the ingredient at index:" + index);
						foundIndex = index;
						break;
					}
				}
	 		}
			Assert.assertTrue(foundIndex != -1, "Failed to find the ingredient in the list");
			
			String cmdToExecuteToBringFocus = getUILocator("cmd_to_perform_to_move_ingredients_cell").replaceAll("<INGREDIENT_INDEX>", Integer.toString(foundIndex));
			*/
			
			/*
			if(StringUtils.isNotEmpty(nearBy)) {
				log("Menu nearby is given. Scrolling to:" + nearBy);
				scrollTo(nearBy, true);
				AppUtilities.delay(1000);
				log("Scrolled to near by menu...");
			}
			*/
			/*
			String cmdToExecuteToBringFocus = getUILocator("cmd_to_perform_to_move_ingredients_cell").replaceAll("<REPLACE_INGREDIENT_ITEM>", ingredient);
			log("Cmd to execute:" + cmdToExecuteToBringFocus);
			driver.executeScript(cmdToExecuteToBringFocus);
			AppUtilities.delay(1000);
			log("Successfully executed the cmd");
			*/
			String itemLocator = getUILocator("cell_item_tobe_deselected_for_soldout").replaceAll("<REPLACE_INGREDIENT_ITEM>", ingredient);			
			MobileElement e = waitForElement(itemLocator);
			if(e == null) {
				log("Looks like the ingredient to be set as sold-out is notpresent or already set as Avaialble");
			} else {
				
				
				int incrementScrollByCell = 2;
				int startCellIndex = incrementScrollByCell + 1;
				
				while(! e.isDisplayed()) {
					
					//driver.context("NATIVE_APP"); 
					
					downScrollTo();
					
					/*
					int endCellIndex = startCellIndex - incrementScrollByCell;
					log("Looks like the element is hidden. scrolling the cell by swipe action..(from:" + startCellIndex + " to:" + endCellIndex + ")");
					//clickHiddenElement(e);
					String startCellLocator = getUILocator("cells_for_ingredients_list_soldout_menu") + "[" + startCellIndex + "]";
					String endCellLocator = getUILocator("cells_for_ingredients_list_soldout_menu") + "[" + endCellIndex + "]";
					
					MobileElement startElement = waitForElement(startCellLocator);
					MobileElement endElement = waitForElement(endCellLocator);
					
					
					if(startElement != null && endElement != null) {
						log("Swiping the cell element:" + startElement.getText());
						
						Point startPoint = startElement.getCenter();
						Point endPoint = endElement.getCenter();
						
						//driver.swipe(startPoint.x, startPoint.y, endPoint.x, endPoint.y, 1000);
						swipeViaJS(startPoint.x, startPoint.y, endPoint.x, endPoint.y, 1000);
						log("Swiped from " + startPoint.x + "," + startPoint.y + " to " + endPoint.x + ", " + endPoint.y);
					
					} else {
						log("Since the UI elements at the indexes might not be there.. moving to next");
					}
					*/
					/*
					log("Before swiping...");
					startElement.swipe(SwipeElementDirection.UP, 1000);
					log("swiped up...");
					*/
					//downScrollTo(e);
					//JavascriptExecutor js = (JavascriptExecutor)driver;
					//js.executeScript("argume, arg1)
					AppUtilities.delay(100);
					e = waitForElement(itemLocator);
					startCellIndex ++;
				}
				
				e.tap(1, 1);
				log("The ingredient:" + ingredient + " is set as avaialble");
			}
			AppUtilities.delay(2000);
		}
		log("All the items given in the list has been set as Sold out");
		Assert.assertTrue(clickElement("btn_soldout_item"), "Failed to click the SoldOut menu item in Navigation bar to close it");
		return this;
	}
	
	public KDSApp makeIngredientsAsAvailable(JSONArray itemsToBeSoldOut) {
		
		//click the sold out menu
		Assert.assertTrue(clickElement("btn_soldout_item"), "Failed to click the SoldOut menu item in Navigation bar");
		
		for(Object i : itemsToBeSoldOut) {
			String nearBy = "";
			String ingredient = (String)i;
			String[] tokens = ingredient.split(":");
			if(tokens.length == 2) {
				nearBy = tokens[0];
				ingredient = tokens[1];
			}
			
			if(StringUtils.isNotEmpty(nearBy)) {
				log("Menu nearby is given. Scrolling to:" + nearBy);
				//scrollTo(nearBy, true);
				AppUtilities.delay(1000);
				log("Scrolled to near by menu...");
			}
			
			String itemLocator = getUILocator("cell_item_tobe_selected_foravailable").replaceAll("<REPLACE_INGREDIENT_ITEM>", ingredient);			
			MobileElement e = waitForElement(itemLocator);
			if(e == null) {
				log("Looks like the ingredient to be set as sold-out is notpresent or already set as Avaialble");
			} else {
				e.tap(1, 1);
				log("The ingredient:" + ingredient + " is set as avaialble");
			}
			AppUtilities.delay(2000);
		}
		log("All the items given in the list has been set as Available");
		Assert.assertTrue(clickElement("btn_soldout_item"), "Failed to click the SoldOut menu item in Navigation bar to close it");
		return this;
	}
	
	public KDSApp openTile(JSONArray orderLists) {
		for(Object i : orderLists) {
			JSONObject orderDetails = (JSONObject)i;
			boolean status = false;
			int orderIdIndex = -1;
			int index = 0;
			log("The input order details:" + orderDetails.toJSONString());
			JSONArray existingOrdersList = getOrdersFromUI();	
			log("The Existing order details from UI:" + existingOrdersList.toJSONString());
			String orderId = (String)orderDetails.get("order_id");
			for(Object o : existingOrdersList) {
				JSONObject order = (JSONObject)o;
				log("Existing order details:" + order.toJSONString());
				String order_id = (String)order.get("order_id");
				log("The order id from UI:" + order_id);
				if(StringUtils.startsWith(order_id, "#")) {
					order_id = order_id.replaceAll("#", "");
				}
				if(order_id.equalsIgnoreCase(orderId)) {
					orderIdIndex = index;
					break;
				}
				index++;
			}
			log("The order has been found at index:" + orderIdIndex);
			Assert.assertTrue(orderIdIndex != -1, "Failed to find the order item of order id:" + orderId);
		
		
		//cmd_to_perform_single_tap_to_complete_order
			String cmdToSingleTapOnElement = getUILocator("cmd_to_perform_single_tap_to_complete_order");
			cmdToSingleTapOnElement = cmdToSingleTapOnElement.replaceAll("<REPLACE_ORDER_INDEX>", Integer.toString(orderIdIndex));
			log("Executing the command to single tap on the order cell:" + cmdToSingleTapOnElement);
			AppUtilities.delay(10000);
			driver.executeScript(cmdToSingleTapOnElement);
		
			log("Successfully opened the order by id:" + orderId);
		}
		return this;
	}


	public KDSApp printerButton() {
		String alertMessagePrinter = "Reprint order ticket?";
		Assert.assertTrue(clickElement("btn_print_in_order_preview"), "Failed to click printer button");
		String alertPrint = getUILocator("alert_kds_message").replaceAll("<REPLACE_ALERT_MESSAGE>",alertMessagePrinter);
		Assert.assertNotNull(waitForElement(alertPrint), "Failed to find the alert message");
		Assert.assertTrue(clickElement("btn_ok_orderprint_alert_ok"), "Failed to click ok button on the alert message for print");
		return this;
	}
	
	public KDSApp cancelButton() {
		String alertMessageCancel ="Void transaction and issue refund to guest?";
		Assert.assertTrue(clickElement("btn_cancel_in_order_preview"), "Failed to click Cancel button");
		String alertPrint = getUILocator("alert_kds_message").replaceAll("<REPLACE_ALERT_MESSAGE>",alertMessageCancel);
		Assert.assertNotNull(waitForElement(alertPrint), "Failed to find the alert message");
		Assert.assertTrue(clickElement("btn_ok_ordercancel_alert_ok"), "failed to click ok on the alert message for cancel");
		return this;
	}
	
	public KDSApp guestAppNotifyButton() {
		String notifyButtonLocator = getUILocator("btn_notify_in_order_preview");
		MobileElement notifyButton = waitForElement(notifyButtonLocator);
		Assert.assertTrue(notifyButton.isEnabled(), "Notify Button is not present for Guestapp orders");
		log("Notify button is enabled for Guestapp orders");
		String alertMessageNotify ="Notify guest to come to station?";
		Assert.assertTrue(clickElement("btn_notify_in_order_preview"), "Failed to click Notify button");
		String alertPrint = getUILocator("alert_kds_message").replaceAll("<REPLACE_ALERT_MESSAGE>",alertMessageNotify);
		Assert.assertNotNull(waitForElement(alertPrint), "Failed to find the alert message");
		Assert.assertTrue(clickElement("btn_ok_orderprint_alert_ok"), "Failed to click ok button on the alert message for notify guest");
		return this;
	}
	
	public KDSApp validateCheckButton(JSONArray orderLists) {
		for(Object i : orderLists) {
			JSONObject orderDetails = (JSONObject)i;
			boolean status = false;
			int orderIdIndex = -1;
			String order_id = null;
			int index = 0;
			log("The input order details:" + orderDetails.toJSONString());
			JSONArray existingOrdersList = getOrdersFromUI();	
			log("The Existing order details from UI:" + existingOrdersList.toJSONString());
			String orderId = (String)orderDetails.get("order_id");
			for(Object o : existingOrdersList) {
				JSONObject order = (JSONObject)o;
				log("Existing order details:" + order.toJSONString());
				order_id = (String)order.get("order_id");
				log("The order id from UI:" + order_id);
				if(StringUtils.startsWith(order_id, "#")) {
					order_id = order_id.replaceAll("#", "");
				}
				if(order_id.equalsIgnoreCase(orderId)) {
					orderIdIndex = index;
					break;
				}
				index++;
			}
			log("The order has been found at index:" + orderIdIndex);
			Assert.assertTrue(orderIdIndex != -1, "Failed to find the order item of order id:" + orderId);
			
			log("Order id is: "+order_id);
			order_id = "#" + order_id;
			log("Order id after: "+order_id);
			AppUtilities.delay(10000);
			String orderCheckbox = getUILocator("checkbox_complete_orders").replaceAll("<REPLACE_ORDER_INDEX>", order_id);
			Assert.assertTrue(clickElement(orderCheckbox), "Failed to click the complete order button");
		
			}
		log("Successfully clicked on complete order button");
		return this;
	}
	
	public KDSApp validateOrderNoButton(JSONArray itemsToChoose) {
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2 up button");
		for(int i = 0; i < itemsToChoose.size(); i++) {
			String stationName = (String)itemsToChoose.get(i);
			//String strStationName = getUILocator("btn_2up").replaceAll("<REPLACE_STATION_NAME>", stationName);
			//log("the UI locator of the station to work on is " + strStationName);
			//Assert.assertTrue(clickElement(strStationName), "Failed to click the toogle button");
			AppUtilities.delay(4000);
			
			String stationOrderCountLocator = getUILocator("validate_order_no").replaceAll("<REPLACE_STATION_NAME>", stationName);
			log("the UI locator of the station to work on is " + stationOrderCountLocator);
			Assert.assertNotNull(waitForElement(stationOrderCountLocator), "Failed to find the order count in the 2up screen ");
			
			//Assert.assertNotNull(waitForElement("stationOrderCountLocator"), "Failed to find the order count in the 2up screen ");
			//int OrderFromStation = Integer.parseInt(waitForElement(stationOrderCountLocator).getAttribute("name"));
		    //log("the order from statin is "+ OrderFromStation+ stationName);
		}
		return this;
	}

	
	public KDSApp validateOrderNoButton2() {
		String stationName = "Pizza";
		Assert.assertTrue(clickElement("btn_2up"), "Failed to click the 2 up button");
		AppUtilities.delay(4000);
		String stationOrderCountLocator = getUILocator("validate_order_no").replaceAll("<REPLACE_STATION_NAME>", stationName);
		log("the UI locator of the station to work on is " + stationOrderCountLocator);
		Assert.assertNotNull(waitForElement(stationOrderCountLocator), "Failed to find the order count in the 2up screen ");
		return this;
	}
	
	public KDSApp completePendingOrders(JSONArray orderList) {
		
		for(Object i : orderList) {
			JSONObject orderDetails = (JSONObject)i;
			String orderID = (String)orderDetails.get("order_id");
			log("Opening the order by id:" + orderID);
			Assert.assertTrue(completeOrder(orderDetails), "Failed to find the order id:" + orderID + " in the landing page");
			//Assert.assertTrue(getOrderIndexById(orderID) == -1, "Failed as the completed order#:" + orderID + " is found in the order list");
			//Assert.assertTrue(getOrderRowIndexFromInOrderHistory(orderID) != -1, "Failed as the completed order#" + orderID + " is not found in the completed order list");
		}
		
		log("The given order list items have been verified in the landing page which are pending for order completion");
		
		return this;
	}
	
	public KDSApp selectRefundAndSearch(JSONObject orderDetail) {
		
		String aStationName = (String)orderDetail.get("caffe_location");
		String orderMethodType = (String)orderDetail.get("order_method");
		String orderStationName = (String)orderDetail.get("order_station");
		String name = (String)orderDetail.get("order_person");
		String orderNumber = (String)orderDetail.get("order_number");
		String orderPaymentMethod = (String)orderDetail.get("order_payment_method");

		
		Assert.assertTrue(clickElement("cell_app_settings_refund_button"), "Failed to select the Refund button");
		Assert.assertNotNull(waitForElement("label_refund_refund_page"), "Failed to find the refund label");
		Assert.assertNotNull(waitForElement("done_button_refund_page"), "Failed to find the refund label");
		
		Assert.assertNotNull(waitForElement("label_required_fields_refund_page"), "Failed to find the refund label");
		Assert.assertNotNull(waitForElement("label_order_date_refund_page"), "Failed to find the refund label");
		
		Assert.assertNotNull(waitForElement("button_search_refund_page"), "Failed to find the default search button");
		String currentDate = null;
		int todayDate = Calendar.DAY_OF_MONTH;
		if (todayDate<10) {
			currentDate = new SimpleDateFormat("MMM d, yyyy").format(new java.util.Date());
		}
		else {
			currentDate = new SimpleDateFormat("MMM dd, yyyy").format(new java.util.Date());
		}
		
		log(currentDate);
		String defaultDateLocator = getUILocator("select_order_date_refund_page");
		defaultDateLocator =defaultDateLocator.replaceAll("<REPLACE_CURRENT_DATE>", currentDate);
		Assert.assertNotNull(waitForElement(defaultDateLocator), "Failed to find the default date");
		
		//MobileElement defaultOrderDateField = waitForElement("select_order_date_refund_page");
		//Assert.assertTrue(clickElement(defaultDateLocator), "Failed to select the Refund button");
		
		//Required Fields
		Assert.assertTrue(clickElement("label_caffe_refund_page"), "Failed to select the caffe button in refund page");
		AppUtilities.delay(2000);
		String caffeName = getUILocator("select_caffe_name");
		caffeName= caffeName.replaceAll("<REPLACE_CAFFE_NAME>", aStationName);
		Assert.assertTrue(clickElement(caffeName), "Failed to select the caffe in caffe selection page");
		
		Assert.assertTrue(clickElement("select_order_method_refund_page"), "Failed to select the caffe button in refund page");
		AppUtilities.delay(2000);
		String orderMethod = getUILocator("select_order_method");
		orderMethod= orderMethod.replaceAll("<ORDER_METHOD>", orderMethodType);
		Assert.assertTrue(clickElement(orderMethod), "Failed to select the order method in order method selection page");
		
		Assert.assertNotNull(waitForElement("button_search_enabled_refund_page"), "Failed to find the default search button");
		
		//Optional Fields
		Assert.assertNotNull(waitForElement("label_optional_fields_refund_page"), "Failed to find the optional fields label");
		
		Assert.assertTrue(clickElement("select_station_refund_page"), "Failed to select the caffe button in refund page");
		AppUtilities.delay(2000);
		String stationName = getUILocator("select_station_name");
		stationName= stationName.replaceAll("<STATION_NAME>", orderStationName);
		Assert.assertTrue(clickElement(stationName), "Failed to select the order method in order method selection page");
		
		Assert.assertTrue(typeText("name_field_refund_page",name), "Failed to select the order method in order method selection page");
		Assert.assertTrue(typeText("order_number_field_refund_page",orderNumber), "Failed to select the order method in order method selection page");
		
		
		Assert.assertTrue(clickElement("button_payment_method_refund_page"), "Failed to select the caffe button in refund page");
		AppUtilities.delay(2000);
		String paymentMethod = getUILocator("select_payment_method");
		paymentMethod= paymentMethod.replaceAll("<PAYMENT_METHOD>", orderPaymentMethod);
		Assert.assertTrue(clickElement(paymentMethod), "Failed to select the order method in order method selection page");
		AppUtilities.delay(2000);
		Assert.assertTrue(clickElement("button_search_enabled_refund_page"), "Failed to select the order method in order method selection page");
		AppUtilities.delay(4000);
		Assert.assertNotNull(waitForElement("back_button_search_page"), "Failed to find the default search button");
		Assert.assertNotNull(waitForElement("searchbar_button_search_page"), "Failed to find the default search button");
		//Assert.assertNotNull(waitForElement("cancel_button_search_page"), "Failed to find the default search button");
		
		MobileElement title = waitForElement("title_search_page");
		String numberOfOrders = title.getAttribute("name");
		log(numberOfOrders);
		String orders[] = numberOfOrders.split(" ");
		int orderCount = Integer.parseInt(orders[0]);
		if (orderCount>0)
		{
			String orderPerson = getUILocator("order_person_search_page");
			orderPerson = orderPerson.replaceAll("<REPLACE_ORDER_NUMBER>", orderNumber);
			orderPerson= orderPerson.replaceAll("<REPLACE_ORDER_PERSON>", name);
			Assert.assertTrue(clickElement(orderPerson), "Failed to select the order method in order method selection page");
			AppUtilities.delay(4000);
			
			//Assert.assertNotNull(waitForElement("back_button_search_page"), "Failed to find the default search button");
			Assert.assertNotNull(waitForElement("refund_button_order_details_page"), "Failed to find the default search button");
			
			Assert.assertNotNull(waitForElement("label_transaction_order_details_page"), "Failed to find the default search button");
			MobileElement orderNumberSearchPage = waitForElement("transaction_id_order_details_page");
			log(orderNumberSearchPage.getAttribute("value"));
			
			Assert.assertNotNull(waitForElement("label_dateandtime_order_details_page"), "Failed to find the default search button");
			MobileElement orderDateSearchPage = waitForElement("dateandtime_order_details_page");
			log(orderDateSearchPage.getAttribute("value"));
			
			Assert.assertNotNull(waitForElement("label_total_order_details_page"), "Failed to find the default search button");
			MobileElement orderTotalSearchPage = waitForElement("total_order_details_page");
			log(orderTotalSearchPage.getAttribute("value"));
			
			Assert.assertNotNull(waitForElement("label_name_order_details_page"), "Failed to find the default search button");
			MobileElement orderNameSearchPage = waitForElement("name_order_details_page");
			log(orderNameSearchPage.getAttribute("value"));
			
			Assert.assertNotNull(waitForElement("label_order_method_order_details_page"), "Failed to find the default search button");
			MobileElement orderMethodSearchPage = waitForElement("order_method_order_details_page");
			log(orderMethodSearchPage.getAttribute("value"));
			
			Assert.assertNotNull(waitForElement("label_payment_method_order_details_page"), "Failed to find the default search button");
			MobileElement orderPaymentMethodSearchPage = waitForElement("payment_method_order_details_page");
			log(orderPaymentMethodSearchPage.getAttribute("value"));
			
			Assert.assertNotNull(waitForElement("label_refundable_amount_order_details_page"), "Failed to find the default search button");
			MobileElement orderRefundableAmountSearchPage = waitForElement("refundable_amount_order_details_page");
			log(orderRefundableAmountSearchPage.getAttribute("value"));		
			
			String labelOrderIdLocator = getUILocator("label_order_id_order_details_page");
			labelOrderIdLocator = labelOrderIdLocator.replaceAll("<REPLACE_ORDER_ID>", orderNumber);
			Assert.assertNotNull(waitForElement(labelOrderIdLocator), "Failed to find the default search button");
			
			String OrderIdLocator = getUILocator("order_id_order_details_page");
			OrderIdLocator = OrderIdLocator.replaceAll("<REPLACE_ORDER_ID>", orderNumber);
			MobileElement orderIdSearchPage = waitForElement(OrderIdLocator);
			log(orderIdSearchPage.getAttribute("value"));		
			
			orderIdSearchPage.click();
			
			AppUtilities.delay(3000);
			
			Assert.assertNotNull(waitForElement("label_order_number_item_details_page"), "Failed to find the default search button");
			MobileElement orderNumberItemPage = waitForElement("order_number_item_details_page");
			log(orderNumberItemPage.getAttribute("value"));		
			
			Assert.assertNotNull(waitForElement("label_station_item_details_page"), "Failed to find the default search button");
			MobileElement stationItemPage = waitForElement("station_item_details_page");
			log(stationItemPage.getAttribute("value"));		
			
			Assert.assertNotNull(waitForElement("label_item_name_item_details_page"), "Failed to find the default search button");
			MobileElement ItemNameItemPage = waitForElement("item_name_item_details_page");
			log(ItemNameItemPage.getAttribute("value"));	
			
			Assert.assertNotNull(waitForElement("label_total_item_details_page"), "Failed to find the default search button");
			MobileElement orderTotalItemPage = waitForElement("total_item_details_page");
			log(orderTotalItemPage.getAttribute("value"));	
			
			Assert.assertNotNull(waitForElement("label_status_item_details_page"), "Failed to find the default search button");
			MobileElement orderStatusItemPage = waitForElement("status_item_details_page");
			log(orderStatusItemPage.getAttribute("value"));		
			
			Assert.assertNotNull(waitForElement("label_refundable_amount_item_details_page"), "Failed to find the default search button");
			MobileElement orderRefundableAmountItemPage = waitForElement("refundable_amount_item_details_page");
			log(orderRefundableAmountItemPage.getAttribute("value"));		
			
			Assert.assertTrue(clickElement("refund_button_order_details_page"), "Failed to select the caffe button in refund page");
		}
		
		return this;
	}
}


